#include "hal/simulated_joint_driver.hpp"

#include <algorithm>
#include <cmath>

namespace arm::hal {

namespace {
const config::JointSpec& lookupSpec(config::JointId id) {
    return config::kJointSpecs[static_cast<std::size_t>(id)];
}
}  // namespace

SimulatedJointDriver::SimulatedJointDriver(config::JointId id, SimulatedCanBus& bus)
    : joint_id_(id), spec_(lookupSpec(id)), bus_(bus) {
    telemetry_.winding_temp_c = 25.0;  // ambient start
}

void SimulatedJointDriver::setPositionSetpoint(double radians) {
    position_setpoint_rad_ = radians;
    position_control_active_ = true;
    bus_.send(CanMessage{static_cast<int>(joint_id_), CanMessageType::kPositionSetpoint, radians, {}});
}

void SimulatedJointDriver::setVelocitySetpoint(double radians_per_sec) {
    velocity_setpoint_rad_s_ = radians_per_sec;
    position_control_active_ = false;
    bus_.send(CanMessage{static_cast<int>(joint_id_), CanMessageType::kVelocitySetpoint, radians_per_sec, {}});
}

void SimulatedJointDriver::setTorqueSetpoint(double newton_meters) {
    torque_setpoint_nm_ = newton_meters;
    bus_.send(CanMessage{static_cast<int>(joint_id_), CanMessageType::kTorqueSetpoint, newton_meters, {}});
}

bool SimulatedJointDriver::triggerSafeTorqueOff() {
    telemetry_.sto_active = true;
    telemetry_.torque_estimate_nm = 0.0;
    bus_.send(CanMessage{static_cast<int>(joint_id_), CanMessageType::kSafeTorqueOffCommand, 1.0, {}});
    return true;
}

void SimulatedJointDriver::clearSafeTorqueOff() {
    telemetry_.sto_active = false;
    // Deliberately does not touch position_setpoint_rad_/velocity_setpoint_rad_s_
    // — same as real STO hardware, clearing STO alone doesn't change what
    // was commanded; whatever setpoint is active resumes (or the caller
    // should issue a fresh, known-safe setpoint before/after clearing).
}

void SimulatedJointDriver::step(double dt_s) {
    if (telemetry_.sto_active) {
        // §9.5: STO removes torque without a full power cycle — velocity
        // decays, position holds where it stopped.
        telemetry_.velocity_rad_s *= 0.5;
        telemetry_.torque_estimate_nm = 0.0;
        return;
    }

    const double max_speed_rad_s = core::deg2rad(spec_.max_joint_speed_deg_s);

    if (position_control_active_) {
        const double pos_error = position_setpoint_rad_ - telemetry_.position_rad;
        // Simple velocity-saturated proportional tracking — adequate as a
        // stand-in plant model for exercising the motion controller/safety
        // stack; the real system's dynamics live in firmware/joint_foc.
        double desired_vel = std::clamp(pos_error / std::max(dt_s, 1e-6), -max_speed_rad_s, max_speed_rad_s);
        telemetry_.velocity_rad_s = desired_vel;
        telemetry_.position_rad += desired_vel * dt_s;
    } else {
        const double v = std::clamp(velocity_setpoint_rad_s_, -max_speed_rad_s, max_speed_rad_s);
        telemetry_.velocity_rad_s = v;
        telemetry_.position_rad += v * dt_s;
    }

    // Coarse torque/current estimate: proportional to commanded/tracking
    // effort plus any injected external (contact) load — feeds the §14
    // torque-deviation collision-detection monitor.
    const double dynamic_component = std::fabs(telemetry_.velocity_rad_s) * 0.5;
    telemetry_.torque_estimate_nm =
        std::clamp(torque_setpoint_nm_ + dynamic_component + external_load_nm_, -spec_.peak_output_torque_nm,
                   spec_.peak_output_torque_nm);
    telemetry_.current_a = std::fabs(telemetry_.torque_estimate_nm) / std::max(spec_.rated_output_torque_nm, 1e-6) *
                            (spec_.motor_power_w / config::kRobotSpec.bus_voltage_vdc) / 10.0;

    // §6.4 thermal model: simple first-order heating toward a load-dependent
    // steady state, capped near the 100C winding limit under sustained peak load.
    const double load_fraction = std::fabs(telemetry_.torque_estimate_nm) / std::max(spec_.peak_output_torque_nm, 1e-6);
    const double steady_state_temp = 25.0 + load_fraction * 70.0;  // approaches 95C under sustained peak load
    telemetry_.winding_temp_c += (steady_state_temp - telemetry_.winding_temp_c) * std::min(1.0, dt_s * 0.05);

    telemetry_.fault = telemetry_.winding_temp_c >= config::kSafetySpec.thermal_trip_c;
}

}  // namespace arm::hal
