#include "safety/safety_fsm.hpp"

#include <cmath>

namespace arm::safety {

std::string_view toString(RobotState s) {
    switch (s) {
        case RobotState::kPowerOn: return "PowerOn";
        case RobotState::kHoming: return "Homing";
        case RobotState::kIdle: return "Idle";
        case RobotState::kRunning: return "Running";
        case RobotState::kPaused: return "Paused";
        case RobotState::kFault: return "Fault";
        case RobotState::kEStop: return "EStop";
    }
    return "Unknown";
}

std::string_view toString(Event e) {
    switch (e) {
        case Event::kBootComplete: return "boot_complete";
        case Event::kHomingComplete: return "homing_complete";
        case Event::kTaskStart: return "task_start";
        case Event::kTaskComplete: return "task_complete";
        case Event::kPauseCommand: return "pause_command";
        case Event::kResumeCommand: return "resume_command";
        case Event::kErrorDetected: return "error_detected";
        case Event::kFaultCleared: return "fault_cleared";
        case Event::kEstopTriggered: return "estop_triggered";
        case Event::kEstopReset: return "estop_reset";
    }
    return "unknown_event";
}

bool SafetyFsm::handle(Event event) {
    // estop_triggered is legal from every state except EStop itself (§13.5:
    // arrows converge on EStop from PowerOn/Homing/Idle/Running/Paused/Fault).
    if (event == Event::kEstopTriggered && state_ != RobotState::kEStop) {
        state_ = RobotState::kEStop;
        return true;
    }

    switch (state_) {
        case RobotState::kPowerOn:
            if (event == Event::kBootComplete) { state_ = RobotState::kHoming; return true; }
            break;
        case RobotState::kHoming:
            if (event == Event::kHomingComplete) { state_ = RobotState::kIdle; return true; }
            break;
        case RobotState::kIdle:
            if (event == Event::kTaskStart) { state_ = RobotState::kRunning; return true; }
            break;
        case RobotState::kRunning:
            if (event == Event::kTaskComplete) { state_ = RobotState::kIdle; return true; }
            if (event == Event::kPauseCommand) { state_ = RobotState::kPaused; return true; }
            if (event == Event::kErrorDetected) { state_ = RobotState::kFault; return true; }
            break;
        case RobotState::kPaused:
            if (event == Event::kResumeCommand) { state_ = RobotState::kRunning; return true; }
            if (event == Event::kErrorDetected) { state_ = RobotState::kFault; return true; }
            break;
        case RobotState::kFault:
            if (event == Event::kFaultCleared) { state_ = RobotState::kIdle; return true; }
            break;
        case RobotState::kEStop:
            if (event == Event::kEstopReset) { state_ = RobotState::kPowerOn; return true; }
            break;
    }
    return false;  // illegal transition for current state — no-op, mirrors the fixed edge set in §13.5
}

bool SafetyFsm::checkTorqueDeviation(double expected_nm, double measured_nm, const config::JointSpec& spec,
                                      double threshold_percent) const {
    const double reference = std::max(spec.rated_output_torque_nm, 1e-6);
    const double deviation_percent = std::fabs(measured_nm - expected_nm) / reference * 100.0;
    return deviation_percent > threshold_percent;
}

bool SafetyFsm::checkSoftLimit(double position_rad, const config::JointSpec& spec) const {
    const double min_rad = core::deg2rad(spec.soft_limit_min_deg);
    const double max_rad = core::deg2rad(spec.soft_limit_max_deg);
    const double range = max_rad - min_rad;
    const double margin = range * (1.0 - config::kRobotSpec.soft_limit_fraction_of_mechanical_range) * 0.5;
    return position_rad < (min_rad + margin) || position_rad > (max_rad - margin);
}

SafetyCheckResult SafetyFsm::evaluate(const hal::JointTelemetry& telemetry, const config::JointSpec& spec,
                                       double commanded_torque_nm, bool hardware_estop_line_active) {
    SafetyCheckResult result{};
    result.estop_pressed = hardware_estop_line_active;
    result.collision_suspected = checkTorqueDeviation(commanded_torque_nm, telemetry.torque_estimate_nm, spec);
    result.overcurrent = std::fabs(telemetry.current_a) > (spec.motor_power_w / config::kRobotSpec.bus_voltage_vdc) * 1.5;
    result.overtemperature = telemetry.winding_temp_c >= config::kSafetySpec.thermal_derate_start_c;
    result.soft_limit_violation = checkSoftLimit(telemetry.position_rad, spec);
    result.hard_limit_violation =
        telemetry.position_rad < core::deg2rad(spec.soft_limit_min_deg) - core::deg2rad(1.0) ||
        telemetry.position_rad > core::deg2rad(spec.soft_limit_max_deg) + core::deg2rad(1.0);
    result.sto_required = telemetry.winding_temp_c >= config::kSafetySpec.thermal_trip_c || result.hard_limit_violation;

    if (result.estop_pressed) {
        handle(Event::kEstopTriggered);
    } else if (result.anyFault() && state_ == RobotState::kRunning) {
        handle(Event::kErrorDetected);
    }
    return result;
}

}  // namespace arm::safety
