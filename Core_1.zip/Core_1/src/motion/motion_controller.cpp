#include "motion/motion_controller.hpp"

#include <algorithm>
#include <cmath>

#include "core/linalg.hpp"

namespace arm::motion {

MotionController::MotionController(std::array<hal::JointInterface*, config::kNumJoints> joints,
                                    double control_loop_hz)
    : joints_(joints), dt_s_(1.0 / control_loop_hz) {}

void MotionController::beginMove(const JointSpaceMove& move) {
    double slowest_duration = 0.0;
    std::array<MotionLimits, config::kNumJoints> limits{};

    for (std::size_t i = 0; i < config::kNumJoints; ++i) {
        const auto& spec = config::kJointSpecs[i];
        const double v_max = core::deg2rad(spec.max_joint_speed_deg_s);
        // §6.3 peak torque already carries the 1.5x design margin; derive a
        // representative accel limit from rated vs peak torque headroom
        // rather than an unstated acceleration spec.
        const double a_max = v_max * 4.0;  // reaches v_max in 250ms — representative, not in source doc
        const double j_max = a_max * 10.0;  // jerk limit shaping the S-curve ramps — implementation choice
        limits[i] = {v_max, a_max, j_max};
    }

    // First pass: build profiles at full-speed limits and find the slowest.
    std::array<std::unique_ptr<TrajectoryProfile>, config::kNumJoints> candidate;
    for (std::size_t i = 0; i < config::kNumJoints; ++i) {
        candidate[i] = makeProfile(move.start[i], move.target[i], limits[i], move.use_s_curve);
        slowest_duration = std::max(slowest_duration, candidate[i]->duration());
    }

    // Second pass: rescale every joint's velocity/accel/jerk limits so all
    // axes complete in `slowest_duration` — a simple synchronized-move
    // strategy (time-scaling), keeping the S-curve/trapezoidal shape.
    for (std::size_t i = 0; i < config::kNumJoints; ++i) {
        const double own_duration = candidate[i]->duration();
        if (own_duration < 1e-9 || slowest_duration < 1e-9) {
            profiles_[i] = std::move(candidate[i]);
            continue;
        }
        const double scale = own_duration / slowest_duration;  // < 1 for faster joints, needs slowing down
        MotionLimits scaled = limits[i];
        scaled.max_velocity *= scale;
        scaled.max_acceleration *= scale * scale;
        scaled.max_jerk *= scale * scale * scale;
        // Guard against degenerate (near-zero) scaled limits for joints with
        // ~0 travel in this move.
        scaled.max_velocity = std::max(scaled.max_velocity, 1e-6);
        scaled.max_acceleration = std::max(scaled.max_acceleration, 1e-6);
        scaled.max_jerk = std::max(scaled.max_jerk, 1e-6);
        profiles_[i] = makeProfile(move.start[i], move.target[i], scaled, move.use_s_curve);
    }

    move_duration_s_ = slowest_duration;
    elapsed_s_ = 0.0;
    move_active_ = true;
}

bool MotionController::tick() {
    if (!move_active_) return false;

    for (std::size_t i = 0; i < config::kNumJoints; ++i) {
        const KinematicSample sample = profiles_[i]->sample(elapsed_s_);
        joints_[i]->setPositionSetpoint(sample.position);
    }

    elapsed_s_ += dt_s_;
    if (elapsed_s_ >= move_duration_s_) {
        move_active_ = false;
        return false;
    }
    return true;
}

}  // namespace arm::motion
