#include "motion/trajectory_profile.hpp"

#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace arm::motion {

// ---------------------------------------------------------------------------
// TrapezoidalProfile — §13.3 default general pick-place profile.
// ---------------------------------------------------------------------------
TrapezoidalProfile::TrapezoidalProfile(double start, double end, const MotionLimits& limits)
    : start_(start), end_(end), v_max_(limits.max_velocity), a_max_(limits.max_acceleration) {
    distance_ = std::fabs(end - start);
    direction_ = (end >= start) ? 1.0 : -1.0;

    const double accel_distance_full = (v_max_ * v_max_) / a_max_;
    if (distance_ >= accel_distance_full) {
        // Full trapezoid: reaches v_max_, has a cruise segment.
        cruise_velocity_ = v_max_;
        t_accel_ = v_max_ / a_max_;
        t_decel_ = t_accel_;
        const double cruise_distance = distance_ - accel_distance_full;
        t_cruise_ = cruise_distance / v_max_;
    } else {
        // Triangular: never reaches v_max_.
        cruise_velocity_ = std::sqrt(distance_ * a_max_);
        t_accel_ = cruise_velocity_ / a_max_;
        t_decel_ = t_accel_;
        t_cruise_ = 0.0;
    }
    total_time_ = t_accel_ + t_cruise_ + t_decel_;
}

KinematicSample TrapezoidalProfile::sample(double t) const {
    t = std::clamp(t, 0.0, total_time_);
    double pos = 0.0, vel = 0.0, accel = 0.0;

    if (t <= t_accel_) {
        accel = a_max_;
        vel = a_max_ * t;
        pos = 0.5 * a_max_ * t * t;
    } else if (t <= t_accel_ + t_cruise_) {
        const double tc = t - t_accel_;
        accel = 0.0;
        vel = cruise_velocity_;
        pos = 0.5 * a_max_ * t_accel_ * t_accel_ + cruise_velocity_ * tc;
    } else {
        const double td = t - t_accel_ - t_cruise_;
        accel = -a_max_;
        vel = cruise_velocity_ - a_max_ * td;
        const double pos_at_cruise_end =
            0.5 * a_max_ * t_accel_ * t_accel_ + cruise_velocity_ * t_cruise_;
        pos = pos_at_cruise_end + cruise_velocity_ * td - 0.5 * a_max_ * td * td;
    }

    KinematicSample s;
    s.time_s = t;
    s.position = start_ + direction_ * pos;
    s.velocity = direction_ * vel;
    s.acceleration = direction_ * accel;
    s.jerk = 0.0;  // discontinuous acceleration at segment boundaries — inherent to trapezoidal profiles
    return s;
}

// ---------------------------------------------------------------------------
// SCurveProfile — §13.3 recommended default (jerk-limited).
// 7-segment symmetric S-curve: [+j, 0, -j, cruise, -j, 0, +j]
// ---------------------------------------------------------------------------
namespace {
struct AccelPhaseResult {
    double t1, t2, t3;  // jerk-up / const-accel / jerk-down durations
    double distance;     // distance covered reaching v_peak from rest
    double v_peak;
};

AccelPhaseResult accelPhase(double v_target, double a_max, double j_max) {
    AccelPhaseResult r{};
    r.v_peak = v_target;
    const double t_j_full = a_max / j_max;
    const double v_gained_in_jerk_ramps = a_max * t_j_full;  // velocity gained over the two jerk segments if accel reaches a_max

    if (v_gained_in_jerk_ramps <= v_target) {
        // Accel reaches a_max — full 3-segment accel phase.
        r.t1 = t_j_full;
        r.t3 = t_j_full;
        r.t2 = (v_target - v_gained_in_jerk_ramps) / a_max;
    } else {
        // Accel-limited: never reaches a_max, pure jerk-up/jerk-down triangle.
        r.t1 = std::sqrt(v_target / j_max);
        r.t3 = r.t1;
        r.t2 = 0.0;
    }

    // Integrate distance across the 3 sub-segments analytically.
    double t = 0.0, pos = 0.0, vel = 0.0, acc = 0.0;
    auto integrate = [&](double dt, double j) {
        pos += vel * dt + 0.5 * acc * dt * dt + (j * dt * dt * dt) / 6.0;
        vel += acc * dt + 0.5 * j * dt * dt;
        acc += j * dt;
        t += dt;
    };
    integrate(r.t1, j_max);
    integrate(r.t2, 0.0);
    integrate(r.t3, -j_max);
    r.distance = pos;
    return r;
}
}  // namespace

SCurveProfile::SCurveProfile(double start, double end, const MotionLimits& limits)
    : start_(start), end_(end), v_max_(limits.max_velocity), a_max_(limits.max_acceleration),
      j_max_(limits.max_jerk) {
    distance_ = std::fabs(end - start);
    direction_ = (end >= start) ? 1.0 : -1.0;
    buildProfile();
}

void SCurveProfile::buildProfile() {
    AccelPhaseResult full_accel = accelPhase(v_max_, a_max_, j_max_);
    double v_peak = v_max_;
    double t_cruise = 0.0;

    if (2.0 * full_accel.distance > distance_) {
        // Velocity-limited case: distance too short to reach v_max_. Bisect
        // on peak velocity so 2*accelPhase(v_peak).distance == distance_.
        double lo = 0.0, hi = v_max_;
        for (int i = 0; i < 60; ++i) {
            const double mid = 0.5 * (lo + hi);
            const AccelPhaseResult r = accelPhase(mid, a_max_, j_max_);
            if (2.0 * r.distance > distance_) {
                hi = mid;
            } else {
                lo = mid;
            }
        }
        v_peak = 0.5 * (lo + hi);
        full_accel = accelPhase(v_peak, a_max_, j_max_);
        t_cruise = 0.0;
    } else {
        const double cruise_distance = distance_ - 2.0 * full_accel.distance;
        t_cruise = cruise_distance / v_max_;
    }

    segments_.clear();
    double t_cursor = 0.0;
    auto push = [&](double dt, double j) {
        t_cursor += dt;
        segments_.push_back({t_cursor, j});
    };
    push(full_accel.t1, j_max_);    // jerk up
    push(full_accel.t2, 0.0);        // const accel
    push(full_accel.t3, -j_max_);   // jerk down to cruise accel (0)
    push(t_cruise, 0.0);              // cruise
    push(full_accel.t3, -j_max_);   // jerk down (begin decel)
    push(full_accel.t2, 0.0);        // const decel
    push(full_accel.t1, j_max_);    // jerk up (accel -> 0 at end, v -> 0)
    total_time_ = t_cursor;
}

KinematicSample SCurveProfile::sample(double t) const {
    t = std::clamp(t, 0.0, total_time_);

    double seg_start_t = 0.0, pos = 0.0, vel = 0.0, acc = 0.0;
    for (const auto& seg : segments_) {
        const double seg_duration = seg.t_end - seg_start_t;
        if (t <= seg.t_end || &seg == &segments_.back()) {
            const double dt = std::clamp(t - seg_start_t, 0.0, seg_duration);
            const double j = seg.j;
            const double p = pos + vel * dt + 0.5 * acc * dt * dt + (j * dt * dt * dt) / 6.0;
            const double v = vel + acc * dt + 0.5 * j * dt * dt;
            const double a = acc + j * dt;
            KinematicSample s;
            s.time_s = t;
            s.position = start_ + direction_ * p;
            s.velocity = direction_ * v;
            s.acceleration = direction_ * a;
            s.jerk = direction_ * j;
            return s;
        }
        // advance accumulated state to end of this segment
        const double dt = seg_duration;
        const double j = seg.j;
        pos += vel * dt + 0.5 * acc * dt * dt + (j * dt * dt * dt) / 6.0;
        vel += acc * dt + 0.5 * j * dt * dt;
        acc += j * dt;
        seg_start_t = seg.t_end;
    }
    // Should not reach here — the back() segment above always returns.
    KinematicSample s;
    s.time_s = t;
    s.position = end_;
    return s;
}

std::unique_ptr<TrajectoryProfile> makeProfile(double start, double end, const MotionLimits& limits,
                                                bool use_s_curve) {
    if (use_s_curve) {
        return std::make_unique<SCurveProfile>(start, end, limits);
    }
    return std::make_unique<TrapezoidalProfile>(start, end, limits);
}

}  // namespace arm::motion
