#include "config/config_loader.hpp"

#include <fstream>
#include <sstream>
#include <unordered_map>

namespace arm::config_io {

namespace {

std::string trim(const std::string& s) {
    const auto first = s.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return "";
    const auto last = s.find_last_not_of(" \t\r\n");
    return s.substr(first, last - first + 1);
}

std::string stripQuotes(const std::string& s) {
    if (s.size() >= 2 && s.front() == '"' && s.back() == '"') return s.substr(1, s.size() - 2);
    return s;
}

std::size_t leadingSpaces(const std::string& line) {
    std::size_t n = 0;
    while (n < line.size() && line[n] == ' ') ++n;
    return n;
}

std::optional<int> jointIndexFromName(const std::string& name) {
    if (name.size() == 2 && name[0] == 'J' && name[1] >= '1' && name[1] <= '6') {
        return static_cast<int>(name[1] - '1');
    }
    return std::nullopt;
}

// Parses "{ min_deg: -170, max_deg: 170, max_speed_deg_s: 180 }" style inline
// flow maps used for joint_limits entries.
std::unordered_map<std::string, double> parseFlowMap(const std::string& s) {
    std::unordered_map<std::string, double> result;
    const auto open = s.find('{');
    const auto close = s.find('}');
    if (open == std::string::npos || close == std::string::npos || close < open) return result;
    const std::string inner = s.substr(open + 1, close - open - 1);
    std::stringstream ss(inner);
    std::string token;
    while (std::getline(ss, token, ',')) {
        const auto colon = token.find(':');
        if (colon == std::string::npos) continue;
        const std::string key = trim(token.substr(0, colon));
        const std::string val = trim(token.substr(colon + 1));
        try {
            result[key] = std::stod(val);
        } catch (...) {
        }
    }
    return result;
}

}  // namespace

std::optional<ArmVariantConfig> loadArmVariantConfig(std::string_view path) {
    std::ifstream file{std::string(path)};
    if (!file.is_open()) return std::nullopt;

    ArmVariantConfig cfg{};
    // Seed with compiled-in defaults so a partially-specified file still
    // yields a usable config (matches §11.7's "loaded at controller startup"
    // intent — the file overrides, it does not have to fully replace, the
    // baseline).
    cfg.dh_parameters = config::kDHTable;
    for (std::size_t i = 0; i < config::kNumJoints; ++i) {
        cfg.joint_limits[i] = {config::kJointSpecs[i].soft_limit_min_deg, config::kJointSpecs[i].soft_limit_max_deg,
                                config::kJointSpecs[i].max_joint_speed_deg_s};
    }

    enum class Section { kRoot, kDhParameters, kJointLimits, kToolChanger };
    Section section = Section::kRoot;
    int current_dh_index = -1;

    std::string line;
    while (std::getline(file, line)) {
        // Strip comments (# ...) that aren't inside quotes — sufficient for
        // this config format.
        if (const auto hash = line.find('#'); hash != std::string::npos) {
            const auto quote_before = line.find('"');
            if (quote_before == std::string::npos || quote_before > hash) line = line.substr(0, hash);
        }
        if (trim(line).empty()) continue;

        const std::size_t indent = leadingSpaces(line);
        const std::string content = trim(line);

        if (indent == 0) {
            // Root-level: either "key: value" or "key:" (section header).
            const auto colon = content.find(':');
            if (colon == std::string::npos) continue;
            const std::string key = trim(content.substr(0, colon));
            const std::string value = trim(content.substr(colon + 1));

            if (key == "robot_variant") {
                cfg.robot_variant = stripQuotes(value);
                section = Section::kRoot;
            } else if (key == "dh_parameters") {
                section = Section::kDhParameters;
                current_dh_index = -1;
            } else if (key == "joint_limits") {
                section = Section::kJointLimits;
            } else if (key == "calibration_offsets_file") {
                cfg.calibration_offsets_file = stripQuotes(value);
                section = Section::kRoot;
            } else if (key == "tool_changer") {
                section = Section::kToolChanger;
            }
            continue;
        }

        // Indented content belongs to whichever section we're in.
        switch (section) {
            case Section::kDhParameters: {
                if (content.rfind("- joint:", 0) == 0) {
                    const std::string name = trim(content.substr(std::string("- joint:").size()));
                    if (auto idx = jointIndexFromName(name)) current_dh_index = *idx;
                    continue;
                }
                if (current_dh_index < 0) continue;
                const auto colon = content.find(':');
                if (colon == std::string::npos) continue;
                const std::string key = trim(content.substr(0, colon));
                const std::string value = trim(content.substr(colon + 1));
                try {
                    const double v = std::stod(value);
                    auto& row = cfg.dh_parameters[static_cast<std::size_t>(current_dh_index)];
                    if (key == "a") row.a_m = v;
                    else if (key == "d") row.d_m = v;
                    else if (key == "alpha") row.alpha_rad = v;
                } catch (...) {
                }
                break;
            }
            case Section::kJointLimits: {
                const auto colon = content.find(':');
                if (colon == std::string::npos) continue;
                const std::string name = trim(content.substr(0, colon));
                if (auto idx = jointIndexFromName(name)) {
                    const auto map = parseFlowMap(content);
                    JointLimitEntry entry = cfg.joint_limits[static_cast<std::size_t>(*idx)];
                    if (auto it = map.find("min_deg"); it != map.end()) entry.min_deg = it->second;
                    if (auto it = map.find("max_deg"); it != map.end()) entry.max_deg = it->second;
                    if (auto it = map.find("max_speed_deg_s"); it != map.end()) entry.max_speed_deg_s = it->second;
                    cfg.joint_limits[static_cast<std::size_t>(*idx)] = entry;
                }
                break;
            }
            case Section::kToolChanger: {
                const auto colon = content.find(':');
                if (colon == std::string::npos) continue;
                const std::string key = trim(content.substr(0, colon));
                const std::string value = trim(content.substr(colon + 1));
                if (key == "default_tool") cfg.default_tool = stripQuotes(value);
                else if (key == "tool_library_path") cfg.tool_library_path = stripQuotes(value);
                break;
            }
            case Section::kRoot:
                break;
        }
    }

    return cfg;
}

}  // namespace arm::config_io
