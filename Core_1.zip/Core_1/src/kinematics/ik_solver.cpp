#include "kinematics/ik_solver.hpp"

#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace arm::kinematics {

using core::Matrix3;
using core::Transform;
using core::Vector3;
using core::Vector6;

namespace {

// so(3) "vee" map of the skew-symmetric part of a (near-)rotation matrix —
// a standard small-angle orientation-error vector used by Newton-style IK.
Vector3 orientationError(const Matrix3& R_err) {
    return Vector3{R_err.m[2][1] - R_err.m[1][2], R_err.m[0][2] - R_err.m[2][0],
                   R_err.m[1][0] - R_err.m[0][1]} *
           0.5;
}

Vector6 poseError(const Transform& target, const Transform& current) {
    const Vector3 pos_err = target.p - current.p;
    const Matrix3 R_err = target.R * current.R.transposed();
    const Vector3 rot_err = orientationError(R_err);
    return {pos_err.x, pos_err.y, pos_err.z, rot_err.x, rot_err.y, rot_err.z};
}

}  // namespace

std::optional<JointAngles> IKSolver::analyticalSeed(const core::Transform& target) const {
    // Link lengths pulled straight from the DH table (§4.3/§20.5) — see the
    // PLACEHOLDER_ notes in robot_config.hpp for which of these are verbatim
    // from the source document vs. filled in to complete the truncated table.
    const auto& dh = chain_.dhTable();
    const double d1 = dh[0].d_m;
    const double a2 = dh[1].a_m;
    const double a3 = dh[2].a_m;
    const double d4 = dh[3].d_m;
    const double d6 = dh[5].d_m;
    const double L3 = std::hypot(a3, d4);  // effective forearm-to-wrist-center length

    // Wrist center: back off from the target TCP along the tool's local Z by
    // the flange offset d6. This is an approximation (it ignores small
    // cross-axis offsets from a3/alpha3) — adequate as a seed for Newton
    // refinement, per the architecture described in §11.4.
    const Vector3 tool_z = target.R.zAxis();
    const Vector3 wc = target.p - tool_z * d6;

    const double theta1 = std::atan2(wc.y, wc.x);
    const double r = std::hypot(wc.x, wc.y);
    const double s = wc.z - d1;
    const double dist2 = r * r + s * s;

    const double cos_theta3_num = dist2 - a2 * a2 - L3 * L3;
    const double cos_theta3_den = 2.0 * a2 * L3;
    if (cos_theta3_den < 1e-9) return std::nullopt;
    const double D = cos_theta3_num / cos_theta3_den;
    if (D < -1.0 - 1e-6 || D > 1.0 + 1e-6) {
        return std::nullopt;  // target outside reach envelope (§2.1: 850 mm)
    }
    const double D_clamped = std::clamp(D, -1.0, 1.0);
    const double theta3 = std::atan2(std::sqrt(std::max(0.0, 1.0 - D_clamped * D_clamped)), D_clamped);  // elbow-up

    const double theta2 = std::atan2(s, r) - std::atan2(L3 * std::sin(theta3), a2 + L3 * std::cos(theta3));

    // Wrist joints (J4-J6): seeded at zero. The Newton refinement stage below
    // resolves full 6-DOF orientation regardless of this seed's accuracy.
    JointAngles seed{theta1, theta2, theta3, 0.0, 0.0, 0.0};
    return seed;
}

std::optional<JointAngles> IKSolver::refine(const core::Transform& target, JointAngles guess) const {
    for (int iter = 0; iter < options_.max_refine_iterations; ++iter) {
        const Transform current = chain_.forwardKinematics(guess);
        const Vector6 err = poseError(target, current);

        const double pos_err_norm = std::sqrt(err[0] * err[0] + err[1] * err[1] + err[2] * err[2]);
        const double rot_err_norm = std::sqrt(err[3] * err[3] + err[4] * err[4] + err[5] * err[5]);
        if (pos_err_norm < options_.position_tolerance_m && rot_err_norm < options_.orientation_tolerance_rad) {
            return guess;
        }

        core::Matrix6 J = chain_.computeJacobian(guess);
        // Damping (Levenberg-Marquardt style) keeps the solve well-conditioned
        // near singularities (e.g. wrist-flip / shoulder-singularity poses),
        // exactly the "fallback ... near singularities" case called out in
        // §11.4.
        for (int i = 0; i < 6; ++i) J.m[i][i] += options_.damping_lambda;

        core::Vector6 dq{};
        try {
            dq = core::solve6(J, err);
        } catch (const std::runtime_error&) {
            return std::nullopt;  // still singular even after damping
        }

        for (int i = 0; i < 6; ++i) {
            double step = dq[i];
            step = std::clamp(step, -options_.max_step_rad, options_.max_step_rad);
            guess[i] += step;
        }
    }
    return std::nullopt;  // did not converge within max_refine_iterations
}

std::optional<JointAngles> IKSolver::solve(const core::Transform& target, const JointAngles& seed_angles) const {
    JointAngles start = seed_angles;
    if (auto analytical = analyticalSeed(target)) {
        start = *analytical;
    }
    return refine(target, start);
}

}  // namespace arm::kinematics
