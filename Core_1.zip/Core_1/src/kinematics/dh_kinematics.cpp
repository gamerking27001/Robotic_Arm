#include "kinematics/dh_kinematics.hpp"

namespace arm::kinematics {

using core::Transform;
using core::Vector3;

LinkFrames DHKinematicChain::computeLinkFrames(const JointAngles& q) const {
    LinkFrames out{};
    Transform accumulated = Transform::identity();
    for (std::size_t i = 0; i < config::kNumJoints; ++i) {
        const auto& row = dh_[i];
        const Transform link = Transform::fromDH(row.a_m, row.alpha_rad, row.d_m, q[i]);
        accumulated = accumulated * link;
        out.frames[i] = accumulated;
    }
    return out;
}

Transform DHKinematicChain::forwardKinematics(const JointAngles& q) const {
    return computeLinkFrames(q).frames.back();
}

core::Matrix6 DHKinematicChain::computeJacobian(const JointAngles& q) const {
    const LinkFrames frames = computeLinkFrames(q);
    const Vector3 tcp = frames.frames.back().p;

    core::Matrix6 J{};
    Vector3 prev_z{0, 0, 1};   // base frame Z axis
    Vector3 prev_o{0, 0, 0};   // base frame origin

    for (std::size_t i = 0; i < config::kNumJoints; ++i) {
        // Revolute joint i contributes:
        //   linear:  z_{i-1} x (o_tcp - o_{i-1})
        //   angular: z_{i-1}
        const Vector3 lin = prev_z.cross(tcp - prev_o);
        J.m[0][i] = lin.x;
        J.m[1][i] = lin.y;
        J.m[2][i] = lin.z;
        J.m[3][i] = prev_z.x;
        J.m[4][i] = prev_z.y;
        J.m[5][i] = prev_z.z;

        prev_z = frames.frames[i].R.zAxis();
        prev_o = frames.frames[i].p;
    }
    return J;
}

}  // namespace arm::kinematics
