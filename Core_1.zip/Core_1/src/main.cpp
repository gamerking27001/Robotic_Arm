// main.cpp — end-to-end demonstration of the core stack:
//   config load -> kinematics (FK/IK) -> trajectory generation -> motion
//   controller -> simulated joint HAL -> safety FSM.
//
// This exercises §11 (Software Architecture)'s full layered stack against the
// §20.5 sample configuration, using simulated CAN/joints in place of real
// hardware (see README for what is/isn't implemented).
#include <cstdio>
#include <iostream>

#include "config/config_loader.hpp"
#include "core/linalg.hpp"
#include "core/robot_config.hpp"
#include "hal/can_bus_simulated.hpp"
#include "hal/simulated_joint_driver.hpp"
#include "kinematics/dh_kinematics.hpp"
#include "kinematics/ik_solver.hpp"
#include "motion/motion_controller.hpp"
#include "safety/safety_fsm.hpp"

using namespace arm;

namespace {

void printRobotSpecSummary() {
    const auto& r = config::kRobotSpec;
    std::printf("=== Robot Specification (\xc2\xa7 1.5 / \xc2\xa7 2.1) ===\n");
    std::printf("  Payload nominal/peak : %.1f / %.1f kg\n", r.payload_nominal_kg, r.payload_peak_kg);
    std::printf("  Reach                : %.0f mm\n", r.reach_mm);
    std::printf("  Repeatability        : \xc2\xb1%.2f mm\n", r.repeatability_mm);
    std::printf("  Pose accuracy (cal)  : \xc2\xb1%.2f mm\n", r.pose_accuracy_mm_post_cal);
    std::printf("  Max TCP speed        : %.1f m/s\n", r.max_tcp_speed_mps);
    std::printf("  Rated power (peak)   : %.0f W @ %.0f VDC\n", r.rated_power_w_peak, r.bus_voltage_vdc);
    std::printf("  Weight (excl. ctrl)  : <= %.0f kg (controller <= %.0f kg)\n", r.weight_kg_excl_controller,
                 r.controller_weight_kg);
    std::printf("  IP rating            : %s (base/forearm), %s (wrist optional)\n",
                 r.ip_rating_base_forearm.data(), r.ip_rating_wrist_optional.data());
    std::printf("  Ambient temp range   : %.0f - %.0f C\n", r.ambient_temp_min_c, r.ambient_temp_max_c);
    std::printf("  Acoustic noise       : < %.0f dB(A) @ 1m\n\n", r.acoustic_noise_dba_at_1m);

    std::printf("=== Per-Joint Specification (\xc2\xa7 5.6 / \xc2\xa7 6.2) ===\n");
    std::printf("  %-10s %-9s %-6s %-9s %-9s %-8s %-4s %-8s\n", "Joint", "Gearbox", "Ratio", "Rated Nm",
                 "Peak Nm", "RPM", "Enc", "Power W");
    for (const auto& j : config::kJointSpecs) {
        const char* gb = j.gearbox == config::GearboxType::kHarmonicStrainWave   ? "Harmonic"
                          : j.gearbox == config::GearboxType::kCycloidal          ? "Cycloidal"
                                                                                     : "Planetary";
        std::printf("  %-10s %-9s %5.0f:1 %9.1f %9.1f %8.0f %3db %8.1f\n", j.name.data(), gb, j.gear_ratio,
                     j.rated_output_torque_nm, j.peak_output_torque_nm, j.rated_motor_rpm, j.encoder_bits,
                     j.motor_power_w);
    }
    std::printf("\n");
}

void printPose(const char* label, const core::Transform& t) {
    std::printf("%s: p=(%.4f, %.4f, %.4f) m\n", label, t.p.x, t.p.y, t.p.z);
}

}  // namespace

int main() {
    printRobotSpecSummary();

    // --- Configuration load (\xc2\xa7 11.7 / \xc2\xa7 20.5) --------------------------
    auto loaded = config_io::loadArmVariantConfig("configs/arm_variant_standard.yaml");
    std::array<config::DHRow, config::kNumJoints> dh_table = config::kDHTable;
    if (loaded) {
        dh_table = loaded->dh_parameters;
        std::printf("Loaded arm variant config: \"%s\"\n\n", loaded->robot_variant.c_str());
    } else {
        std::printf("Config file not found — using compiled-in defaults from robot_config.hpp\n\n");
    }

    // --- Kinematics (\xc2\xa7 4 / \xc2\xa7 11.4) -------------------------------------
    kinematics::DHKinematicChain chain(dh_table);
    kinematics::JointAngles home{0, 0, 0, 0, 0, 0};
    const core::Transform home_pose = chain.forwardKinematics(home);
    printPose("Home pose (FK)", home_pose);

    kinematics::JointAngles target_angles{core::deg2rad(20.0), core::deg2rad(-30.0), core::deg2rad(45.0),
                                           core::deg2rad(10.0), core::deg2rad(-25.0), core::deg2rad(15.0)};
    const core::Transform target_pose = chain.forwardKinematics(target_angles);
    printPose("Target pose (from known joint angles, for IK validation)", target_pose);

    kinematics::IKSolver ik(chain);
    auto ik_result = ik.solve(target_pose, home);
    if (ik_result) {
        std::printf("IK solved. Recovered joint angles (deg): ");
        for (double q : *ik_result) std::printf("%.2f ", core::rad2deg(q));
        std::printf("\n");
        const core::Transform verify = chain.forwardKinematics(*ik_result);
        printPose("IK solution FK round-trip", verify);
    } else {
        std::printf("IK solve failed to converge.\n");
    }
    std::printf("\n");

    // --- HAL + Motion controller (\xc2\xa7 9 / \xc2\xa7 11.3) ------------------------
    hal::SimulatedCanBus can_bus;
    std::vector<std::unique_ptr<hal::SimulatedJointDriver>> drivers;
    std::array<hal::JointInterface*, config::kNumJoints> joint_ifaces{};
    for (std::size_t i = 0; i < config::kNumJoints; ++i) {
        drivers.push_back(std::make_unique<hal::SimulatedJointDriver>(static_cast<config::JointId>(i), can_bus));
        joint_ifaces[i] = drivers.back().get();
    }

    motion::MotionController controller(joint_ifaces, /*control_loop_hz=*/200.0);

    // --- Safety FSM boot sequence (\xc2\xa7 13.5) -----------------------------------
    safety::SafetyFsm fsm;
    std::printf("Safety FSM initial state: %s\n", safety::toString(fsm.state()).data());
    fsm.handle(safety::Event::kBootComplete);
    fsm.handle(safety::Event::kHomingComplete);
    std::printf("After boot + homing: %s\n\n", safety::toString(fsm.state()).data());

    // --- Execute a synchronized joint-space move (S-curve, \xc2\xa7 13.3 default) ---
    fsm.handle(safety::Event::kTaskStart);
    std::printf("Task started. State: %s\n", safety::toString(fsm.state()).data());

    motion::JointSpaceMove move{home, ik_result.value_or(target_angles), /*use_s_curve=*/true};
    controller.beginMove(move);

    const double dt = 1.0 / 200.0;
    int tick_count = 0;
    bool collision_injected = false;
    bool moving = true;
    while (moving) {
        moving = controller.tick();
        for (auto& d : drivers) d->step(dt);

        // Around the midpoint of the move, inject a simulated contact load on
        // J3 to exercise \xc2\xa7 14's torque-deviation collision detection path.
        if (!collision_injected && controller.elapsedTime() > 0.4) {
            drivers[2]->injectExternalLoadNm(80.0);  // large, sudden unexpected load on the elbow joint
            collision_injected = true;
            std::printf("  [t=%.2fs] Injected simulated contact load on J3\n", controller.elapsedTime());
        }

        const auto telem = drivers[2]->readTelemetry();
        const auto check = fsm.evaluate(telem, config::kJointSpecs[2], /*commanded_torque_nm=*/0.0,
                                         /*hardware_estop_line_active=*/false);

        if (check.collision_suspected && fsm.state() == safety::RobotState::kFault) {
            std::printf("  [t=%.2fs] Collision suspected on J3 (torque deviation) -> Safety FSM: %s\n",
                         controller.elapsedTime(), safety::toString(fsm.state()).data());
            break;  // stop the demo move once a fault is latched
        }
        ++tick_count;
    }
    std::printf("Move loop ran %d ticks (%.3fs simulated)\n\n", tick_count, controller.elapsedTime());

    // --- Fault recovery and E-stop demonstration (\xc2\xa7 13.5) --------------------
    std::printf("Clearing fault and resuming to Idle...\n");
    fsm.handle(safety::Event::kFaultCleared);
    std::printf("State: %s\n", safety::toString(fsm.state()).data());

    std::printf("Simulating hardware E-stop press...\n");
    fsm.handle(safety::Event::kEstopTriggered);
    std::printf("State: %s\n", safety::toString(fsm.state()).data());
    for (auto& d : drivers) d->triggerSafeTorqueOff();  // \xc2\xa7 9.5 STO on every joint

    std::printf("Operator resets E-stop...\n");
    fsm.handle(safety::Event::kEstopReset);
    std::printf("State: %s (back to %s, homing required again per \xc2\xa7 13.5)\n\n",
                 safety::toString(fsm.state()).data(), safety::toString(safety::RobotState::kPowerOn).data());

    return 0;
}
