# cad/freecad

A fourth representation of the same canonical robot, alongside the URDF
(`ros2_ws/src/robot_description/`), MJCF (`simulation/mujoco/`), and
CoppeliaSim-via-import (`simulation/coppeliasim/`) — continuing the same
"ONE CANONICAL ROBOT" principle into CAD. Also the first thing filed
under a top-level `cad/` directory — `documentation/design-baseline.md`'s
repo-mapping note flagged this directory as missing since the physical
design work had never been started; this is a first, modest step into
that gap, not the mechanical design work itself (see "What this honestly
is / is not" below).

## Why FreeCAD specifically

`documentation/design-baseline.md` §19.7 names SolidWorks as the primary
CAD tool, with Fusion 360/FreeCAD as alternate/collaborator tooling.
SolidWorks is a proprietary, closed-format, no-API-without-a-license
application — not something a script running outside it can generate
files for. FreeCAD is the one option in that comparison that's
open-source, has a documented Python scripting API, and — critically —
can export **STEP**, the actual interchange format that makes the
SolidWorks/Fusion/Onshape/FreeCAD comparison in §19.7 meaningful in the
first place (open the STEP output in whichever of those a mechanical
engineer actually has a license for).

## What this honestly is / is not

**Is:** a parametric skeleton — six plain cylinders (joint housings) and
six plain cylinders (links), placed at the exact positions and
orientations the same DH chain every other representation uses, sized
from the same illustrative radius constants `generate_mjcf.py` already
established. Right joint locations, right link lengths, right overall
reach. A real mechanical designer opening this in FreeCAD has a
correctly-dimensioned-in-position starting skeleton instead of a blank
document.

**Is NOT:** real mechanical design. No gearbox, no bearing, no motor, no
fastener, no wall thickness, no housing split-line, nothing from
`documentation/design-baseline.md` §5–9's actual joint/housing/gearbox/
electronics design has been modeled. Every dimension here is `DESIGN
PARAMETER — TO BE VALIDATED`, the same labeling convention the source
document itself uses, applied consistently rather than let slide because
"it's just CAD." Per that document's own explicit rule: **"Do not claim
a 3D-printable design is automatically suitable for industrial loads"**
— nothing produced here is claimed to be suitable for anything beyond
visualization and as a starting reference skeleton.

## Confidence level — and what actually was checked

**No FreeCAD install was available** in the environment this was written
in, so `Part::Cylinder`/`Placement`/`Part.export` API calls were never
run. That's the biggest unverified piece.

**What genuinely was checked, reproducibly:** the transform-chain math
(`build_transform_chain()`) is pure Python with no FreeCAD dependency, so
it was tested — and cross-validated against an independent
re-implementation reading `../../simulation/mujoco/generated_arm.xml`'s
own body positions directly, not by calling this file's code:

```bash
# This script's own computed positions:
python3 -c "
import sys; sys.path.insert(0, '.')
from generate_arm_cad import build_transform_chain
for i, (pos, rot) in enumerate(build_transform_chain()):
    print(f'link{i+1}:', [round(p, 6) for p in pos])
"

# Independently re-derived from the MJCF file (see the module docstring
# for the full independent-composition code) -- both produce:
#   link1=(0, 0, 0.284)        link4=(0.75, 0, -0.066)
#   link2=(0.4, 0, 0.284)      link5=(0.75, 0, -0.066)
#   link3=(0.75, 0, 0.284)     link6=(0.75, 0, -0.166)
```

This confirms the composition logic is correct — it does **not** confirm
the FreeCAD API calls built on top of it are.

## Known gap — resolved

`DH_TABLE` is now imported from `../../tools/robot_params.py`, the same
shared source `generate_urdf.py` and `generate_mjcf.py` import from —
no more copies to drift. Confirmed the refactor preserved the exact
transform math: re-ran `build_transform_chain()` after the change and
got the identical link positions listed above.

## Running it

```bash
freecadcmd generate_arm_cad.py
# or paste generate_arm_cad.py's contents into FreeCAD's own Python console
```

Produces `generated_arm.FCStd` (native FreeCAD) and `generated_arm.step`
(portable STEP export) in this directory.

## Same placeholder caveat as everywhere else in this repo

J3–J6 DH parameters are still `PLACEHOLDER_` values (source document
truncated — see `documentation/design-baseline.md`). This CAD skeleton
inherits that same placeholder geometry, same as the URDF/MJCF/
CoppeliaSim representations do.
