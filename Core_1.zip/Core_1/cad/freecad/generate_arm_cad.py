#!/usr/bin/env python3
"""generate_arm_cad.py

Run INSIDE FreeCAD (its Python console, or via `freecadcmd
generate_arm_cad.py` headless) — this is a FreeCAD macro, not a
standalone script; it imports the `FreeCAD`/`Part` modules FreeCAD's own
Python environment provides, which don't exist outside it.

Generates a FOURTH representation of the same canonical robot —
following ../../ros2_ws/src/robot_description/scripts/generate_urdf.py
and ../../simulation/mujoco/generate_mjcf.py's exact pattern: read the
same DH_TABLE/JOINT_LIMITS, build the same parent-child transform chain,
this time as FreeCAD `Part::Cylinder` primitives with `Placement`
objects instead of URDF `<link>`/`<joint>` or MJCF `<body>` elements.

READ THIS BEFORE MISTAKING THE OUTPUT FOR REAL MECHANICAL DESIGN:
this produces placeholder envelope geometry — plain cylinders, sized
from the exact same illustrative radius/length constants
generate_mjcf.py already uses (LARGE_LINK_RADIUS_M, SMALL_LINK_RADIUS_M,
etc.) — NOT real joint housing/link geometry. There is no gearbox, no
bearing, no motor, no fastener, no wall thickness, no real CAD anywhere
in this output. Section 5-9 of documentation/design-baseline.md
describes real joint/housing/gearbox/electronics design that has never
been done in any CAD tool -- this script's actual, honest purpose is
narrower: giving a parametric, correctly-DIMENSIONED-IN-POSITION
skeleton (right joint locations, right link lengths, right overall
reach) that a real mechanical design pass can be built ON TOP OF inside
FreeCAD, rather than starting from nothing. Per the source design
document's own explicit rule: "Do not claim a 3D-printable design is
automatically suitable for industrial loads" -- nothing here is claimed
to be suitable for anything beyond visualization/reference. Every
dimension is DESIGN PARAMETER — TO BE VALIDATED per that document's own
labeling convention, exactly like the placeholder DH values for J3-J6
already are everywhere else in this repo.

Cross-check performed before trusting this file's placement math: the
final link positions this script's `build_transform_chain()` computes
were checked against an INDEPENDENT re-implementation of the same
composition, driven by parsing ../../simulation/mujoco/generated_arm.xml's
own body pos/axisangle values directly (not by importing/calling this
file's own code) — both produce the identical world-frame positions:
link1=(0, 0, 0.284), link2=(0.4, 0, 0.284), link3=(0.75, 0, 0.284),
link4=(0.75, 0, -0.066), link5=(0.75, 0, -0.066), link6=(0.75, 0, -0.166)
— see cad/freecad/README.md for the actual commands used to reproduce
this. That check validates the TRANSFORM MATH only, not anything about
whether FreeCAD's actual Part::Cylinder/Placement API calls below are
correct — no FreeCAD install was available to run this script for real
(see README.md).

Output: cad/freecad/generated_arm.FCStd (native FreeCAD, if run from
FreeCAD's own Python console with a document context) and
cad/freecad/generated_arm.step (STEP export, portable to
SolidWorks/Fusion/Onshape per documentation/design-baseline.md §19.7's
CAD tool comparison — STEP is the actual interchange format that matters
across that comparison, which is why this script targets it rather than
a FreeCAD-only output).
"""
import math
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "tools"))
from robot_params import DH_TABLE, JOINT_NAMES  # noqa: E402

# Same illustrative constants as generate_mjcf.py -- reused verbatim, not
# reinvented, so this stays visually/dimensionally consistent with the
# other three representations rather than becoming a fifth set of numbers.
BASE_RADIUS_M = 0.09
BASE_HEIGHT_M = 0.05
LARGE_LINK_RADIUS_M = 0.06
SMALL_LINK_RADIUS_M = 0.035
LARGE_JOINT_HOUSING_RADIUS_M = 0.09   # illustrative -- housings modeled somewhat larger than the link they join
SMALL_JOINT_HOUSING_RADIUS_M = 0.05   # illustrative
JOINT_HOUSING_LENGTH_M = 0.06         # illustrative


def rot_x(angle_rad):
    c, s = math.cos(angle_rad), math.sin(angle_rad)
    return [[1, 0, 0], [0, c, -s], [0, s, c]]


def mat_vec(m, v):
    return [sum(m[i][j] * v[j] for j in range(3)) for i in range(3)]


def mat_mul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


def build_transform_chain():
    """Returns a list of (position_m, rotation_3x3) tuples, one per link,
    in the WORLD frame -- the same DH chain composition
    generate_mjcf.py's body pos/axisangle nesting encodes, just carried
    out here as explicit matrix math instead of relying on MJCF's own
    body-nesting semantics to do the composition implicitly. Used both to
    place the CAD primitives below AND as the cross-check computation
    described in this file's module docstring.
    """
    frames = []
    position = [0.0, 0.0, 0.0]
    rotation = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]  # identity -- world frame at the base
    for (a, alpha, d) in DH_TABLE:
        # At theta=0 (home pose, per this script's "reference pose"
        # framing in the module docstring), the DH offset is a pure
        # translation (a, 0, d) in the current frame, then a rotation by
        # alpha about the current frame's local X axis -- exactly
        # generate_mjcf.py's body pos=f"{a} 0 {d}" axisangle=f"1 0 0 {alpha}",
        # restated as matrix math.
        offset_world = mat_vec(rotation, [a, 0.0, d])
        position = [position[i] + offset_world[i] for i in range(3)]
        rotation = mat_mul(rotation, rot_x(alpha))
        frames.append((list(position), [row[:] for row in rotation]))
    return frames


def rotation_matrix_to_freecad_placement(FreeCAD, position, rotation):
    """Converts a 3x3 rotation matrix + position into a FreeCAD Placement
    via axis-angle extraction -- FreeCAD's Rotation constructor accepts
    (axis, angle_degrees) or a rotation matrix directly depending on
    version; this uses the matrix constructor form
    (FreeCAD.Rotation(Matrix)) as the more version-stable choice, per
    documented FreeCAD API conventions. NOT verified against a real
    FreeCAD install -- see README.md.
    """
    m = FreeCAD.Matrix()
    for i in range(3):
        for j in range(3):
            m.A[i * 4 + j] = rotation[i][j]
    placement = FreeCAD.Placement()
    placement.Base = FreeCAD.Vector(*position)
    placement.Rotation = FreeCAD.Rotation(m)
    return placement


def main():
    try:
        import FreeCAD
        import Part
    except ImportError:
        raise RuntimeError(
            "generate_arm_cad.py must be run inside FreeCAD (its Python console, or "
            "`freecadcmd generate_arm_cad.py`) -- the FreeCAD/Part modules are not installable "
            "via pip, they come from a FreeCAD installation. See README.md."
        )

    doc = FreeCAD.newDocument("modular_arm_msme")

    base = doc.addObject("Part::Cylinder", "base_link")
    base.Radius = BASE_RADIUS_M * 1000  # FreeCAD's default unit is mm; DH_TABLE etc. are in meters throughout
    base.Height = BASE_HEIGHT_M * 1000

    frames = build_transform_chain()
    prev_position = [0.0, 0.0, 0.0]
    for i, ((a, alpha, d), (position, rotation), name) in enumerate(zip(DH_TABLE, frames, JOINT_NAMES)):
        is_large = i < 3
        housing_radius = (LARGE_JOINT_HOUSING_RADIUS_M if is_large else SMALL_JOINT_HOUSING_RADIUS_M) * 1000
        link_radius = (LARGE_LINK_RADIUS_M if is_large else SMALL_LINK_RADIUS_M) * 1000
        length = max(abs(a), abs(d), 0.05) * 1000

        housing = doc.addObject("Part::Cylinder", f"joint{i+1}_{name}_housing")
        housing.Radius = housing_radius
        housing.Height = JOINT_HOUSING_LENGTH_M * 1000
        housing.Placement = rotation_matrix_to_freecad_placement(FreeCAD, prev_position, [[1, 0, 0], [0, 1, 0], [0, 0, 1]])

        link = doc.addObject("Part::Cylinder", f"link{i+1}")
        link.Radius = link_radius
        link.Height = length
        link.Placement = rotation_matrix_to_freecad_placement(FreeCAD, position, rotation)

        prev_position = position

    doc.recompute()

    script_dir = os.path.dirname(os.path.abspath(__file__))
    fcstd_path = os.path.join(script_dir, "generated_arm.FCStd")
    step_path = os.path.join(script_dir, "generated_arm.step")
    doc.saveAs(fcstd_path)
    Part.export(doc.Objects, step_path)
    print(f"Wrote {fcstd_path}")
    print(f"Wrote {step_path}")


if __name__ == "__main__":
    main()
