// server.js
// The part of this Electron app worth testing independently of the GUI:
// serves dashboard/frontend's built static bundle and proxies /api (REST)
// and /ws (WebSocket) to the real dashboard/backend — replicating in a
// packaged desktop app exactly what dashboard/frontend/vite.config.ts's dev
// proxy does during development, so the SAME tested React bundle
// (dashboard/frontend) runs unmodified inside this native window.
'use strict';
const path = require('path');
const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');

function createServer({ backendUrl = 'http://127.0.0.1:8000', distPath } = {}) {
  const resolvedDistPath = distPath || path.join(__dirname, '..', '..', 'dashboard', 'frontend', 'dist');

  const app = express();

  app.use(
    '/api',
    createProxyMiddleware({
      target: backendUrl,
      changeOrigin: true,
      // Express strips the '/api' mount prefix before this middleware sees
      // req.url, and this version of http-proxy-middleware forwards
      // whatever req.url already is rather than req.originalUrl — without
      // this, dashboard/backend (whose routes are literally /api/config,
      // /api/telemetry, etc.) received "/config" instead of "/api/config"
      // and every request 404'd. Confirmed with a debug script that logged
      // what the mock backend actually received before this fix existed.
      pathRewrite: (path) => `/api${path}`,
    }),
  );
  const wsProxy = createProxyMiddleware({
    target: backendUrl.replace(/^http/, 'ws'),
    changeOrigin: true,
    ws: true,
    // NOTE: deliberately NO pathRewrite here, unlike the /api proxy above.
    // The raw 'upgrade' TCP event (wired via attachWebSocketProxy below)
    // bypasses Express's routing entirely, so req.url still has the full,
    // unstripped original path ('/ws/telemetry') by the time this proxy
    // sees it — adding '/ws' again here produced '/ws/ws/telemetry' and
    // broke every WS connection. Confirmed by directly logging what the
    // mock backend received before this fix existed.
  });
  app.use('/ws', wsProxy);

  app.use(express.static(resolvedDistPath));
  // SPA fallback: any non-API route serves index.html so client-side routing
  // (if the frontend ever adds any) doesn't 404 on refresh. Using a plain
  // app.use() catch-all rather than app.get('*', ...) — Express 5's
  // path-to-regexp no longer accepts a bare '*' pattern (this broke all
  // three tests in test/server.test.js until fixed here).
  app.use((req, res) => {
    res.sendFile(path.join(resolvedDistPath, 'index.html'));
  });

  // Express's app is an HTTP request handler, not a full http.Server — it
  // never sees the raw 'upgrade' event a WebSocket handshake arrives as, so
  // http-proxy-middleware's ws-proxying silently does nothing until the
  // caller wires this handler to the actual server's 'upgrade' event after
  // calling app.listen(). Caught by test/server.test.js's WebSocket test
  // timing out even after the pathRewrite fix above — the request was
  // never reaching the proxy at all, at any path.
  app.attachWebSocketProxy = (server) => {
    server.on('upgrade', wsProxy.upgrade);
  };

  return app;
}

module.exports = { createServer };
