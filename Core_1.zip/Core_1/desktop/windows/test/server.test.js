// test/server.test.js
// Exercises server.js for real: a mock backend (plain http server) stands in
// for dashboard/backend, a temp directory stands in for dashboard/frontend's
// built dist/, and this test confirms static serving, /api proxying, and the
// SPA fallback all actually work — not just that the module loads.
'use strict';
const { test } = require('node:test');
const assert = require('node:assert');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createServer } = require('../server');

function startMockBackend() {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      if (req.url === '/api/config') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ robot: { reach_mm: 850 }, joints: [] }));
        return;
      }
      res.writeHead(404);
      res.end();
    });
    server.listen(0, '127.0.0.1', () => resolve(server));
  });
}

function makeTempDist() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'arm-desktop-test-'));
  fs.writeFileSync(path.join(dir, 'index.html'), '<html><body>Modular Arm Dashboard</body></html>');
  return dir;
}

test('serves the built dashboard index.html for the root route', async () => {
  const distPath = makeTempDist();
  const app = createServer({ backendUrl: 'http://127.0.0.1:1', distPath });
  const server = app.listen(0, '127.0.0.1');
  await new Promise((r) => server.once('listening', r));
  const { port } = server.address();

  const res = await fetch(`http://127.0.0.1:${port}/`);
  const text = await res.text();

  assert.strictEqual(res.status, 200);
  assert.match(text, /Modular Arm Dashboard/);

  server.close();
});

test('proxies /api requests to the configured backend', async () => {
  const backend = await startMockBackend();
  const distPath = makeTempDist();
  const app = createServer({ backendUrl: `http://127.0.0.1:${backend.address().port}`, distPath });
  const server = app.listen(0, '127.0.0.1');
  await new Promise((r) => server.once('listening', r));
  const { port } = server.address();

  const res = await fetch(`http://127.0.0.1:${port}/api/config`);
  const body = await res.json();

  assert.strictEqual(res.status, 200);
  assert.strictEqual(body.robot.reach_mm, 850);

  server.close();
  backend.close();
});

test('falls back to index.html for unknown non-API routes (SPA fallback)', async () => {
  const distPath = makeTempDist();
  const app = createServer({ backendUrl: 'http://127.0.0.1:1', distPath });
  const server = app.listen(0, '127.0.0.1');
  await new Promise((r) => server.once('listening', r));
  const { port } = server.address();

  const res = await fetch(`http://127.0.0.1:${port}/some/client/route`);
  const text = await res.text();

  assert.strictEqual(res.status, 200);
  assert.match(text, /Modular Arm Dashboard/);

  server.close();
});

test('proxies WebSocket connections to the backend at the correct path', async () => {
  const WebSocket = require('ws');

  // Mock backend WS server — mounted at /ws/telemetry, exactly matching
  // dashboard/backend/main.py's real route, so this test would have caught
  // the path-stripping bug fixed above (it connects to /telemetry with the
  // bug present, and this mock server would never see that connection).
  const wsServer = new WebSocket.Server({ noServer: true });
  const backend = http.createServer();
  backend.on('upgrade', (req, socket, head) => {
    if (req.url !== '/ws/telemetry') {
      socket.destroy();
      return;
    }
    wsServer.handleUpgrade(req, socket, head, (ws) => {
      ws.send(JSON.stringify({ safety: { state: 'Idle' } }));
    });
  });
  await new Promise((r) => backend.listen(0, '127.0.0.1', r));

  const distPath = makeTempDist();
  const app = createServer({ backendUrl: `http://127.0.0.1:${backend.address().port}`, distPath });
  const server = app.listen(0, '127.0.0.1');
  app.attachWebSocketProxy(server);
  await new Promise((r) => server.once('listening', r));
  const { port } = server.address();

  const client = new WebSocket(`ws://127.0.0.1:${port}/ws/telemetry`);
  const received = await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error('No message received within 3s')), 3000);
    client.on('message', (data) => {
      clearTimeout(timeout);
      resolve(JSON.parse(data.toString()));
    });
    client.on('error', (e) => {
      clearTimeout(timeout);
      reject(e);
    });
  });

  assert.strictEqual(received.safety.state, 'Idle');

  client.close();
  server.close();
  backend.close();
});
