# desktop/windows — native desktop operator app

An Electron desktop app implementing the same operator dashboard as
`dashboard/frontend` — but as a native Windows/Mac/Linux window, not a
browser tab. Deliberately built to **reuse** the already-tested
`dashboard/frontend` React bundle unmodified, rather than reimplementing the
UI: this app is a thin native shell plus a small local server
(`server.js`) that serves that bundle and proxies its API/WebSocket calls to
the real `dashboard/backend`.

## This is the most thoroughly tested piece in the whole project

Unlike the Android app (blocked entirely by unreachable Android/Gradle
infrastructure), Electron's own binaries are fetched from GitHub releases,
which **were** reachable here — so this got real, escalating verification:

1. **Unit tests** (`test/server.test.js`, Node's built-in test runner, zero
   extra test-framework dependency): static file serving, `/api` proxying,
   SPA fallback, and WebSocket proxying — 4/4 passing.
2. **Full integration test**: the real built `dashboard/frontend` bundle,
   served through `server.js`, proxying to a real running
   `dashboard/backend` — confirmed real config/telemetry data flows through
   correctly via `curl`.
3. **The actual Electron app launched** under Xvfb (a virtual X display,
   installed via `apt-get install xvfb`) and **screenshotted** — not just
   "the process didn't crash" but an actual rendered screenshot showing live
   data. See the two screenshots below.
4. **The actual packaged binary** (`electron-builder --win --dir` and
   `--linux --dir`) — real cross-platform packaging, not just dev-mode
   `electron .`. The Linux-packaged binary was run directly (not through
   `npx electron`) and confirmed to start correctly and log the right proxy
   configuration.

## Three real bugs found and fixed during this process

**Bug 1 — `/api` proxy stripped its own prefix.** Express strips a
middleware's mount path (`/api`) from `req.url` before the middleware sees
it; this version of `http-proxy-middleware` forwards whatever `req.url`
already is, so `dashboard/backend`'s actual route `/api/config` was reached
as `/config` and 404'd. Fixed with `pathRewrite: (path) => `/api${path}``.
Caught by `test/server.test.js`'s second test, and confirmed with a
standalone debug script that logged exactly what the mock backend received
before vs. after the fix.

**Bug 2 — WebSocket proxying needed manual wiring, and then double-prefixed
the path.** Express's `app` only handles HTTP `request` events, not the raw
`upgrade` event a WebSocket handshake arrives as — `ws: true` on the proxy
middleware does nothing unless the underlying `http.Server`'s `'upgrade'`
event is explicitly wired to it (`server.on('upgrade', wsProxy.upgrade)`,
now exposed as `app.attachWebSocketProxy(server)`). Once wired, the *same*
`pathRewrite` fix from Bug 1, applied here too, turned out to be wrong in
this context: the raw `upgrade` event bypasses Express's path-stripping
entirely, so the original `/ws/telemetry` path was already intact, and
adding `/ws` again produced `/ws/ws/telemetry`. Caught in stages: first via
a screenshot showing "live" (the handshake succeeded, but at the wrong
path/against nothing that would ever respond, so no data ever arrived) with
an empty telemetry table; then precisely diagnosed with a debug script that
logged the mock backend's received upgrade path; fixed by removing the
`pathRewrite` for the WS proxy specifically. See `server.js`'s comments for
both fixes in place, and `test/server.test.js`'s WebSocket test, which would
catch a regression of either bug.

**Bug 3 — startup flash of a blank window before content loads.** Reported
directly by the project owner running the packaged app: on launch, the
window shows a blank flash before the (correctly-rendering) API key screen
appears. Cause: `BrowserWindow` defaults to `show: true`, so Electron
displays the window immediately on creation, then it sits visibly blank
while `loadURL()`'s page loads, parses its JS bundle, and React mounts —
all of which takes long enough to see, especially on first launch before
any caching. Fixed with the standard Electron pattern: `show: false` at
construction, `backgroundColor: '#fafafa'` (matching
`dashboard/frontend/src/index.css`'s actual body background, so even the
brief window before the real content paints shows the right color instead
of Electron's own default), and `mainWindow.once('ready-to-show', () =>
mainWindow.show())` to defer showing the window until the renderer has
something real to display.

**Confidence level, honestly lower than Bugs 1/2's:** those two were caught
and confirmed via the actual escalating verification described above
(unit tests → integration test → real Xvfb-screenshotted launch → packaged
binary). This fix was written from the bug report plus a code read —
`show`/`backgroundColor`/`ready-to-show` are basic, long-stable Electron
`BrowserWindow` API (high confidence in the pattern itself), but there was
no Electron install, no Xvfb, and no network to get either in the
environment this fix was written in, so unlike Bugs 1/2 this one only got
`node --check main.js` (syntax validation), not a real running/
screenshotted confirmation. Worth an actual launch-and-look before
considering this closed.

### Screenshot evidence

**Before the WebSocket fix** (`screenshots/before_ws_fix.png`) — "live"
indicator shows connected, but `State: Unknown` and an empty telemetry
table, because the handshake succeeded without ever reaching the real
backend route.

**After the fix** (`screenshots/after_ws_fix.png`) — `State: Idle`, all 6
joints showing real telemetry (position, velocity, current, torque,
temperature all populated from the live simulated plant).

Both are real screenshots (`webContents.capturePage()`), not mockups —
captured from this exact `main.js`/`server.js` running under Electron with
a live `dashboard/backend` behind it.

## Run

```bash
npm install
npm run build-frontend      # builds dashboard/frontend/dist
npm start                   # launches the Electron app (needs a display;
                             # use `xvfb-run npm start` in a headless env)
```

Point it at a real backend first: `cd ../../dashboard/backend && ./build.sh
&& uvicorn main:app &`, then `npm start` from here (default backend URL is
`http://127.0.0.1:8000`, override with `ARM_BACKEND_URL`).

## Package (Windows/Mac/Linux)

```bash
npm run dist          # electron-builder, uses the "build" config in package.json
```

This genuinely produces a real Windows `.exe` (PE32+, confirmed via `file`)
here — Electron ships prebuilt per-platform binaries fetched from GitHub
releases, so cross-packaging a `--dir` (unpacked) build doesn't need Wine or
a Windows machine. What I did **not** verify: the NSIS installer step
(`electron-builder --win` without `--dir`) traditionally needs Wine on
Linux to build the installer wrapper — untested here. And obviously, I
can't run a `.exe` in this environment to confirm the Windows binary
actually launches correctly on real Windows, even though its Linux sibling
(built from the identical source) was screenshotted working.
