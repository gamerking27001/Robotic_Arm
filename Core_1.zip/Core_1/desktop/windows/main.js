// main.js — Electron main process. Deliberately thin: all the logic worth
// testing lives in server.js (tested independently, see test/server.test.js).
// This file's only job is to start that server on a local port and open a
// native window pointed at it.
'use strict';
const path = require('path');
const { app, BrowserWindow, Menu } = require('electron');
const { createServer } = require('./server');

const BACKEND_URL = process.env.ARM_BACKEND_URL || 'http://127.0.0.1:8000';
const LOCAL_PORT = process.env.ARM_LOCAL_PORT ? parseInt(process.env.ARM_LOCAL_PORT, 10) : 0; // 0 = OS picks a free port

// In a packaged app, dashboard/frontend's built dist/ is copied in via
// electron-builder's `extraResources` config (package.json's "build"
// section) since it lives outside this project's own directory tree and
// electron-builder's default `files` inclusion won't reach it (confirmed by
// inspecting the packaged app.asar — the first attempt at this omitted the
// frontend bundle entirely). In dev, server.js's own default (a relative
// path back to ../../dashboard/frontend/dist) is used instead.
const DIST_PATH = app.isPackaged ? path.join(process.resourcesPath, 'dashboard-frontend-dist') : undefined;

let mainWindow = null;
let httpServer = null;

function createWindow(port) {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    title: 'Modular Arm — Operator Dashboard',
    // show:false + the ready-to-show listener below is the standard fix
    // for Electron's "flash of blank/white window" on startup: without
    // this, the window appears immediately (Electron's default) with its
    // native default background, then sits visibly blank while
    // loadURL()'s page loads, parses its JS bundle, and React mounts and
    // runs its first effects (including the ApiKeyGate/dashboard
    // decision in dashboard/frontend/src/App.tsx) -- all of which takes
    // long enough to see. backgroundColor matches
    // dashboard/frontend/src/index.css's actual body background (#fafafa)
    // so that even the brief window between 'ready-to-show' firing and
    // the real page content finishing its paint shows the right color
    // instead of Electron's own default (white or black depending on
    // platform/theme), rather than trading a color-mismatch flash for a
    // blank-window flash.
    show: false,
    backgroundColor: '#fafafa',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });
  mainWindow.loadURL(`http://127.0.0.1:${port}`);
  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  const expressApp = createServer({ backendUrl: BACKEND_URL, distPath: DIST_PATH });
  httpServer = expressApp.listen(LOCAL_PORT, '127.0.0.1', () => {
    const { port } = httpServer.address();
    console.log(`Local server listening on 127.0.0.1:${port}, proxying to ${BACKEND_URL}`);
    createWindow(port);
  });
  expressApp.attachWebSocketProxy(httpServer);

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0 && httpServer) {
      createWindow(httpServer.address().port);
    }
  });
});

app.on('window-all-closed', () => {
  if (httpServer) httpServer.close();
  if (process.platform !== 'darwin') app.quit();
});
