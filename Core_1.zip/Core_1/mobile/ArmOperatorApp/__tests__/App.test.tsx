/**
 * @format
 */
import React from 'react';
import ReactTestRenderer, { act } from 'react-test-renderer';
import App from '../App';

const CONFIG_RESPONSE = {
  robot: { payload_nominal_kg: 5.0, payload_peak_kg: 8.0, reach_mm: 850.0 },
  joints: [{ name: 'Waist', soft_limit_min_deg: -170, soft_limit_max_deg: 170 }],
};

const JOINT_NAMES = ['waist', 'shoulder', 'elbow', 'wrist_roll', 'wrist_pitch', 'flange_roll'];

function telemetryResponse(overrides: Partial<{ position: number; fault: boolean }> = {}) {
  const joints = JOINT_NAMES.map((name) => ({
    joint_name: name,
    position_deg: overrides.position ?? 0,
    velocity_deg_s: 0,
    current_a: 1.2,
    torque_estimate_nm: 0.5,
    winding_temp_c: 25,
    sto_active: false,
    fault: overrides.fault ?? false,
  }));
  return { joints, move_active: false, elapsed_move_time_s: 0 };
}

function safetyResponse(overrides: Partial<{ state: string; any_fault: boolean; collision: boolean }> = {}) {
  return {
    state: overrides.state ?? 'Idle',
    estop_pressed: false,
    sto_required: false,
    collision_suspected: overrides.collision ?? false,
    overcurrent: false,
    overtemperature: false,
    soft_limit_violation: false,
    hard_limit_violation: false,
    any_fault: overrides.any_fault ?? false,
  };
}

function mockFetchSequence(responses: Record<string, unknown>) {
  globalThis.fetch = jest.fn((url: string) => {
    for (const [path, body] of Object.entries(responses)) {
      if (url.includes(path)) {
        return Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve(body) } as Response);
      }
    }
    return Promise.resolve({ ok: false, status: 404, statusText: 'not found', text: () => Promise.resolve('') } as Response);
  }) as unknown as typeof fetch;
}

function findByTestId(root: ReactTestRenderer.ReactTestRenderer, testID: string) {
  const found = root.root.findAllByProps({ testID }).at(0);
  if (!found) throw new Error(`No element with testID="${testID}" found`);
  return found;
}

test('renders correctly and fetches config on mount', async () => {
  mockFetchSequence({
    '/api/config': CONFIG_RESPONSE,
    '/api/telemetry': telemetryResponse(),
    '/api/safety': safetyResponse(),
  });

  let root!: ReactTestRenderer.ReactTestRenderer;
  await act(async () => {
    root = ReactTestRenderer.create(<App />);
  });

  expect(findByTestId(root, 'connection-indicator')).toBeTruthy();
  expect(findByTestId(root, 'safety-state').props.children.join('')).toContain('Idle');
  await act(async () => { root.unmount(); });
});

test('shows disconnected state when the backend is unreachable', async () => {
  globalThis.fetch = jest.fn(() => Promise.reject(new Error('network error'))) as unknown as typeof fetch;

  let root!: ReactTestRenderer.ReactTestRenderer;
  await act(async () => {
    root = ReactTestRenderer.create(<App />);
  });

  const indicator = findByTestId(root, 'connection-indicator');
  expect(indicator?.props.children).toBe('disconnected');
  await act(async () => { root.unmount(); });
});

test('displays a fault reason when the safety endpoint reports collision_suspected', async () => {
  mockFetchSequence({
    '/api/config': CONFIG_RESPONSE,
    '/api/telemetry': telemetryResponse({ fault: true }),
    '/api/safety': safetyResponse({ state: 'Fault', any_fault: true, collision: true }),
  });

  let root!: ReactTestRenderer.ReactTestRenderer;
  await act(async () => {
    root = ReactTestRenderer.create(<App />);
  });

  const stateText = findByTestId(root, 'safety-state');
  expect(stateText?.props.children.join('')).toContain('Fault');

  const allText = root.root.findAllByType(require('react-native').Text).map((n) => n.props.children).flat();
  expect(allText.some((c) => typeof c === 'string' && c.includes('Collision suspected'))).toBe(true);
  await act(async () => { root.unmount(); });
});

test('E-stop trigger button calls the trigger endpoint', async () => {
  const calledUrls: string[] = [];
  globalThis.fetch = jest.fn((url: string, opts?: RequestInit) => {
    calledUrls.push(url);
    if (url.includes('/api/config')) return Promise.resolve({ ok: true, json: () => Promise.resolve(CONFIG_RESPONSE) } as Response);
    if (url.includes('/api/telemetry')) return Promise.resolve({ ok: true, json: () => Promise.resolve(telemetryResponse()) } as Response);
    if (url.includes('/api/safety')) return Promise.resolve({ ok: true, json: () => Promise.resolve(safetyResponse()) } as Response);
    if (url.includes('/api/estop/trigger')) {
      expect(opts?.method).toBe('POST');
      return Promise.resolve({ ok: true, json: () => Promise.resolve({ accepted: true }) } as Response);
    }
    return Promise.resolve({ ok: false, status: 404, statusText: 'nf', text: () => Promise.resolve('') } as Response);
  }) as unknown as typeof fetch;

  let root!: ReactTestRenderer.ReactTestRenderer;
  await act(async () => {
    root = ReactTestRenderer.create(<App />);
  });

  const button = findByTestId(root, 'estop-trigger');
  await act(async () => {
    button?.props.onPress();
  });

  expect(calledUrls.some((u) => u.includes('/api/estop/trigger'))).toBe(true);
  await act(async () => { root.unmount(); });
});
