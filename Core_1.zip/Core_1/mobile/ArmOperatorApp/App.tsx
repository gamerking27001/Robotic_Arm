/**
 * Modular Arm — Android operator dashboard.
 * Same functionality as dashboard/frontend (telemetry, safety banner, move
 * controls, E-stop) but as a native app talking to dashboard/backend's REST
 * API over an explicit host — see src/api.ts and README.md.
 *
 * @format
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import {
  ArmApiClient,
  DEFAULT_BASE_URL,
  type ConfigResponse,
  type SafetyStatus,
  type Telemetry,
} from './src/api';

const DEFAULT_TELEMETRY: Telemetry = { joints: [], move_active: false, elapsed_move_time_s: 0 };
const DEFAULT_SAFETY: SafetyStatus = {
  state: 'Unknown',
  estop_pressed: false,
  sto_required: false,
  collision_suspected: false,
  overcurrent: false,
  overtemperature: false,
  soft_limit_violation: false,
  hard_limit_violation: false,
  any_fault: false,
};

function faultReasons(s: SafetyStatus): string[] {
  const reasons: string[] = [];
  if (s.estop_pressed) reasons.push('E-stop pressed');
  if (s.collision_suspected) reasons.push('Collision suspected');
  if (s.overcurrent) reasons.push('Overcurrent');
  if (s.overtemperature) reasons.push('Overtemperature');
  if (s.soft_limit_violation) reasons.push('Soft limit violation');
  if (s.hard_limit_violation) reasons.push('Hard limit violation');
  return reasons;
}

function stateColor(state: string): string {
  if (state === 'EStop' || state === 'Fault') return '#d9534f';
  if (state === 'Running' || state === 'Paused') return '#2b6cb0';
  return '#2f9e44';
}

export default function App() {
  const [baseUrl, setBaseUrl] = useState(DEFAULT_BASE_URL);
  const [apiKey, setApiKey] = useState('');
  const clientRef = useRef(new ArmApiClient(DEFAULT_BASE_URL));
  const [config, setConfig] = useState<ConfigResponse | null>(null);
  const [telemetry, setTelemetry] = useState<Telemetry>(DEFAULT_TELEMETRY);
  const [safety, setSafety] = useState<SafetyStatus>(DEFAULT_SAFETY);
  const [connected, setConnected] = useState(false);
  const [targets, setTargets] = useState<string[]>(Array(6).fill('0'));
  const [lastError, setLastError] = useState<string | null>(null);

  useEffect(() => {
    clientRef.current.setBaseUrl(baseUrl);
  }, [baseUrl]);

  useEffect(() => {
    clientRef.current.setApiKey(apiKey);
  }, [apiKey]);

  const poll = useCallback(async () => {
    try {
      const [t, s] = await Promise.all([clientRef.current.fetchTelemetry(), clientRef.current.fetchSafety()]);
      setTelemetry(t);
      setSafety(s);
      setConnected(true);
      setLastError(null);
    } catch (e) {
      setConnected(false);
      setLastError(String(e));
    }
  }, []);

  useEffect(() => {
    clientRef.current
      .fetchConfig()
      .then(setConfig)
      .catch((e) => setLastError(String(e)));
    // Polling rather than a WebSocket — see README's "What's simplified"
    // section for why.
    const interval = setInterval(poll, 500);
    poll();
    return () => clearInterval(interval);
  }, [poll]);

  async function handleMove() {
    try {
      await clientRef.current.postMove(targets.map(Number), true);
    } catch (e) {
      setLastError(String(e));
    }
  }

  async function handleEstopTrigger() {
    try {
      await clientRef.current.postEstopTrigger('mobile app button');
    } catch (e) {
      setLastError(String(e));
    }
  }

  async function handleEstopReset() {
    try {
      await clientRef.current.postEstopReset('mobile-operator');
    } catch (e) {
      setLastError(String(e));
    }
  }

  const reasons = faultReasons(safety);

  return (
    <SafeAreaView style={styles.safeArea} testID="app-root">
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.title}>Modular Arm — Operator</Text>

        <View style={styles.section}>
          <Text style={styles.label}>Backend URL</Text>
          <TextInput style={styles.input} value={baseUrl} onChangeText={setBaseUrl} autoCapitalize="none" />
          <Text style={styles.label}>API Key</Text>
          <TextInput
            style={styles.input}
            value={apiKey}
            onChangeText={setApiKey}
            autoCapitalize="none"
            secureTextEntry
            placeholder="required -- see dashboard/backend README"
            testID="api-key-input"
          />
          <Text style={connected ? styles.statusOk : styles.statusBad} testID="connection-indicator">
            {connected ? 'connected' : 'disconnected'}
          </Text>
        </View>

        <View style={[styles.section, { borderLeftColor: stateColor(safety.state), borderLeftWidth: 6 }]}>
          <Text style={styles.stateText} testID="safety-state">
            State: {safety.state}
          </Text>
          {reasons.map((r) => (
            <Text key={r} style={styles.faultText}>
              • {r}
            </Text>
          ))}
          <View style={styles.buttonRow}>
            <TouchableOpacity style={styles.dangerButton} onPress={handleEstopTrigger} testID="estop-trigger">
              <Text style={styles.buttonText}>Trigger E-stop</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.secondaryButton} onPress={handleEstopReset} testID="estop-reset">
              <Text style={styles.buttonText}>Reset E-stop</Text>
            </TouchableOpacity>
          </View>
        </View>

        {config && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Robot Spec</Text>
            <Text>Payload: {config.robot.payload_nominal_kg} / {config.robot.payload_peak_kg} kg</Text>
            <Text>Reach: {config.robot.reach_mm} mm</Text>
          </View>
        )}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Joint Telemetry</Text>
          {telemetry.joints.length === 0 && <ActivityIndicator />}
          {telemetry.joints.map((j, i) => (
            <View key={j.joint_name} style={styles.jointRow} testID={`joint-row-${i}`}>
              <Text style={styles.jointName}>{j.joint_name}</Text>
              <Text>{j.position_deg.toFixed(1)}°</Text>
              <Text>{j.current_a.toFixed(2)}A</Text>
              <Text style={j.fault ? styles.faultText : undefined}>{j.fault ? 'FAULT' : 'ok'}</Text>
              <TextInput
                style={styles.targetInput}
                keyboardType="numeric"
                value={targets[i]}
                onChangeText={(v) => {
                  const next = [...targets];
                  next[i] = v;
                  setTargets(next);
                }}
              />
            </View>
          ))}
          <TouchableOpacity
            style={styles.primaryButton}
            onPress={handleMove}
            disabled={telemetry.move_active}
            testID="send-move">
            <Text style={styles.buttonText}>
              {telemetry.move_active ? `Moving (t=${telemetry.elapsed_move_time_s.toFixed(2)}s)` : 'Send Move'}
            </Text>
          </TouchableOpacity>
        </View>

        {lastError && (
          <Text style={styles.errorText} testID="error-text">
            {lastError}
          </Text>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#fafafa' },
  scrollContent: { padding: 16 },
  title: { fontSize: 20, fontWeight: '700', marginBottom: 12 },
  section: { backgroundColor: 'white', borderRadius: 8, padding: 12, marginBottom: 12 },
  sectionTitle: { fontWeight: '700', marginBottom: 6 },
  label: { fontSize: 12, color: '#666' },
  input: { borderWidth: 1, borderColor: '#ccc', borderRadius: 4, padding: 6, marginVertical: 4 },
  statusOk: { color: '#2f9e44', fontWeight: '600' },
  statusBad: { color: '#d9534f', fontWeight: '600' },
  stateText: { fontSize: 16, fontWeight: '700' },
  faultText: { color: '#d9534f' },
  buttonRow: { flexDirection: 'row', gap: 8, marginTop: 8 },
  dangerButton: { backgroundColor: '#d9534f', padding: 10, borderRadius: 6 },
  secondaryButton: { backgroundColor: '#6c757d', padding: 10, borderRadius: 6 },
  primaryButton: { backgroundColor: '#2b6cb0', padding: 10, borderRadius: 6, marginTop: 8, alignItems: 'center' },
  buttonText: { color: 'white', fontWeight: '600' },
  jointRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 4 },
  jointName: { fontWeight: '600', width: 70 },
  targetInput: { borderWidth: 1, borderColor: '#ccc', borderRadius: 4, width: 50, padding: 4 },
  errorText: { color: '#d9534f', fontSize: 12 },
});
