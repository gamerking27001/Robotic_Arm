// config/config_loader.hpp
// §20.5 "Configuration File Structure (Representative)" and §11.7:
// "A configuration system stores robot geometry (DH parameters, link
// masses/inertias), calibration offsets, and joint-specific tuning ... in
// versioned configuration files, loaded at controller startup and re-loaded
// automatically after a module swap."
//
// This loader parses the specific subset of YAML used by
// configs/arm_variant_standard.yaml (a hand-rolled, dependency-free reader —
// intentionally not a general YAML parser, to keep the core stack
// dependency-free per README).
#pragma once

#include <array>
#include <optional>
#include <string>
#include <string_view>

#include "core/robot_config.hpp"

namespace arm::config_io {

struct JointLimitEntry {
    double min_deg = 0.0;
    double max_deg = 0.0;
    double max_speed_deg_s = 0.0;
};

struct ArmVariantConfig {
    std::string robot_variant;
    std::array<config::DHRow, config::kNumJoints> dh_parameters{};
    std::array<JointLimitEntry, config::kNumJoints> joint_limits{};
    std::string calibration_offsets_file;
    std::string default_tool;
    std::string tool_library_path;
};

// Parses a file matching the §20.5 structure. Returns std::nullopt (rather
// than throwing) on a malformed file so callers can fall back to the
// compiled-in defaults in robot_config.hpp.
[[nodiscard]] std::optional<ArmVariantConfig> loadArmVariantConfig(std::string_view path);

}  // namespace arm::config_io
