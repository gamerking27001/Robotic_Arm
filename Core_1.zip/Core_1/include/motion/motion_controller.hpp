// motion/motion_controller.hpp
// §11.3: "The host-side motion controller consumes joint-space or
// Cartesian-space trajectory targets and performs real-time interpolation,
// publishing per-joint setpoints to the CAN bus at the joint-drive update
// rate."
#pragma once

#include <array>
#include <memory>
#include <vector>

#include "hal/joint_interface.hpp"
#include "kinematics/dh_kinematics.hpp"
#include "motion/trajectory_profile.hpp"

namespace arm::motion {

using JointAngles = kinematics::JointAngles;

// One point-to-point joint-space move, per-joint trajectory profiles are
// generated so every joint arrives together (longest-joint-time governs the
// overall move duration — synchronized multi-axis move).
struct JointSpaceMove {
    JointAngles start;
    JointAngles target;
    bool use_s_curve = config::kMotionDefaults.use_s_curve_default;  // §13.3 recommendation
};

class MotionController {
public:
    MotionController(std::array<hal::JointInterface*, config::kNumJoints> joints, double control_loop_hz =
                                                                                       config::kMotionDefaults
                                                                                           .control_loop_hz);

    // Builds per-joint profiles for the move (§13.4 pipeline: TaskCommand ->
    // TrajectoryProfileGenerator), synchronizing all axes to the slowest
    // joint's duration so the TCP path arrives coherently.
    void beginMove(const JointSpaceMove& move);

    // Advances the real-time interpolator by one control-loop tick and
    // publishes per-joint setpoints (§11.3) to each JointInterface. Returns
    // false once the active move has completed.
    bool tick();

    [[nodiscard]] bool isMoveActive() const { return move_active_; }
    [[nodiscard]] double elapsedTime() const { return elapsed_s_; }

private:
    std::array<hal::JointInterface*, config::kNumJoints> joints_;
    double dt_s_;
    std::array<std::unique_ptr<TrajectoryProfile>, config::kNumJoints> profiles_;
    bool move_active_ = false;
    double elapsed_s_ = 0.0;
    double move_duration_s_ = 0.0;
};

}  // namespace arm::motion
