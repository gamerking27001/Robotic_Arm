// motion/trajectory_profile.hpp
// §13.3 Motion Profiles: Trapezoidal (default general-purpose) and S-Curve
// (jerk-limited, recommended system default per §13.3's stated tradeoff).
// §13.4 Motion Control Pipeline: TaskCommand -> PathPlanner -> Trajectory
// Profile Generator -> Real-Time Interpolator -> Per-Joint Setpoints.
#pragma once

#include <memory>
#include <vector>

namespace arm::motion {

// Single-axis kinematic state at time t, sampled by the real-time interpolator
// (§11.3) and converted into per-joint setpoints.
struct KinematicSample {
    double time_s = 0.0;
    double position = 0.0;      // same units as start/end (rad for joint-space, m for Cartesian)
    double velocity = 0.0;
    double acceleration = 0.0;
    double jerk = 0.0;           // 0 for trapezoidal (discontinuous accel), populated for S-curve
};

struct MotionLimits {
    double max_velocity;       // units/s
    double max_acceleration;   // units/s^2
    double max_jerk;            // units/s^3 (S-curve only)
};

// Abstract single-axis profile — the "TrajectoryProfileGenerator" box in
// §13.4's pipeline diagram.
class TrajectoryProfile {
public:
    virtual ~TrajectoryProfile() = default;
    [[nodiscard]] virtual double duration() const = 0;
    [[nodiscard]] virtual KinematicSample sample(double t) const = 0;
};

// §13.3: "Default profile for general pick-place moves."
class TrapezoidalProfile final : public TrajectoryProfile {
public:
    TrapezoidalProfile(double start, double end, const MotionLimits& limits);
    [[nodiscard]] double duration() const override { return total_time_; }
    [[nodiscard]] KinematicSample sample(double t) const override;

private:
    double start_, end_, distance_, direction_;
    double v_max_, a_max_;
    double t_accel_, t_cruise_, t_decel_, total_time_;
    double cruise_velocity_;
};

// §13.3: "Recommended for payload-sensitive or vibration-sensitive tasks" —
// and per §13.3's recommendation, this is the system-default profile.
// Implements a symmetric 7-segment jerk-limited S-curve
// (jerk-up / const-accel / jerk-down / cruise / jerk-down / const-decel / jerk-up).
class SCurveProfile final : public TrajectoryProfile {
public:
    SCurveProfile(double start, double end, const MotionLimits& limits);
    [[nodiscard]] double duration() const override { return total_time_; }
    [[nodiscard]] KinematicSample sample(double t) const override;

private:
    struct Segment {
        double t_end;      // cumulative end time of this segment
        double j;           // constant jerk applied during this segment (0 for cruise)
    };
    double start_, end_, distance_, direction_;
    double v_max_, a_max_, j_max_;
    std::vector<Segment> segments_;
    double total_time_;

    void buildProfile();
};

// Factory matching §13.3's recommendation (S-curve default, trapezoidal
// available for simple moves where jerk-limiting isn't needed).
std::unique_ptr<TrajectoryProfile> makeProfile(double start, double end, const MotionLimits& limits,
                                                bool use_s_curve);

}  // namespace arm::motion
