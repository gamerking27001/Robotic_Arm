// hal/can_bus_simulated.hpp
// §9.7: "CAN Bus — Joint-to-controller command/feedback (primary) —
// Deterministic, robust in industrial EMI environments, low wiring
// complexity." §19.5 names CANopen as the concrete protocol.
//
// This is a simulated transport (in-process queue with an injectable latency)
// standing in for the real CANopen stack in `drivers/can_bus` (§18/§20.2),
// so the rest of the codebase can be exercised without physical hardware.
#pragma once

#include <chrono>
#include <cstdint>
#include <deque>
#include <optional>

namespace arm::hal {

enum class CanMessageType : std::uint8_t {
    kPositionSetpoint,
    kVelocitySetpoint,
    kTorqueSetpoint,
    kTelemetryReport,
    kSafeTorqueOffCommand,
    kHeartbeat,
};

struct CanMessage {
    int joint_id = 0;               // 0-5, matches config::JointId
    CanMessageType type{};
    double payload = 0.0;             // setpoint value, or encoded telemetry scalar
    std::chrono::steady_clock::time_point timestamp{};
};

// Minimal deterministic in-process bus: FIFO per direction, with an optional
// simulated one-way latency to approximate real CAN bus timing
// characteristics for scheduling/telemetry-freshness testing.
class SimulatedCanBus {
public:
    explicit SimulatedCanBus(std::chrono::microseconds simulated_latency = std::chrono::microseconds{200})
        : latency_(simulated_latency) {}

    void send(const CanMessage& msg) { queue_.push_back(msg); }

    [[nodiscard]] std::optional<CanMessage> poll() {
        if (queue_.empty()) return std::nullopt;
        CanMessage msg = queue_.front();
        queue_.pop_front();
        return msg;
    }

    [[nodiscard]] std::size_t pending() const { return queue_.size(); }
    [[nodiscard]] std::chrono::microseconds latency() const { return latency_; }

private:
    std::deque<CanMessage> queue_;
    std::chrono::microseconds latency_;
};

}  // namespace arm::hal
