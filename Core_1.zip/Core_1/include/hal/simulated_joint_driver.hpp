// hal/simulated_joint_driver.hpp
// Stand-in for the real per-joint FOC drive stage (§9.3, §20.4's
// `firmware/joint_foc`). Implements JointInterface with a first-order
// position/velocity model bounded by the joint's §6.2 torque/speed envelope,
// so the motion controller and safety FSM can be exercised end-to-end without
// physical hardware.
#pragma once

#include "hal/can_bus_simulated.hpp"
#include "hal/joint_interface.hpp"

namespace arm::hal {

class SimulatedJointDriver final : public JointInterface {
public:
    SimulatedJointDriver(config::JointId id, SimulatedCanBus& bus);

    void setPositionSetpoint(double radians) override;
    void setVelocitySetpoint(double radians_per_sec) override;
    void setTorqueSetpoint(double newton_meters) override;
    [[nodiscard]] JointTelemetry readTelemetry() const override { return telemetry_; }
    bool triggerSafeTorqueOff() override;
    void clearSafeTorqueOff() override;

    [[nodiscard]] const config::JointSpec& spec() const override { return spec_; }

    // Advances the simulated dynamics by dt seconds; called by the motion
    // controller's real-time loop (§11.3) once per control-loop tick.
    void step(double dt_s);

    // Injects an external contact/collision load for demonstrating the §14
    // torque-deviation collision-detection path.
    void injectExternalLoadNm(double load_nm) { external_load_nm_ = load_nm; }

private:
    config::JointId joint_id_;
    const config::JointSpec& spec_;
    SimulatedCanBus& bus_;

    double position_setpoint_rad_ = 0.0;
    double velocity_setpoint_rad_s_ = 0.0;
    double torque_setpoint_nm_ = 0.0;
    double external_load_nm_ = 0.0;

    JointTelemetry telemetry_{};
    bool position_control_active_ = true;
};

}  // namespace arm::hal
