// hal/joint_interface.hpp
// §20.4 "Joint Hardware Abstraction Layer (Representative)" — reproduced here
// as the real interface this codebase builds on, extended with telemetry
// fields drawn from the §7.1 sensor catalogue and §9.3 motor-driver notes.
#pragma once

#include "core/robot_config.hpp"

namespace arm::hal {

// §7.1 sensor catalogue, joint-local subset (absolute/incremental encoder,
// current sensors, temperature sensors — aggregated on the joint's local
// sensing PCB per §7.2 and reported upstream over CAN).
struct JointTelemetry {
    double position_rad = 0.0;      // absolute encoder, 17-20 bit per §7.1
    double velocity_rad_s = 0.0;    // incremental encoder derived
    double current_a = 0.0;          // per-phase current sensor, §7.1 (aggregate magnitude here)
    double torque_estimate_nm = 0.0; // from current + torque sensor (J2/J3 have direct torque sensors, §7.1)
    double winding_temp_c = 0.0;     // §6.4 thermal requirement (100C limit at 45C ambient)
    bool sto_active = false;          // §9.5 Safe Torque Off state
    bool fault = false;
};

// §20.4 JointInterface — the source document's representative snippet only
// declares triggerSafeTorqueOff() with no way to clear it, which is fine for
// a documentation excerpt but not for an operable system: without a clear
// path, any joint that's ever been STO'd stays frozen forever, even after a
// full E-stop reset. clearSafeTorqueOff() is added here to close that gap —
// it mirrors real STO hardware (IEC 61800-5-2), which does have a defined
// re-enable sequence once the STO command is removed.
class JointInterface {
public:
    virtual ~JointInterface() = default;

    virtual void setPositionSetpoint(double radians) = 0;
    virtual void setVelocitySetpoint(double radians_per_sec) = 0;
    virtual void setTorqueSetpoint(double newton_meters) = 0;
    [[nodiscard]] virtual JointTelemetry readTelemetry() const = 0;
    virtual bool triggerSafeTorqueOff() = 0;
    virtual void clearSafeTorqueOff() = 0;

    [[nodiscard]] virtual const config::JointSpec& spec() const = 0;
};

}  // namespace arm::hal
