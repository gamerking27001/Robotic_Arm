// kinematics/ik_solver.hpp
// §11.4: "Inverse kinematics uses a closed-form analytical solution (available
// for this 6-DOF spherical-wrist configuration) with a numerical
// (Jacobian-based) fallback solver for edge cases near singularities."
//
// This implementation follows that architecture literally:
//   1. analyticalSeed()  — closed-form geometric solve (waist/shoulder/elbow
//      via the wrist-center construction, wrist orientation via rotation
//      decomposition) assuming the anthropomorphic shoulder-elbow-spherical
//      wrist layout described in §3.1/§4.
//   2. refine()          — damped-least-squares Jacobian iteration that polishes
//      the seed to the requested tolerance and is the fallback path used near
//      singularities or when the closed-form seed has residual error (e.g.
//      from the link-length assumptions baked into the analytical step).
#pragma once

#include <optional>

#include "core/linalg.hpp"
#include "kinematics/dh_kinematics.hpp"

namespace arm::kinematics {

struct IKOptions {
    int max_refine_iterations = 100;
    double position_tolerance_m = 1e-5;
    double orientation_tolerance_rad = 1e-4;
    double damping_lambda = 1e-3;   // Levenberg-Marquardt-style damping near singularities
    double max_step_rad = 0.35;      // per-iteration joint step clamp, for stability
};

class IKSolver {
public:
    explicit IKSolver(const DHKinematicChain& chain, IKOptions options = {})
        : chain_(chain), options_(options) {}

    // Full solve: analytical seed followed by Jacobian refinement.
    // `seed_angles` (from §11.4's "seed_angles" parameter) is used only if the
    // analytical stage cannot produce a usable geometric seed (e.g. target
    // outside reach), in which case it becomes the refinement starting point.
    [[nodiscard]] std::optional<JointAngles> solve(const core::Transform& target,
                                                     const JointAngles& seed_angles) const;

    // Stage 1 only — closed-form geometric solution.
    [[nodiscard]] std::optional<JointAngles> analyticalSeed(const core::Transform& target) const;

    // Stage 2 only — Newton/damped-least-squares polish from a starting guess.
    [[nodiscard]] std::optional<JointAngles> refine(const core::Transform& target,
                                                      JointAngles guess) const;

private:
    DHKinematicChain chain_;
    IKOptions options_;
};

}  // namespace arm::kinematics
