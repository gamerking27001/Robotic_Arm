// kinematics/dh_kinematics.hpp
// Forward kinematics and geometric Jacobian for a 6-DOF serial arm defined by
// a Denavit-Hartenberg parameter chain (§4.3 / §11.4).
#pragma once

#include <array>

#include "core/linalg.hpp"
#include "core/robot_config.hpp"

namespace arm::kinematics {

using JointAngles = std::array<double, config::kNumJoints>;  // radians

struct LinkFrames {
    // frames[0] = base->link1 ... frames[5] = base->TCP(link6/flange)
    std::array<core::Transform, config::kNumJoints> frames;
};

class DHKinematicChain {
public:
    explicit DHKinematicChain(std::array<config::DHRow, config::kNumJoints> dh = config::kDHTable)
        : dh_(dh) {}

    // Pose of the tool-center-point in the base frame.
    [[nodiscard]] core::Transform forwardKinematics(const JointAngles& q) const;

    // All intermediate link frames (base->link_i), needed by the Jacobian and
    // by collision/visualization code.
    [[nodiscard]] LinkFrames computeLinkFrames(const JointAngles& q) const;

    // Geometric Jacobian (6x6): rows 0-2 linear velocity, rows 3-5 angular
    // velocity, columns = joints J1..J6, all revolute (§4 — no prismatic
    // joints in this design).
    [[nodiscard]] core::Matrix6 computeJacobian(const JointAngles& q) const;

    [[nodiscard]] const std::array<config::DHRow, config::kNumJoints>& dhTable() const { return dh_; }

private:
    std::array<config::DHRow, config::kNumJoints> dh_;
};

}  // namespace arm::kinematics
