// core/linalg.hpp
// Minimal, dependency-free linear algebra used by the kinematics/motion stack.
// Deliberately self-contained (no Eigen/etc.) so the project builds with only
// a C++20 standard library — see README for rationale.
#pragma once

#include <array>
#include <cmath>
#include <ostream>
#include <stdexcept>

namespace arm::core {

// ---------------------------------------------------------------------------
// Vector3
// ---------------------------------------------------------------------------
struct Vector3 {
    double x{0.0}, y{0.0}, z{0.0};

    constexpr Vector3() = default;
    constexpr Vector3(double x_, double y_, double z_) : x(x_), y(y_), z(z_) {}

    [[nodiscard]] constexpr Vector3 operator+(const Vector3& o) const { return {x + o.x, y + o.y, z + o.z}; }
    [[nodiscard]] constexpr Vector3 operator-(const Vector3& o) const { return {x - o.x, y - o.y, z - o.z}; }
    [[nodiscard]] constexpr Vector3 operator-() const { return {-x, -y, -z}; }
    [[nodiscard]] constexpr Vector3 operator*(double s) const { return {x * s, y * s, z * s}; }

    [[nodiscard]] constexpr double dot(const Vector3& o) const { return x * o.x + y * o.y + z * o.z; }
    [[nodiscard]] constexpr Vector3 cross(const Vector3& o) const {
        return {y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x};
    }
    [[nodiscard]] double norm() const { return std::sqrt(dot(*this)); }
    [[nodiscard]] Vector3 normalized() const {
        const double n = norm();
        if (n < 1e-12) return {0, 0, 0};
        return {x / n, y / n, z / n};
    }
};

inline std::ostream& operator<<(std::ostream& os, const Vector3& v) {
    return os << "(" << v.x << ", " << v.y << ", " << v.z << ")";
}

// ---------------------------------------------------------------------------
// Matrix3 (row-major rotation matrix)
// ---------------------------------------------------------------------------
struct Matrix3 {
    std::array<std::array<double, 3>, 3> m{{{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}};

    static constexpr Matrix3 identity() { return Matrix3{}; }

    static Matrix3 rotationX(double rad) {
        const double c = std::cos(rad), s = std::sin(rad);
        return Matrix3{{{{1, 0, 0}, {0, c, -s}, {0, s, c}}}};
    }
    static Matrix3 rotationY(double rad) {
        const double c = std::cos(rad), s = std::sin(rad);
        return Matrix3{{{{c, 0, s}, {0, 1, 0}, {-s, 0, c}}}};
    }
    static Matrix3 rotationZ(double rad) {
        const double c = std::cos(rad), s = std::sin(rad);
        return Matrix3{{{{c, -s, 0}, {s, c, 0}, {0, 0, 1}}}};
    }

    [[nodiscard]] Vector3 operator*(const Vector3& v) const {
        return {m[0][0] * v.x + m[0][1] * v.y + m[0][2] * v.z,
                m[1][0] * v.x + m[1][1] * v.y + m[1][2] * v.z,
                m[2][0] * v.x + m[2][1] * v.y + m[2][2] * v.z};
    }

    [[nodiscard]] Matrix3 operator*(const Matrix3& o) const {
        Matrix3 r{};
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j) {
                double s = 0.0;
                for (int k = 0; k < 3; ++k) s += m[i][k] * o.m[k][j];
                r.m[i][j] = s;
            }
        return r;
    }

    // For an orthonormal rotation matrix, inverse == transpose.
    [[nodiscard]] Matrix3 transposed() const {
        Matrix3 r{};
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j) r.m[i][j] = m[j][i];
        return r;
    }

    // Third column == local Z axis expressed in the parent frame (used by the
    // geometric Jacobian to know each joint's rotation axis).
    [[nodiscard]] Vector3 zAxis() const { return {m[0][2], m[1][2], m[2][2]}; }
};

// ---------------------------------------------------------------------------
// Transform — rigid-body homogeneous transform (rotation + translation).
// ---------------------------------------------------------------------------
struct Transform {
    Matrix3 R{};
    Vector3 p{};

    static Transform identity() { return {}; }

    // Standard (Craig / classic) DH transform: rotate about x by alpha, then
    // about z by theta, translate a along x, d along z — composed per the
    // convention used throughout Section 4/20 of the design baseline.
    static Transform fromDH(double a, double alpha, double d, double theta) {
        const double ct = std::cos(theta), st = std::sin(theta);
        const double ca = std::cos(alpha), sa = std::sin(alpha);
        Transform t{};
        t.R.m = {{{ct, -st * ca, st * sa}, {st, ct * ca, -ct * sa}, {0, sa, ca}}};
        t.p = {a * ct, a * st, d};
        return t;
    }

    [[nodiscard]] Transform operator*(const Transform& o) const {
        Transform r{};
        r.R = R * o.R;
        r.p = R * o.p + p;
        return r;
    }

    [[nodiscard]] Vector3 apply(const Vector3& v) const { return R * v + p; }

    [[nodiscard]] Transform inverse() const {
        Transform r{};
        r.R = R.transposed();
        r.p = -(r.R * p);
        return r;
    }
};

// ---------------------------------------------------------------------------
// Fixed-size 6-vector and 6x6 matrix — used for the geometric Jacobian and the
// damped-least-squares numerical IK fallback (Section 11.4).
// ---------------------------------------------------------------------------
using Vector6 = std::array<double, 6>;

struct Matrix6 {
    std::array<std::array<double, 6>, 6> m{};

    static Matrix6 identity() {
        Matrix6 r{};
        for (int i = 0; i < 6; ++i) r.m[i][i] = 1.0;
        return r;
    }

    [[nodiscard]] Matrix6 transposed() const {
        Matrix6 r{};
        for (int i = 0; i < 6; ++i)
            for (int j = 0; j < 6; ++j) r.m[i][j] = m[j][i];
        return r;
    }

    [[nodiscard]] Matrix6 operator*(const Matrix6& o) const {
        Matrix6 r{};
        for (int i = 0; i < 6; ++i)
            for (int j = 0; j < 6; ++j) {
                double s = 0.0;
                for (int k = 0; k < 6; ++k) s += m[i][k] * o.m[k][j];
                r.m[i][j] = s;
            }
        return r;
    }

    [[nodiscard]] Matrix6 operator+(const Matrix6& o) const {
        Matrix6 r{};
        for (int i = 0; i < 6; ++i)
            for (int j = 0; j < 6; ++j) r.m[i][j] = m[i][j] + o.m[i][j];
        return r;
    }

    [[nodiscard]] Vector6 operator*(const Vector6& v) const {
        Vector6 r{};
        for (int i = 0; i < 6; ++i) {
            double s = 0.0;
            for (int j = 0; j < 6; ++j) s += m[i][j] * v[j];
            r[i] = s;
        }
        return r;
    }
};

// Solve A x = b for a 6x6 system via Gauss-Jordan elimination with partial
// pivoting. Throws std::runtime_error if the system is (numerically)
// singular — callers add damping to A's diagonal near singularities.
inline Vector6 solve6(Matrix6 A, Vector6 b) {
    for (int col = 0; col < 6; ++col) {
        int pivotRow = col;
        double best = std::fabs(A.m[col][col]);
        for (int r = col + 1; r < 6; ++r) {
            if (std::fabs(A.m[r][col]) > best) {
                best = std::fabs(A.m[r][col]);
                pivotRow = r;
            }
        }
        if (best < 1e-12) throw std::runtime_error("solve6: singular matrix");
        if (pivotRow != col) {
            std::swap(A.m[pivotRow], A.m[col]);
            std::swap(b[pivotRow], b[col]);
        }
        const double pivot = A.m[col][col];
        for (int j = 0; j < 6; ++j) A.m[col][j] /= pivot;
        b[col] /= pivot;
        for (int r = 0; r < 6; ++r) {
            if (r == col) continue;
            const double factor = A.m[r][col];
            if (factor == 0.0) continue;
            for (int j = 0; j < 6; ++j) A.m[r][j] -= factor * A.m[col][j];
            b[r] -= factor * b[col];
        }
    }
    return b;
}

inline double deg2rad(double d) { return d * M_PI / 180.0; }
inline double rad2deg(double r) { return r * 180.0 / M_PI; }

}  // namespace arm::core
