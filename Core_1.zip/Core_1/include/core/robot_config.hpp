// core/robot_config.hpp
// Every numeric engineering parameter from "Modular Industrial Robotic Arm for
// MSMEs" (SIH baseline doc) expressed as strongly-typed, constexpr C++ data.
// Section references (§) point back to the source document so the two stay
// traceable to each other.
//
// NOTE ON GAPS IN THE SOURCE DOCUMENT:
// The source PDF's representative config (§20.5) explicitly truncates the DH
// table and joint-limit table after J1/J2 ("# ... J3-J6 continued"). Those
// missing numeric values are marked below with `PLACEHOLDER_` comments and
// filled with engineering-reasonable values consistent with the stated specs
// (850 mm reach, spherical wrist, §2.1/§4). Replace them with the authoritative
// values once available — everything downstream (kinematics, limits, safety)
// reads from this single file, so correcting it here propagates everywhere.
#pragma once

#include <array>
#include <cstddef>
#include <string_view>

#include "core/linalg.hpp"

namespace arm::config {

constexpr std::size_t kNumJoints = 6;

// --- §1.5 / §2.1 — Robot-level specification -------------------------------
struct RobotSpec {
    double payload_nominal_kg = 5.0;
    double payload_peak_kg = 8.0;              // reduced-reach peak
    double reach_mm = 850.0;
    double repeatability_mm = 0.03;
    double pose_accuracy_mm_post_cal = 0.15;
    double max_tcp_speed_mps = 1.5;
    double max_joint_speed_j1_j3_deg_s = 180.0;
    double max_joint_speed_j4_j6_deg_s = 300.0;
    double typical_cycle_time_s = 0.55;         // 25 mm pick-place, 1 kg
    double workspace_volume_m3 = 1.9;
    double rated_power_w_peak = 800.0;
    double bus_voltage_vdc = 48.0;
    double weight_kg_excl_controller = 22.0;    // "<=" upper bound
    double controller_weight_kg = 4.0;          // "<=" upper bound
    double ambient_temp_min_c = 0.0;
    double ambient_temp_max_c = 45.0;
    double acoustic_noise_dba_at_1m = 65.0;      // "<" upper bound
    std::string_view ip_rating_base_forearm = "IP54";
    std::string_view ip_rating_wrist_optional = "IP65";
    double soft_limit_fraction_of_mechanical_range = 0.90;  // §5.3 / §14.1
    double joint_replace_target_minutes = 30.0;              // §3.6
    double tool_change_target_seconds = 10.0;                 // §8.2
    double flange_mating_tolerance_mm = 0.02;                 // §17.3
};

inline constexpr RobotSpec kRobotSpec{};

// --- §5 / §6.2 — Per-joint mechanical + actuator specification -------------
enum class JointId : int { J1 = 0, J2, J3, J4, J5, J6 };

enum class GearboxType { kHarmonicStrainWave, kCycloidal, kPlanetary };
enum class MotorType { kPmsmExternalDrive, kBldcServo };
enum class BearingType { kCrossRoller, kAngularContactPair, kDeepGroovePair };

struct JointSpec {
    JointId id;
    std::string_view name;
    bool is_large_module;                 // true: J1-J3 large module, false: J4-J6 small module
    GearboxType gearbox;
    double gear_ratio;                    // e.g. 101.0 for "~101:1"
    MotorType motor;
    BearingType bearing;
    double rated_output_torque_nm;
    double peak_output_torque_nm;         // already includes 1.5x design margin, §6.3
    double rated_motor_rpm;
    int encoder_bits;                     // absolute encoder resolution, §7.1
    double motor_power_w;
    double max_joint_speed_deg_s;         // §1.5/§2.1 grouping (J1-3 vs J4-6)
    double soft_limit_min_deg;
    double soft_limit_max_deg;
    double regrease_interval_hours;       // 2000h large joints; sealed-for-life small joints (=> 0/N-A)
};

// clang-format off
inline constexpr std::array<JointSpec, kNumJoints> kJointSpecs{{
    // id      name             large  gearbox                        ratio  motor                        bearing                          rated_Nm peak_Nm rpm    enc  power_W maxspd  min_deg max_deg regrease_h
    JointSpec{JointId::J1, "Waist",       true,  GearboxType::kHarmonicStrainWave, 101.0, MotorType::kPmsmExternalDrive, BearingType::kCrossRoller,       120.0, 240.0, 3000.0, 20, 200.0, 180.0, -170.0, 170.0, 2000.0},
    JointSpec{JointId::J2, "Shoulder",    true,  GearboxType::kHarmonicStrainWave, 101.0, MotorType::kPmsmExternalDrive, BearingType::kCrossRoller,       150.0, 300.0, 3000.0, 20, 250.0, 180.0,  -95.0,  95.0, 2000.0},
    JointSpec{JointId::J3, "Elbow",       true,  GearboxType::kCycloidal,           81.0, MotorType::kPmsmExternalDrive, BearingType::kAngularContactPair, 60.0, 120.0, 3000.0, 20, 150.0, 180.0, -175.0, 175.0, 2000.0}, // PLACEHOLDER_LIMIT: not given in source (truncated); representative for spherical-wrist elbow reach
    JointSpec{JointId::J4, "WristRoll",   false, GearboxType::kHarmonicStrainWave,  51.0, MotorType::kBldcServo,         BearingType::kAngularContactPair, 12.0,  24.0, 4000.0, 17,  60.0, 300.0, -185.0, 185.0,    0.0}, // PLACEHOLDER_LIMIT + sealed-for-life (§5.4)
    JointSpec{JointId::J5, "WristPitch",  false, GearboxType::kHarmonicStrainWave,  51.0, MotorType::kBldcServo,         BearingType::kAngularContactPair, 12.0,  24.0, 4000.0, 17,  60.0, 300.0, -120.0, 120.0,    0.0}, // PLACEHOLDER_LIMIT
    JointSpec{JointId::J6, "FlangeRoll",  false, GearboxType::kPlanetary,           31.0, MotorType::kBldcServo,         BearingType::kDeepGroovePair,      6.0,  12.0, 4000.0, 17,  40.0, 300.0, -360.0, 360.0,    0.0}, // PLACEHOLDER_LIMIT
}};
// clang-format on

// --- §4.3 / §20.5 — Denavit-Hartenberg parameters (standard DH convention) -
// a [m], alpha [rad], d [m]; theta is the *variable* joint angle, so it is not
// stored here — it is the kinematics input vector.
struct DHRow {
    double a_m;
    double alpha_rad;
    double d_m;
};

// clang-format off
inline constexpr std::array<DHRow, kNumJoints> kDHTable{{
    DHRow{0.000, 1.5707963268,  0.284},  // J1 — verbatim from source §20.5
    DHRow{0.400, 0.0,           0.000},  // J2 — verbatim from source §20.5
    DHRow{0.350, 1.5707963268,  0.000},  // J3 — PLACEHOLDER: source truncated ("...J3-J6 continued"); sized for 850mm reach
    DHRow{0.000, -1.5707963268, 0.350},  // J4 — PLACEHOLDER: spherical-wrist offset (J4-J6 axes intersect at wrist center)
    DHRow{0.000, 1.5707963268,  0.000},  // J5 — PLACEHOLDER: spherical-wrist convention
    DHRow{0.000, 0.0,           0.100},  // J6 — PLACEHOLDER: flange offset to TCP
}};
// clang-format on

// --- §14 — Safety-system parameters ----------------------------------------
struct SafetySpec {
    double torque_deviation_threshold_percent = 15.0;  // configurable sensitivity, §14.1 (not numerically specified in source; conservative default)
    double thermal_derate_start_c = 90.0;               // approach to 100C winding limit, §6.4
    double thermal_trip_c = 100.0;                       // §6.4 winding temperature limit
    double sto_response_note_iec = true;                 // IEC 61800-5-2 dual channel STO, §9.5/§14
    double estop_reset_requires_manual_ack = true;
};

inline constexpr SafetySpec kSafetySpec{};

// --- §13.3 — Motion profile defaults ----------------------------------------
struct MotionDefaults {
    double control_loop_hz = 1000.0;   // interpolator update-rate assumption (not numerically fixed in source; representative)
    double current_loop_khz = 10.0;    // §9.3 "closed locally at >10 kHz"
    bool use_s_curve_default = true;    // §13.3 recommendation
    double jerk_limit_fraction = 0.5;   // fraction of max accel/time used to shape jerk segments (implementation choice)
};

inline constexpr MotionDefaults kMotionDefaults{};

}  // namespace arm::config
