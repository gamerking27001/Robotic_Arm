// safety/safety_fsm.hpp
// §13.5 Operational State Machine (PowerOn -> Homing -> Idle -> Running ->
// {Paused, Fault} -> EStop, with estop_reset back to PowerOn) plus the §14.1
// safety functions (E-stop, STO, collision detection via torque deviation,
// current/thermal monitoring, software/hardware limits).
//
// Architecturally this mirrors §9.8's separation: the safety board's logic is
// independent of the main controller/motion-control path "so a firmware
// fault cannot defeat the safety function" — this class has no dependency on
// MotionController and can be driven purely from telemetry + events.
#pragma once

#include <array>
#include <functional>
#include <string_view>
#include <vector>

#include "core/robot_config.hpp"
#include "hal/joint_interface.hpp"

namespace arm::safety {

enum class RobotState { kPowerOn, kHoming, kIdle, kRunning, kPaused, kFault, kEStop };

enum class Event {
    kBootComplete,     // PowerOn -> Homing
    kHomingComplete,   // Homing -> Idle
    kTaskStart,         // Idle -> Running
    kTaskComplete,      // Running -> Idle
    kPauseCommand,      // Running -> Paused
    kResumeCommand,     // Paused -> Running
    kErrorDetected,     // Running/Paused -> Fault
    kFaultCleared,      // Fault -> Idle
    kEstopTriggered,    // any -> EStop
    kEstopReset,         // EStop -> PowerOn
};

[[nodiscard]] std::string_view toString(RobotState s);
[[nodiscard]] std::string_view toString(Event e);

// §14.1 individual safety-function results, aggregated once per safety-board
// tick (analogous to the dedicated SafetyBoardMCU in §14.2's architecture
// diagram).
struct SafetyCheckResult {
    bool estop_pressed = false;
    bool sto_required = false;
    bool collision_suspected = false;             // torque-deviation monitor
    bool overcurrent = false;
    bool overtemperature = false;
    bool soft_limit_violation = false;
    bool hard_limit_violation = false;

    [[nodiscard]] bool anyFault() const {
        return sto_required || collision_suspected || overcurrent || overtemperature || soft_limit_violation ||
               hard_limit_violation;
    }
};

class SafetyFsm {
public:
    SafetyFsm() = default;

    [[nodiscard]] RobotState state() const { return state_; }

    // Attempts a state transition for `event`; returns false (and leaves
    // state_ unchanged) if the transition isn't legal from the current state,
    // mirroring the fixed edge set drawn in §13.5's diagram.
    bool handle(Event event);

    // §14.1 "Collision Detection": compares expected (commanded) vs measured
    // joint torque against a configurable sensitivity threshold.
    [[nodiscard]] bool checkTorqueDeviation(double expected_nm, double measured_nm, const config::JointSpec& spec,
                                             double threshold_percent = config::kSafetySpec
                                                                             .torque_deviation_threshold_percent) const;

    // §14.1 "Software Limits": soft limits at §-configured fraction of
    // mechanical range, enforced in the motion controller.
    [[nodiscard]] bool checkSoftLimit(double position_rad, const config::JointSpec& spec) const;

    // Runs the full §14.1 function set against one joint's telemetry + a
    // hardware E-stop line, and raises kErrorDetected / kEstopTriggered on the
    // FSM automatically when a check fails (this is the "safety supervision"
    // role called out for the main controller in §9.2, kept here for a single
    // authoritative safety evaluation point).
    SafetyCheckResult evaluate(const hal::JointTelemetry& telemetry, const config::JointSpec& spec,
                                double commanded_torque_nm, bool hardware_estop_line_active);

private:
    RobotState state_ = RobotState::kPowerOn;
};

}  // namespace arm::safety
