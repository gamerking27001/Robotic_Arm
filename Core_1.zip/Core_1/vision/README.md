# vision/

§15 (Computer Vision, marked **Optional** in the source doc) + §19.6's
technology stack (OpenCV core; YOLO/TensorRT for object detection). §18's
repository structure places this at the top level: "vision/ # Vision
pipeline: detection, pose estimation, calibration."

## This layer is built and tested — 32/32 tests pass on real synthetic data
(18 as of the previous pass, plus 14 net-new: 9 for the YOLO ONNX
pipeline, 5 for the detector-selection factory)

```bash
pip install -r requirements.txt
python3 -m pytest tests/ -v
```

Every module has a dedicated test that generates real synthetic image/point
data with a **known ground truth** and checks the module actually recovers
it — not just "does it run without crashing":

| Module | What the test verifies |
|---|---|
| `calibration/` | Chessboard corner detection + `cv2.calibrateCamera` converges on synthetic warped views |
| `part_localization/` | Recovers a known centroid/angle from a synthetic rotated part; pixel→world homography round-trips exactly |
| `barcode_reading/` | Decodes real QR codes (generated via the `qrcode` package) with known payloads, including multiple codes in one image |
| `object_detection/` (`ColorBlobDetector`) | The classical color-blob fallback correctly finds and classifies two differently-colored synthetic objects |
| `object_detection/` (`HOGSVMDetector`) | A real trained HOG+SVM sliding-window detector recovers a synthetic shape's class and location, correctly finds nothing on a clean background, correctly distinguishes two different shapes in one image with non-max suppression, and round-trips through save/load |
| `object_detection/` (`YOLOOnnxDetector`) | Letterbox preprocessing round-trips exactly for both wide and tall images; the raw-output decode pipeline recovers a hand-constructed known box exactly through the full letterbox→model-space→original-space transform chain; confidence thresholding and NMS both verified; missing-weights and call-before-load both raise clear, actionable errors |
| `object_detection/` (`detector_factory`) | The YOLO→HOG+SVM→color-blob fallback chain picks the right backend at every tier, including that a genuinely broken/invalid ONNX file is attempted first and THEN falls through — not skipped |
| `quality_inspection/` | An identical image passes; a synthetic defect (added blob) fails; mismatched image shapes raise |
| `pose_estimation/` | PCA-recovered surface normal matches a known tilt angle to <0.1°; a non-planar point cloud is correctly flagged as low-planarity |

One test needed fixing during development: the calibration test's initial
reprojection-error threshold assumed near-photographic synthetic views, but
a 2D perspective warp of a flat texture isn't a true pinhole-camera
projection — see the comment in `tests/test_camera_calibration.py` for why
the threshold was loosened rather than treating it as a code bug.

Bugs found and fixed while building this layer's ML-backed detectors: (1)
`cv2` was incorrectly believed unavailable in an earlier pass elsewhere in
this repo (see `ai/README.md`'s compliance-audit note) — re-verified
directly (`cv2.__version__` → `4.13.0`) before building anything that
depends on it; (2) `HOGSVMDetector`'s first version used same-class non-max
suppression, which left cross-class "ghost" detections at real object
boundaries — caught by testing against an actual two-shape image, fixed by
making suppression class-agnostic (now shared via `nms.py`, used by both
`HOGSVMDetector` and `YOLOOnnxDetector` so the fix applies to both).

## Module-by-module honesty notes

- **`object_detection/`** now has THREE `ObjectDetector` implementations,
  selected automatically by `detector_factory.py`'s fallback chain:
  - `YOLOOnnxDetector` — real `onnxruntime.InferenceSession`-backed YOLOv8
    inference: standard letterbox preprocessing, standard raw-output decode,
    shared NMS. This is genuinely what §15.1/§19.6 call for. What it can't
    do in this environment: run against a REAL trained model — there's no
    network access to export or download `.onnx` weights, and `onnx` (the
    package needed to even construct a minimal synthetic one for testing)
    isn't installable here either. Every piece that CAN be verified without
    real weights — preprocessing, the full decode/NMS pipeline against a
    hand-constructed synthetic model output with known ground truth, error
    handling — IS verified; see `yolo_onnx_detector.py`'s module docstring
    for the exact line between what's tested and what's structurally
    correct-but-unexercised.
  - `HOGSVMDetector` — real trained classical ML (HOG features + calibrated
    linear SVM), genuinely learns shape/texture, not just color, trained on
    synthetic geometric shapes since no real industrial part images exist
    here.
  - `ColorBlobDetector` — the original classical color-thresholding
    fallback, always available, zero setup, zero training required.

  `ros2_ws/src/vision_pipeline/vision_pipeline/vision_node.py` — the one
  real consumer of this interface in this repo — now goes through
  `create_object_detector()` instead of hardcoding `ColorBlobDetector`
  directly, configured via three new ROS2 parameters
  (`object_detection.yolo_weights_path`,
  `object_detection.yolo_class_names`,
  `object_detection.hog_svm_weights_path`, all empty/unset by default).
  Pointing the first at a real exported `.onnx` file is the entire
  integration step required to run this node against real YOLO — nothing
  else in `vision_node.py` changes, because it only ever calls the
  `ObjectDetector` interface. This import chain was verified directly
  against the real repo layout (see the compliance-audit note below) even
  though `rclpy` itself isn't installable here to run the node end-to-end.

## Compliance-audit note: an earlier false "cv2 unavailable" claim

An earlier pass in this repo's `ai/` layer incorrectly stated `cv2` "isn't
installed in this sandbox," based on a package check that covered several
other libraries but never actually imported `cv2`. It IS installed
(`4.13.0`), confirmed directly by running this whole test suite against it,
not assumed. `scikit-image` and `onnxruntime` were confirmed available the
same way, directly, before anything was built against them. See
`ai/README.md`'s fuller compliance-audit section for the complete story and
why an unverified "X isn't available" claim is treated as seriously here as
a missing feature.
- **`pose_estimation/`** implements the point-cloud/PCA half of §15.1's Pose
  Estimation cell; the "learned pose networks" alternative it also lists
  isn't implemented, for the same reason as object detection.
- Every other module (calibration, part localization, barcode reading,
  quality inspection) implements real, working classical CV matching what
  §15.1 specifies for that capability — no placeholders.

## Relationship to ros2_ws

§20.2 lists `vision_pipeline/` as a ROS2 package ("Detection/pose-estimation
nodes"). `ros2_ws/src/vision_pipeline/` wraps these modules as a `vision_node`
subscribing to a camera image topic and publishing `robot_msgs` detection
messages — see `ros2_ws/README.md`'s package table for details. That ROS2
wrapper carries the same "not compiled/tested against a real ROS2 install"
caveat as the rest of `ros2_ws` (no ROS2 available in this environment), but
the vision *logic* it calls into is this package's own independently-tested
code — I verified the exact import/path-resolution logic `vision_node.py`
uses to reach these modules actually works, outside of ROS2, before treating
that wrapper as done.

Camera calibration (`calibration/`) is intentionally NOT wrapped as a
continuously-running node — it's a one-time offline routine in real
deployments, not a per-frame operation — so `vision_node` doesn't call into
it; run `camera_calibration.py` separately and feed its resulting homography
into `vision_node`'s `part_localization.homography` parameter.
