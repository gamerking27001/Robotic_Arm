"""vision/barcode_reading/barcode_reader.py

§15.1: "Barcode Reading | RGB camera | Standard barcode/QR decode libraries |
Traceability, kitting verification."
"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass
class BarcodeResult:
    data: str
    corners_px: list[tuple[float, float]]


def read_qr_codes(image_bgr: np.ndarray) -> list[BarcodeResult]:
    """Decodes QR codes via OpenCV's built-in QRCodeDetector (§19.6: "Core CV
    Library OpenCV") — no external barcode SDK dependency needed for the QR
    case, which covers most kitting/traceability labels."""
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY) if image_bgr.ndim == 3 else image_bgr
    detector = cv2.QRCodeDetector()
    ok, decoded_info, points, _ = detector.detectAndDecodeMulti(gray)

    results: list[BarcodeResult] = []
    if not ok or points is None:
        return results
    for text, corner_set in zip(decoded_info, points):
        if not text:
            continue  # a QR pattern was localized but couldn't be decoded (damaged/occluded)
        results.append(BarcodeResult(data=text, corners_px=[tuple(p) for p in corner_set]))
    return results


def read_1d_barcodes(image_bgr: np.ndarray) -> list[BarcodeResult]:
    """1D barcode (Code128/EAN, etc.) decode via OpenCV's BarcodeDetector, if
    the installed OpenCV build includes it (it's part of opencv-contrib, not
    always bundled) — falls back to an empty list rather than raising, since
    a missing optional decoder shouldn't take down the whole vision pipeline."""
    if not hasattr(cv2, "barcode") or not hasattr(cv2.barcode, "BarcodeDetector"):
        return []
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY) if image_bgr.ndim == 3 else image_bgr
    detector = cv2.barcode.BarcodeDetector()
    ok, decoded_info, _, points = detector.detectAndDecode(gray)
    results: list[BarcodeResult] = []
    if not ok:
        return results
    for text, corner_set in zip(decoded_info, points):
        if not text:
            continue
        results.append(BarcodeResult(data=text, corners_px=[tuple(p) for p in corner_set]))
    return results
