"""vision/object_detection/hog_svm_detector.py

§15.1/§19.6 name a YOLO-class detector as the target. `ColorBlobDetector`
(object_detector.py) is the documented classical-CV fallback for that,
but it only generalizes along color — two objects of the same color and
different shape are indistinguishable to it, and it can't work on
grayscale/monochrome parts at all.

This is a second, meaningfully stronger `ObjectDetector` implementation:
HOG (Histogram of Oriented Gradients) features + a trained linear SVM,
run as a multi-scale sliding-window classifier with non-max suppression.
This is real trained machine learning — genuinely learns SHAPE/texture,
not just color — and was the state of the art for object detection before
deep CNNs (Dalal & Triggs 2005; this is the same feature family
`cv2.HOGDescriptor`'s built-in pedestrian detector uses). It is still NOT
a YOLO-class deep detector: no learned feature hierarchy, no end-to-end
region proposal, and — same honest constraint documented in
object_detector.py's module docstring — no real industrial part images
exist in this environment to train on, so `train_hog_svm.py` trains on
synthetic geometric-shape classes (circle/square/ring, standing in for
e.g. bolt-head/bracket/washer), not real parts. Swapping in a real
labeled dataset means replacing `generate_synthetic_shape_dataset()`
only; `HOGSVMDetector`'s feature extraction, training, and sliding-
window inference code doesn't change.
"""
from __future__ import annotations

import pickle
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

import cv2
import numpy as np
from skimage.feature import hog
from sklearn.calibration import CalibratedClassifierCV
from sklearn.svm import LinearSVC

from object_detector import Detection
from nms import non_max_suppression

PATCH_SIZE = 64  # HOG window size, px (square)
HOG_PARAMS = dict(orientations=9, pixels_per_cell=(8, 8), cells_per_block=(2, 2), block_norm="L2-Hys")


def _extract_hog(gray_patch: np.ndarray) -> np.ndarray:
    if gray_patch.shape != (PATCH_SIZE, PATCH_SIZE):
        gray_patch = cv2.resize(gray_patch, (PATCH_SIZE, PATCH_SIZE))
    return hog(gray_patch, **HOG_PARAMS)


def _draw_shape(canvas: np.ndarray, shape: str, cx: int, cy: int, size: int, color: int, rng: np.random.Generator) -> None:
    thickness = -1 if rng.random() < 0.7 else max(2, size // 10)
    if shape == "circle":
        cv2.circle(canvas, (cx, cy), size // 2, color, thickness)
    elif shape == "square":
        angle = rng.uniform(0, 45)
        rect = ((float(cx), float(cy)), (float(size) * 0.8, float(size) * 0.8), float(angle))
        box = cv2.boxPoints(rect).astype(np.int32)
        if thickness == -1:
            cv2.fillPoly(canvas, [box], color)
        else:
            cv2.polylines(canvas, [box], True, color, thickness)
    elif shape == "ring":
        cv2.circle(canvas, (cx, cy), size // 2, color, max(3, size // 8))
    else:
        raise ValueError(f"unknown shape {shape!r}")


def generate_synthetic_shape_dataset(
    n_positive_per_class: int = 150, n_negative: int = 300, seed: int = 0,
) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    """Positive patches: one shape (circle/square/ring), centered,
    random scale/rotation/intensity/noise/thickness, on a cluttered
    background. Negative patches: pure background clutter, no shape,
    same noise distribution — so the classifier has to learn "is
    there a shape here", not just "is this patch noisy"."""
    rng = np.random.default_rng(seed)
    classes = ["circle", "square", "ring"]
    X: List[np.ndarray] = []
    y: List[str] = []

    def _background(size: int) -> np.ndarray:
        base = rng.integers(60, 200)
        canvas = np.full((size, size), base, dtype=np.uint8)
        # clutter: a handful of random faint lines/blobs, distinct from the foreground shape's color
        for _ in range(rng.integers(0, 4)):
            pt1 = tuple(rng.integers(0, size, size=2).tolist())
            pt2 = tuple(rng.integers(0, size, size=2).tolist())
            cv2.line(canvas, pt1, pt2, int(np.clip(base + rng.integers(-30, 30), 0, 255)), 1)
        noise = rng.normal(0, 8, (size, size))
        return np.clip(canvas.astype(float) + noise, 0, 255).astype(np.uint8)

    for cls in classes:
        for _ in range(n_positive_per_class):
            canvas = _background(PATCH_SIZE)
            bg_mean = int(canvas.mean())
            color = int(np.clip(bg_mean + rng.choice([-1, 1]) * rng.integers(60, 120), 0, 255))
            size = rng.integers(28, 48)
            cx = PATCH_SIZE // 2 + rng.integers(-4, 5)
            cy = PATCH_SIZE // 2 + rng.integers(-4, 5)
            _draw_shape(canvas, cls, cx, cy, size, color, rng)
            X.append(_extract_hog(canvas))
            y.append(cls)

    for _ in range(n_negative):
        canvas = _background(PATCH_SIZE)
        X.append(_extract_hog(canvas))
        y.append("background")

    # Flat (near-zero-noise, no clutter) negatives too — without
    # these, the classifier only ever saw noisy/cluttered backgrounds
    # during training and produced spurious detections on clean,
    # uniform image regions, which real industrial images (a plain
    # conveyor belt, uncluttered bin floor) very much include.
    n_flat = max(1, n_negative // 4)
    for _ in range(n_flat):
        base = rng.integers(60, 200)
        canvas = np.full((PATCH_SIZE, PATCH_SIZE), base, dtype=np.uint8)
        noise = rng.normal(0, 2, (PATCH_SIZE, PATCH_SIZE))  # small sensor-noise floor only
        canvas = np.clip(canvas.astype(float) + noise, 0, 255).astype(np.uint8)
        X.append(_extract_hog(canvas))
        y.append("background")

    return np.array(X), np.array(y), classes


@dataclass
class HOGSVMDetector:
    """Multi-scale sliding-window HOG+SVM detector implementing the
    same `ObjectDetector` protocol as `ColorBlobDetector`
    (object_detector.py) — `.detect(image_bgr) -> list[Detection]`."""

    classes: List[str] = field(default_factory=lambda: ["circle", "square", "ring"])
    window_stride: int = 12
    scales: Tuple[float, ...] = (0.7, 1.0, 1.4)
    nms_iou_threshold: float = 0.3
    min_confidence: float = 0.6

    def __post_init__(self) -> None:
        self._clf: Optional[CalibratedClassifierCV] = None

    def fit(self, X: np.ndarray, y: np.ndarray) -> "HOGSVMDetector":
        base = LinearSVC(C=1.0, max_iter=5000)
        # CalibratedClassifierCV wraps the SVM's decision_function in
        # Platt scaling so `.predict_proba` gives a genuine calibrated
        # confidence — unlike ColorBlobDetector's area-ratio heuristic,
        # documented there as explicitly NOT a calibrated probability.
        self._clf = CalibratedClassifierCV(base, cv=3)
        self._clf.fit(X, y)
        return self

    def save(self, path: str | Path) -> None:
        if self._clf is None:
            raise RuntimeError("detector not fitted — call fit() first")
        with open(path, "wb") as f:
            pickle.dump({"clf": self._clf, "classes": self.classes}, f)

    @classmethod
    def load(cls, path: str | Path, **kwargs) -> "HOGSVMDetector":
        with open(path, "rb") as f:
            data = pickle.load(f)
        det = cls(classes=data["classes"], **kwargs)
        det._clf = data["clf"]
        return det

    def detect(self, image_bgr: np.ndarray) -> List[Detection]:
        if self._clf is None:
            raise RuntimeError("detector not fitted — call fit() or load() first")
        gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY) if image_bgr.ndim == 3 else image_bgr

        raw: List[Detection] = []
        for scale in self.scales:
            window = int(PATCH_SIZE * scale)
            if window > min(gray.shape) or window < 16:
                continue
            for y in range(0, gray.shape[0] - window + 1, self.window_stride):
                for x in range(0, gray.shape[1] - window + 1, self.window_stride):
                    patch = gray[y : y + window, x : x + window]
                    feats = _extract_hog(patch).reshape(1, -1)
                    proba = self._clf.predict_proba(feats)[0]
                    class_names = list(self._clf.classes_)
                    if "background" in class_names:
                        bg_idx = class_names.index("background")
                    else:
                        bg_idx = -1
                    best_idx = int(np.argmax(proba))
                    if best_idx == bg_idx:
                        continue
                    confidence = float(proba[best_idx])
                    if confidence < self.min_confidence:
                        continue
                    raw.append(Detection(class_name=class_names[best_idx], confidence=confidence, bbox_px=(x, y, window, window)))

        return non_max_suppression(raw, self.nms_iou_threshold)


