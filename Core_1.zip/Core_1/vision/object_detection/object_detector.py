"""vision/object_detection/object_detector.py

§15.1: "Object Detection | RGB camera | YOLO-class detector
(TensorRT-accelerated on Jetson variant) | Multi-SKU bin picking, sorting."
§19.6: "Object Detection YOLO (class of models)", "Inference Acceleration
TensorRT (on Jetson-equipped variant)."

IMPORTANT SCOPE NOTE: this module does NOT implement a real YOLO detector.
Running actual YOLO inference needs pretrained weights (hundreds of MB,
fetched from a model zoo) and, for the TensorRT-accelerated path, an NVIDIA
GPU/Jetson — neither is available in this environment, and downloading
third-party model weights isn't something to do speculatively. What's here
instead:
  1. An `ObjectDetector` protocol (interface) matching what a real YOLO
     wrapper would expose — multi-class detection with confidence + bounding
     box, so downstream code (bin-picking task logic) can be written against
     a stable interface now.
  2. `ColorBlobDetector` — a classical-CV fallback implementing that same
     interface via color-space thresholding + connected components. This is
     genuinely useful for the "few known SKU colors, fixed lighting" case,
     but does NOT generalize the way a trained YOLO model does — it's a
     stand-in, not a replacement.
Swapping in real YOLO means implementing `ObjectDetector` against
`ultralytics`/`onnxruntime`/TensorRT and leaving every caller unchanged.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import cv2
import numpy as np


@dataclass
class Detection:
    class_name: str
    confidence: float
    bbox_px: tuple[int, int, int, int]  # x, y, w, h


class ObjectDetector(Protocol):
    def detect(self, image_bgr: np.ndarray) -> list[Detection]: ...


@dataclass
class ColorClass:
    name: str
    hsv_lower: tuple[int, int, int]
    hsv_upper: tuple[int, int, int]


class ColorBlobDetector:
    """Classical-CV stand-in for a trained multi-class detector — see the
    module-level docstring's scope note. Detects one blob per configured
    color class via HSV thresholding + connected components."""

    def __init__(self, classes: list[ColorClass], min_area_px: float = 150.0):
        self.classes = classes
        self.min_area_px = min_area_px

    def detect(self, image_bgr: np.ndarray) -> list[Detection]:
        hsv = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2HSV)
        detections: list[Detection] = []
        for cls in self.classes:
            mask = cv2.inRange(hsv, np.array(cls.hsv_lower), np.array(cls.hsv_upper))
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for c in contours:
                area = cv2.contourArea(c)
                if area < self.min_area_px:
                    continue
                x, y, w, h = cv2.boundingRect(c)
                # Confidence here is a coverage heuristic (blob area / bbox
                # area), NOT a calibrated probability the way a trained
                # model's softmax output would be — documented so it isn't
                # mistaken for one downstream.
                confidence = min(1.0, area / max(w * h, 1))
                detections.append(Detection(class_name=cls.name, confidence=confidence, bbox_px=(x, y, w, h)))
        return detections
