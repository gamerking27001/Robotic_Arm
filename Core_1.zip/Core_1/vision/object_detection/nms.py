"""vision/object_detection/nms.py

Shared non-max suppression, extracted so `HOGSVMDetector` and the new
`YOLOOnnxDetector` (yolo_onnx_detector.py) use the exact same
suppression logic rather than each having their own — the class-
agnostic-vs-per-class distinction here was itself the subject of a
real bug found and fixed while building `HOGSVMDetector` (see that
module's changelog note), so it's worth not re-deriving per detector.
"""
from __future__ import annotations

from typing import List, Tuple

from object_detector import Detection


def iou(a: Tuple[int, int, int, int], b: Tuple[int, int, int, int]) -> float:
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    ix1, iy1 = max(ax, bx), max(ay, by)
    ix2, iy2 = min(ax + aw, bx + bw), min(ay + ah, by + bh)
    iw, ih = max(0, ix2 - ix1), max(0, iy2 - iy1)
    inter = iw * ih
    union = aw * ah + bw * bh - inter
    return inter / union if union > 0 else 0.0


def non_max_suppression(detections: List[Detection], iou_threshold: float, class_agnostic: bool = True) -> List[Detection]:
    """Class-AGNOSTIC by default: a single physical location should not
    yield two different-class detections just because two overlapping
    candidate boxes were classified differently — this was a real bug
    (see hog_svm_detector.py's module docstring for how it was caught:
    a same-class-only NMS left cross-class "ghost" detections at real
    object boundaries in an actual two-shape test image). Pass
    `class_agnostic=False` only when that's genuinely the desired
    behavior for a specific use case."""
    detections = sorted(detections, key=lambda d: -d.confidence)
    kept: List[Detection] = []
    for d in detections:
        if all(
            iou(d.bbox_px, k.bbox_px) < iou_threshold or (not class_agnostic and d.class_name != k.class_name)
            for k in kept
        ):
            kept.append(d)
    return kept
