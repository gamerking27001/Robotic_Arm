#!/usr/bin/env python3
"""vision/object_detection/train_hog_svm.py — trains HOGSVMDetector on
the synthetic shape dataset and saves it to disk, so a real deployment
loads a pretrained detector (fast) rather than retraining on every
process start (a few seconds, but still wasteful for a per-frame
inference path).
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from hog_svm_detector import HOGSVMDetector, generate_synthetic_shape_dataset  # noqa: E402


def main() -> None:
    t0 = time.time()
    X, y, classes = generate_synthetic_shape_dataset(n_positive_per_class=150, n_negative=300, seed=0)
    print(f"dataset: {X.shape[0]} patches, {X.shape[1]} HOG features each ({time.time() - t0:.1f}s)")

    t0 = time.time()
    detector = HOGSVMDetector(classes=classes, min_confidence=0.75).fit(X, y)
    print(f"trained ({time.time() - t0:.1f}s)")

    out_path = Path(__file__).resolve().parent / "hog_svm_detector.pkl"
    detector.save(out_path)
    print(f"saved -> {out_path}")


if __name__ == "__main__":
    main()
