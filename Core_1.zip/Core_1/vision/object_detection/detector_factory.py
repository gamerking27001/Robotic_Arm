"""vision/object_detection/detector_factory.py

The actual integration point: ONE function every consumer (currently
just `vision_node.py`, but this is the intended pattern for any future
one) calls to get an `ObjectDetector`, instead of hardcoding a
specific implementation. This is what makes "swap in real YOLO
weights" a config change instead of a code change — the moment a real
`.onnx` file exists at the configured path, every caller of
`create_object_detector()` starts using it with zero changes to their
own code, because they only ever hold an `ObjectDetector`, never a
`YOLOOnnxDetector`/`HOGSVMDetector`/`ColorBlobDetector` by name.

Selection order, most-capable-first, each with a real, checkable
reason to fall through rather than a silent guess:
  1. YOLOOnnxDetector  — if `yolo_weights_path` is given AND the file
     exists AND `onnxruntime` is importable. The real target (§15.1).
  2. HOGSVMDetector     — if `hog_svm_weights_path` is given AND the
     file exists (see train_hog_svm.py). Real trained ML, shape-aware,
     but not YOLO-class.
  3. ColorBlobDetector  — always available, zero setup; the documented
     "few known SKU colors" fallback (object_detector.py's docstring).

Every fallback is LOGGED, not silent — a deployment that expected real
YOLO and got the color-blob fallback because a path was misconfigured
should be obvious from the log, not discovered later from bad
detections.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

from object_detector import ColorBlobDetector, ColorClass, ObjectDetector

logger = logging.getLogger("vision.object_detection.detector_factory")


def create_object_detector(
    yolo_weights_path: Optional[str | Path] = None,
    yolo_class_names: Optional[List[str]] = None,
    hog_svm_weights_path: Optional[str | Path] = None,
    color_classes: Optional[List[ColorClass]] = None,
) -> ObjectDetector:
    """Returns the most-capable `ObjectDetector` that can actually be
    constructed given what's configured/available, logging which one
    and why. See this module's docstring for the fallback order.
    """
    if yolo_weights_path:
        path = Path(yolo_weights_path)
        if path.exists():
            try:
                from yolo_onnx_detector import YOLOOnnxDetector

                detector = YOLOOnnxDetector.load(path, class_names=yolo_class_names or [])
                logger.info("object detector: YOLOOnnxDetector loaded from %s", path)
                return detector
            except ImportError:
                logger.warning(
                    "yolo_weights_path=%s configured but onnxruntime is not installed — falling back", path
                )
            except Exception:
                logger.exception("failed to load YOLO ONNX model at %s — falling back", path)
        else:
            logger.warning("yolo_weights_path=%s configured but file does not exist — falling back", path)

    if hog_svm_weights_path:
        path = Path(hog_svm_weights_path)
        if path.exists():
            try:
                from hog_svm_detector import HOGSVMDetector

                detector = HOGSVMDetector.load(path)
                logger.info("object detector: HOGSVMDetector loaded from %s", path)
                return detector
            except Exception:
                logger.exception("failed to load HOG+SVM model at %s — falling back", path)
        else:
            logger.warning("hog_svm_weights_path=%s configured but file does not exist — falling back", path)

    logger.info("object detector: ColorBlobDetector (classical fallback, no trained weights required)")
    return ColorBlobDetector(classes=color_classes or [])
