"""vision/object_detection/yolo_onnx_detector.py

§15.1/§19.6's actual target: "Object Detection | RGB camera |
YOLO-class detector (TensorRT-accelerated on Jetson variant)."
`object_detector.py`'s module docstring names the exact swap path:
"implementing `ObjectDetector` against `ultralytics`/`onnxruntime`/
TensorRT." This is that implementation, against `onnxruntime` — which
IS installed and working in this sandbox (`onnxruntime==1.24.4`,
confirmed directly, not assumed — see `ai/README.md`'s compliance-
audit note for why that verification habit matters here specifically).

What this delivers for real: standard YOLOv8-style preprocessing
(letterbox resize, BGR→RGB, CHW, normalize), the standard YOLOv8 raw-
output decode (transposed (1, 4+num_classes, num_boxes) tensor →
boxes/scores/classes, confidence filtering, coordinate rescale back
through the letterbox transform to original image coordinates), and
shared NMS (nms.py) — all real, all independently unit-tested against
HAND-CONSTRUCTED synthetic raw model outputs with a known ground truth
(see tests/test_yolo_onnx_detector.py), because that's the entire
decode/postprocess pipeline and it doesn't need a real model to verify
it's implemented correctly.

What this does NOT deliver, and cannot, in this environment: an actual
trained `.onnx` weights file. `onnx` — the package needed to even
CONSTRUCT a minimal valid ONNX graph for testing — isn't installable
here either (no network access; confirmed the same way as every other
"is X really unavailable" claim in this repo, see ai/README.md).
Producing real YOLO weights means either running `yolo export
format=onnx` (ultralytics, needs network) or training from scratch
(needs a labeled dataset and serious compute) — neither is something
to fake. `YOLOOnnxDetector.load()` therefore cannot be exercised
end-to-end with a real model in this session; it's real, correct
`onnxruntime.InferenceSession` usage, written and reviewed carefully
because it CAN'T be verified by running it, tested for what CAN be
verified (the surrounding pre/post-processing), and it raises a
clear, actionable `FileNotFoundError`/`onnxruntime` error rather than
silently doing nothing if pointed at a path with no real model.

Tight integration, the actual point of this file existing: this
implements the exact same `ObjectDetector.detect(image_bgr) ->
list[Detection]` interface as `ColorBlobDetector` and
`HOGSVMDetector`. `detector_factory.py` is what makes that swap
automatic — the moment a real `.onnx` file is placed at the
configured path, `ros2_ws/src/vision_pipeline/vision_pipeline/vision_node.py`
starts using real YOLO inference with ZERO code changes, because it
already only ever calls the `ObjectDetector` interface, never
`YOLOOnnxDetector` by name.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

import cv2
import numpy as np

from object_detector import Detection
from nms import non_max_suppression

try:
    import onnxruntime as ort

    _HAVE_ONNXRUNTIME = True
except ImportError:  # pragma: no cover - exercised only where onnxruntime genuinely isn't installed
    _HAVE_ONNXRUNTIME = False


@dataclass
class LetterboxResult:
    image: np.ndarray
    scale: float
    pad_x: float
    pad_y: float
    original_shape: Tuple[int, int]  # (height, width)


def letterbox(image_bgr: np.ndarray, target_size: int = 640) -> LetterboxResult:
    """Resize an image to fit inside a `target_size` x `target_size`
    square, preserving aspect ratio, padding the rest with neutral
    gray (114,114,114) — the standard YOLOv5/v8 preprocessing step.
    Returns enough information (`scale`, `pad_x`, `pad_y`) to map a
    detection in the padded/resized frame back to original image
    coordinates exactly.
    """
    h, w = image_bgr.shape[:2]
    scale = min(target_size / h, target_size / w)
    new_h, new_w = int(round(h * scale)), int(round(w * scale))
    resized = cv2.resize(image_bgr, (new_w, new_h), interpolation=cv2.INTER_LINEAR)

    pad_x = (target_size - new_w) / 2.0
    pad_y = (target_size - new_h) / 2.0
    top, bottom = int(round(pad_y - 0.1)), int(round(pad_y + 0.1))
    left, right = int(round(pad_x - 0.1)), int(round(pad_x + 0.1))
    # Guard against a 1px rounding shortfall so the padded frame is
    # always EXACTLY target_size x target_size.
    while top + bottom + new_h < target_size:
        bottom += 1
    while left + right + new_w < target_size:
        right += 1

    padded = cv2.copyMakeBorder(resized, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(114, 114, 114))
    return LetterboxResult(image=padded, scale=scale, pad_x=left, pad_y=top, original_shape=(h, w))


def preprocess(image_bgr: np.ndarray, target_size: int = 640) -> Tuple[np.ndarray, LetterboxResult]:
    """image_bgr -> normalized (1, 3, target_size, target_size) float32
    tensor, the exact input format `yolo export format=onnx` produces
    a model expecting."""
    lb = letterbox(image_bgr, target_size)
    rgb = cv2.cvtColor(lb.image, cv2.COLOR_BGR2RGB)
    chw = rgb.transpose(2, 0, 1).astype(np.float32) / 255.0
    return chw[np.newaxis, ...], lb


def decode_yolov8_output(
    raw_output: np.ndarray,
    class_names: List[str],
    letterbox_result: LetterboxResult,
    conf_threshold: float = 0.25,
    iou_threshold: float = 0.45,
) -> List[Detection]:
    """Decode a raw YOLOv8-ONNX-export output tensor into `Detection`
    objects in ORIGINAL image coordinates (undoing the letterbox
    transform). Standard YOLOv8 ONNX output shape:
    `(1, 4 + num_classes, num_boxes)` — 4 box params (cx, cy, w, h, in
    the model's input-pixel space) followed by one row per class'
    confidence, transposed relative to YOLOv5's `(1, num_boxes,
    5+num_classes)` layout. This function assumes the v8 layout,
    matching what `ultralytics`' own ONNX exporter produces by
    default.
    """
    if raw_output.ndim == 3 and raw_output.shape[0] == 1:
        raw_output = raw_output[0]  # (4+num_classes, num_boxes)
    num_classes = len(class_names)
    if raw_output.shape[0] != 4 + num_classes:
        raise ValueError(
            f"raw_output has {raw_output.shape[0]} rows, expected {4 + num_classes} "
            f"(4 box params + {num_classes} classes) — class_names doesn't match this model"
        )

    boxes_cxcywh = raw_output[:4, :].T  # (num_boxes, 4)
    class_scores = raw_output[4:, :].T  # (num_boxes, num_classes)

    best_class_idx = np.argmax(class_scores, axis=1)
    best_class_score = class_scores[np.arange(len(class_scores)), best_class_idx]

    keep_mask = best_class_score >= conf_threshold
    if not np.any(keep_mask):
        return []

    boxes_cxcywh = boxes_cxcywh[keep_mask]
    best_class_idx = best_class_idx[keep_mask]
    best_class_score = best_class_score[keep_mask]

    detections: List[Detection] = []
    h, w = letterbox_result.original_shape
    for (cx, cy, bw, bh), cls_idx, score in zip(boxes_cxcywh, best_class_idx, best_class_score):
        # Undo the letterbox transform: subtract padding, divide by scale.
        x1 = (cx - bw / 2 - letterbox_result.pad_x) / letterbox_result.scale
        y1 = (cy - bh / 2 - letterbox_result.pad_y) / letterbox_result.scale
        box_w = bw / letterbox_result.scale
        box_h = bh / letterbox_result.scale

        x1 = float(np.clip(x1, 0, w))
        y1 = float(np.clip(y1, 0, h))
        box_w = float(np.clip(box_w, 0, w - x1))
        box_h = float(np.clip(box_h, 0, h - y1))
        if box_w <= 0 or box_h <= 0:
            continue

        detections.append(
            Detection(
                class_name=class_names[int(cls_idx)],
                confidence=float(score),
                bbox_px=(int(round(x1)), int(round(y1)), int(round(box_w)), int(round(box_h))),
            )
        )

    return non_max_suppression(detections, iou_threshold, class_agnostic=True)


@dataclass
class YOLOOnnxDetector:
    """Real `onnxruntime.InferenceSession`-backed YOLOv8 detector.
    Implements the same `ObjectDetector` protocol as `ColorBlobDetector`
    and `HOGSVMDetector` — `.detect(image_bgr) -> list[Detection]`.

    NOT exercisable end-to-end without a real `.onnx` weights file —
    see this module's docstring for exactly why, and what IS verified
    instead.
    """

    class_names: List[str]
    input_size: int = 640
    conf_threshold: float = 0.25
    iou_threshold: float = 0.45
    providers: Tuple[str, ...] = ("CPUExecutionProvider",)

    def __post_init__(self) -> None:
        self._session: Optional["ort.InferenceSession"] = None

    @classmethod
    def load(cls, weights_path: str | Path, class_names: List[str], **kwargs) -> "YOLOOnnxDetector":
        if not _HAVE_ONNXRUNTIME:
            raise ImportError("onnxruntime is not installed — cannot load a YOLO ONNX model")
        weights_path = Path(weights_path)
        if not weights_path.exists():
            raise FileNotFoundError(
                f"no ONNX weights file at {weights_path} — export one with "
                f"`yolo export model=<weights>.pt format=onnx` (ultralytics) "
                f"or point at an existing exported model"
            )
        det = cls(class_names=class_names, **kwargs)
        det._session = ort.InferenceSession(str(weights_path), providers=list(det.providers))
        return det

    def detect(self, image_bgr: np.ndarray) -> List[Detection]:
        if self._session is None:
            raise RuntimeError("detector not loaded — call YOLOOnnxDetector.load(weights_path, class_names) first")
        input_tensor, lb = preprocess(image_bgr, self.input_size)
        input_name = self._session.get_inputs()[0].name
        raw_output = self._session.run(None, {input_name: input_tensor})[0]
        return decode_yolov8_output(
            raw_output, self.class_names, lb, conf_threshold=self.conf_threshold, iou_threshold=self.iou_threshold
        )
