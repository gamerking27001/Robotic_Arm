"""vision/quality_inspection/quality_inspection.py

§15.1: "Quality Inspection | RGB or depth camera | Classical CV or
CNN-based defect detection | In-line QC checks."

Classical-CV implementation: absolute-difference against a registered
"golden" reference image, thresholded and morphologically cleaned to reject
single-pixel noise, with the total anomalous area as the pass/fail score.
This is the standard approach for fixed-pose, consistent-lighting inspection
stations (§8.1's "Inspection Camera... paired with ring-light illumination")
— it is not a substitute for a trained defect-classification CNN on
variable/textured parts, which is why §15.1 lists that as an alternative.
"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass
class InspectionResult:
    anomaly_score: float          # fraction of pixels flagged anomalous, [0, 1]
    anomaly_mask: np.ndarray
    passed: bool


def inspect_against_golden(
    test_image_bgr: np.ndarray,
    golden_image_bgr: np.ndarray,
    diff_threshold: int = 30,
    pass_score_max: float = 0.01,
) -> InspectionResult:
    if test_image_bgr.shape != golden_image_bgr.shape:
        raise ValueError(
            f"Test image shape {test_image_bgr.shape} doesn't match golden reference "
            f"{golden_image_bgr.shape} — inspection requires a registered, same-pose capture."
        )

    test_gray = cv2.cvtColor(test_image_bgr, cv2.COLOR_BGR2GRAY)
    golden_gray = cv2.cvtColor(golden_image_bgr, cv2.COLOR_BGR2GRAY)

    diff = cv2.absdiff(test_gray, golden_gray)
    _, mask = cv2.threshold(diff, diff_threshold, 255, cv2.THRESH_BINARY)

    # Morphological opening removes single-pixel sensor noise so it isn't
    # counted as a defect.
    kernel = np.ones((3, 3), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

    anomaly_score = float(np.count_nonzero(mask)) / mask.size
    return InspectionResult(anomaly_score=anomaly_score, anomaly_mask=mask, passed=anomaly_score <= pass_score_max)
