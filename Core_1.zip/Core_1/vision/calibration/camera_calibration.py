"""vision/calibration/camera_calibration.py

§15.2: "Vision processing runs on the host computer (Section 10)." Camera
intrinsic calibration is the prerequisite step for every other module in
this package (part localization's pixel->world mapping, pose estimation's
depth interpretation) — get the intrinsics wrong and every downstream
measurement is wrong by the same systematic error.

Standard OpenCV chessboard calibration: findChessboardCorners on several
views of a known-size checkerboard, then calibrateCamera to recover the
intrinsic matrix + distortion coefficients.
"""
from __future__ import annotations

import numpy as np
import cv2


class CalibrationResult:
    def __init__(self, camera_matrix: np.ndarray, dist_coeffs: np.ndarray, rms_error: float):
        self.camera_matrix = camera_matrix
        self.dist_coeffs = dist_coeffs
        self.rms_error = rms_error

    @property
    def fx(self) -> float:
        return float(self.camera_matrix[0, 0])

    @property
    def fy(self) -> float:
        return float(self.camera_matrix[1, 1])

    @property
    def cx(self) -> float:
        return float(self.camera_matrix[0, 2])

    @property
    def cy(self) -> float:
        return float(self.camera_matrix[1, 2])


def calibrate_from_chessboard_views(
    images: list[np.ndarray],
    pattern_size: tuple[int, int] = (9, 6),
    square_size_m: float = 0.025,
) -> CalibrationResult:
    """Standard OpenCV intrinsic calibration from N chessboard views.

    pattern_size is (columns, rows) of *inner corners* (not squares) —
    e.g. a 10x7-square board has a (9, 6) inner-corner pattern.
    """
    objp = np.zeros((pattern_size[0] * pattern_size[1], 3), np.float32)
    objp[:, :2] = np.mgrid[0:pattern_size[0], 0:pattern_size[1]].T.reshape(-1, 2) * square_size_m

    obj_points: list[np.ndarray] = []
    img_points: list[np.ndarray] = []
    image_size: tuple[int, int] | None = None

    for img in images:
        gray = img if img.ndim == 2 else cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        if image_size is None:
            image_size = (gray.shape[1], gray.shape[0])
        found, corners = cv2.findChessboardCorners(gray, pattern_size)
        if not found:
            continue
        corners = cv2.cornerSubPix(
            gray, corners, (11, 11), (-1, -1),
            (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001),
        )
        obj_points.append(objp)
        img_points.append(corners)

    if len(obj_points) < 3:
        raise ValueError(
            f"Only found the chessboard pattern in {len(obj_points)} of {len(images)} views — "
            "need at least 3 good views for a well-conditioned calibration."
        )

    rms, camera_matrix, dist_coeffs, _, _ = cv2.calibrateCamera(
        obj_points, img_points, image_size, None, None
    )
    return CalibrationResult(camera_matrix, dist_coeffs, rms)
