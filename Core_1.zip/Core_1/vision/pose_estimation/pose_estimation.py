"""vision/pose_estimation/pose_estimation.py

§15.1: "Pose Estimation | Depth camera | Point-cloud registration / learned
pose networks | Bin-picking with unknown orientation."

Implements the point-cloud-registration half of that cell: given a depth
patch (points believed to belong to one part's visible surface), recover the
surface centroid and normal via PCA — the standard classical approach, and
the natural complement to §15.1's "Part Localization" for tasks where the
2D in-plane angle isn't enough (the part is tilted, not just rotated flat on
the table). Learned pose networks (the doc's other listed option, for
complex/occluded geometry) are not implemented here.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class SurfacePose:
    centroid_m: np.ndarray   # (3,) — mean of the input points
    normal_m: np.ndarray      # (3,) unit vector — the surface's estimated normal
    planarity: float           # 0..1, how well the points fit a single plane (1 = perfectly planar)


def estimate_surface_pose(points_xyz: np.ndarray) -> SurfacePose:
    """points_xyz: (N, 3) array of 3D points (meters) sampled from one part's
    visible surface, e.g. after segmenting a depth image / point cloud down
    to a single detected blob's footprint (see part_localization for the 2D
    segmentation step that would feed this)."""
    if points_xyz.ndim != 2 or points_xyz.shape[1] != 3:
        raise ValueError(f"Expected an (N, 3) point array, got shape {points_xyz.shape}")
    if points_xyz.shape[0] < 3:
        raise ValueError("Need at least 3 points to estimate a surface plane")

    centroid = points_xyz.mean(axis=0)
    centered = points_xyz - centroid

    # PCA via SVD: the eigenvector with the SMALLEST variance is the surface
    # normal (the direction the points vary least along, for a flat-ish
    # patch); the top two span the in-plane directions.
    _, singular_values, vt = np.linalg.svd(centered, full_matrices=False)
    normal = vt[-1]
    normal = normal / np.linalg.norm(normal)

    # Orient the normal to point "up" (+Z) by convention, toward the camera
    # for a table-mounted downward-looking depth camera — a real deployment
    # would instead orient it away from the known camera origin.
    if normal[2] < 0:
        normal = -normal

    # Planarity: how much of the point spread is explained by the two
    # largest singular values vs. the (normal-direction) smallest one —
    # low values flag a noisy/non-planar patch (e.g. it straddles two parts,
    # or an edge) that pose_estimation's assumptions don't hold for.
    variances = singular_values ** 2
    total_variance = float(np.sum(variances))
    planarity = 1.0 - (float(variances[-1]) / total_variance) if total_variance > 1e-12 else 0.0

    return SurfacePose(centroid_m=centroid, normal_m=normal, planarity=planarity)
