"""Synthetic-data test for object_detection/object_detector.py's classical
ColorBlobDetector fallback (see that module's scope note re: real YOLO)."""
import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "object_detection"))
from object_detector import ColorBlobDetector, ColorClass  # noqa: E402


def make_multi_object_image():
    img = np.full((300, 400, 3), 255, dtype=np.uint8)  # white background
    # Pure red rectangle (BGR order)
    cv2.rectangle(img, (30, 30), (110, 90), (0, 0, 220), thickness=-1)
    # Pure blue rectangle
    cv2.rectangle(img, (200, 150), (300, 230), (220, 0, 0), thickness=-1)
    return img


def test_color_blob_detector_finds_both_objects():
    img = make_multi_object_image()
    classes = [
        ColorClass(name="red_part", hsv_lower=(0, 150, 100), hsv_upper=(10, 255, 255)),
        ColorClass(name="blue_part", hsv_lower=(110, 150, 100), hsv_upper=(130, 255, 255)),
    ]
    detector = ColorBlobDetector(classes)

    detections = detector.detect(img)

    names = sorted(d.class_name for d in detections)
    assert names == ["blue_part", "red_part"], names
    for d in detections:
        assert d.confidence > 0.8, f"{d.class_name} confidence unexpectedly low: {d.confidence}"
        x, y, w, h = d.bbox_px
        assert w > 50 and h > 40, f"{d.class_name} bbox too small: {d.bbox_px}"


def test_color_blob_detector_finds_nothing_for_absent_color():
    img = make_multi_object_image()
    classes = [ColorClass(name="green_part", hsv_lower=(50, 150, 100), hsv_upper=(70, 255, 255))]
    detector = ColorBlobDetector(classes)
    assert detector.detect(img) == []


if __name__ == "__main__":
    test_color_blob_detector_finds_both_objects()
    test_color_blob_detector_finds_nothing_for_absent_color()
    print("object_detection: all tests passed")
