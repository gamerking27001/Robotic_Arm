"""Tests for object_detection/yolo_onnx_detector.py.

There's no real `.onnx` YOLO weights file available in this
environment (see that module's docstring for exactly why — no network
to export or download one, and `onnx` itself isn't installable to
even construct a minimal synthetic one). What CAN be verified, and IS
here: the letterbox preprocessing math (round-trips exactly), and the
raw-output decode pipeline against a HAND-CONSTRUCTED synthetic
"model output" tensor with a known ground-truth box — this is the
entire postprocessing pipeline a real model's raw output would flow
through, tested independently of whether a real model exists.
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "object_detection"))
from yolo_onnx_detector import (  # noqa: E402
    YOLOOnnxDetector,
    decode_yolov8_output,
    letterbox,
    preprocess,
)


def test_letterbox_preserves_aspect_ratio_and_pads_to_exact_square():
    img = np.zeros((480, 640, 3), dtype=np.uint8)  # wider than tall
    lb = letterbox(img, target_size=640)
    assert lb.image.shape == (640, 640, 3)
    assert abs(lb.scale - 1.0) < 1e-6  # width already matches target, scale=1
    assert lb.pad_y > 0 and lb.pad_x == 0  # padding added top/bottom only


def test_letterbox_handles_a_tall_image_padding_left_right():
    img = np.zeros((640, 320, 3), dtype=np.uint8)  # taller than wide
    lb = letterbox(img, target_size=640)
    assert lb.image.shape == (640, 640, 3)
    assert lb.pad_x > 0 and lb.pad_y == 0


def test_preprocess_output_shape_dtype_and_value_range():
    img = np.random.default_rng(0).integers(0, 255, (480, 640, 3), dtype=np.uint8)
    tensor, lb = preprocess(img, target_size=640)
    assert tensor.shape == (1, 3, 640, 640)
    assert tensor.dtype == np.float32
    assert tensor.min() >= 0.0 and tensor.max() <= 1.0


def _build_synthetic_raw_output(class_names, known_box_model_space, class_idx, num_boxes=100):
    cx, cy, w, h = known_box_model_space
    raw = np.zeros((1, 4 + len(class_names), num_boxes), dtype=np.float32)
    raw[0, 0, 0] = cx
    raw[0, 1, 0] = cy
    raw[0, 2, 0] = w
    raw[0, 3, 0] = h
    raw[0, 4 + class_idx, 0] = 0.9
    raw[0, 4:, 1:] = 0.01  # every other candidate box: low confidence noise
    return raw


def test_decode_recovers_a_known_box_exactly_through_the_letterbox_round_trip():
    img = np.zeros((480, 640, 3), dtype=np.uint8)
    _, lb = preprocess(img, target_size=640)

    x, y, w, h = 100, 50, 80, 60  # known ground-truth box, ORIGINAL image coords
    cx_model = (x + w / 2) * lb.scale + lb.pad_x
    cy_model = (y + h / 2) * lb.scale + lb.pad_y
    w_model, h_model = w * lb.scale, h * lb.scale

    class_names = ["circle", "square"]
    raw = _build_synthetic_raw_output(class_names, (cx_model, cy_model, w_model, h_model), class_idx=0)

    detections = decode_yolov8_output(raw, class_names, lb, conf_threshold=0.25)
    assert len(detections) == 1
    d = detections[0]
    assert d.class_name == "circle"
    assert abs(d.confidence - 0.9) < 1e-4
    assert d.bbox_px == (x, y, w, h)  # exact recovery, not just "close"


def test_decode_respects_confidence_threshold():
    img = np.zeros((480, 640, 3), dtype=np.uint8)
    _, lb = preprocess(img, target_size=640)
    class_names = ["circle"]
    raw = np.zeros((1, 5, 50), dtype=np.float32)
    raw[0, 0, 0], raw[0, 1, 0], raw[0, 2, 0], raw[0, 3, 0] = 320, 320, 40, 40
    raw[0, 4, 0] = 0.1  # below default 0.25 threshold

    detections = decode_yolov8_output(raw, class_names, lb, conf_threshold=0.25)
    assert detections == []


def test_decode_raises_clear_error_on_class_count_mismatch():
    img = np.zeros((480, 640, 3), dtype=np.uint8)
    _, lb = preprocess(img, target_size=640)
    raw = np.zeros((1, 5, 10), dtype=np.float32)  # 1 class worth of rows
    try:
        decode_yolov8_output(raw, class_names=["a", "b", "c"], letterbox_result=lb)  # 3 classes claimed
        assert False, "expected ValueError"
    except ValueError as e:
        assert "class_names doesn't match" in str(e)


def test_decode_suppresses_overlapping_duplicate_boxes_via_nms():
    img = np.zeros((480, 640, 3), dtype=np.uint8)
    _, lb = preprocess(img, target_size=640)
    class_names = ["circle"]
    raw = np.zeros((1, 5, 3), dtype=np.float32)
    # two near-identical boxes at the same location, one lower confidence
    for i, conf in enumerate([0.9, 0.8]):
        raw[0, 0, i], raw[0, 1, i], raw[0, 2, i], raw[0, 3, i] = 320, 320, 40, 40
        raw[0, 4, i] = conf
    detections = decode_yolov8_output(raw, class_names, lb, conf_threshold=0.25, iou_threshold=0.45)
    assert len(detections) == 1
    assert abs(detections[0].confidence - 0.9) < 1e-4  # the higher-confidence one survives


def test_load_raises_clear_actionable_error_for_missing_weights_file():
    try:
        YOLOOnnxDetector.load("/nonexistent/path/to/model.onnx", class_names=["a"])
        assert False, "expected FileNotFoundError"
    except FileNotFoundError as e:
        assert "yolo export" in str(e) or "no ONNX weights file" in str(e)


def test_detect_raises_clear_error_if_called_before_load():
    det = YOLOOnnxDetector(class_names=["a"])
    try:
        det.detect(np.zeros((100, 100, 3), dtype=np.uint8))
        assert False, "expected RuntimeError"
    except RuntimeError as e:
        assert "not loaded" in str(e)
