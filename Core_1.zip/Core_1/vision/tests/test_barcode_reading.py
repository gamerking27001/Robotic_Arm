"""Synthetic-data test for barcode_reading/barcode_reader.py — uses the
`qrcode` package to generate real QR codes with known payloads, then decodes
them back with our OpenCV-based reader."""
import sys
from pathlib import Path

import cv2
import numpy as np
import qrcode

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "barcode_reading"))
from barcode_reader import read_qr_codes  # noqa: E402


def make_qr_image(payload: str, box_size: int = 8, border: int = 4) -> np.ndarray:
    qr = qrcode.QRCode(box_size=box_size, border=border)
    qr.add_data(payload)
    qr.make(fit=True)
    pil_img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    arr = np.array(pil_img)
    return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)


def test_read_qr_codes_decodes_known_payload():
    payload = "PART-ID:AX-4471;LOT:2026-08-04"
    img = make_qr_image(payload)

    results = read_qr_codes(img)

    assert len(results) == 1, f"Expected 1 QR code, found {len(results)}"
    assert results[0].data == payload
    assert len(results[0].corners_px) == 4


def test_read_qr_codes_empty_on_blank_image():
    blank = np.full((200, 200, 3), 255, dtype=np.uint8)
    assert read_qr_codes(blank) == []


def test_read_qr_codes_handles_multiple_codes_in_one_image():
    payload_a = "TOOL:parallel_gripper_v1"
    payload_b = "TOOL:vacuum_gripper_v2"
    img_a = make_qr_image(payload_a, box_size=6)
    img_b = make_qr_image(payload_b, box_size=6)

    canvas = np.full((max(img_a.shape[0], img_b.shape[0]) + 20, img_a.shape[1] + img_b.shape[1] + 30, 3), 255,
                      dtype=np.uint8)
    canvas[10:10 + img_a.shape[0], 10:10 + img_a.shape[1]] = img_a
    x_off = img_a.shape[1] + 20
    canvas[10:10 + img_b.shape[0], x_off:x_off + img_b.shape[1]] = img_b

    results = read_qr_codes(canvas)
    decoded = {r.data for r in results}
    assert decoded == {payload_a, payload_b}, decoded


if __name__ == "__main__":
    test_read_qr_codes_decodes_known_payload()
    test_read_qr_codes_empty_on_blank_image()
    test_read_qr_codes_handles_multiple_codes_in_one_image()
    print("barcode_reading: all tests passed")
