"""Synthetic-data test for part_localization/part_localization.py."""
import math
import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "part_localization"))
from part_localization import locate_parts, pixel_to_world  # noqa: E402


def make_part_image(center=(200, 150), size=(80, 40), angle_deg=25.0, img_size=(400, 300)):
    img = np.full((img_size[1], img_size[0], 3), 255, dtype=np.uint8)  # white background
    rect = (center, size, angle_deg)
    box = cv2.boxPoints(rect).astype(np.int32)
    cv2.fillPoly(img, [box], (40, 40, 40))  # dark part
    return img


def test_locate_parts_recovers_known_centroid_and_angle():
    true_center = (200.0, 150.0)
    true_angle = 25.0
    img = make_part_image(center=true_center, angle_deg=true_angle)

    detections = locate_parts(img, threshold=127, min_area_px=100, invert=True)

    assert len(detections) == 1, f"Expected exactly 1 part, found {len(detections)}"
    d = detections[0]
    assert math.isclose(d.centroid_px[0], true_center[0], abs_tol=2.0)
    assert math.isclose(d.centroid_px[1], true_center[1], abs_tol=2.0)
    # cv2.minAreaRect's angle convention wraps at 90 degrees for a rectangle
    # with two axes of near-symmetry — accept either the angle or its
    # complement-to-90 as correct.
    angle_ok = math.isclose(d.angle_deg, true_angle, abs_tol=2.0) or math.isclose(
        d.angle_deg, true_angle - 90.0, abs_tol=2.0
    )
    assert angle_ok, f"angle {d.angle_deg} not close to expected {true_angle} (or its -90 complement)"


def test_locate_parts_finds_nothing_on_blank_image():
    blank = np.full((300, 400, 3), 255, dtype=np.uint8)
    assert locate_parts(blank, invert=True) == []


def test_pixel_to_world_round_trip():
    # Four known pixel<->world correspondences (a 1m x 1m table region,
    # imaged by a camera looking straight down at a fixed height —
    # represented here purely as a homography, no camera intrinsics needed).
    pixel_pts = np.float32([[0, 0], [640, 0], [640, 480], [0, 480]])
    world_pts = np.float32([[0.0, 0.0], [1.0, 0.0], [1.0, 0.75], [0.0, 0.75]])
    H, _ = cv2.findHomography(pixel_pts, world_pts)

    for u, v, expected_x, expected_y in [(0, 0, 0.0, 0.0), (640, 480, 1.0, 0.75), (320, 240, 0.5, 0.375)]:
        x, y = pixel_to_world(u, v, H)
        assert math.isclose(x, expected_x, abs_tol=1e-3), (u, v, x, expected_x)
        assert math.isclose(y, expected_y, abs_tol=1e-3), (u, v, y, expected_y)


if __name__ == "__main__":
    test_locate_parts_recovers_known_centroid_and_angle()
    test_locate_parts_finds_nothing_on_blank_image()
    test_pixel_to_world_round_trip()
    print("part_localization: all tests passed")
