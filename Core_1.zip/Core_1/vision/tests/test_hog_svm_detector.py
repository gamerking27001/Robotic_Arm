"""Synthetic-data test for object_detection/hog_svm_detector.py — a
real trained HOG+SVM detector, tested the same way every other module
in this package is: generate synthetic data with a KNOWN ground
truth, verify the module actually recovers it, not just "does it run
without crashing."
"""
import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "object_detection"))
from hog_svm_detector import HOGSVMDetector, generate_synthetic_shape_dataset  # noqa: E402


def _trained_detector(seed: int = 0) -> HOGSVMDetector:
    X, y, classes = generate_synthetic_shape_dataset(n_positive_per_class=120, n_negative=250, seed=seed)
    return HOGSVMDetector(classes=classes, min_confidence=0.75).fit(X, y)


def _noisy_background(size: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    img = np.full((size, size, 3), 140, dtype=np.uint8)
    noise = rng.normal(0, 6, (size, size, 1))
    return np.clip(img.astype(float) + noise, 0, 255).astype(np.uint8)


def test_detects_single_circle_at_the_correct_location():
    det = _trained_detector(seed=0)
    img = _noisy_background(160, seed=1)
    cv2.circle(img, (80, 80), 20, (30, 30, 30), -1)

    detections = det.detect(img)
    assert len(detections) == 1
    d = detections[0]
    assert d.class_name == "circle"
    cx, cy = d.bbox_px[0] + d.bbox_px[2] / 2, d.bbox_px[1] + d.bbox_px[3] / 2
    assert abs(cx - 80) < 20 and abs(cy - 80) < 20  # bbox center close to the true center


def test_clean_background_with_no_object_produces_no_detections():
    det = _trained_detector(seed=0)
    img = _noisy_background(160, seed=2)  # no shape drawn at all
    assert det.detect(img) == []


def test_two_different_shapes_are_both_found_and_correctly_classified():
    det = _trained_detector(seed=0)
    img = _noisy_background(220, seed=3)
    cv2.circle(img, (60, 60), 18, (40, 40, 40), -1)         # filled circle
    cv2.circle(img, (160, 150), 22, (250, 250, 250), 8)     # ring: hollow circle, opposite polarity

    detections = det.detect(img)
    assert len(detections) == 2
    classes_found = {d.class_name for d in detections}
    assert classes_found == {"circle", "ring"}


def test_confidence_is_calibrated_not_a_raw_heuristic():
    # Unlike ColorBlobDetector's documented area-ratio heuristic,
    # HOGSVMDetector's confidence comes from CalibratedClassifierCV's
    # predict_proba — check it actually behaves like a probability
    # (bounded, and the winning class' probability is the max across
    # all classes for that window).
    det = _trained_detector(seed=0)
    img = _noisy_background(160, seed=4)
    cv2.circle(img, (80, 80), 20, (30, 30, 30), -1)
    detections = det.detect(img)
    assert len(detections) >= 1
    for d in detections:
        assert 0.0 <= d.confidence <= 1.0


def test_save_and_load_round_trip_preserves_detection_behavior():
    import tempfile

    det = _trained_detector(seed=0)
    img = _noisy_background(160, seed=5)
    cv2.circle(img, (80, 80), 20, (30, 30, 30), -1)
    original_detections = det.detect(img)

    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "detector.pkl"
        det.save(path)
        reloaded = HOGSVMDetector.load(path, min_confidence=0.75)
        reloaded_detections = reloaded.detect(img)

    assert len(reloaded_detections) == len(original_detections)
    assert reloaded_detections[0].class_name == original_detections[0].class_name
