"""Tests for object_detection/detector_factory.py — the fallback chain
that makes swapping in real YOLO weights a config change, not a code
change. Each tier is tested for real, including that a broken/missing
YOLO config genuinely falls through rather than raising.
"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "object_detection"))
from detector_factory import create_object_detector  # noqa: E402
from object_detector import ColorBlobDetector, ColorClass  # noqa: E402
from hog_svm_detector import HOGSVMDetector, generate_synthetic_shape_dataset  # noqa: E402


def test_no_config_falls_back_to_color_blob_detector():
    det = create_object_detector(color_classes=[ColorClass("red", (0, 150, 100), (10, 255, 255))])
    assert isinstance(det, ColorBlobDetector)


def test_nonexistent_yolo_path_falls_back_rather_than_raising():
    det = create_object_detector(yolo_weights_path="/no/such/file.onnx", yolo_class_names=["a"])
    assert isinstance(det, ColorBlobDetector)


def test_existing_hog_svm_weights_are_actually_used_when_no_yolo_configured():
    with tempfile.TemporaryDirectory() as tmp:
        X, y, classes = generate_synthetic_shape_dataset(n_positive_per_class=20, n_negative=40, seed=0)
        model = HOGSVMDetector(classes=classes).fit(X, y)
        weights_path = Path(tmp) / "detector.pkl"
        model.save(weights_path)

        det = create_object_detector(hog_svm_weights_path=weights_path)
        assert isinstance(det, HOGSVMDetector)


def test_yolo_takes_priority_over_hog_svm_when_both_configured_and_yolo_exists():
    # yolo_weights_path points at a real FILE (doesn't have to be a
    # valid ONNX model for THIS check — the point is priority order:
    # a broken/invalid YOLO file should still attempt YOLO first and
    # THEN fall through on the actual load failure, not skip straight
    # to HOG+SVM just because both were configured).
    with tempfile.TemporaryDirectory() as tmp:
        fake_yolo_path = Path(tmp) / "not_really_onnx.onnx"
        fake_yolo_path.write_bytes(b"not a real onnx model")

        X, y, classes = generate_synthetic_shape_dataset(n_positive_per_class=20, n_negative=40, seed=0)
        hog_model = HOGSVMDetector(classes=classes).fit(X, y)
        hog_path = Path(tmp) / "detector.pkl"
        hog_model.save(hog_path)

        det = create_object_detector(
            yolo_weights_path=fake_yolo_path, yolo_class_names=["a"], hog_svm_weights_path=hog_path
        )
        # The fake ONNX file fails to load (not real model bytes) ->
        # falls through to HOG+SVM, confirming YOLO was genuinely
        # attempted first rather than skipped.
        assert isinstance(det, HOGSVMDetector)


def test_missing_hog_svm_path_falls_back_to_color_blob():
    det = create_object_detector(
        hog_svm_weights_path="/no/such/hog_model.pkl",
        color_classes=[ColorClass("blue", (110, 150, 100), (130, 255, 255))],
    )
    assert isinstance(det, ColorBlobDetector)
