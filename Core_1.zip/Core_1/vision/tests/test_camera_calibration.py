"""Synthetic-data test for calibration/camera_calibration.py.

Generates a flat checkerboard texture, then several perspective-warped
"views" of it (standing in for photographing a real board from different
angles), and verifies the calibration pipeline actually finds the corners in
every view and converges to a low reprojection error — i.e. that the
OpenCV plumbing (findChessboardCorners -> cornerSubPix -> calibrateCamera)
is wired together correctly, which is the part actually worth testing here
(a homography warp isn't a full pinhole+distortion camera model, so exact
ground-truth intrinsic recovery isn't the claim being checked).
"""
import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "calibration"))
from camera_calibration import calibrate_from_chessboard_views  # noqa: E402

PATTERN = (9, 6)  # inner corners
SQUARE_PX = 40


def make_flat_checkerboard() -> np.ndarray:
    cols, rows = PATTERN[0] + 1, PATTERN[1] + 1
    board = np.zeros((rows * SQUARE_PX, cols * SQUARE_PX), dtype=np.uint8)
    for r in range(rows):
        for c in range(cols):
            if (r + c) % 2 == 0:
                board[r * SQUARE_PX:(r + 1) * SQUARE_PX, c * SQUARE_PX:(c + 1) * SQUARE_PX] = 255
    # Pad with a plain border so corner detection isn't confused by the board's edge.
    return cv2.copyMakeBorder(board, 60, 60, 60, 60, cv2.BORDER_CONSTANT, value=255)


def warp_view(board: np.ndarray, tilt_px: int, out_size=(640, 480)) -> np.ndarray:
    h, w = board.shape
    src = np.float32([[0, 0], [w, 0], [w, h], [0, h]])
    # Simulate a tilted view by pushing the top edge inward/outward.
    dst = np.float32([[tilt_px, 0], [w - tilt_px, 20], [w - 40, h - 10], [40, h]])
    M = cv2.getPerspectiveTransform(src, dst)
    return cv2.warpPerspective(board, M, out_size, borderValue=255)


def test_calibration_converges_on_synthetic_views():
    board = make_flat_checkerboard()
    views = [warp_view(board, tilt_px) for tilt_px in (30, 60, 90, 120, 10)]

    result = calibrate_from_chessboard_views(views, pattern_size=PATTERN, square_size_m=0.025)

    # NOTE on the threshold: these synthetic views are 2D perspective warps
    # of a flat texture, not renders of a real 3D chessboard from a true
    # pinhole camera — they don't perfectly satisfy calibrateCamera's
    # underlying model, so some reprojection error is expected even for a
    # correctly-working calibration pipeline. What this test actually checks
    # is that the pipeline (corner detection -> subpixel refinement ->
    # calibrateCamera) runs end-to-end and converges to *a* self-consistent
    # solution at all — not sub-pixel metric accuracy, which would need
    # real photographs of a real board to test honestly.
    assert result.rms_error < 10.0, f"Calibration RMS reprojection error too high: {result.rms_error}"
    assert result.fx > 0 and result.fy > 0, "Recovered focal lengths should be positive"
    # Principal point should land roughly within the image bounds.
    assert 0 < result.cx < 640
    assert 0 < result.cy < 480


def test_calibration_raises_with_too_few_good_views():
    blank = np.full((480, 640), 255, dtype=np.uint8)  # no chessboard pattern at all
    try:
        calibrate_from_chessboard_views([blank, blank], pattern_size=PATTERN)
        assert False, "Expected ValueError for insufficient valid views"
    except ValueError:
        pass


if __name__ == "__main__":
    test_calibration_converges_on_synthetic_views()
    test_calibration_raises_with_too_few_good_views()
    print("camera_calibration: all tests passed")
