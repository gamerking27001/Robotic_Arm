"""Synthetic-data test for pose_estimation/pose_estimation.py."""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "pose_estimation"))
from pose_estimation import estimate_surface_pose  # noqa: E402


def make_tilted_plane_points(normal_deg_from_z: float, n_points: int = 400, noise_std_m: float = 0.0005,
                              seed: int = 42) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    # Flat patch in the local XY plane, then tilt about the X axis by the
    # requested angle to produce a known ground-truth normal.
    xs = rng.uniform(-0.05, 0.05, n_points)
    ys = rng.uniform(-0.05, 0.05, n_points)
    zs = np.zeros(n_points)
    local_pts = np.stack([xs, ys, zs], axis=1)

    theta = np.radians(normal_deg_from_z)
    R = np.array([
        [1, 0, 0],
        [0, np.cos(theta), -np.sin(theta)],
        [0, np.sin(theta), np.cos(theta)],
    ])
    tilted = local_pts @ R.T
    tilted += rng.normal(0, noise_std_m, tilted.shape)

    true_normal = R @ np.array([0.0, 0.0, 1.0])
    if true_normal[2] < 0:
        true_normal = -true_normal
    return tilted, true_normal


def test_estimate_surface_pose_recovers_known_normal():
    points, true_normal = make_tilted_plane_points(normal_deg_from_z=15.0)

    pose = estimate_surface_pose(points)

    cos_angle = float(np.dot(pose.normal_m, true_normal))
    assert cos_angle > 0.999, f"Recovered normal off by {np.degrees(np.arccos(min(1.0, cos_angle))):.2f} deg"
    assert pose.planarity > 0.99, f"Expected near-perfect planarity for a flat synthetic patch, got {pose.planarity}"
    assert np.allclose(pose.centroid_m, [0, 0, 0], atol=0.01)


def test_estimate_surface_pose_flags_low_planarity_for_noisy_cloud():
    rng = np.random.default_rng(7)
    # A cube-ish blob of points has no dominant plane at all.
    noisy_blob = rng.uniform(-0.05, 0.05, (300, 3))

    pose = estimate_surface_pose(noisy_blob)

    assert pose.planarity < 0.8, f"Expected low planarity for a non-planar point cloud, got {pose.planarity}"


def test_estimate_surface_pose_requires_at_least_three_points():
    try:
        estimate_surface_pose(np.array([[0, 0, 0], [1, 0, 0]]))
        assert False, "Expected ValueError for too few points"
    except ValueError:
        pass


if __name__ == "__main__":
    test_estimate_surface_pose_recovers_known_normal()
    test_estimate_surface_pose_flags_low_planarity_for_noisy_cloud()
    test_estimate_surface_pose_requires_at_least_three_points()
    print("pose_estimation: all tests passed")
