"""Synthetic-data test for quality_inspection/quality_inspection.py."""
import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "quality_inspection"))
from quality_inspection import inspect_against_golden  # noqa: E402


def make_golden_image():
    img = np.full((200, 300, 3), 200, dtype=np.uint8)
    cv2.rectangle(img, (50, 50), (250, 150), (120, 120, 120), thickness=-1)
    return img


def test_identical_image_passes():
    golden = make_golden_image()
    test = golden.copy()

    result = inspect_against_golden(test, golden)

    assert result.passed, f"Identical image unexpectedly failed inspection (score={result.anomaly_score})"
    assert result.anomaly_score < 0.001


def test_defective_image_fails():
    golden = make_golden_image()
    defective = golden.copy()
    # A conspicuous "scratch"/foreign-object defect not present in the golden reference.
    cv2.circle(defective, (150, 100), 20, (0, 0, 255), thickness=-1)

    result = inspect_against_golden(defective, golden)

    assert not result.passed, f"Defective image unexpectedly passed inspection (score={result.anomaly_score})"
    assert result.anomaly_score > 0.01


def test_mismatched_shapes_raise():
    golden = make_golden_image()
    wrong_size = cv2.resize(golden, (100, 80))
    try:
        inspect_against_golden(wrong_size, golden)
        assert False, "Expected ValueError for mismatched image shapes"
    except ValueError:
        pass


if __name__ == "__main__":
    test_identical_image_passes()
    test_defective_image_fails()
    test_mismatched_shapes_raise()
    print("quality_inspection: all tests passed")
