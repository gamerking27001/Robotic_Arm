"""vision/part_localization/part_localization.py

§15.1: "Part Localization | RGB or depth camera | Classical CV (edge/blob) or
lightweight CNN | Pick-place with variable part position."

Classical-CV implementation: threshold -> contour -> minAreaRect gives pixel
centroid + in-plane orientation. A homography (computed once during
calibration, from >=4 known table-plane points) maps that pixel location to
a world-frame (X, Y) on the table plane, which is what the motion
controller's IK (kinematics/ik_solver.*) actually needs.
"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass
class PartDetection:
    centroid_px: tuple[float, float]
    angle_deg: float          # in-plane orientation from cv2.minAreaRect, [-90, 90)
    area_px: float
    world_xy_m: tuple[float, float] | None = None


def locate_parts(
    image_bgr: np.ndarray,
    threshold: int = 127,
    min_area_px: float = 200.0,
    invert: bool = False,
) -> list[PartDetection]:
    """Finds part-like blobs via fixed thresholding + contours.

    Assumes reasonable contrast between parts and background (a lit,
    single-color conveyor/tray background) — the same assumption §15.1's
    "Classical CV (edge/blob)" entry makes; low-contrast or cluttered scenes
    are exactly why §15.1 also lists a lightweight-CNN fallback, which this
    module does not implement.
    """
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY) if image_bgr.ndim == 3 else image_bgr
    flag = cv2.THRESH_BINARY_INV if invert else cv2.THRESH_BINARY
    _, binary = cv2.threshold(gray, threshold, 255, flag)

    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    detections: list[PartDetection] = []
    for c in contours:
        area = cv2.contourArea(c)
        if area < min_area_px:
            continue
        rect = cv2.minAreaRect(c)  # ((cx, cy), (w, h), angle)
        (cx, cy), (_, _), angle = rect
        detections.append(PartDetection(centroid_px=(cx, cy), angle_deg=angle, area_px=area))
    return detections


def pixel_to_world(u: float, v: float, homography: np.ndarray) -> tuple[float, float]:
    """Maps an image pixel to a world-frame (X, Y) on the calibrated table
    plane via a 3x3 homography (computed once, offline, from >=4
    known-position fiducials — see tests/test_part_localization.py for how
    that homography is built and validated)."""
    pt = np.array([u, v, 1.0])
    world = homography @ pt
    world /= world[2]
    return float(world[0]), float(world[1])


def locate_parts_in_world(
    image_bgr: np.ndarray,
    homography: np.ndarray,
    **kwargs,
) -> list[PartDetection]:
    detections = locate_parts(image_bgr, **kwargs)
    for d in detections:
        d.world_xy_m = pixel_to_world(d.centroid_px[0], d.centroid_px[1], homography)
    return detections
