import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Proxies /api and /ws to the FastAPI backend (dashboard/backend, default
// port 8000) during `npm run dev`, so the frontend's fetch()/WebSocket calls
// to relative paths (see src/api.ts) work without a separate CORS setup.
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
      },
      '/ws': {
        target: 'ws://127.0.0.1:8000',
        ws: true,
      },
    },
  },
})
