# dashboard/frontend

§19.4: "Frontend React + TypeScript." A minimal but functional operator
dashboard: live joint telemetry (via WebSocket), a safety-state banner with
fault reasons, E-stop trigger/reset buttons, and a form to send a joint-space
move — talking to `dashboard/backend`'s REST/WebSocket API.

## This layer is actually built and integration-tested

- `npm run build` runs a real `tsc -b` type-check + Vite production build —
  verified clean (no type errors).
- The built app was served with `vite preview` alongside a real running
  backend, and I confirmed (not assumed) that the dev/preview proxy
  correctly forwards both `/api/*` REST calls and the `/ws/telemetry`
  WebSocket to the FastAPI backend — checked the actual JSON payload and a
  real WebSocket message came back, not just an HTTP 200 (Vite's proxy
  can return a misleading 200 via SPA fallback if misconfigured, so this
  was worth checking rather than assuming).

## Run

```bash
npm install
npm run dev        # http://localhost:5173, proxies /api and /ws to
                    # http://127.0.0.1:8000 (see vite.config.ts) — start
                    # dashboard/backend first
```

Or build for production and serve `dist/` from any static file server (or
have the FastAPI backend serve it directly via `StaticFiles` — not wired up
here, since that's a deployment choice rather than something the source doc
specifies).

## What's here vs. what a real operator dashboard would need

This is intentionally minimal — a working skeleton, not a polished product:

- No auth (a real deployment would gate E-stop/move endpoints behind
  operator login).
- No Cartesian/TCP-space move input (§13.1 Cartesian Control mode) — only
  joint-space targets, matching what `dashboard/backend`'s `/api/moves`
  currently exposes.
- No historical trending/logging view — only live current state.
- No visual 3D robot rendering (that's what `ros2_ws/robot_description`'s
  RViz view is for; this dashboard is deliberately just numbers and
  controls).
