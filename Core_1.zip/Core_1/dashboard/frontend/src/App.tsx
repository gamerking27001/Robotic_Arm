import { useEffect, useMemo, useState } from 'react';
import './App.css';
import {
  fetchConfig,
  getApiKey,
  postEstopReset,
  postEstopTrigger,
  postMove,
  setApiKey,
  subscribeTelemetry,
  UnauthorizedError,
  type ConfigResponse,
  type SafetyStatus,
  type Telemetry,
} from './api';

const DEFAULT_TELEMETRY: Telemetry = { joints: [], move_active: false, elapsed_move_time_s: 0 };
const DEFAULT_SAFETY: SafetyStatus = {
  state: 'Unknown',
  estop_pressed: false,
  sto_required: false,
  collision_suspected: false,
  overcurrent: false,
  overtemperature: false,
  soft_limit_violation: false,
  hard_limit_violation: false,
  any_fault: false,
};

function faultReasons(s: SafetyStatus): string[] {
  const reasons: string[] = [];
  if (s.estop_pressed) reasons.push('E-stop pressed');
  if (s.collision_suspected) reasons.push('Collision suspected (torque deviation)');
  if (s.overcurrent) reasons.push('Overcurrent');
  if (s.overtemperature) reasons.push('Overtemperature');
  if (s.soft_limit_violation) reasons.push('Soft limit violation');
  if (s.hard_limit_violation) reasons.push('Hard limit violation');
  if (s.sto_required) reasons.push('STO required');
  return reasons;
}

function stateClass(state: string): string {
  if (state === 'EStop' || state === 'Fault') return 'state-bad';
  if (state === 'Running' || state === 'Paused') return 'state-active';
  return 'state-ok';
}

/** Minimal key-entry gate, added alongside dashboard/backend's new auth
 * requirement (see api.ts's module comment). Deliberately simple -- a
 * single field, no separate viewer/operator role selection in the UI
 * itself, since the backend already enforces that distinction per-request
 * based on which key was actually issued to the operator. A real
 * deployment's identity/role management (who gets which key, rotation,
 * etc.) happens outside this dashboard, e.g. via whatever secret-storage
 * process issues DASHBOARD_OPERATOR_API_KEY in the first place. */
function ApiKeyGate({ onSubmit }: { onSubmit: () => void }) {
  const [value, setValue] = useState('');
  return (
    <div className="dashboard api-key-gate">
      <header className="topbar">
        <h1>Modular Arm — Operator Dashboard</h1>
      </header>
      <section className="safety-banner state-ok">
        <strong>Enter API key to continue</strong>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!value.trim()) return;
            setApiKey(value.trim());
            onSubmit();
          }}
        >
          <input
            type="password"
            autoFocus
            placeholder="API key"
            value={value}
            onChange={(e) => setValue(e.target.value)}
          />
          <button className="btn-primary" type="submit">
            Connect
          </button>
        </form>
      </section>
    </div>
  );
}

export default function App() {
  const [hasKey, setHasKey] = useState<boolean>(() => getApiKey() !== null);
  const [config, setConfig] = useState<ConfigResponse | null>(null);
  const [telemetry, setTelemetry] = useState<Telemetry>(DEFAULT_TELEMETRY);
  const [safety, setSafety] = useState<SafetyStatus>(DEFAULT_SAFETY);
  const [connected, setConnected] = useState(false);
  const [targets, setTargets] = useState<number[]>(Array(6).fill(0));
  const [busy, setBusy] = useState(false);
  const [lastError, setLastError] = useState<string | null>(null);

  // If the stored key turns out to be wrong (or the backend restarted with
  // different keys), any request will 401 -- send the operator back to the
  // key-entry gate instead of leaving a silently-broken dashboard up.
  function handleUnauthorized() {
    setHasKey(false);
    setLastError('API key rejected -- please re-enter it.');
  }

  useEffect(() => {
    if (!hasKey) return;
    fetchConfig()
      .then(setConfig)
      .catch((e) => {
        if (e instanceof UnauthorizedError) handleUnauthorized();
        else setLastError(String(e));
      });
  }, [hasKey]);

  useEffect(() => {
    if (!hasKey) return;
    const unsubscribe = subscribeTelemetry(
      (msg) => {
        setTelemetry(msg.telemetry);
        setSafety(msg.safety);
      },
      setConnected,
    );
    return unsubscribe;
  }, [hasKey]);

  const jointNames = useMemo(
    () => config?.joints.map((j) => j.name) ?? telemetry.joints.map((j) => j.joint_name),
    [config, telemetry],
  );

  async function handleMoveSubmit() {
    setBusy(true);
    setLastError(null);
    try {
      await postMove(targets, true);
    } catch (e) {
      if (e instanceof UnauthorizedError) handleUnauthorized();
      else setLastError(String(e));
    } finally {
      setBusy(false);
    }
  }

  async function handleEstopTrigger() {
    setLastError(null);
    try {
      await postEstopTrigger('operator dashboard button');
    } catch (e) {
      if (e instanceof UnauthorizedError) handleUnauthorized();
      else setLastError(String(e));
    }
  }

  async function handleEstopReset() {
    setLastError(null);
    try {
      await postEstopReset('dashboard-operator');
    } catch (e) {
      if (e instanceof UnauthorizedError) handleUnauthorized();
      else setLastError(String(e));
    }
  }

  const reasons = faultReasons(safety);

  if (!hasKey) {
    return <ApiKeyGate onSubmit={() => setHasKey(true)} />;
  }

  return (
    <div className="dashboard">
      <header className="topbar">
        <h1>Modular Arm — Operator Dashboard</h1>
        <span className={`ws-indicator ${connected ? 'ws-up' : 'ws-down'}`}>
          {connected ? 'live' : 'disconnected'}
        </span>
      </header>

      <section className={`safety-banner ${stateClass(safety.state)}`}>
        <strong>State: {safety.state}</strong>
        {reasons.length > 0 && (
          <ul className="fault-list">
            {reasons.map((r) => (
              <li key={r}>{r}</li>
            ))}
          </ul>
        )}
        <div className="estop-controls">
          <button className="btn-danger" onClick={handleEstopTrigger}>
            Trigger E-stop
          </button>
          <button className="btn-secondary" onClick={handleEstopReset}>
            Reset E-stop
          </button>
        </div>
      </section>

      {config && (
        <section className="spec-summary">
          <h2>Robot Spec (§1.5/§2.1)</h2>
          <div className="spec-grid">
            <div>Payload: {config.robot.payload_nominal_kg} / {config.robot.payload_peak_kg} kg</div>
            <div>Reach: {config.robot.reach_mm} mm</div>
            <div>Repeatability: ±{config.robot.repeatability_mm} mm</div>
            <div>Max TCP speed: {config.robot.max_tcp_speed_mps} m/s</div>
            <div>Bus: {config.robot.bus_voltage_vdc} VDC / {config.robot.rated_power_w_peak} W peak</div>
          </div>
        </section>
      )}

      <section className="joints">
        <h2>Joint Telemetry</h2>
        <table>
          <thead>
            <tr>
              <th>Joint</th>
              <th>Position (deg)</th>
              <th>Velocity (deg/s)</th>
              <th>Current (A)</th>
              <th>Torque (Nm)</th>
              <th>Temp (°C)</th>
              <th>STO</th>
              <th>Fault</th>
              <th>Target (deg)</th>
            </tr>
          </thead>
          <tbody>
            {telemetry.joints.map((j, i) => (
              <tr key={j.joint_name} className={j.fault ? 'row-fault' : ''}>
                <td>{jointNames[i] ?? j.joint_name}</td>
                <td>{j.position_deg.toFixed(2)}</td>
                <td>{j.velocity_deg_s.toFixed(2)}</td>
                <td>{j.current_a.toFixed(2)}</td>
                <td>{j.torque_estimate_nm.toFixed(2)}</td>
                <td>{j.winding_temp_c.toFixed(1)}</td>
                <td>{j.sto_active ? 'ON' : '—'}</td>
                <td>{j.fault ? 'FAULT' : 'ok'}</td>
                <td>
                  <input
                    type="number"
                    value={targets[i]}
                    onChange={(e) => {
                      const next = [...targets];
                      next[i] = Number(e.target.value);
                      setTargets(next);
                    }}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="move-controls">
          <button className="btn-primary" onClick={handleMoveSubmit} disabled={busy || telemetry.move_active}>
            {telemetry.move_active ? `Moving (t=${telemetry.elapsed_move_time_s.toFixed(2)}s)` : 'Send move'}
          </button>
        </div>
      </section>

      {lastError && <div className="error-banner">{lastError}</div>}
    </div>
  );
}
