// src/api.ts
// Types mirror dashboard/backend/main.py's Pydantic response models exactly
// (§19.4: "Frontend React + TypeScript").

export interface RobotSpec {
  payload_nominal_kg: number;
  payload_peak_kg: number;
  reach_mm: number;
  repeatability_mm: number;
  pose_accuracy_mm: number;
  max_tcp_speed_mps: number;
  rated_power_w_peak: number;
  bus_voltage_vdc: number;
  weight_kg: number;
  controller_weight_kg: number;
  ambient_temp_min_c: number;
  ambient_temp_max_c: number;
  acoustic_noise_dba: number;
}

export interface JointSpec {
  name: string;
  gear_ratio: number;
  rated_torque_nm: number;
  peak_torque_nm: number;
  rated_rpm: number;
  motor_power_w: number;
  encoder_bits: number;
  soft_limit_min_deg: number;
  soft_limit_max_deg: number;
  max_speed_deg_s: number;
}

export interface ConfigResponse {
  robot: RobotSpec;
  joints: JointSpec[];
}

export interface JointTelemetry {
  joint_name: string;
  position_deg: number;
  velocity_deg_s: number;
  current_a: number;
  torque_estimate_nm: number;
  winding_temp_c: number;
  sto_active: boolean;
  fault: boolean;
}

export interface Telemetry {
  joints: JointTelemetry[];
  move_active: boolean;
  elapsed_move_time_s: number;
}

export interface SafetyStatus {
  state: string;
  estop_pressed: boolean;
  sto_required: boolean;
  collision_suspected: boolean;
  overcurrent: boolean;
  overtemperature: boolean;
  soft_limit_violation: boolean;
  hard_limit_violation: boolean;
  any_fault: boolean;
}

export interface WsMessage {
  telemetry: Telemetry;
  safety: SafetyStatus;
}

const API_BASE = '/api';

// --- API key (added alongside dashboard/backend's new auth requirement --
// see main.py's module docstring). Stored in sessionStorage rather than
// localStorage: it's cleared when the tab closes, which is the right
// tradeoff for a credential that can command robot motion -- surviving a
// page reload is convenient, surviving indefinitely on a shared machine
// is not.
//
// NOTE: this module now sends the key on every request/connection; it does
// NOT yet include a UI affordance to collect it from the operator (a login
// screen, a settings field, etc.) -- that's a small addition for whichever
// component owns app-level layout (not guessed at here since this file's
// job is the API client, not component structure). Until that exists,
// call setApiKey(...) once (e.g. from the browser console during
// development, or a temporary hardcoded call during initial bring-up) or
// the backend will reject every request with 401.
const API_KEY_STORAGE_KEY = 'arm_dashboard_api_key';

export function setApiKey(key: string): void {
  sessionStorage.setItem(API_KEY_STORAGE_KEY, key);
}

export function getApiKey(): string | null {
  return sessionStorage.getItem(API_KEY_STORAGE_KEY);
}

export function clearApiKey(): void {
  sessionStorage.removeItem(API_KEY_STORAGE_KEY);
}

/** Thrown specifically on a 401 so calling UI code can distinguish "not
 * authenticated" from other failures and prompt for a key, rather than
 * showing a generic error. */
export class UnauthorizedError extends Error {
  constructor() {
    super('Unauthorized -- missing or invalid API key');
    this.name = 'UnauthorizedError';
  }
}

function authHeaders(): HeadersInit {
  const key = getApiKey();
  return key ? { 'X-API-Key': key } : {};
}

async function jsonOrThrow<T>(res: Response): Promise<T> {
  if (res.status === 401) {
    throw new UnauthorizedError();
  }
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`${res.status} ${res.statusText}: ${body}`);
  }
  return res.json() as Promise<T>;
}

export async function fetchConfig(): Promise<ConfigResponse> {
  return jsonOrThrow(await fetch(`${API_BASE}/config`, { headers: authHeaders() }));
}

export async function fetchTelemetry(): Promise<Telemetry> {
  return jsonOrThrow(await fetch(`${API_BASE}/telemetry`, { headers: authHeaders() }));
}

export async function fetchSafety(): Promise<SafetyStatus> {
  return jsonOrThrow(await fetch(`${API_BASE}/safety`, { headers: authHeaders() }));
}

export async function postMove(targetDeg: number[], useSCurve = true): Promise<{ accepted: boolean }> {
  const res = await fetch(`${API_BASE}/moves`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({ target_deg: targetDeg, use_s_curve: useSCurve }),
  });
  return jsonOrThrow(res);
}

export async function postEstopTrigger(reason: string): Promise<{ accepted: boolean }> {
  const res = await fetch(`${API_BASE}/estop/trigger`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({ reason }),
  });
  return jsonOrThrow(res);
}

export async function postEstopReset(operatorId: string): Promise<{ accepted: boolean }> {
  const res = await fetch(`${API_BASE}/estop/reset`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({ operator_id: operatorId }),
  });
  return jsonOrThrow(res);
}

/** Opens the /ws/telemetry stream. Returns a cleanup function; `onMessage`
 * fires ~10x/sec with a fresh {telemetry, safety} snapshot (see
 * dashboard/backend/main.py's ws_telemetry handler). Auth via ?api_key=
 * query param -- browsers can't set custom headers on a WebSocket
 * handshake, so this mirrors the backend's documented workaround
 * (see main.py's module docstring). */
export function subscribeTelemetry(
  onMessage: (msg: WsMessage) => void,
  onStatusChange?: (connected: boolean) => void,
): () => void {
  const proto = window.location.protocol === 'https:' ? 'wss' : 'ws';
  const key = getApiKey();
  const query = key ? `?api_key=${encodeURIComponent(key)}` : '';
  const url = `${proto}://${window.location.host}/ws/telemetry${query}`;
  let socket: WebSocket | null = null;
  let closed = false;
  let retryTimer: ReturnType<typeof setTimeout> | null = null;

  const connect = () => {
    if (closed) return;
    socket = new WebSocket(url);
    socket.onopen = () => onStatusChange?.(true);
    socket.onmessage = (event) => {
      try {
        onMessage(JSON.parse(event.data) as WsMessage);
      } catch {
        // ignore malformed frames
      }
    };
    socket.onclose = () => {
      onStatusChange?.(false);
      if (!closed) retryTimer = setTimeout(connect, 1000);
    };
    socket.onerror = () => socket?.close();
  };
  connect();

  return () => {
    closed = true;
    if (retryTimer) clearTimeout(retryTimer);
    socket?.close();
  };
}
