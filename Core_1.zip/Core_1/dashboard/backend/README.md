# dashboard/backend

§19.4/§20.1: "Backend API FastAPI" / "dashboard/backend FastAPI service
exposing robot state, diagnostics, and configuration endpoints." Backed by
`native_bridge/` — a thin C ABI (extern "C", POD structs) wrapping the
already-verified core C++ stack (`../../include`, `../../src`), loaded from
Python via `ctypes`. No pybind11/Boost.Python, no ROS2 dependency.

## This layer is actually tested, unlike ros2_ws

Unlike `ros2_ws/` (which needs a real ROS2 install this environment doesn't
have), this backend was originally built, run, and exercised with real HTTP
requests against the real ticking simulation:

- Every GET/POST endpoint tested with `curl` against a live `uvicorn` server.
- A full move tracked in real time from 0° to 30° via `/api/telemetry`
  polling, confirming the S-curve profile and exact target arrival.
- The E-stop trigger → move-rejected-with-409 → reset → move-works-again
  cycle, end to end.
- A real bug caught and fixed in the process: the first version only ran
  `SafetyFsm::evaluate()` when `/api/safety` happened to be polled, so a
  fault occurring right before a short move finished could be missed
  entirely (the move would complete and return to `Idle` before the fault
  was ever evaluated against `Running` state). Fixed by moving the
  evaluation into `robot_bridge_tick()` itself, once per tick, with the
  result cached for the getter to report — see the comment in
  `native_bridge/robot_bridge.cpp`.
- The collision-injection test hook (`/api/joints/{i}/load`) confirmed to
  correctly latch `Running -> Fault` and clear via the E-stop cycle.
- The WebSocket streaming endpoint (`/ws/telemetry`) smoke-tested with a real
  Python `websockets` client.

**Caveat on the authentication layer added since:** the API-key auth
described below was written and syntax-checked (`python3 -m py_compile`)
in an environment without network access to install `fastapi`/`uvicorn`,
so — unlike everything above — it has **not** been re-verified with the
same live-server `curl` testing. The logic was reviewed carefully by hand
(constant-time key comparison, fail-closed startup check, dependency
wiring on every endpoint), but treat it with the same "careful first
draft" caution as `ros2_ws` until it's actually been run. Test it with:
```bash
export DASHBOARD_VIEWER_API_KEY=devkey_viewer
export DASHBOARD_OPERATOR_API_KEY=devkey_operator
uvicorn main:app --reload &
curl -i http://127.0.0.1:8000/api/telemetry                              # expect 401
curl -i -H "X-API-Key: devkey_viewer" http://127.0.0.1:8000/api/telemetry # expect 200
curl -i -H "X-API-Key: devkey_viewer" -X POST http://127.0.0.1:8000/api/estop/trigger \
  -H "Content-Type: application/json" -d '{"reason":"test"}'             # expect 401 (viewer can't trigger)
curl -i -H "X-API-Key: devkey_operator" -X POST http://127.0.0.1:8000/api/estop/trigger \
  -H "Content-Type: application/json" -d '{"reason":"test"}'             # expect 200
```
before relying on it for anything beyond local development.

## Authentication

Two API keys are required via environment variables — there is no default
key baked in (a hardcoded default is itself a well-known vulnerability, so
this fails closed: the app refuses to start rather than start unsecured):

| Variable | Grants |
|---|---|
| `DASHBOARD_VIEWER_API_KEY` | Read-only: `GET /api/*`, `/ws/telemetry` |
| `DASHBOARD_OPERATOR_API_KEY` | Read/write: all of the above plus every `POST /api/*` (moves, E-stop trigger/reset, load injection) |

Send the key as an `X-API-Key` header (HTTP) or `?api_key=...` query
parameter (WebSocket — browsers can't set custom headers on the WS
handshake). For local development only, `DASHBOARD_ALLOW_INSECURE=1`
skips auth entirely and logs a warning on startup; never set this in a
real deployment.

`DASHBOARD_CORS_ORIGINS` (comma-separated) controls cross-origin browser
access — empty/unset means same-origin only.

## Build & run

```bash
./build.sh                       # compiles native_bridge/librobot_bridge.so
pip install -r requirements.txt
uvicorn main:app --reload        # http://127.0.0.1:8000
```

`build.sh` compiles directly against `../../include` and `../../src` — same
monorepo-relative-path pattern used by `ros2_ws`'s `CMakeLists.txt` files (see
those files' comments for the rationale).

## Endpoints

| Method & path | Auth | Purpose |
|---|---|---|
| `GET /api/config` | viewer | Full robot + per-joint spec (§1.5/§2.1/§6.2), straight from the compiled-in config |
| `GET /api/telemetry` | viewer | Live per-joint telemetry (position/velocity/current/torque/temp) |
| `GET /api/safety` | viewer | Safety FSM state (§13.5) + aggregated safety-function checks (§14.1) |
| `POST /api/moves` | operator | `{"target_deg": [J1..J6], "use_s_curve": true}` — starts a synchronized joint-space move |
| `POST /api/estop/trigger` | operator | `{"reason": "..."}` — software E-stop |
| `POST /api/estop/reset` | operator | `{"operator_id": "..."}` — clears E-stop, re-homes to Idle |
| `POST /api/joints/{i}/load` | operator | `{"load_nm": ...}` — test/demo hook, injects an external load to exercise collision detection |
| `WS /ws/telemetry` | viewer | Streams `{telemetry, safety}` at ~10 Hz |

## What's real vs. illustrative here

- The physics, kinematics, motion profiles, and safety FSM are the exact
  same verified code `arm_demo` exercises — this backend adds no new
  simulation logic, just a control surface over it.
- The background `TickerThread` runs the plant at 200 Hz regardless of
  request load — HTTP requests only read/write state, they don't drive
  simulation time (avoids the plant's timing depending on client behavior).
- `/api/joints/{i}/load` is a testing convenience, not part of the source
  design doc's specified API — real deployments wouldn't expose "inject an
  arbitrary joint load" over HTTP.
