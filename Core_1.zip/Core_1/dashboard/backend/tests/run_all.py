#!/usr/bin/env python3
"""dashboard/backend/tests/run_all.py — runs both dashboard backend
test files (adapter tests + live-HTTP tests) with one combined
pass/fail summary. No pytest required."""
import sys

sys.path.insert(0, ".")
import test_ai_routes_adapters as t1
import test_ai_routes_over_http as t2

total_failed = 0
for mod, label in [(t1, "adapters"), (t2, "over_http")]:
    print(f"=== {label} ===")
    rc = mod._run()
    total_failed += rc

sys.exit(1 if total_failed else 0)
