"""dashboard/backend/tests/test_ai_routes_adapters.py

Tests the telemetry-adapter functions in ai_routes.py WITHOUT
FastAPI or pydantic — plain dataclass stand-ins for TelemetryOut/
JointTelemetryOut, matching their exact field names, exercise the
same duck-typed contract main.py's real models satisfy. Run with:

    python3 dashboard/backend/tests/test_ai_routes_adapters.py

(no pytest required — same pytest-style/pytest-compatible pattern as
ai/tests/run_tests.py.)
"""
from __future__ import annotations

import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import List

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import ai_routes  # noqa: E402


@dataclass
class FakeJointTelemetry:
    joint_name: str
    position_deg: float
    velocity_deg_s: float
    current_a: float
    torque_estimate_nm: float
    winding_temp_c: float
    sto_active: bool
    fault: bool


@dataclass
class FakeTelemetryOut:
    joints: List[FakeJointTelemetry]
    move_active: bool = False
    elapsed_move_time_s: float = 0.0


def _make_telemetry(temp_c: float = 40.0, current_a: float = 2.0) -> FakeTelemetryOut:
    joints = [
        FakeJointTelemetry(
            joint_name=name, position_deg=0.0, velocity_deg_s=10.0,
            current_a=current_a, torque_estimate_nm=8.0, winding_temp_c=temp_c,
            sto_active=False, fault=False,
        )
        for name in ["waist", "shoulder", "elbow", "wrist_pitch", "wrist_roll", "wrist_yaw"]
    ]
    return FakeTelemetryOut(joints=joints)


def test_observe_telemetry_out_accepts_duck_typed_telemetry_object():
    telemetry = _make_telemetry()
    ai_routes.observe_telemetry_out(telemetry)  # must not raise


def test_predictive_maintenance_summary_returns_one_entry_per_joint():
    for _ in range(30):
        ai_routes.observe_telemetry_out(_make_telemetry())
    joint_names = [j.joint_name for j in _make_telemetry().joints]
    summary = ai_routes.get_predictive_maintenance_summary(joint_names)
    assert len(summary) == len(joint_names)
    assert all("payload" in s for s in summary)


def test_thermal_summary_reflects_rising_temperature():
    for t in [40 + i for i in range(30)]:
        ai_routes.observe_telemetry_out(_make_telemetry(temp_c=t))
    summary = ai_routes.get_thermal_summary(["elbow"])
    assert len(summary) == 1
    assert "forecast_temp_c" in summary[0]["payload"]


def test_anomaly_summary_runs_without_error_after_observations():
    for _ in range(60):
        ai_routes.observe_telemetry_out(_make_telemetry())
    summary = ai_routes.get_anomaly_summary(["elbow"])
    assert len(summary) == 1
    assert "anomaly_score" in summary[0]["payload"]


def test_fleet_summary_and_operator_assistant_are_reachable():
    fleet = ai_routes.get_fleet_summary()
    assert "maintenance_priority_ranking" in fleet["payload"]

    answer = ai_routes.ask_operator_assistant("What is the meaning of life?")
    assert answer["payload"]["refused"] is True  # ungrounded query — correctly refused, not invented


def test_low_rul_observation_produces_a_retrievable_alert():
    # Push enough low-wear-looking observations that predictive
    # maintenance's cold-start/fleet-baseline model still returns
    # SOME finite RUL, then check the alert path end-to-end through
    # the real ai_routes module-level store (not a fresh test store),
    # confirming the wiring in ai_routes.py itself — not just
    # persistence.py in isolation — actually connects services to
    # the store.
    for _ in range(40):
        ai_routes.observe_telemetry_out(_make_telemetry(temp_c=90.0, current_a=6.0))
    ai_routes.get_predictive_maintenance_summary(["elbow"])  # triggers .run() -> persists + evaluates alert rules
    alerts = ai_routes.get_alerts()
    assert isinstance(alerts, list)  # may or may not cross a threshold depending on the trained model's output,
    # but the call must succeed and return a well-formed list either way — the real assertion is no exception.


def test_acknowledge_alert_is_idempotent_through_the_adapter():
    # Exercises the acknowledge path even with zero real alerts present
    # — acknowledging a nonexistent id must return acknowledged: False,
    # not raise.
    result = ai_routes.acknowledge_alert("nonexistent-alert-id", acknowledged_by="test-operator")
    assert result["acknowledged"] is False


def test_module_imports_cleanly_regardless_of_fastapi_availability():
    # The core guarantee this module makes: adapter functions work
    # whether or not fastapi is installed. build_router's behavior
    # differs (raises ImportError without fastapi), but importing
    # ai_routes itself never fails either way.
    assert hasattr(ai_routes, "observe_telemetry_out")
    assert hasattr(ai_routes, "build_router")


def _run() -> int:
    fns = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    failed = 0
    for fn in fns:
        try:
            fn()
            print(f"  ok   {fn.__name__}")
        except Exception:
            failed += 1
            print(f"  FAIL {fn.__name__}")
            traceback.print_exc()
    print(f"\n{len(fns) - failed}/{len(fns)} tests passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(_run())
