@echo off
REM dashboard/backend/build.bat
REM Windows equivalent of build.sh: compiles native_bridge/robot_bridge.dll
REM against the same core stack sources (../../../include, ../../../src).
REM
REM UNVERIFIED NOTICE, stated plainly: this script was written carefully
REM (correct MSVC flags, correct /D define matching robot_bridge.h's
REM export macro, correct source list mirrored 1:1 from build.sh) but has
REM NOT been run — there is no MSVC (cl.exe) or MinGW cross-compiler
REM available in the sandbox this was written in to actually test it.
REM What WAS verified directly: robot_bridge.h's new ROBOT_BRIDGE_API
REM export-macro change does not break the existing, working Linux build
REM (re-ran build.sh and a real ctypes smoke test against the rebuilt
REM .so — see ai/README.md's compliance-audit section for why this
REM verify-don't-assume habit matters). Treat this specific file as a
REM careful first draft to test on real Windows hardware, same caution
REM this repo's own README already asks for on other untested layers.
REM
REM Requires "Developer Command Prompt for VS" (or run vcvarsall.bat
REM first) so cl.exe is on PATH. See the MinGW alternative below this
REM script for a GCC-based option if MSVC Build Tools aren't installed.

setlocal
cd /d "%~dp0"

set CORE_ROOT=..\..

cl.exe /std:c++20 /O2 /W4 /EHsc /LD ^
  /D ROBOT_BRIDGE_BUILD_DLL ^
  /I "%CORE_ROOT%\include" ^
  native_bridge\robot_bridge.cpp ^
  "%CORE_ROOT%\src\kinematics\dh_kinematics.cpp" ^
  "%CORE_ROOT%\src\kinematics\ik_solver.cpp" ^
  "%CORE_ROOT%\src\motion\trajectory_profile.cpp" ^
  "%CORE_ROOT%\src\motion\motion_controller.cpp" ^
  "%CORE_ROOT%\src\hal\simulated_joint_driver.cpp" ^
  "%CORE_ROOT%\src\safety\safety_fsm.cpp" ^
  /Fe:native_bridge\robot_bridge.dll

if %ERRORLEVEL% NEQ 0 (
  echo Build failed.
  exit /b 1
)

echo Built native_bridge\robot_bridge.dll

REM --- MinGW-w64 alternative (if MSVC Build Tools aren't installed) ---
REM Comment out the cl.exe block above and use this instead. MinGW's
REM g++ accepts nearly the same flags as the Linux build.sh:
REM
REM g++ -std=c++20 -O2 -Wall -Wextra -shared -DROBOT_BRIDGE_BUILD_DLL ^
REM   -I "%CORE_ROOT%\include" ^
REM   native_bridge\robot_bridge.cpp ^
REM   "%CORE_ROOT%\src\kinematics\dh_kinematics.cpp" ^
REM   "%CORE_ROOT%\src\kinematics\ik_solver.cpp" ^
REM   "%CORE_ROOT%\src\motion\trajectory_profile.cpp" ^
REM   "%CORE_ROOT%\src\motion\motion_controller.cpp" ^
REM   "%CORE_ROOT%\src\hal\simulated_joint_driver.cpp" ^
REM   "%CORE_ROOT%\src\safety\safety_fsm.cpp" ^
REM   -o native_bridge\robot_bridge.dll

endlocal
