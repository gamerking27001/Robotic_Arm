// dashboard/backend/native_bridge/robot_bridge.h
// Plain C ABI wrapping the already-verified core C++ stack
// (../../../include, ../../../src) for consumption from Python via ctypes —
// no pybind11/Boost.Python dependency, just a small extern "C" surface and
// POD structs with fixed layout.
//
// §20.1: "dashboard/backend FastAPI service exposing robot state,
// diagnostics, and configuration endpoints." This header is the seam between
// that FastAPI service and the core stack: main.py loads the compiled
// .so via ctypes and calls straight into arm::hal::SimulatedJointDriver /
// arm::motion::MotionController / arm::safety::SafetyFsm.
#ifndef ROBOT_BRIDGE_H_
#define ROBOT_BRIDGE_H_

// Cross-platform export macro. On Linux/macOS, .so/.dylib symbols are
// exported by default, so this expands to nothing there — but on
// Windows, DLL symbols are NOT exported by default. Without
// __declspec(dllexport) on every function below, the DLL would still
// compile and load fine via ctypes.CDLL(), but every single
// `lib.robot_bridge_create` (etc.) attribute lookup from Python would
// fail with AttributeError, because the symbol simply wouldn't be in
// the DLL's export table. This was a real, code-level gap — caught by
// checking for `__declspec` in this header (there wasn't one) while
// making this bridge Windows-compatible, not assumed fine because the
// Linux/.so build worked.
#ifdef _WIN32
  #ifdef ROBOT_BRIDGE_BUILD_DLL
    #define ROBOT_BRIDGE_API __declspec(dllexport)
  #else
    #define ROBOT_BRIDGE_API __declspec(dllimport)
  #endif
#else
  #define ROBOT_BRIDGE_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    double payload_nominal_kg;
    double payload_peak_kg;
    double reach_mm;
    double repeatability_mm;
    double pose_accuracy_mm;
    double max_tcp_speed_mps;
    double rated_power_w_peak;
    double bus_voltage_vdc;
    double weight_kg;
    double controller_weight_kg;
    double ambient_temp_min_c;
    double ambient_temp_max_c;
    double acoustic_noise_dba;
} RobotSpecC;

typedef struct {
    char name[32];
    double gear_ratio;
    double rated_torque_nm;
    double peak_torque_nm;
    double rated_rpm;
    double motor_power_w;
    int encoder_bits;
    double soft_limit_min_deg;
    double soft_limit_max_deg;
    double max_speed_deg_s;
} JointSpecC;

typedef struct {
    double position_rad;
    double velocity_rad_s;
    double current_a;
    double torque_estimate_nm;
    double winding_temp_c;
    int sto_active;   // 0/1
    int fault;         // 0/1
} JointTelemetryC;

typedef struct {
    char state[16];             // "PowerOn"/"Homing"/"Idle"/"Running"/"Paused"/"Fault"/"EStop"
    int estop_pressed;
    int sto_required;
    int collision_suspected;
    int overcurrent;
    int overtemperature;
    int soft_limit_violation;
    int hard_limit_violation;
    int any_fault;
} SafetyStatusC;

typedef void* RobotBridgeHandle;

// Lifecycle. create() boots the safety FSM through PowerOn->Homing->Idle
// automatically (§13.5) and constructs six simulated joints + a
// MotionController, mirroring src/main.cpp's setup.
RobotBridgeHandle ROBOT_BRIDGE_API robot_bridge_create(void);
void ROBOT_BRIDGE_API robot_bridge_destroy(RobotBridgeHandle handle);

// Static configuration (doesn't need a handle — it's compiled-in config).
void ROBOT_BRIDGE_API robot_bridge_get_robot_spec(RobotSpecC* out);
int ROBOT_BRIDGE_API robot_bridge_get_joint_spec(int joint_index, JointSpecC* out);  // returns 1 on success, 0 if index out of range

// Live state.
int ROBOT_BRIDGE_API robot_bridge_get_joint_telemetry(RobotBridgeHandle handle, int joint_index, JointTelemetryC* out);
void ROBOT_BRIDGE_API robot_bridge_get_safety_status(RobotBridgeHandle handle, SafetyStatusC* out);
int ROBOT_BRIDGE_API robot_bridge_is_move_active(RobotBridgeHandle handle);
double ROBOT_BRIDGE_API robot_bridge_elapsed_move_time(RobotBridgeHandle handle);

// Control.
// target_deg6 must point to 6 doubles (joint angles in degrees, J1..J6).
// Returns 1 if the move was accepted and started, 0 otherwise (e.g. IK/limit
// rejection is not checked here — this is a joint-space move, §13.1).
int ROBOT_BRIDGE_API robot_bridge_begin_move(RobotBridgeHandle handle, const double* target_deg6, int use_s_curve);

// Advances the simulated plant + motion controller + safety evaluation by
// dt_s seconds — call this from a fixed-rate loop (the Python side runs this
// in a background thread, see main.py).
void ROBOT_BRIDGE_API robot_bridge_tick(RobotBridgeHandle handle, double dt_s);

int ROBOT_BRIDGE_API robot_bridge_trigger_estop(RobotBridgeHandle handle);
int ROBOT_BRIDGE_API robot_bridge_reset_estop(RobotBridgeHandle handle);

// Test/demo hook mirroring src/main.cpp's collision-injection demo (§14).
int ROBOT_BRIDGE_API robot_bridge_inject_load(RobotBridgeHandle handle, int joint_index, double load_nm);

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_BRIDGE_H_
