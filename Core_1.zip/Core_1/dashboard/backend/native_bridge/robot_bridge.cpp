// robot_bridge.cpp
#include "robot_bridge.h"

#include <array>
#include <cstring>
#include <memory>
#include <mutex>
#include <vector>

#include "core/linalg.hpp"
#include "core/robot_config.hpp"
#include "hal/can_bus_simulated.hpp"
#include "hal/simulated_joint_driver.hpp"
#include "motion/motion_controller.hpp"
#include "safety/safety_fsm.hpp"

namespace {

struct RobotBridgeImpl {
    arm::hal::SimulatedCanBus can_bus;
    std::vector<std::unique_ptr<arm::hal::SimulatedJointDriver>> joints;
    std::array<arm::hal::JointInterface*, arm::config::kNumJoints> joint_ptrs{};
    std::unique_ptr<arm::motion::MotionController> controller;
    arm::safety::SafetyFsm fsm;
    std::array<double, arm::config::kNumJoints> external_loads{};
    arm::safety::SafetyCheckResult last_check{};  // computed once per tick(), see robot_bridge_tick()
    std::mutex mutex;  // guards everything above; tick() and the getters can be called from different threads
};

void fillSafetyStatus(SafetyStatusC* out, const arm::safety::RobotState state,
                       const arm::safety::SafetyCheckResult& check) {
    std::memset(out->state, 0, sizeof(out->state));
    const auto sv = arm::safety::toString(state);
    std::strncpy(out->state, sv.data(), std::min(sv.size(), sizeof(out->state) - 1));
    out->estop_pressed = check.estop_pressed ? 1 : 0;
    out->sto_required = check.sto_required ? 1 : 0;
    out->collision_suspected = check.collision_suspected ? 1 : 0;
    out->overcurrent = check.overcurrent ? 1 : 0;
    out->overtemperature = check.overtemperature ? 1 : 0;
    out->soft_limit_violation = check.soft_limit_violation ? 1 : 0;
    out->hard_limit_violation = check.hard_limit_violation ? 1 : 0;
    out->any_fault = check.anyFault() ? 1 : 0;
}

}  // namespace

extern "C" {

RobotBridgeHandle robot_bridge_create() {
    auto* impl = new RobotBridgeImpl();
    for (std::size_t i = 0; i < arm::config::kNumJoints; ++i) {
        impl->joints.push_back(
            std::make_unique<arm::hal::SimulatedJointDriver>(static_cast<arm::config::JointId>(i), impl->can_bus));
        impl->joint_ptrs[i] = impl->joints[i].get();
    }
    impl->controller = std::make_unique<arm::motion::MotionController>(impl->joint_ptrs, /*control_loop_hz=*/200.0);

    // §13.5 automatic startup sequence.
    impl->fsm.handle(arm::safety::Event::kBootComplete);
    impl->fsm.handle(arm::safety::Event::kHomingComplete);

    return static_cast<RobotBridgeHandle>(impl);
}

void robot_bridge_destroy(RobotBridgeHandle handle) {
    delete static_cast<RobotBridgeImpl*>(handle);
}

void robot_bridge_get_robot_spec(RobotSpecC* out) {
    const auto& r = arm::config::kRobotSpec;
    *out = RobotSpecC{r.payload_nominal_kg,   r.payload_peak_kg,        r.reach_mm,
                       r.repeatability_mm,     r.pose_accuracy_mm_post_cal, r.max_tcp_speed_mps,
                       r.rated_power_w_peak,   r.bus_voltage_vdc,        r.weight_kg_excl_controller,
                       r.controller_weight_kg, r.ambient_temp_min_c,     r.ambient_temp_max_c,
                       r.acoustic_noise_dba_at_1m};
}

int robot_bridge_get_joint_spec(int joint_index, JointSpecC* out) {
    if (joint_index < 0 || static_cast<std::size_t>(joint_index) >= arm::config::kNumJoints) return 0;
    const auto& j = arm::config::kJointSpecs[static_cast<std::size_t>(joint_index)];
    std::memset(out->name, 0, sizeof(out->name));
    std::strncpy(out->name, j.name.data(), std::min(j.name.size(), sizeof(out->name) - 1));
    out->gear_ratio = j.gear_ratio;
    out->rated_torque_nm = j.rated_output_torque_nm;
    out->peak_torque_nm = j.peak_output_torque_nm;
    out->rated_rpm = j.rated_motor_rpm;
    out->motor_power_w = j.motor_power_w;
    out->encoder_bits = j.encoder_bits;
    out->soft_limit_min_deg = j.soft_limit_min_deg;
    out->soft_limit_max_deg = j.soft_limit_max_deg;
    out->max_speed_deg_s = j.max_joint_speed_deg_s;
    return 1;
}

int robot_bridge_get_joint_telemetry(RobotBridgeHandle handle, int joint_index, JointTelemetryC* out) {
    auto* impl = static_cast<RobotBridgeImpl*>(handle);
    if (joint_index < 0 || static_cast<std::size_t>(joint_index) >= arm::config::kNumJoints) return 0;
    std::lock_guard<std::mutex> lock(impl->mutex);
    const auto t = impl->joints[static_cast<std::size_t>(joint_index)]->readTelemetry();
    out->position_rad = t.position_rad;
    out->velocity_rad_s = t.velocity_rad_s;
    out->current_a = t.current_a;
    out->torque_estimate_nm = t.torque_estimate_nm;
    out->winding_temp_c = t.winding_temp_c;
    out->sto_active = t.sto_active ? 1 : 0;
    out->fault = t.fault ? 1 : 0;
    return 1;
}

void robot_bridge_get_safety_status(RobotBridgeHandle handle, SafetyStatusC* out) {
    auto* impl = static_cast<RobotBridgeImpl*>(handle);
    std::lock_guard<std::mutex> lock(impl->mutex);
    fillSafetyStatus(out, impl->fsm.state(), impl->last_check);
}

int robot_bridge_is_move_active(RobotBridgeHandle handle) {
    auto* impl = static_cast<RobotBridgeImpl*>(handle);
    std::lock_guard<std::mutex> lock(impl->mutex);
    return impl->controller->isMoveActive() ? 1 : 0;
}

double robot_bridge_elapsed_move_time(RobotBridgeHandle handle) {
    auto* impl = static_cast<RobotBridgeImpl*>(handle);
    std::lock_guard<std::mutex> lock(impl->mutex);
    return impl->controller->elapsedTime();
}

int robot_bridge_begin_move(RobotBridgeHandle handle, const double* target_deg6, int use_s_curve) {
    auto* impl = static_cast<RobotBridgeImpl*>(handle);
    std::lock_guard<std::mutex> lock(impl->mutex);

    if (impl->fsm.state() == arm::safety::RobotState::kIdle) {
        impl->fsm.handle(arm::safety::Event::kTaskStart);
    } else if (impl->fsm.state() != arm::safety::RobotState::kRunning) {
        return 0;  // Fault/EStop/Paused/etc. — reject new moves until cleared
    }

    arm::motion::JointSpaceMove move{};
    for (std::size_t i = 0; i < arm::config::kNumJoints; ++i) {
        move.start[i] = impl->joints[i]->readTelemetry().position_rad;
        move.target[i] = arm::core::deg2rad(target_deg6[i]);
    }
    move.use_s_curve = (use_s_curve != 0);
    impl->controller->beginMove(move);
    return 1;
}

void robot_bridge_tick(RobotBridgeHandle handle, double dt_s) {
    auto* impl = static_cast<RobotBridgeImpl*>(handle);
    std::lock_guard<std::mutex> lock(impl->mutex);

    const bool was_active = impl->controller->isMoveActive();
    if (was_active) {
        impl->controller->tick();
    }

    arm::safety::SafetyCheckResult aggregate{};
    for (std::size_t i = 0; i < arm::config::kNumJoints; ++i) {
        impl->joints[i]->injectExternalLoadNm(impl->external_loads[i]);
        impl->joints[i]->step(dt_s);
        // §14: evaluate while the FSM's state still reflects "right now" —
        // evaluating only when an HTTP request happens to arrive can miss
        // the Running window entirely if the move finishes first.
        const auto t = impl->joints[i]->readTelemetry();
        const auto check = impl->fsm.evaluate(t, arm::config::kJointSpecs[i], /*commanded_torque_nm=*/0.0,
                                               /*hardware_estop_line_active=*/false);
        aggregate.estop_pressed = aggregate.estop_pressed || check.estop_pressed;
        aggregate.sto_required = aggregate.sto_required || check.sto_required;
        aggregate.collision_suspected = aggregate.collision_suspected || check.collision_suspected;
        aggregate.overcurrent = aggregate.overcurrent || check.overcurrent;
        aggregate.overtemperature = aggregate.overtemperature || check.overtemperature;
        aggregate.soft_limit_violation = aggregate.soft_limit_violation || check.soft_limit_violation;
        aggregate.hard_limit_violation = aggregate.hard_limit_violation || check.hard_limit_violation;
    }
    impl->last_check = aggregate;

    if (was_active && !impl->controller->isMoveActive() && impl->fsm.state() == arm::safety::RobotState::kRunning) {
        impl->fsm.handle(arm::safety::Event::kTaskComplete);
    }
}

int robot_bridge_trigger_estop(RobotBridgeHandle handle) {
    auto* impl = static_cast<RobotBridgeImpl*>(handle);
    std::lock_guard<std::mutex> lock(impl->mutex);
    const bool ok = impl->fsm.handle(arm::safety::Event::kEstopTriggered);
    if (ok) {
        // §9.5: E-stop cuts torque on every joint, not just the FSM's state label.
        for (auto& j : impl->joints) j->triggerSafeTorqueOff();
    }
    return ok ? 1 : 0;
}

int robot_bridge_reset_estop(RobotBridgeHandle handle) {
    auto* impl = static_cast<RobotBridgeImpl*>(handle);
    std::lock_guard<std::mutex> lock(impl->mutex);
    const bool ok = impl->fsm.handle(arm::safety::Event::kEstopReset);
    if (ok) {
        for (auto& j : impl->joints) j->clearSafeTorqueOff();
        impl->fsm.handle(arm::safety::Event::kBootComplete);
        impl->fsm.handle(arm::safety::Event::kHomingComplete);
    }
    return ok ? 1 : 0;
}

int robot_bridge_inject_load(RobotBridgeHandle handle, int joint_index, double load_nm) {
    auto* impl = static_cast<RobotBridgeImpl*>(handle);
    if (joint_index < 0 || static_cast<std::size_t>(joint_index) >= arm::config::kNumJoints) return 0;
    std::lock_guard<std::mutex> lock(impl->mutex);
    impl->external_loads[static_cast<std::size_t>(joint_index)] = load_nm;
    return 1;
}

}  // extern "C"
