# dashboard/commissioning-wizard

A second, distinct web app from `dashboard/frontend` (the day-to-day operator
dashboard): this one implements §17.5's "Deployment Workflow" diagram and
§20.7's `commissioning_checklist.yaml` structure as an interactive,
mostly-automated setup wizard, run once per install rather than during
normal operation.

## This is genuinely tested — the real shipped code, executed against a live backend

Every automated step's logic was executed for real, not just type-checked:

1. `npm run build` — clean `tsc` + Vite build.
2. Manually replicated every automated step's exact REST call sequence via
   `curl` against a live `dashboard/backend`, to validate the underlying
   behavior before wiring up the UI.
3. **Then actually ran `src/checklist.ts` itself** — the real file this app
   ships — via a Node/`tsx` harness that shims relative `/api/...` URLs to
   point at a live backend (Vite's dev-server proxy does this in the
   browser; the harness does the equivalent for a one-shot Node run). Output:

   ```
   --- Power-On Self-Test ---              => pass
   --- Joint-Zero Calibration ---           => pass
   --- Safety Function Verification — E-stop ---        => pass
   --- Safety Function Verification — STO on all joints --- => pass
   --- Safety Function Verification — Soft & Hard Limits --- => pass
   --- Repeatability Verification ---       => pass
   --- Tool-Changer Verification ---        => manual (by design, see below)
   --- Network Connectivity Check ---       => pass
   ```

## API key field added later — NOT re-verified against a live backend, unlike everything above

`dashboard/backend` gained a mandatory API-key requirement after this
wizard was originally built and genuinely tested against a live instance
(see that package's README). This wizard had no way to send one, so every
automated step above — including E-stop trigger/reset — would now fail
with 401 against a real backend, silently invalidating the "pass" results
documented above for any current run. Fixed: an API Key field in the
header (`sessionStorage`-backed, same pattern as `dashboard/frontend`'s
`src/api.ts`), and `X-API-Key` on every request in `src/api.ts` — which
`src/checklist.ts` already routes every call through, so no changes were
needed there.

**This specific change was not re-run against a live backend or through
`tsc`/`vite build`** — no network was available in the environment it was
written in, the same constraint documented throughout the rest of this
project from this point forward. That's a meaningfully bigger caveat here
than most places, given this file's whole credibility rested on the
"genuinely tested" claim above. Before trusting the checklist results
again: rebuild (`npm run build`) and re-run the same live-backend
verification this README already describes, with a real
`DASHBOARD_OPERATOR_API_KEY` configured and entered in the new field.

## A real bug this wizard's design surfaced (fixed in the core stack)

While designing the STO checklist step, I realized `dashboard/backend`'s
E-stop trigger updated the safety FSM's *state label* but never actually
asserted Safe Torque Off on the joints themselves — `JointInterface` also
had no way to *clear* STO once set, so any joint that was ever e-stopped
would stay frozen forever, breaking recovery. Both are fixed at the source:
`include/hal/joint_interface.hpp` gained `clearSafeTorqueOff()`, and
`dashboard/backend/native_bridge/robot_bridge.cpp`'s trigger/reset now
actually call `triggerSafeTorqueOff()`/`clearSafeTorqueOff()` on every joint.
This fix benefits `dashboard/backend` generally, not just this wizard — see
that package's own README for the updated verification.

## Run

```bash
# from dashboard/backend:
./build.sh && uvicorn main:app &
# from dashboard/commissioning-wizard:
npm install && npm run dev   # http://localhost:5173 (or whichever port Vite picks)
```

## Checklist steps and what's automated

| Step (§20.7 name) | Automated? | What it actually checks |
|---|---|---|
| `power_on_self_test` | Yes | Backend reachable, 6-joint config, safety state readable |
| `joint_zero_calibration` | Yes (substituted) | Simulated joints report ~0° at boot. Real hardware does a physical encoder-homing routine instead — this checks the simulated stand-in, not real homing. |
| `safety_function_verification` — estop | Yes | Real trigger->EStop->reset->Idle cycle |
| `safety_function_verification` — sto_all_joints | Yes | STO asserted on all 6 joints during E-stop, cleared on all 6 after reset (the exact fix above) |
| `safety_function_verification` — soft/hard limits | Yes | Commands a joint 35° past its limit, confirms both violation flags, recovers, re-homes |
| `repeatability_verification` | Yes (caveat) | 5 repeated moves, max deviation measured. The simulated plant is idealized/deterministic (no backlash or wear), so this demonstrates the automation wiring, not a real §2.1 ±0.03mm hardware measurement — see the in-app step description. |
| `tool_changer_verification` | **No** | §8.2's tool-changer (quick-change flange, tool-ID EEPROM) isn't modeled anywhere in this codebase — nothing to automate against. Marked `manual`, operator must verify physically. |
| `network_connectivity_check` | Yes (substituted) | §20.7 specifies a ROS2 `ros2_domain_id`/`host_ip` check; this wizard talks to `dashboard/backend` over REST, not ROS2, so the substitute is simply "is the backend reachable" — already implied by every prior step having run. |
| `sign_off` | N/A | Client-side form (technician ID + date) that assembles a downloadable JSON report of every step's result — no new backend endpoint needed. |

The "Run All Steps" button stops at the first real failure rather than
plowing through a possibly-inconsistent robot state; each step also has its
own "Run" button for re-running individually.
