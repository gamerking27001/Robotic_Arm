// src/api.ts — talks to the same dashboard/backend used by dashboard/frontend.
// No new backend endpoints were needed for this wizard; every check below is
// built from the existing REST API.

export interface JointSpec {
  name: string;
  soft_limit_min_deg: number;
  soft_limit_max_deg: number;
}

export interface ConfigResponse {
  robot: Record<string, number>;
  joints: JointSpec[];
}

export interface JointTelemetry {
  joint_name: string;
  position_deg: number;
  velocity_deg_s: number;
  sto_active: boolean;
  fault: boolean;
}

export interface Telemetry {
  joints: JointTelemetry[];
  move_active: boolean;
  elapsed_move_time_s: number;
}

export interface SafetyStatus {
  state: string;
  estop_pressed: boolean;
  sto_required: boolean;
  collision_suspected: boolean;
  overcurrent: boolean;
  overtemperature: boolean;
  soft_limit_violation: boolean;
  hard_limit_violation: boolean;
  any_fault: boolean;
}

const API_BASE = '/api';

// --- API key (added alongside dashboard/backend's auth requirement --
// see main.py's module docstring). Same sessionStorage-backed pattern as
// dashboard/frontend/src/api.ts -- this wizard talks to the same
// backend and needs the same credential. sessionStorage (not
// localStorage) so the key doesn't outlive the browser tab, matching
// the reasoning already established for the operator dashboard: a
// credential that can trigger real robot actions (this wizard's
// automated steps include E-stop trigger/reset, per checklist.ts)
// shouldn't persist indefinitely on a shared machine.
const API_KEY_STORAGE_KEY = 'arm_commissioning_wizard_api_key';

export function setApiKey(key: string): void {
  sessionStorage.setItem(API_KEY_STORAGE_KEY, key);
}

export function getApiKey(): string | null {
  return sessionStorage.getItem(API_KEY_STORAGE_KEY);
}

function authHeaders(): HeadersInit {
  const key = getApiKey();
  return key ? { 'X-API-Key': key } : {};
}

async function jsonOrThrow<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`${res.status} ${res.statusText}: ${body}`);
  }
  return res.json() as Promise<T>;
}

export async function fetchConfig(): Promise<ConfigResponse> {
  return jsonOrThrow(await fetch(`${API_BASE}/config`, { headers: authHeaders() }));
}

export async function fetchTelemetry(): Promise<Telemetry> {
  return jsonOrThrow(await fetch(`${API_BASE}/telemetry`, { headers: authHeaders() }));
}

export async function fetchSafety(): Promise<SafetyStatus> {
  return jsonOrThrow(await fetch(`${API_BASE}/safety`, { headers: authHeaders() }));
}

export async function postMove(targetDeg: number[], useSCurve = true): Promise<{ accepted: boolean }> {
  const res = await fetch(`${API_BASE}/moves`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({ target_deg: targetDeg, use_s_curve: useSCurve }),
  });
  if (res.status === 409) return { accepted: false };
  return jsonOrThrow(res);
}

export async function postEstopTrigger(reason: string): Promise<{ accepted: boolean }> {
  const res = await fetch(`${API_BASE}/estop/trigger`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({ reason }),
  });
  return jsonOrThrow(res);
}

export async function postEstopReset(operatorId: string): Promise<{ accepted: boolean }> {
  const res = await fetch(`${API_BASE}/estop/reset`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({ operator_id: operatorId }),
  });
  return jsonOrThrow(res);
}

/** Polls `check` every `intervalMs` until it returns true or `timeoutMs` elapses. */
export async function pollUntil(
  check: () => Promise<boolean>,
  timeoutMs: number,
  intervalMs = 150,
): Promise<boolean> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (await check()) return true;
    await new Promise((r) => setTimeout(r, intervalMs));
  }
  return false;
}

export async function waitForMoveToFinish(timeoutMs = 5000): Promise<boolean> {
  return pollUntil(async () => !(await fetchTelemetry()).move_active, timeoutMs);
}
