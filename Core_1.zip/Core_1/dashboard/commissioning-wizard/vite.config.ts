import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Same proxy pattern as dashboard/frontend/vite.config.ts — points at the
// same dashboard/backend instance.
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
      },
    },
  },
})
