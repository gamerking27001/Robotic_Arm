# deploy/docker/dashboard-frontend.Dockerfile
#
# Build from the REPO ROOT (same convention as dashboard-backend.Dockerfile
# -- see its header comment), NOT from dashboard/frontend/, because this
# file needs to COPY deploy/docker/nginx.conf too and Docker forbids COPY
# paths outside the build context:
#   docker build -f deploy/docker/dashboard-frontend.Dockerfile -t arm-dashboard-frontend .
#
# NOTE: not run through `docker build` in this environment (no Docker
# daemon, and no network to `npm install` either -- see App.tsx/api.ts's
# changes for the same limitation on the plain `npm run build` path).
# Reviewed carefully by hand; the underlying `npm run build` command is
# exactly what dashboard/frontend/package.json already defines
# (`tsc -b && vite build`), not something invented for this Dockerfile.

FROM node:22-slim AS build
WORKDIR /app
COPY dashboard/frontend/package.json dashboard/frontend/package-lock.json* ./
RUN npm install
COPY dashboard/frontend/ .
RUN npm run build

FROM nginx:alpine AS runtime
COPY --from=build /app/dist /usr/share/nginx/html
COPY deploy/docker/nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
    CMD wget -q -O /dev/null http://127.0.0.1/ || exit 1
