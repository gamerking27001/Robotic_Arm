# deploy/docker/dashboard-backend.Dockerfile
#
# Multi-stage build: compile native_bridge/librobot_bridge.so against the
# core stack sources in a build stage with a full g++ toolchain, then copy
# just the compiled .so and Python source into a slim runtime image — no
# compiler, headers, or source tree needed at runtime.
#
# Build from the REPO ROOT (not this directory), since it needs
# ../../include and ../../src per the monorepo-relative-path pattern
# documented in dashboard/backend/build.sh:
#   docker build -f deploy/docker/dashboard-backend.Dockerfile -t arm-dashboard-backend .
#
# NOTE: written carefully but not actually run through `docker build` in
# this environment (no Docker daemon available) -- same "careful first
# draft" caveat as the rest of this deployment scaffolding. The underlying
# build command (g++ ... -o native_bridge/librobot_bridge.so) IS verified;
# what's unverified is the Dockerfile/image-layering syntax around it.

FROM debian:bookworm-slim AS build
RUN apt-get update && apt-get install -y --no-install-recommends \
    g++ \
    && rm -rf /var/lib/apt/lists/*
WORKDIR /src
COPY include/ include/
COPY src/ src/
COPY dashboard/backend/native_bridge/ dashboard/backend/native_bridge/
WORKDIR /src/dashboard/backend
RUN g++ -std=c++20 -O2 -Wall -Wextra -fPIC -shared \
    -I ../../include \
    native_bridge/robot_bridge.cpp \
    ../../src/kinematics/dh_kinematics.cpp \
    ../../src/kinematics/ik_solver.cpp \
    ../../src/motion/trajectory_profile.cpp \
    ../../src/motion/motion_controller.cpp \
    ../../src/hal/simulated_joint_driver.cpp \
    ../../src/safety/safety_fsm.cpp \
    -o native_bridge/librobot_bridge.so

FROM python:3.12-slim AS runtime
# Runs as a non-root user -- a compromised dashboard process shouldn't have
# more privilege than it needs, standard container-hardening practice.
RUN useradd --create-home --shell /usr/sbin/nologin appuser
WORKDIR /app
COPY dashboard/backend/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY dashboard/backend/main.py .
COPY --from=build /src/dashboard/backend/native_bridge/librobot_bridge.so native_bridge/librobot_bridge.so
USER appuser

# DASHBOARD_VIEWER_API_KEY and DASHBOARD_OPERATOR_API_KEY are required and
# deliberately NOT set here -- see main.py's module docstring on why there
# is no baked-in default key. Pass them at `docker run` time or via
# docker-compose's env_file (see docker-compose.yml / .env.example).
ENV DASHBOARD_LOG_LEVEL=INFO

EXPOSE 8000
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
    CMD python -c "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:8000/healthz', timeout=2).status==200 else 1)"

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
