# deploy/ — deployment scaffolding

Two independent deployment paths, pick based on your environment:

| | `docker/` | `systemd/` |
|---|---|---|
| Best for | Cloud/server deployment, easy rollback, dev machines | Industrial edge PCs already running systemd, lower overhead |
| Covers | Dashboard backend + frontend only | Dashboard backend + ROS2 bringup |
| Confidence | Backend Dockerfile builds on a verified `g++` command; not run through `docker build` itself (no daemon in this dev environment) | Same — units written carefully, not run through `systemctl` here |

Neither path currently packages `ros2_ws` for Docker — that would need a
full ROS2 base image and is a heavier, separate effort. The systemd path
covers ROS2 bringup for a bare-metal install instead (`arm-ros2-bringup.service`),
**but read that file's warning banner before enabling it** — `ros2_ws`
itself is still an unverified first draft (see `ros2_ws/README.md`).

## What's actually new here vs. what existed before

Before this pass, there was no deployment story at all beyond "run
`uvicorn` directly" and "run `ros2 launch` directly" — fine for
development, not something you'd put in front of a real robot. This adds:

1. **Dashboard auth** (`dashboard/backend/main.py`, `dashboard/frontend/src/api.ts`+`App.tsx`) —
   previously explicitly flagged as "No auth" in the backend README; now
   requires two API keys (viewer/operator), fails closed if unset, and the
   frontend has a matching key-entry gate.
2. **Containerization** (this directory's `docker/`) — reproducible builds,
   non-root containers, health checks.
3. **systemd units** (`systemd/`) — for edge PCs that don't want a
   container runtime.
4. **CI** (`.github/workflows/ci.yml`) — builds the core stack, firmware
   demo, dashboard backend (with a real auth smoke test), vision tests, and
   critically, a **real `colcon build`** of `ros2_ws` against actual ROS2
   Jazzy — something neither this repo's original build session nor the
   session that did the safety-authority fix could do (no ROS2/network
   available in either sandbox). A green run of that job is the first real
   compile verification `ros2_ws` will have had.

## Still open (not done in this pass)

- **Real robot / real CAN hardware deployment.** Everything here assumes
  the simulated joint driver (`arm::hal::SimulatedJointDriver`). Swapping
  in a real CAN transport is a real hardware-integration project — see
  `robot_hardware_interface/README.md` for where that swap point is in the
  code, but the deployment/systemd concerns around real hardware (CAN
  interface bring-up ordering, udev rules, etc.) aren't addressed here.
- **Formal safety certification.** Nothing here or elsewhere in this repo
  constitutes a certified safety system — see the source design document's
  own safety chapter for what real certification (IEC 61508 / ISO 13849 /
  ISO 10218 / ISO/TS 15066, per an earlier scoping pass on this project)
  actually requires. A qualified functional-safety engineer needs to review
  this before any real deployment near people.
- **Secrets management beyond plain env files.** `.env`/`EnvironmentFile`
  is a reasonable floor, not a ceiling — a larger deployment (multiple
  robots, multiple sites) would want a real secrets manager (Vault, cloud
  provider's secret store, etc.) instead of per-host env files.
- **Log aggregation / monitoring / alerting.** `safety_monitor_node`'s
  README notes exactly where a real alerting integration would hook in
  (fault-transition logging) but doesn't implement one — left as a
  deliberate placeholder rather than guessing at a specific vendor/tool.
