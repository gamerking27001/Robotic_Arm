"""display.launch.py — §12.1: view the generated URDF in RViz with the joint_state_publisher_gui for manual joint jogging (no hardware/ros2_control involved)."""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_share = get_package_share_directory("robot_description")
    urdf_path = os.path.join(pkg_share, "urdf", "generated_arm.urdf")
    rviz_config = os.path.join(pkg_share, "config", "view_arm.rviz")

    with open(urdf_path, "r") as f:
        robot_description_content = f.read()

    return LaunchDescription([
        DeclareLaunchArgument("use_gui", default_value="true",
                               description="Launch joint_state_publisher_gui for manual jogging"),
        Node(
            package="robot_state_publisher",
            executable="robot_state_publisher",
            name="robot_state_publisher",
            output="screen",
            parameters=[{"robot_description": robot_description_content}],
        ),
        Node(
            package="joint_state_publisher_gui",
            executable="joint_state_publisher_gui",
            name="joint_state_publisher_gui",
            condition=None,  # simplified: always launch; wire IfCondition(LaunchConfiguration("use_gui")) for real use
        ),
        Node(
            package="rviz2",
            executable="rviz2",
            name="rviz2",
            arguments=["-d", rviz_config],
            output="screen",
        ),
    ])
