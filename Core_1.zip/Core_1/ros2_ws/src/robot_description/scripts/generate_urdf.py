#!/usr/bin/env python3
"""generate_urdf.py

Generates urdf/generated_arm.urdf from the same DH-parameter and
joint-limit values as ../../../../tools/robot_params.py (the single
shared source of truth — previously this file had its own copy-pasted
copy, consolidated away; see that module's docstring for the full
history and ../../../../configs/arm_variant_standard.yaml /
../../../../include/core/robot_config.hpp for the C++ side of this same
data).

DH -> URDF conversion note: classic DH's variable rotation theta_i happens
about z_{i-1} (the PARENT frame's z axis, before the a/alpha/d offset),
whereas a URDF revolute joint rotates about its own axis *after* <origin> is
applied. To reproduce the DH chain exactly, each DH joint is emitted as TWO
URDF joints:
  1. "jointN"        (revolute, origin=identity, axis=z) — the actual DH
                       rotation, about the parent frame's z axis.
  2. "jointN_offset" (fixed, origin=xyz(a,0,d) rpy=(alpha,0,0)) — the DH
                       geometric offset, which at theta=0 is exactly a pure
                       X-rotation by alpha plus translation (a,0,d) — see the
                       derivation in this file's comments / ros2_ws/README.md.
This is the standard, provably-correct DH->URDF technique (an intermediate
zero-mass link carries the split) rather than an approximation.
"""
import os
import sys
import xml.etree.ElementTree as ET
import xml.dom.minidom as minidom

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", "..", "tools"))
from robot_params import DH_TABLE, JOINT_LIMITS, JOINT_NAMES  # noqa: E402

LARGE_JOINT_EFFORT_NM = [240.0, 300.0, 120.0]  # peak torque, J1-J3 (§6.2)
SMALL_JOINT_EFFORT_NM = [24.0, 24.0, 12.0]      # peak torque, J4-J6 (§6.2)


def deg2rad(d):
    import math
    return d * math.pi / 180.0


def sub(parent, tag, **attrs):
    return ET.SubElement(parent, tag, {k: str(v) for k, v in attrs.items()})


def add_inertial(link, mass, radius):
    inertial = sub(link, "inertial")
    sub(inertial, "mass", value=mass)
    i = (2.0 / 5.0) * mass * radius * radius  # solid-sphere approximation, illustrative only
    sub(inertial, "inertia", ixx=i, ixy=0, ixz=0, iyy=i, iyz=0, izz=i)


def add_visual_collision(link, length, radius, material="arm_grey"):
    for tag in ("visual", "collision"):
        el = sub(link, tag)
        origin = sub(el, "origin", xyz=f"0 0 {length / 2.0}", rpy="0 0 0")
        geometry = sub(el, "geometry")
        sub(geometry, "cylinder", radius=radius, length=length)
        if tag == "visual":
            mat = sub(el, "material", name=material)
            sub(mat, "color", rgba="0.55 0.57 0.60 1.0")


def build_urdf(hardware_plugin="robot_hardware_interface/RobotSystemInterface", sim_endpoint=None):
    """hardware_plugin selects which <ros2_control><hardware><plugin> gets
    emitted -- see ros2_ws/src/sim_network_hardware_interface/README.md's
    "URDF wiring" section, which this function now implements instead of
    just describing by hand. sim_endpoint is required when hardware_plugin
    is the network one (the Mac-side simulator's address, e.g.
    "10.211.55.2:50052") and ignored otherwise.
    """
    robot = ET.Element("robot", name="modular_arm_msme")

    material = sub(robot, "material", name="arm_grey")
    sub(material, "color", rgba="0.55 0.57 0.60 1.0")

    base_link = sub(robot, "link", name="base_link")
    add_visual_collision(base_link, length=0.05, radius=0.09)
    add_inertial(base_link, mass=3.0, radius=0.09)

    parent = "base_link"
    for i, ((a, alpha, d), (min_deg, max_deg, max_speed), name) in enumerate(
        zip(DH_TABLE, JOINT_LIMITS, JOINT_NAMES)
    ):
        pre_link = f"link{i+1}_axis"
        real_link = f"link{i+1}"
        is_large = i < 3
        effort = (LARGE_JOINT_EFFORT_NM if is_large else SMALL_JOINT_EFFORT_NM)[i if is_large else i - 3]
        radius = 0.06 if is_large else 0.035
        # Illustrative visual link length — NOT from §3's mechanical CAD
        # (not specified numerically in the source doc); just enough that
        # the model isn't degenerate for visualization purposes.
        length = max(abs(a), abs(d), 0.05)

        # 1) revolute joint: the actual DH rotation, about the parent frame's z.
        pre = sub(robot, "link", name=pre_link)
        add_inertial(pre, mass=0.05, radius=0.02)  # negligible mass — this link only carries the rotation frame

        j = sub(robot, "joint", name=f"joint{i+1}", type="revolute")
        sub(j, "parent", link=parent)
        sub(j, "child", link=pre_link)
        sub(j, "origin", xyz="0 0 0", rpy="0 0 0")
        sub(j, "axis", xyz="0 0 1")
        sub(j, "limit", lower=deg2rad(min_deg), upper=deg2rad(max_deg), velocity=deg2rad(max_speed), effort=effort)

        # 2) fixed joint: the DH geometric offset (a, alpha, d) at theta=0.
        real = sub(robot, "link", name=real_link)
        add_visual_collision(real, length=length, radius=radius)
        add_inertial(real, mass=2.0 if is_large else 0.6, radius=radius)

        off = sub(robot, "joint", name=f"joint{i+1}_offset", type="fixed")
        sub(off, "parent", link=pre_link)
        sub(off, "child", link=real_link)
        sub(off, "origin", xyz=f"{a} 0 {d}", rpy=f"{alpha} 0 0")

        parent = real_link

    # Tool-changer flange frame, coincident with the final link (§8.2).
    tcp = sub(robot, "link", name="tool0")
    fixed = sub(robot, "joint", name="joint6_to_tool0", type="fixed")
    sub(fixed, "parent", link=parent)
    sub(fixed, "child", link="tool0")
    sub(fixed, "origin", xyz="0 0 0", rpy="0 0 0")

    # §20.2/§20.6: declares the ros2_control hardware interface plugin
    # and each joint's state/command interfaces. Defaults to
    # robot_hardware_interface (real/simulated-CAN); pass hardware_plugin
    # to select sim_network_hardware_interface instead — see that
    # package's README "URDF wiring" section, which this now implements.
    ros2_control = sub(robot, "ros2_control", name="modular_arm_msme_system", type="system")
    hw = sub(ros2_control, "hardware")
    sub(hw, "plugin").text = hardware_plugin
    if hardware_plugin == "sim_network_hardware_interface/SimNetworkSystemInterface":
        if not sim_endpoint:
            raise ValueError(
                "sim_endpoint is required when hardware_plugin is sim_network_hardware_interface's "
                "-- e.g. build_urdf(hardware_plugin='sim_network_hardware_interface/SimNetworkSystemInterface', "
                "sim_endpoint='10.211.55.2:50052')"
            )
        sub(hw, "param", name="sim_endpoint").text = sim_endpoint
    for i in range(len(DH_TABLE)):
        joint_el = sub(ros2_control, "joint", name=f"joint{i+1}")
        cmd_pos = sub(joint_el, "command_interface", name="position")
        sub(cmd_pos, "param", name="min").text = str(deg2rad(JOINT_LIMITS[i][0]))
        sub(cmd_pos, "param", name="max").text = str(deg2rad(JOINT_LIMITS[i][1]))
        sub(joint_el, "state_interface", name="position")
        sub(joint_el, "state_interface", name="velocity")
        sub(joint_el, "state_interface", name="effort")

    return robot


def main():
    import argparse
    import os

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--hardware-plugin",
        choices=["real", "sim-network"],
        default="real",
        help="'real' (default) emits robot_hardware_interface (real/simulated-CAN bus, "
        "written to urdf/generated_arm.urdf). 'sim-network' emits "
        "sim_network_hardware_interface (Mac-side MuJoCo/CoppeliaSim over gRPC, written to "
        "a SEPARATE file urdf/generated_arm_sim_network.urdf -- deliberately not the same "
        "file robot_bringup's default launch path uses, so generating the sim-network variant "
        "never silently changes what the real/simulated-CAN bringup loads).",
    )
    parser.add_argument(
        "--sim-endpoint",
        default=None,
        help="Required with --hardware-plugin sim-network -- the Mac-side simulator's "
        "address, e.g. 10.211.55.2:50052 (MuJoCo's mac_sim_server.py default port) or "
        "10.211.55.2:50053 (CoppeliaSim's coppeliasim_sim_server.py default port).",
    )
    args = parser.parse_args()

    if args.hardware_plugin == "real":
        plugin = "robot_hardware_interface/RobotSystemInterface"
        out_name = "generated_arm.urdf"
    else:
        if not args.sim_endpoint:
            parser.error("--sim-endpoint is required when --hardware-plugin sim-network is given")
        plugin = "sim_network_hardware_interface/SimNetworkSystemInterface"
        out_name = "generated_arm_sim_network.urdf"

    robot = build_urdf(hardware_plugin=plugin, sim_endpoint=args.sim_endpoint)
    rough = ET.tostring(robot, encoding="unicode")
    pretty = minidom.parseString(rough).toprettyxml(indent="  ")
    # Drop the extra blank lines minidom likes to insert.
    pretty = "\n".join(line for line in pretty.split("\n") if line.strip())
    script_dir = os.path.dirname(os.path.abspath(__file__))
    out_path = os.path.join(script_dir, "..", "urdf", out_name)
    with open(out_path, "w") as f:
        f.write(pretty)
    print(f"Wrote {os.path.normpath(out_path)}")


if __name__ == "__main__":
    main()
