// safety_monitor_node.cpp
//
// REWRITTEN as part of the safety-authority fix — see
// robot_hardware_interface/robot_system_interface.hpp's class-level comment
// and ros2_ws/README.md's "Safety authority fix" section for the full
// story. Previously, this node owned its own arm::safety::SafetyFsm
// instance and offered trigger_estop/reset_estop services — but that FSM
// had no connection to whatever actually commanded the joints, so those
// services updated a status topic without ever stopping the robot.
//
// The authoritative FSM now lives inside RobotSystemInterface (in the real
// control loop, where it belongs), and the operator-facing
// trigger_estop/reset_estop services now live in estop_controller/, which
// can actually reach it (via command interfaces — see that package's
// README for why that's the right mechanism).
//
// This node's remaining job is honest and still useful: it's a passive
// subscriber to estop_controller's authoritative safety_status topic,
// logging state transitions for an audit trail / higher-level alerting
// hook. It has no authority over the robot at all — it cannot trigger or
// reset anything. If you were calling this node's old services directly,
// call estop_controller's instead (same robot_msgs/TriggerEstop,
// robot_msgs/ResetEstop service types — no client-side changes needed
// beyond which node you're calling).
#include <memory>
#include <string>

#include "rclcpp/rclcpp.hpp"
#include "robot_msgs/msg/safety_status.hpp"

class SafetyMonitorNode : public rclcpp::Node {
public:
    SafetyMonitorNode() : rclcpp::Node("safety_monitor_node") {
        status_sub_ = create_subscription<robot_msgs::msg::SafetyStatus>(
            "safety_status", 10, std::bind(&SafetyMonitorNode::onStatus, this, std::placeholders::_1));
        RCLCPP_INFO(get_logger(),
                    "safety_monitor_node: passive status logger only -- trigger_estop/reset_estop now live on "
                    "estop_controller, which has real authority over motion (see this file's header comment).");
    }

private:
    void onStatus(const robot_msgs::msg::SafetyStatus::SharedPtr msg) {
        if (msg->state != last_logged_state_) {
            RCLCPP_INFO(get_logger(), "Safety FSM state: %s -> %s", last_logged_state_.c_str(), msg->state.c_str());
            last_logged_state_ = msg->state;
        }
        if (msg->any_fault && !last_any_fault_) {
            RCLCPP_WARN(get_logger(),
                        "Fault flags active: estop=%d sto=%d collision=%d overcurrent=%d overtemp=%d "
                        "soft_limit=%d hard_limit=%d",
                        msg->estop_pressed, msg->sto_required, msg->collision_suspected, msg->overcurrent,
                        msg->overtemperature, msg->soft_limit_violation, msg->hard_limit_violation);
        }
        last_any_fault_ = msg->any_fault;
        // A real deployment's audit-trail/alerting integration (e.g.
        // writing to a persistent log store, paging an on-call engineer on
        // repeated faults) hooks in here -- deliberately left as a simple
        // log line rather than guessing at a specific integration.
    }

    std::string last_logged_state_ = "(none yet)";
    bool last_any_fault_ = false;
    rclcpp::Subscription<robot_msgs::msg::SafetyStatus>::SharedPtr status_sub_;
};

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<SafetyMonitorNode>());
    rclcpp::shutdown();
    return 0;
}
