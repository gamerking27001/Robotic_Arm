#include "estop_controller/estop_controller.hpp"

#include <array>
#include <chrono>
#include <thread>

#include "safety/safety_fsm.hpp"

namespace estop_controller {

namespace {
// Must match, in order, the "safety/<suffix>" state interfaces
// RobotSystemInterface exports (robot_system_interface.cpp's
// export_state_interfaces()) — indices below are positional against this
// list, not looked up by name, since that's the simplest approach that
// doesn't depend on an interface-lookup-by-name helper I can't confirm the
// exact signature of without a real controller_interface install.
constexpr std::array<const char*, 9> kStateSuffixes = {
    "state_ordinal", "any_fault",           "estop_pressed",         "sto_required", "collision_suspected",
    "overcurrent",   "overtemperature",     "soft_limit_violation",  "hard_limit_violation"};
enum StateIdx {
    kStateOrdinal = 0,
    kAnyFault,
    kEstopPressed,
    kStoRequired,
    kCollisionSuspected,
    kOvercurrent,
    kOvertemperature,
    kSoftLimitViolation,
    kHardLimitViolation
};

constexpr std::array<const char*, 2> kCommandSuffixes = {"estop_request", "estop_reset_request"};
enum CommandIdx { kEstopRequestCmd = 0, kEstopResetRequestCmd };

std::string toRobotStateString(double ordinal) {
    // Mirrors arm::safety::toString() without depending on being able to
    // construct an arm::safety::RobotState from an arbitrary double safely
    // — a simple switch on the rounded ordinal, matching the enum's
    // declared order in safety_fsm.hpp exactly.
    const int v = static_cast<int>(ordinal + 0.5);
    switch (v) {
        case static_cast<int>(arm::safety::RobotState::kPowerOn): return "PowerOn";
        case static_cast<int>(arm::safety::RobotState::kHoming): return "Homing";
        case static_cast<int>(arm::safety::RobotState::kIdle): return "Idle";
        case static_cast<int>(arm::safety::RobotState::kRunning): return "Running";
        case static_cast<int>(arm::safety::RobotState::kPaused): return "Paused";
        case static_cast<int>(arm::safety::RobotState::kFault): return "Fault";
        case static_cast<int>(arm::safety::RobotState::kEStop): return "EStop";
        default: return "Unknown";
    }
}
}  // namespace

controller_interface::InterfaceConfiguration EstopController::command_interface_configuration() const {
    controller_interface::InterfaceConfiguration config;
    config.type = controller_interface::interface_configuration_type::INDIVIDUAL;
    for (const char* suffix : kCommandSuffixes) {
        config.names.emplace_back(std::string("safety/") + suffix);
    }
    return config;
}

controller_interface::InterfaceConfiguration EstopController::state_interface_configuration() const {
    controller_interface::InterfaceConfiguration config;
    config.type = controller_interface::interface_configuration_type::INDIVIDUAL;
    for (const char* suffix : kStateSuffixes) {
        config.names.emplace_back(std::string("safety/") + suffix);
    }
    return config;
}

controller_interface::CallbackReturn EstopController::on_init() {
    return controller_interface::CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn EstopController::on_configure(const rclcpp_lifecycle::State&) {
    auto node = get_node();

    trigger_estop_srv_ = node->create_service<robot_msgs::srv::TriggerEstop>(
        "trigger_estop",
        std::bind(&EstopController::onTriggerEstop, this, std::placeholders::_1, std::placeholders::_2));
    reset_estop_srv_ = node->create_service<robot_msgs::srv::ResetEstop>(
        "reset_estop",
        std::bind(&EstopController::onResetEstop, this, std::placeholders::_1, std::placeholders::_2));

    status_pub_ = node->create_publisher<robot_msgs::msg::SafetyStatus>("safety_status", rclcpp::SystemDefaultsQoS());
    status_rt_pub_ = std::make_shared<realtime_tools::RealtimePublisher<robot_msgs::msg::SafetyStatus>>(status_pub_);

    return controller_interface::CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn EstopController::on_activate(const rclcpp_lifecycle::State&) {
    estop_pulse_pending_.store(false);
    reset_pulse_pending_.store(false);
    update_cycle_count_.store(0);
    return controller_interface::CallbackReturn::SUCCESS;
}

controller_interface::CallbackReturn EstopController::on_deactivate(const rclcpp_lifecycle::State&) {
    // Fail safe on deactivation: make sure neither command interface is left
    // asserted, in case this controller is swapped out while a request was
    // mid-flight.
    if (!command_interfaces_.empty()) {
        command_interfaces_[kEstopRequestCmd].set_value(0.0);
        command_interfaces_[kEstopResetRequestCmd].set_value(0.0);
    }
    return controller_interface::CallbackReturn::SUCCESS;
}

controller_interface::return_type EstopController::update(const rclcpp::Time& /*time*/,
                                                             const rclcpp::Duration& /*period*/) {
    // One-shot pulses: each flag is high for exactly the one update() cycle
    // after a service call set it, then dropped back to 0.0 — see the
    // header's file-level comment on why RobotSystemInterface needs a clean
    // edge (not a held level) to re-arm for a future request.
    const bool fire_estop = estop_pulse_pending_.exchange(false);
    const bool fire_reset = reset_pulse_pending_.exchange(false);
    command_interfaces_[kEstopRequestCmd].set_value(fire_estop ? 1.0 : 0.0);
    command_interfaces_[kEstopResetRequestCmd].set_value(fire_reset ? 1.0 : 0.0);

    // Republish the authoritative status every cycle — same fields
    // safety_monitor_node used to publish from its own (now-removed)
    // disconnected FSM, sourced here from RobotSystemInterface's real state
    // interfaces instead.
    if (status_rt_pub_ && status_rt_pub_->trylock()) {
        auto& msg = status_rt_pub_->msg_;
        msg.state = toRobotStateString(state_interfaces_[kStateOrdinal].get_value());
        msg.any_fault = state_interfaces_[kAnyFault].get_value() > 0.5;
        msg.estop_pressed = state_interfaces_[kEstopPressed].get_value() > 0.5;
        msg.sto_required = state_interfaces_[kStoRequired].get_value() > 0.5;
        msg.collision_suspected = state_interfaces_[kCollisionSuspected].get_value() > 0.5;
        msg.overcurrent = state_interfaces_[kOvercurrent].get_value() > 0.5;
        msg.overtemperature = state_interfaces_[kOvertemperature].get_value() > 0.5;
        msg.soft_limit_violation = state_interfaces_[kSoftLimitViolation].get_value() > 0.5;
        msg.hard_limit_violation = state_interfaces_[kHardLimitViolation].get_value() > 0.5;
        status_rt_pub_->unlockAndPublish();
    }

    update_cycle_count_.fetch_add(1);
    return controller_interface::return_type::OK;
}

bool EstopController::waitForUpdateCycle(std::chrono::milliseconds timeout) {
    const uint64_t start = update_cycle_count_.load();
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (update_cycle_count_.load() == start) {
        if (std::chrono::steady_clock::now() > deadline) return false;
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    return true;
}

void EstopController::onTriggerEstop(const std::shared_ptr<robot_msgs::srv::TriggerEstop::Request> request,
                                       std::shared_ptr<robot_msgs::srv::TriggerEstop::Response> response) {
    RCLCPP_WARN(get_node()->get_logger(), "Software E-stop requested: %s", request->reason.c_str());
    estop_pulse_pending_.store(true);
    // Bounded wait for the RT loop to process this cycle's pulse and update
    // the state interfaces, so the response reflects what actually
    // happened rather than just "we asked". controller_manager's default
    // update_rate is 100Hz (see controllers.yaml) — two cycles is a
    // generous margin; this never blocks unboundedly.
    waitForUpdateCycle(std::chrono::milliseconds(200));
    waitForUpdateCycle(std::chrono::milliseconds(200));
    response->accepted = !state_interfaces_.empty() && state_interfaces_[kStateOrdinal].get_value() ==
                                                             static_cast<double>(arm::safety::RobotState::kEStop);
}

void EstopController::onResetEstop(const std::shared_ptr<robot_msgs::srv::ResetEstop::Request> request,
                                     std::shared_ptr<robot_msgs::srv::ResetEstop::Response> response) {
    RCLCPP_INFO(get_node()->get_logger(), "E-stop reset requested by operator '%s'", request->operator_id.c_str());

    // kEstopReset is only a legal transition from kEStop (safety_fsm.hpp's
    // handle() rejects it from anywhere else, matching §13.5's fixed edge
    // set) — record the pre-request state so the response can distinguish
    // "was in EStop, successfully reset to Running" from "wasn't in EStop,
    // nothing to reset", rather than just inferring from the after-state
    // (which is ambiguous: a rejected reset leaves the state unchanged, and
    // "unchanged" can itself be != EStop for reasons that have nothing to
    // do with this request).
    const double state_before = state_interfaces_.empty() ? -1.0 : state_interfaces_[kStateOrdinal].get_value();
    const bool was_in_estop = state_before == static_cast<double>(arm::safety::RobotState::kEStop);

    reset_pulse_pending_.store(true);
    waitForUpdateCycle(std::chrono::milliseconds(200));
    waitForUpdateCycle(std::chrono::milliseconds(200));

    const double state_now = state_interfaces_.empty() ? -1.0 : state_interfaces_[kStateOrdinal].get_value();
    response->accepted = was_in_estop && state_now == static_cast<double>(arm::safety::RobotState::kRunning);
    response->state_after_reset = toRobotStateString(state_now);
}

}  // namespace estop_controller

#include "pluginlib/class_list_macros.hpp"
PLUGINLIB_EXPORT_CLASS(estop_controller::EstopController, controller_interface::ControllerInterface)
