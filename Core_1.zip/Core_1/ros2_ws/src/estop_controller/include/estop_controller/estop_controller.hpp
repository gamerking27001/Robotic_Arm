// estop_controller/estop_controller.hpp
//
// The ROS2-facing side of the safety-authority fix described in
// robot_hardware_interface/robot_system_interface.hpp's class-level comment
// and ros2_ws/README.md's "Safety authority fix" section.
//
// Previously, safety_monitor_node exposed trigger_estop/reset_estop services
// but had no way to actually stop the robot — it ran its own disconnected
// SafetyFsm. RobotSystemInterface now owns the one authoritative SafetyFsm
// and gates all motion on it directly (in-process, every control cycle —
// the fastest and only genuinely safety-critical part of the fix). This
// controller is what lets an operator's service call reach that FSM at all:
// controllers run in the same real-time loop as hardware interfaces
// (both driven by controller_manager at the same update rate), and claim
// command/state interfaces the same way a hardware interface exports them
// — this is the standard, realtime-safe ros2_control mechanism for exactly
// this kind of cross-boundary signal, unlike an arbitrary topic subscription
// inside a hardware interface (which real-time hardware interfaces
// generally shouldn't have).
//
// Service calls arrive on a non-realtime executor thread; update() runs on
// the realtime control thread. The two are bridged with plain
// std::atomic<bool> pulse flags (set by the service callback, consumed
// exactly once by update()) rather than a lock — this keeps update() itself
// wait-free, which is the actual realtime-safety requirement (a mutex here
// would technically violate it under priority inversion, even though in
// practice the critical section is tiny; the atomic pattern avoids the
// question entirely and is the conventional realtime_tools-adjacent
// approach for boolean flags this simple).
//
// NOTE: written against the ros2_control (Jazzy) controller_interface API
// from documented conventions, at the same confidence level as the rest of
// ros2_ws — NOT compiled against a real controller_interface install. The
// safety semantics this bridges to (SafetyFsm, the command-interface
// contract it writes to) are the verified/careful-first-draft pieces
// described in robot_system_interface.hpp; this file's own
// controller_interface::ControllerInterface plumbing is new and equally
// unverified. See ros2_ws/README.md before trusting this without a real
// colcon build.
#pragma once

#include <atomic>
#include <memory>

#include "controller_interface/controller_interface.hpp"
#include "rclcpp/rclcpp.hpp"
#include "realtime_tools/realtime_publisher.hpp"
#include "robot_msgs/msg/safety_status.hpp"
#include "robot_msgs/srv/reset_estop.hpp"
#include "robot_msgs/srv/trigger_estop.hpp"

namespace estop_controller {

class EstopController : public controller_interface::ControllerInterface {
public:
    controller_interface::InterfaceConfiguration command_interface_configuration() const override;
    controller_interface::InterfaceConfiguration state_interface_configuration() const override;

    controller_interface::CallbackReturn on_init() override;
    controller_interface::CallbackReturn on_configure(const rclcpp_lifecycle::State& previous_state) override;
    controller_interface::CallbackReturn on_activate(const rclcpp_lifecycle::State& previous_state) override;
    controller_interface::CallbackReturn on_deactivate(const rclcpp_lifecycle::State& previous_state) override;

    controller_interface::return_type update(const rclcpp::Time& time, const rclcpp::Duration& period) override;

private:
    void onTriggerEstop(const std::shared_ptr<robot_msgs::srv::TriggerEstop::Request> request,
                         std::shared_ptr<robot_msgs::srv::TriggerEstop::Response> response);
    void onResetEstop(const std::shared_ptr<robot_msgs::srv::ResetEstop::Request> request,
                       std::shared_ptr<robot_msgs::srv::ResetEstop::Response> response);

    // Bounded wait (see .cpp) for a service handler to observe at least one
    // update() cycle after setting a pulse flag, so the service response can
    // report the FSM state that actually resulted — not just "we asked".
    bool waitForUpdateCycle(std::chrono::milliseconds timeout);

    // Set by service callbacks (non-RT thread), consumed exactly once by
    // update() (RT thread) — see the file-level comment on why atomics
    // rather than a lock.
    std::atomic<bool> estop_pulse_pending_{false};
    std::atomic<bool> reset_pulse_pending_{false};
    std::atomic<uint64_t> update_cycle_count_{0};

    rclcpp::Service<robot_msgs::srv::TriggerEstop>::SharedPtr trigger_estop_srv_;
    rclcpp::Service<robot_msgs::srv::ResetEstop>::SharedPtr reset_estop_srv_;

    std::shared_ptr<realtime_tools::RealtimePublisher<robot_msgs::msg::SafetyStatus>> status_rt_pub_;
    rclcpp::Publisher<robot_msgs::msg::SafetyStatus>::SharedPtr status_pub_;
};

}  // namespace estop_controller
