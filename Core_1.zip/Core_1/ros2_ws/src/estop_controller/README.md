# estop_controller

New package, added as part of the safety-authority fix — see
`robot_hardware_interface/README.md` (or the class-level comment in
`robot_system_interface.hpp`) for the bug this closes: `safety_monitor_node`
used to run its own `SafetyFsm`, completely disconnected from the FSM that
actually gated joint motion, so triggering E-stop had no real effect.

## What this is

A `controller_interface::ControllerInterface` plugin — it runs inside
`controller_manager`, in the same real-time loop as
`robot_hardware_interface`, and claims two command interfaces
(`safety/estop_request`, `safety/estop_reset_request`) plus nine state
interfaces (the authoritative FSM state + per-check fault flags,
double-encoded — see `robot_system_interface.hpp`).

It exposes the same two operator-facing services the old
`safety_monitor_node` had (`trigger_estop`, `reset_estop`, same
`robot_msgs` service types — no change needed on the client/dashboard side),
but now those calls actually reach the hardware loop, via a one-shot pulse
on the command interfaces, consumed by `RobotSystemInterface` on the very
next control cycle.

It also republishes `safety_status` — the same message shape
`safety_monitor_node` used to publish, sourced here from the real state
interfaces instead of a redundant local computation.

## Why a controller (not a topic subscription inside the hardware interface)

Hardware interface plugins run in the real-time control loop and
conventionally don't own arbitrary ROS2 subscriptions themselves — command
interfaces are ros2_control's standard, realtime-safe channel for exactly
this kind of cross-boundary signal (a controller, which does have normal
ROS2 pub/sub/service access on a non-RT thread, claims and writes to them).
This is the same pattern used for any other externally-commanded interface
in ros2_control (position/velocity commands from a trajectory controller,
GPIO commands from a gripper controller, etc.) — nothing new was invented
here, just applied to a boolean E-stop signal instead of a continuous
position setpoint.

## Confidence level

Same as the rest of `ros2_ws`: written carefully against documented
`controller_interface`/`realtime_tools` conventions, reusing the exact
`arm::safety::SafetyFsm` semantics already exercised by the verified
`arm_demo` and `dashboard/backend` (see those for what IS tested). This
package's own `controller_interface::ControllerInterface` plumbing —
`command_interface_configuration()`/`state_interface_configuration()`,
the `realtime_tools::RealtimePublisher` usage, the exact lifecycle
callback signatures — has **not** been compiled against a real ROS2
install. Expect to debug real API mismatches on the first `colcon build`,
most likely around:
- exact `controller_interface::CallbackReturn`/`return_type` enum
  namespacing for this ROS2 distro,
- `realtime_tools::RealtimePublisher`'s exact constructor/API (this
  package uses the conventional `trylock()`/`msg_`/`unlockAndPublish()`
  pattern, but the exact class location/namespace has shifted between
  ROS2 releases historically — verify against your installed
  `realtime_tools` version),
- whether `get_node()` is the correct accessor name for this
  `controller_interface` version (some versions differ slightly here).

## Bounded-wait acknowledgement

The service handlers (`onTriggerEstop`/`onResetEstop`) block briefly
(up to ~400ms, two control cycles at the 100Hz `update_rate` set in
`controllers.yaml`) waiting for the RT loop to process the pulse, so the
service response (`accepted`, `state_after_reset`) reflects what actually
happened rather than just "we asked". This is a bounded wait on the
service's own callback thread — it never blocks `update()` itself, which
stays wait-free every cycle (a hard requirement for anything running in
the RT loop).
