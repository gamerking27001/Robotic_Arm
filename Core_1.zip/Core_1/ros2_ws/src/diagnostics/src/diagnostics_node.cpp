// diagnostics_node.cpp
// §12.3 "diagnostics_node": "Logging, health monitoring". Subscribes to the
// standard /joint_states (published by ros2_control's joint_state_broadcaster
// from robot_hardware_interface's exported state interfaces) and republishes
// as robot_msgs/ArmTelemetry (consumed by safety_monitor_node) plus a
// standard diagnostic_msgs/DiagnosticArray.
//
// LIMITATION: /joint_states only carries position/velocity/effort (the
// standard ros2_control state interface types) — current_a and
// winding_temp_c are NOT part of that message, so they're published as 0.0
// here. Getting real current/temperature into ROS2 needs either a custom
// state interface exposing them (extending RobotSystemInterface) or a
// separate topic from robot_hardware_interface; that isn't wired up yet.
#include <array>
#include <string>

#include "core/robot_config.hpp"
#include "diagnostic_msgs/msg/diagnostic_array.hpp"
#include "diagnostic_msgs/msg/diagnostic_status.hpp"
#include "diagnostic_msgs/msg/key_value.hpp"
#include "rclcpp/rclcpp.hpp"
#include "robot_msgs/msg/arm_telemetry.hpp"
#include "sensor_msgs/msg/joint_state.hpp"

namespace {
constexpr std::array<const char*, arm::config::kNumJoints> kJointNames = {"waist",      "shoulder",  "elbow",
                                                                             "wrist_roll", "wrist_pitch", "flange_roll"};
}

class DiagnosticsNode : public rclcpp::Node {
public:
    DiagnosticsNode() : rclcpp::Node("diagnostics_node") {
        telemetry_pub_ = create_publisher<robot_msgs::msg::ArmTelemetry>("arm_telemetry", 10);
        diag_pub_ = create_publisher<diagnostic_msgs::msg::DiagnosticArray>("/diagnostics", 10);

        joint_state_sub_ = create_subscription<sensor_msgs::msg::JointState>(
            "joint_states", 10, std::bind(&DiagnosticsNode::onJointState, this, std::placeholders::_1));
    }

private:
    void onJointState(const sensor_msgs::msg::JointState::SharedPtr msg) {
        robot_msgs::msg::ArmTelemetry telemetry;
        telemetry.header.stamp = now();

        diagnostic_msgs::msg::DiagnosticArray diag;
        diag.header.stamp = now();

        for (std::size_t i = 0; i < arm::config::kNumJoints && i < msg->name.size(); ++i) {
            auto& jt = telemetry.joints[i];
            jt.header.stamp = now();
            jt.joint_name = kJointNames[i];
            jt.position_rad = (i < msg->position.size()) ? msg->position[i] : 0.0;
            jt.velocity_rad_s = (i < msg->velocity.size()) ? msg->velocity[i] : 0.0;
            jt.torque_estimate_nm = (i < msg->effort.size()) ? msg->effort[i] : 0.0;
            jt.current_a = 0.0;       // see file header LIMITATION
            jt.winding_temp_c = 0.0;  // see file header LIMITATION
            jt.sto_active = false;
            jt.fault = false;
            jt.overcurrent_fault = false;
            jt.overtemp_fault = false;

            diagnostic_msgs::msg::DiagnosticStatus status;
            status.name = std::string("joint/") + kJointNames[i];
            status.level = diagnostic_msgs::msg::DiagnosticStatus::OK;
            status.message = "nominal";
            diagnostic_msgs::msg::KeyValue pos_kv;
            pos_kv.key = "position_rad";
            pos_kv.value = std::to_string(jt.position_rad);
            status.values.push_back(pos_kv);
            diagnostic_msgs::msg::KeyValue vel_kv;
            vel_kv.key = "velocity_rad_s";
            vel_kv.value = std::to_string(jt.velocity_rad_s);
            status.values.push_back(vel_kv);
            diag.status.push_back(status);
        }

        telemetry_pub_->publish(telemetry);
        diag_pub_->publish(diag);
    }

    rclcpp::Publisher<robot_msgs::msg::ArmTelemetry>::SharedPtr telemetry_pub_;
    rclcpp::Publisher<diagnostic_msgs::msg::DiagnosticArray>::SharedPtr diag_pub_;
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr joint_state_sub_;
};

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<DiagnosticsNode>());
    rclcpp::shutdown();
    return 0;
}
