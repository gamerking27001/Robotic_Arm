// sim_network_hardware_interface/sim_network_system_interface.hpp
//
// The simulator-facing half of the Mac↔Ubuntu bridge — see
// documentation/mac-ubuntu-bridge-architecture.md §6 for the design
// rationale and documentation/bridge_proto/sim_hardware.proto for the
// wire contract this class is a gRPC CLIENT of (the Mac-side simulator,
// MuJoCo or CoppeliaSim, is the SERVER — see that .proto's header
// comment for why the roles are assigned that way).
//
// This is a SIBLING to robot_hardware_interface/RobotSystemInterface, not
// a replacement — the URDF's <ros2_control><hardware><plugin> tag selects
// one or the other (the same swap mechanism the removed Gazebo
// integration used for gz_ros2_control). Everything above the hardware
// interface layer (estop_controller, arm_controller, diagnostics_node,
// robot_gateway) is UNCHANGED regardless of which plugin is loaded — this
// class deliberately exports the exact same "safety/*" state and command
// interface names RobotSystemInterface does (see that class's header
// comment for what each one means), so estop_controller's command-
// interface claims resolve identically either way. This is the practical
// payoff of the "ONE CANONICAL ROBOT" principle applied to the control
// stack, not just the geometry: swapping simulators shouldn't mean
// touching anything above this layer.
//
// SAFETY ARCHITECTURE: this class owns its OWN authoritative
// arm::safety::SafetyFsm instance (NOT shared with
// RobotSystemInterface's — only one of the two hardware interfaces is
// ever loaded at a time, so there is no risk of two competing FSMs
// running simultaneously the way the original safety_monitor_node bug
// had). Critically, the FSM is evaluated in the VM, from telemetry
// received over the network, NOT on the Mac-side simulator — the
// simulator only ever receives "go to this position," it never makes or
// influences a safety decision. See sim_hardware.proto's SAFETY NOTE for
// why, and the "Stale telemetry" comment below for what happens when the
// network connection itself is the problem.
//
// NOTE: written against the ros2_control (Jazzy) SystemInterface API from
// documented conventions, matching RobotSystemInterface's already-used
// patterns wherever this class's job is the same (safety evaluation,
// interface naming). NOT compiled — no ros2_control install AND no
// grpc++/protobuf toolchain were available in the environment this was
// written in (same compounded caveat as robot_gateway — see that
// package's README for what that means in practice). See this package's
// own README for the specific new risk this class adds beyond
// robot_hardware_interface's: a background gRPC I/O thread feeding
// read()/write() through a thread-safe buffer, which is new machinery
// RobotSystemInterface didn't need (it talks to in-process simulated
// hardware, no network thread required).
#pragma once

#include <array>
#include <atomic>
#include <chrono>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "core/robot_config.hpp"
#include "hardware_interface/handle.hpp"
#include "hardware_interface/hardware_info.hpp"
#include "hardware_interface/system_interface.hpp"
#include "hardware_interface/types/hardware_interface_return_values.hpp"
#include "rclcpp/macros.hpp"
#include "rclcpp_lifecycle/state.hpp"
#include "safety/safety_fsm.hpp"
#include "sim_hardware.grpc.pb.h"  // generated from documentation/bridge_proto/sim_hardware.proto (see CMakeLists.txt)

namespace sim_network_hardware_interface {

class SimNetworkSystemInterface : public hardware_interface::SystemInterface {
public:
    RCLCPP_SHARED_PTR_DEFINITIONS(SimNetworkSystemInterface)

    hardware_interface::CallbackReturn on_init(const hardware_interface::HardwareInfo& info) override;

    std::vector<hardware_interface::StateInterface> export_state_interfaces() override;
    std::vector<hardware_interface::CommandInterface> export_command_interfaces() override;

    hardware_interface::CallbackReturn on_activate(const rclcpp_lifecycle::State& previous_state) override;
    hardware_interface::CallbackReturn on_deactivate(const rclcpp_lifecycle::State& previous_state) override;

    hardware_interface::return_type read(const rclcpp::Time& time, const rclcpp::Duration& period) override;
    hardware_interface::return_type write(const rclcpp::Time& time, const rclcpp::Duration& period) override;

    ~SimNetworkSystemInterface() override;

private:
    static constexpr std::size_t kNumJoints = arm::config::kNumJoints;

    std::vector<std::string> joint_names_;  // populated from HardwareInfo, same as RobotSystemInterface

    // hardware_parameters read from the URDF's <ros2_control> tag (see
    // README.md's "URDF wiring" section) -- the Mac-side simulator's
    // address is deliberately a parameter, not hardcoded, since it
    // depends on the Parallels networking mode chosen (see
    // documentation/mac-ubuntu-bridge-architecture.md §3) and will differ
    // per developer machine.
    std::string sim_endpoint_ = "";  // e.g. "10.211.55.2:50052" -- required, on_init fails if unset

    // ros2_control state/command buffers -- identical shape and meaning
    // to RobotSystemInterface's, see that class for what each one is.
    std::array<double, kNumJoints> hw_position_states_{};
    std::array<double, kNumJoints> hw_velocity_states_{};
    std::array<double, kNumJoints> hw_effort_states_{};
    std::array<double, kNumJoints> hw_position_commands_{};

    arm::safety::SafetyFsm safety_fsm_;
    double safety_state_ordinal_ = 0.0;
    double safety_any_fault_ = 0.0;
    double safety_estop_pressed_ = 0.0;
    double safety_sto_required_ = 0.0;
    double safety_collision_suspected_ = 0.0;
    double safety_overcurrent_ = 0.0;
    double safety_overtemperature_ = 0.0;
    double safety_soft_limit_violation_ = 0.0;
    double safety_hard_limit_violation_ = 0.0;

    double estop_request_cmd_ = 0.0;
    double estop_reset_request_cmd_ = 0.0;
    bool last_estop_request_ = false;
    bool last_estop_reset_request_ = false;

    // Self-contained clock for throttled stale-telemetry logging (see
    // evaluateSafety()) -- deliberately NOT assumed to be available from
    // hardware_interface::SystemInterface's base class, since that wasn't
    // confirmed against real ros2_control source the way
    // RobotSystemInterface's already-checked API surface was (see
    // ros2_ws/README.md's verification notes) -- a self-owned
    // rclcpp::Clock avoids depending on uncertain base-class API for
    // something this minor.
    rclcpp::Clock stale_log_clock_{RCL_STEADY_TIME};

    // No physical hardware E-stop line exists on this path either (the
    // Mac-side simulator has no such concept) -- kept as a named,
    // always-false field for the same reason RobotSystemInterface keeps
    // one: a consistent place a future real integration could wire into,
    // and so evaluateSafety()'s call to safety_fsm_.evaluate() has an
    // unambiguous, honest value to pass rather than a magic literal.
    bool hardware_estop_line_active_ = false;

    void evaluateSafety();

    // --- Network I/O -------------------------------------------------
    // read()/write() run on controller_manager's real-time thread and
    // must never block on network I/O -- so the actual gRPC stream lives
    // on a separate background thread (grpc_io_thread_), communicating
    // with read()/write() through the mutex-protected buffers below.
    // This is the same "keep the RT thread wait-free" principle
    // estop_controller's atomics and robot_gateway's promise/future
    // bridge both apply, just with a persistent stream instead of
    // request/response calls.
    void grpcIoThreadMain();

    std::shared_ptr<grpc::Channel> channel_;
    std::unique_ptr<robot_gateway::v1::SimulationHardwareService::Stub> stub_;
    std::thread grpc_io_thread_;
    std::atomic<bool> shutdown_requested_{false};

    std::mutex io_mutex_;
    std::array<double, kNumJoints> pending_command_{};  // written by write(), read by grpc_io_thread_
    std::array<double, kNumJoints> received_position_{};
    std::array<double, kNumJoints> received_velocity_{};
    std::array<double, kNumJoints> received_current_{};
    std::array<double, kNumJoints> received_torque_{};
    std::array<double, kNumJoints> received_temp_{};
    std::array<bool, kNumJoints> received_sto_{};
    std::array<bool, kNumJoints> received_fault_{};
    int64_t last_received_cycle_ = -1;
    std::chrono::steady_clock::time_point last_received_wall_time_;
    bool have_first_state_ = false;

    // Stale-telemetry threshold: see the .cpp's evaluateSafety() comment
    // on why a missed-cycle count (not a fixed wall-clock timeout alone)
    // drives the fault decision, mirroring this repo's established
    // "stale must never silently continue" principle from the digital-
    // twin/dashboard work earlier in this project.
    static constexpr int kMaxMissedCycles = 3;
    int64_t local_cycle_count_ = 0;
};

}  // namespace sim_network_hardware_interface
