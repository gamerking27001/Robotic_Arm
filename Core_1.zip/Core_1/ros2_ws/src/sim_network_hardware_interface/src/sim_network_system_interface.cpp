#include "sim_network_hardware_interface/sim_network_system_interface.hpp"

#include "hardware_interface/types/hardware_interface_type_values.hpp"
#include "pluginlib/class_list_macros.hpp"
#include "rclcpp/logging.hpp"

namespace sim_network_hardware_interface {

namespace {
rclcpp::Logger logger() { return rclcpp::get_logger("sim_network_hardware_interface"); }
}  // namespace

hardware_interface::CallbackReturn SimNetworkSystemInterface::on_init(const hardware_interface::HardwareInfo& info) {
    if (hardware_interface::SystemInterface::on_init(info) != hardware_interface::CallbackReturn::SUCCESS) {
        return hardware_interface::CallbackReturn::ERROR;
    }

    if (info_.joints.size() != kNumJoints) {
        RCLCPP_ERROR(logger(), "Expected %zu joints in the URDF ros2_control tag, got %zu", kNumJoints,
                     info_.joints.size());
        return hardware_interface::CallbackReturn::ERROR;
    }

    joint_names_.clear();
    for (const auto& joint : info_.joints) joint_names_.push_back(joint.name);

    // Required hardware_parameter -- see the URDF wiring example in
    // README.md. Fails closed (ERROR, not a silent default) since a wrong
    // or missing endpoint would otherwise mean this interface silently
    // never connects to anything, which is a much more confusing failure
    // mode than an explicit startup error.
    auto it = info_.hardware_parameters.find("sim_endpoint");
    if (it == info_.hardware_parameters.end() || it->second.empty()) {
        RCLCPP_ERROR(logger(),
                     "Missing required hardware_parameter 'sim_endpoint' (e.g. \"10.211.55.2:50052\") -- "
                     "see sim_network_hardware_interface/README.md's URDF wiring example.");
        return hardware_interface::CallbackReturn::ERROR;
    }
    sim_endpoint_ = it->second;

    hw_position_states_.fill(0.0);
    hw_velocity_states_.fill(0.0);
    hw_effort_states_.fill(0.0);
    hw_position_commands_.fill(0.0);
    pending_command_.fill(0.0);
    received_position_.fill(0.0);
    received_velocity_.fill(0.0);
    received_current_.fill(0.0);
    received_torque_.fill(0.0);
    received_temp_.fill(0.0);
    received_sto_.fill(false);
    received_fault_.fill(false);

    return hardware_interface::CallbackReturn::SUCCESS;
}

std::vector<hardware_interface::StateInterface> SimNetworkSystemInterface::export_state_interfaces() {
    // Identical shape to RobotSystemInterface::export_state_interfaces()
    // -- see that class and this file's header comment for why matching
    // exactly matters (estop_controller claims these by name, unaware of
    // which hardware interface is actually loaded).
    std::vector<hardware_interface::StateInterface> state_interfaces;
    for (std::size_t i = 0; i < kNumJoints; ++i) {
        state_interfaces.emplace_back(joint_names_[i], hardware_interface::HW_IF_POSITION, &hw_position_states_[i]);
        state_interfaces.emplace_back(joint_names_[i], hardware_interface::HW_IF_VELOCITY, &hw_velocity_states_[i]);
        state_interfaces.emplace_back(joint_names_[i], hardware_interface::HW_IF_EFFORT, &hw_effort_states_[i]);
    }
    state_interfaces.emplace_back("safety", "state_ordinal", &safety_state_ordinal_);
    state_interfaces.emplace_back("safety", "any_fault", &safety_any_fault_);
    state_interfaces.emplace_back("safety", "estop_pressed", &safety_estop_pressed_);
    state_interfaces.emplace_back("safety", "sto_required", &safety_sto_required_);
    state_interfaces.emplace_back("safety", "collision_suspected", &safety_collision_suspected_);
    state_interfaces.emplace_back("safety", "overcurrent", &safety_overcurrent_);
    state_interfaces.emplace_back("safety", "overtemperature", &safety_overtemperature_);
    state_interfaces.emplace_back("safety", "soft_limit_violation", &safety_soft_limit_violation_);
    state_interfaces.emplace_back("safety", "hard_limit_violation", &safety_hard_limit_violation_);
    return state_interfaces;
}

std::vector<hardware_interface::CommandInterface> SimNetworkSystemInterface::export_command_interfaces() {
    std::vector<hardware_interface::CommandInterface> command_interfaces;
    for (std::size_t i = 0; i < kNumJoints; ++i) {
        command_interfaces.emplace_back(joint_names_[i], hardware_interface::HW_IF_POSITION,
                                         &hw_position_commands_[i]);
    }
    command_interfaces.emplace_back("safety", "estop_request", &estop_request_cmd_);
    command_interfaces.emplace_back("safety", "estop_reset_request", &estop_reset_request_cmd_);
    return command_interfaces;
}

hardware_interface::CallbackReturn SimNetworkSystemInterface::on_activate(
    const rclcpp_lifecycle::State& /*previous_state*/) {
    for (std::size_t i = 0; i < kNumJoints; ++i) {
        hw_position_commands_[i] = hw_position_states_[i];
    }

    // Same boot sequence as RobotSystemInterface::on_activate() -- see
    // that class for why Running (not Idle) is the steady state here too.
    safety_fsm_.handle(arm::safety::Event::kBootComplete);
    safety_fsm_.handle(arm::safety::Event::kHomingComplete);
    safety_fsm_.handle(arm::safety::Event::kTaskStart);
    safety_state_ordinal_ = static_cast<double>(safety_fsm_.state());
    estop_request_cmd_ = 0.0;
    estop_reset_request_cmd_ = 0.0;
    last_estop_request_ = false;
    last_estop_reset_request_ = false;
    have_first_state_ = false;
    last_received_cycle_ = -1;
    local_cycle_count_ = 0;

    // NOTE: InsecureChannelCredentials -- matches robot_gateway's own
    // flagged TLS gap (see that package's README). This connection
    // crosses the Mac<->VM boundary described in
    // documentation/mac-ubuntu-bridge-architecture.md §3 -- whatever
    // isolation that boundary has comes from the Parallels networking
    // mode chosen there, not from this channel's own security, same
    // caveat as robot_gateway's.
    channel_ = grpc::CreateChannel(sim_endpoint_, grpc::InsecureChannelCredentials());
    stub_ = robot_gateway::v1::SimulationHardwareService::NewStub(channel_);

    shutdown_requested_.store(false);
    grpc_io_thread_ = std::thread(&SimNetworkSystemInterface::grpcIoThreadMain, this);

    RCLCPP_INFO(logger(), "SimNetworkSystemInterface activated, connecting to %s", sim_endpoint_.c_str());
    return hardware_interface::CallbackReturn::SUCCESS;
}

hardware_interface::CallbackReturn SimNetworkSystemInterface::on_deactivate(
    const rclcpp_lifecycle::State& /*previous_state*/) {
    shutdown_requested_.store(true);
    if (grpc_io_thread_.joinable()) {
        grpc_io_thread_.join();
    }
    return hardware_interface::CallbackReturn::SUCCESS;
}

SimNetworkSystemInterface::~SimNetworkSystemInterface() {
    shutdown_requested_.store(true);
    if (grpc_io_thread_.joinable()) {
        grpc_io_thread_.join();
    }
}

void SimNetworkSystemInterface::grpcIoThreadMain() {
    // Runs the persistent bidirectional stream described in
    // sim_hardware.proto -- one JointCommand out, one JointState back,
    // repeated for the life of the connection. This thread owns the gRPC
    // call entirely; read()/write() never touch stub_/channel_ directly,
    // only the mutex-protected buffers below (io_mutex_).
    grpc::ClientContext context;
    auto stream = stub_->StreamJoints(&context);

    while (!shutdown_requested_.load()) {
        robot_gateway::v1::JointCommand cmd;
        {
            std::lock_guard<std::mutex> lock(io_mutex_);
            for (std::size_t i = 0; i < kNumJoints; ++i) {
                cmd.add_position_setpoint_rad(pending_command_[i]);
            }
            cmd.set_cycle_sequence(local_cycle_count_);
        }

        if (!stream->Write(cmd)) {
            RCLCPP_ERROR(logger(), "gRPC stream write failed -- Mac-side simulator connection lost");
            break;
        }

        robot_gateway::v1::JointState state;
        if (!stream->Read(&state)) {
            RCLCPP_ERROR(logger(), "gRPC stream read failed -- Mac-side simulator connection lost");
            break;
        }

        {
            std::lock_guard<std::mutex> lock(io_mutex_);
            for (int i = 0; i < state.joints_size() && i < static_cast<int>(kNumJoints); ++i) {
                const auto& j = state.joints(i);
                received_position_[i] = j.position_rad();
                received_velocity_[i] = j.velocity_rad_s();
                received_current_[i] = j.current_a();
                received_torque_[i] = j.torque_estimate_nm();
                received_temp_[i] = j.winding_temp_c();
                received_sto_[i] = j.sto_active();
                received_fault_[i] = j.fault();
            }
            last_received_cycle_ = state.cycle_sequence();
            last_received_wall_time_ = std::chrono::steady_clock::now();
            have_first_state_ = true;
        }
    }

    // Stream ended (either shutdown_requested_ or a real failure) --
    // read()'s staleness check (evaluateSafety()) is what actually
    // notices this and drives the safety FSM; this thread's only job on
    // exit is to stop cleanly, not to make a safety decision itself (see
    // the header comment on why that decision belongs in read()/
    // evaluateSafety(), which run on the RT thread with the FSM).
    stream->WritesDone();
    grpc::Status status = stream->Finish();
    if (!status.ok() && !shutdown_requested_.load()) {
        RCLCPP_ERROR(logger(), "gRPC stream ended with error: %s", status.error_message().c_str());
    }
}

void SimNetworkSystemInterface::evaluateSafety() {
    const bool estop_request_now = estop_request_cmd_ > 0.5;
    const bool estop_reset_now = estop_reset_request_cmd_ > 0.5;

    if (estop_request_now && !last_estop_request_) {
        RCLCPP_WARN(logger(), "Software E-stop requested via estop_controller");
        safety_fsm_.handle(arm::safety::Event::kEstopTriggered);
        // NOTE: unlike RobotSystemInterface, there is no local
        // triggerSafeTorqueOff() to call here -- there are no
        // arm::hal::JointInterface objects owned by this class (the
        // "joints" are simulated on the Mac, not in this process). The
        // FSM transition to kEStop is what write() gates motion on (see
        // write() below); actually cutting torque on the simulated side
        // is the Mac-side simulator's responsibility once it sees motion
        // stop being commanded. This is a real, honest limitation of a
        // network-mediated safety boundary compared to
        // RobotSystemInterface's in-process one -- see README.md's
        // "What this doesn't do yet".
    }
    if (estop_reset_now && !last_estop_reset_request_) {
        RCLCPP_INFO(logger(), "E-stop reset requested via estop_controller");
        if (safety_fsm_.handle(arm::safety::Event::kEstopReset)) {
            safety_fsm_.handle(arm::safety::Event::kBootComplete);
            safety_fsm_.handle(arm::safety::Event::kHomingComplete);
            safety_fsm_.handle(arm::safety::Event::kTaskStart);
        }
    }
    last_estop_request_ = estop_request_now;
    last_estop_reset_request_ = estop_reset_now;

    // Stale-telemetry check: if the background thread hasn't delivered a
    // NEW cycle since last time (missed_cycles counted against this
    // read()'s own cycle count, not wall-clock time alone, since
    // controller_manager's own timing is the relevant clock here), treat
    // every joint as faulted for this evaluation -- reusing
    // SafetyFsm::evaluate()'s existing fault-detection path rather than
    // inventing a parallel one. This is the concrete implementation of
    // the "stale must never silently continue" principle named in the
    // header comment: a dropped network connection to the Mac must read
    // as a fault, not as "everything's still fine, just no updates."
    bool stale;
    arm::hal::JointTelemetry per_joint_telemetry[kNumJoints];
    {
        std::lock_guard<std::mutex> lock(io_mutex_);
        stale = !have_first_state_ || (local_cycle_count_ - last_received_cycle_) > kMaxMissedCycles;
        for (std::size_t i = 0; i < kNumJoints; ++i) {
            hw_position_states_[i] = received_position_[i];
            hw_velocity_states_[i] = received_velocity_[i];
            hw_effort_states_[i] = received_torque_[i];

            per_joint_telemetry[i].position_rad = received_position_[i];
            per_joint_telemetry[i].velocity_rad_s = received_velocity_[i];
            per_joint_telemetry[i].current_a = received_current_[i];
            per_joint_telemetry[i].torque_estimate_nm = received_torque_[i];
            per_joint_telemetry[i].winding_temp_c = received_temp_[i];
            per_joint_telemetry[i].sto_active = received_sto_[i];
            // Force a fault reading when stale, regardless of what the
            // last real message said -- see the comment above.
            per_joint_telemetry[i].fault = stale || received_fault_[i];
        }
    }
    if (stale) {
        RCLCPP_WARN_THROTTLE(logger(), stale_log_clock_, 1000,
                              "Stale telemetry from Mac-side simulator (missed >%d cycles) -- treating as fault",
                              kMaxMissedCycles);
    }

    arm::safety::SafetyCheckResult aggregate{};
    for (std::size_t i = 0; i < kNumJoints; ++i) {
        const auto check = safety_fsm_.evaluate(per_joint_telemetry[i], arm::config::kJointSpecs[i],
                                                 /*commanded_torque_nm=*/0.0, hardware_estop_line_active_);
        aggregate.estop_pressed = aggregate.estop_pressed || check.estop_pressed;
        aggregate.sto_required = aggregate.sto_required || check.sto_required;
        aggregate.collision_suspected = aggregate.collision_suspected || check.collision_suspected;
        aggregate.overcurrent = aggregate.overcurrent || check.overcurrent;
        aggregate.overtemperature = aggregate.overtemperature || check.overtemperature;
        aggregate.soft_limit_violation = aggregate.soft_limit_violation || check.soft_limit_violation;
        aggregate.hard_limit_violation = aggregate.hard_limit_violation || check.hard_limit_violation;
    }
    safety_state_ordinal_ = static_cast<double>(safety_fsm_.state());
    safety_any_fault_ = aggregate.anyFault() ? 1.0 : 0.0;
    safety_estop_pressed_ = aggregate.estop_pressed ? 1.0 : 0.0;
    safety_sto_required_ = aggregate.sto_required ? 1.0 : 0.0;
    safety_collision_suspected_ = aggregate.collision_suspected ? 1.0 : 0.0;
    safety_overcurrent_ = aggregate.overcurrent ? 1.0 : 0.0;
    safety_overtemperature_ = aggregate.overtemperature ? 1.0 : 0.0;
    safety_soft_limit_violation_ = aggregate.soft_limit_violation ? 1.0 : 0.0;
    safety_hard_limit_violation_ = aggregate.hard_limit_violation ? 1.0 : 0.0;
}

hardware_interface::return_type SimNetworkSystemInterface::read(const rclcpp::Time& /*time*/,
                                                                    const rclcpp::Duration& /*period*/) {
    local_cycle_count_++;
    evaluateSafety();
    return hardware_interface::return_type::OK;
}

hardware_interface::return_type SimNetworkSystemInterface::write(const rclcpp::Time& /*time*/,
                                                                     const rclcpp::Duration& /*period*/) {
    // Same gating rule as RobotSystemInterface::write() -- commands only
    // queued for transmission when the FSM permits motion. Note this
    // still queues into pending_command_ for the I/O thread to send even
    // when NOT Running (holding the last commanded position), same
    // "hold, don't blindly forward" behavior as the in-process interface.
    if (safety_fsm_.state() == arm::safety::RobotState::kRunning) {
        std::lock_guard<std::mutex> lock(io_mutex_);
        for (std::size_t i = 0; i < kNumJoints; ++i) {
            pending_command_[i] = hw_position_commands_[i];
        }
    }
    return hardware_interface::return_type::OK;
}

}  // namespace sim_network_hardware_interface

PLUGINLIB_EXPORT_CLASS(sim_network_hardware_interface::SimNetworkSystemInterface, hardware_interface::SystemInterface)
