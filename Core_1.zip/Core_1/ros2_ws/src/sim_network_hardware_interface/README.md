# sim_network_hardware_interface

The simulator-facing sibling to `robot_hardware_interface` — see
`documentation/mac-ubuntu-bridge-architecture.md` §6 for why this exists
and `documentation/bridge_proto/sim_hardware.proto` for the wire
contract. This package is the **gRPC client**; the Mac-side simulator
(MuJoCo or CoppeliaSim — neither built yet, see
`simulation/mujoco/README.md` and `simulation/coppeliasim/README.md`)
is the server.

## The one thing worth understanding before anything else

This exports the **exact same** `safety/*` state and command interface
names `robot_hardware_interface` does. That's deliberate, not
incidental: `estop_controller`, `arm_controller`, `diagnostics_node`, and
`robot_gateway` all claim/subscribe to those names without knowing or
caring which hardware interface plugin is actually loaded. Switching
between the simulated-CAN robot and a Mac-side simulator is a one-line
change to the URDF's `<ros2_control><hardware><plugin>` tag — see "URDF
wiring" below — not a change to anything above the hardware interface
layer.

## URDF wiring

`generate_urdf.py` now supports emitting this plugin directly — no more
hand-editing the generated URDF:

```bash
cd ../robot_description/scripts
python3 generate_urdf.py --hardware-plugin sim-network --sim-endpoint 10.211.55.2:50052
```

This writes to a **separate file**, `urdf/generated_arm_sim_network.urdf`
— deliberately not the same file (`generated_arm.urdf`) the real/
simulated-CAN bringup's default launch path uses, so generating the
sim-network variant never silently changes what that path loads. Point
your own launch file at the sim-network file explicitly when you want
this plugin instead. Tested (the one part of this whole bridge that
actually could be, since it's pure Python/XML with no ROS2/gRPC
dependency): both variants generate valid XML, and the joint
limits/geometry are byte-for-byte identical between them — only the
`<hardware><plugin>` block differs, confirmed by parsing both files back
and comparing every joint's limits programmatically.

The resulting `<ros2_control>` block looks like:

```xml
<ros2_control name="modular_arm_msme_system" type="system">
  <hardware>
    <plugin>sim_network_hardware_interface/SimNetworkSystemInterface</plugin>
    <param name="sim_endpoint">10.211.55.2:50052</param>
  </hardware>
  <!-- joint definitions unchanged -->
</ros2_control>
```

`sim_endpoint` is **required** — `on_init()` fails closed (returns
`CallbackReturn::ERROR`, not a silent default) if it's missing, same
fail-closed pattern used throughout this project's other new components.
The actual IP depends on the Parallels networking mode chosen (see the
bridge architecture doc §3) and which simulator's server you're running
— MuJoCo's `mac_sim_server.py` defaults to port 50052, CoppeliaSim's
`coppeliasim_sim_server.py` defaults to port 50053 (see
`simulation/mujoco/` and `simulation/coppeliasim/` respectively).

## What happens on a dropped connection — read before assuming this is safe by default

If the Mac-side simulator stops responding (network drop, simulator
crash, anything), the background gRPC thread's `stream->Read()` call
fails and the thread exits. **Before that happens**, `read()`'s own
staleness check (`evaluateSafety()`, comparing `local_cycle_count_`
against `last_received_cycle_`) is what actually protects the robot: if
more than `kMaxMissedCycles` (3) control cycles pass without fresh
telemetry, every joint is fed into `SafetyFsm::evaluate()` as faulted,
driving the FSM toward `Fault`/`EStop` the same way a real
overcurrent/overtemperature condition would. This reuses
`SafetyFsm`'s existing fault path rather than inventing a parallel
"connection lost" state machine.

**A real, honest limitation of this specific safety boundary, not
present in `robot_hardware_interface`:** that in-process interface can
call `joints_[i]->triggerSafeTorqueOff()` directly on E-stop —
`SimNetworkSystemInterface` cannot, because there is no local
`arm::hal::JointInterface` object to call it on; the "joint" is
simulated on the Mac. E-stop here means "this plugin stops sending
position commands and the FSM reports EStop," and it is the **Mac-side
simulator's own responsibility** to notice motion has stopped being
commanded and behave accordingly. For a pure simulation this is a
reasonable limitation (nothing physical is at risk); it stops being
reasonable the moment `sim_network_hardware_interface` is pointed at
anything with real actuators behind it, which it should never be — this
plugin's entire design assumes a Mac-side *simulator*, not a real robot.

## Confidence level

Same compounded caveat as `robot_gateway` (its README explains this in
more detail — the short version: no ROS2 install *and* no
`grpc++`/`protobuf` toolchain were available while writing this). On top
of that, this package adds a new risk `robot_hardware_interface` never
had: a background I/O thread feeding the real-time `read()`/`write()`
cycle through mutex-protected buffers (`io_mutex_`). The locking pattern
here is straightforward (short critical sections, no blocking calls
while holding the lock), but "straightforward under review" and
"correct under real `controller_manager` RT-thread scheduling pressure"
are different claims — the second one needs a real build and real
runtime testing to back up, not just a careful read-through.

**Before trusting this beyond development-time simulation testing:**
get it through a real `colcon build`, then run it against a Mac-side
stub server that just echoes back whatever `JointCommand` it receives as
`JointState` (a five-line test server, not a real simulator) to confirm
the streaming loop, the staleness detection, and the safety-gating logic
all behave as designed before pointing it at an actual MuJoCo/CoppeliaSim
integration.

## What this doesn't do yet

- No TLS (matches `robot_gateway`'s same flagged gap).
- No reconnection logic — if the gRPC stream drops, the background
  thread exits and stays exited; `read()`'s staleness detection correctly
  keeps the robot safe, but nothing here attempts to reconnect. A real
  deployment would want `on_activate()`-style reconnection, not a
  one-shot connection that requires a full hardware interface
  deactivate/reactivate cycle to retry.
- `write()`'s "hold last commanded position when not Running" behavior
  (same as `robot_hardware_interface`) means the *last* position keeps
  getting sent to the Mac-side simulator during a fault — the simulator
  itself needs to decide what "hold position" actually means physically,
  since there's no local torque-off call to fall back on (see above).
