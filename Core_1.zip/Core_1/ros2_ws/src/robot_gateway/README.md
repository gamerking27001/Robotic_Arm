# robot_gateway

Operator-facing gRPC gateway — the Mac-side native app's entry point into
ROS2, implementing `documentation/bridge_proto/robot_control.proto`'s
`RobotControlService`. See `documentation/mac-ubuntu-bridge-architecture.md`
§5 for the design rationale (why gRPC, why this is split from Foxglove's
own `foxglove_bridge` path, why this node has no motion authority beyond
what `estop_controller`/`arm_controller` already grant).

## What this node actually does

| RPC | Backed by |
|---|---|
| `DiscoverRobots` | Hardcoded single-robot response (see "Known simplifications") |
| `Connect` | Validates `ROBOT_GATEWAY_AUTH_TOKEN`, issues a session_id |
| `StreamTelemetry` | Subscribes to `arm_telemetry` + `safety_status`, polls and streams |
| `TriggerEstop` / `ResetEstop` | Calls `estop_controller`'s existing services — no new authority |
| `MoveJoint` | Calls `arm_controller`'s `FollowJointTrajectory` action (not a raw topic publish — see the .cpp comment on why the action interface specifically, for a real accept/reject signal) |
| `RunCalibration` | **Honestly returns "not implemented"** — no calibration service exists anywhere in `ros2_ws` to call into. Not a stub pretending to work. |
| `GetDiagnostics` | Subscribes to `/diagnostics`, translates `DiagnosticArray` → the proto's snapshot list |

## Confidence level — read this before trusting any of it

This is the least-verified package in `ros2_ws`, for a concrete reason:
every other package's caveat is "no ROS2 install available in this
environment." This one has that caveat **plus** no `grpc++`/`protobuf`
toolchain available either (checked: no `protoc`, no `grpc++` headers, no
`pip install grpcio` — no network access to get any of them). That means:

- **Never compiled, in any form.** Not the C++, not the generated
  protobuf/gRPC bindings (which don't exist yet — `CMakeLists.txt`'s
  `add_custom_command` for `protoc`/`grpc_cpp_plugin` has never actually
  run).
- The rclcpp/gRPC API usage (sync server-streaming via
  `grpc::ServerWriter`, the promise/future bridge between gRPC worker
  threads and ROS2's executor thread, `rclcpp_action::create_client`)
  matches documented conventions for both libraries, but the *interaction*
  between two libraries that were each individually well-understood is
  exactly the kind of thing that surfaces real integration bugs on a
  first real build — expect some.
- Most likely specific trouble spots on a real build, roughly in order of
  likelihood: (1) the CMake `gRPC`/`Protobuf` `find_package` invocations
  — CMake integration for gRPC varies more across distro package versions
  than most ROS2 dependencies do; (2) whether `grpc::ServerWriter::Write()`
  blocking inside a loop that also does `std::this_thread::sleep_for`
  behaves the way this code assumes under real gRPC flow control; (3) the
  promise/future pattern in `TriggerEstop`/`ResetEstop` — correct in
  principle, but two-thread handoffs are exactly where a small mistake
  compiles fine and fails at runtime instead.

**Before running this against a real robot:** get it compiling first (a
real `colcon build` will surface CMake/API issues immediately), then test
each RPC individually against a running `estop_controller` +
`arm_controller` + `diagnostics_node`, in a simulated-CAN environment
before anything with real hardware attached.

## What this doesn't do yet

- **Auth is a single shared token, not per-operator identity.**
  `ROBOT_GATEWAY_AUTH_TOKEN` is one credential for the whole gateway
  (same fail-closed pattern as `dashboard/backend`'s API keys) — there's
  no user database, no role distinction (viewer vs. operator, unlike the
  dashboard), and session_ids are generated with `std::mt19937_64`, not a
  reviewed cryptographic token library. Fine for a single-operator/small-
  team development setup; a real multi-operator deployment needs more.
- **No TLS.** `main.cpp` uses `grpc::InsecureServerCredentials()`
  explicitly, with a comment flagging it — this should become
  `SslServerCredentials` with a real certificate before this is exposed
  beyond an already-network-isolated Mac↔VM link (see the bridge
  architecture doc's Shared-networking default — that isolation is a
  property of the *network mode*, not of this server, and shouldn't be
  the only thing standing between this and the wider LAN).
- **`MoveJoint`'s trajectory timing is a hardcoded 2-second placeholder**,
  not derived from the core stack's real S-curve trajectory profile
  (`arm::motion::TrajectoryProfile`), which isn't exposed to this node.
  A real implementation would want to either expose that profile's timing
  calculation to this node, or accept a duration/speed parameter from the
  caller instead of guessing.
- **`DiscoverRobots` is hardcoded to one robot.** A real fleet scenario
  needs this to actually enumerate multiple robots, which nothing in this
  repo currently supports at any layer.
- **`StreamTelemetry` polls on a sleep loop** rather than waking
  immediately on new data via a condition variable — bounded by
  `max_rate_hz` either way, so this is a reasonable v1 simplification,
  not a correctness problem, but worth knowing if sub-period latency ever
  matters.
- **The `sim_network_hardware_interface` plugin and
  `SimulationHardwareService`'s server side (Mac-side simulator
  integration) are not part of this package** — see
  `documentation/bridge_proto/sim_hardware.proto` and the bridge
  architecture doc §6. This package only implements
  `RobotControlService`.

## Running it (once it compiles)

```bash
export ROBOT_GATEWAY_AUTH_TOKEN=$(python3 -c "import secrets; print(secrets.token_urlsafe(32))")
ros2 run robot_gateway robot_gateway_node
```

Requires `estop_controller`, `arm_controller` (via `robot_bringup`), and
`diagnostics_node` already running for `TriggerEstop`/`ResetEstop`/
`MoveJoint`/`GetDiagnostics` to have anything to call into —
`robot_gateway_node` is deliberately **not** included in
`robot_bringup.launch.py`'s default node list (same reasoning as
`vision_pipeline`'s exclusion: it needs `ROBOT_GATEWAY_AUTH_TOKEN` set,
which a default launch file shouldn't silently require or silently work
around).
