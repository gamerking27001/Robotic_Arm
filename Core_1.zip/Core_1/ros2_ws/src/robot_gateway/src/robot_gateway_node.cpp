// robot_gateway_node.cpp
//
// See robot_gateway_node.hpp for the design rationale. This file
// implements each RobotControlService RPC by translating it into calls
// against existing ROS2 interfaces -- it deliberately adds no new
// authority over the robot beyond what those existing interfaces already
// grant (see the header's safety-boundary comment).
#include "robot_gateway/robot_gateway_node.hpp"

#include <chrono>
#include <cmath>
#include <cstdlib>
#include <future>
#include <random>
#include <sstream>

#include "control_msgs/action/follow_joint_trajectory.hpp"
#include "rclcpp_action/rclcpp_action.hpp"

namespace robot_gateway {

namespace {
// Simple random session-id generator -- sufficient to make session_ids
// unguessable-in-practice for a single-operator/small-team deployment,
// NOT a cryptographically-reviewed token scheme. A real multi-tenant
// deployment should replace this with a proper auth library rather than
// extend it in place -- see README.md's "What this doesn't do yet".
std::string generateSessionId() {
    std::random_device rd;
    std::mt19937_64 gen(rd());
    std::uniform_int_distribution<uint64_t> dist;
    std::ostringstream oss;
    oss << std::hex << dist(gen) << dist(gen);
    return oss.str();
}

double degToRad(double deg) { return deg * M_PI / 180.0; }
}  // namespace

RobotGatewayService::RobotGatewayService(rclcpp::Node::SharedPtr node) : node_(std::move(node)) {
    const char* token_env = std::getenv("ROBOT_GATEWAY_AUTH_TOKEN");
    if (token_env == nullptr || std::string(token_env).empty()) {
        // Fail-closed, same pattern as dashboard/backend/main.py's
        // DASHBOARD_VIEWER_API_KEY/DASHBOARD_OPERATOR_API_KEY check --
        // this service can trigger real robot motion, so refusing to
        // start without a configured token is safer than starting
        // unsecured. See main.cpp for where this exception surfaces.
        throw std::runtime_error(
            "ROBOT_GATEWAY_AUTH_TOKEN must be set -- robot_gateway refuses to start without an auth "
            "token configured (it can trigger real robot motion). No default token is provided.");
    }
    auth_token_ = token_env;

    telemetry_sub_ = node_->create_subscription<robot_msgs::msg::ArmTelemetry>(
        "arm_telemetry", 10, [this](robot_msgs::msg::ArmTelemetry::SharedPtr msg) {
            std::lock_guard<std::mutex> lock(state_mutex_);
            latest_telemetry_ = *msg;
            have_telemetry_ = true;
        });

    safety_sub_ = node_->create_subscription<robot_msgs::msg::SafetyStatus>(
        "safety_status", 10, [this](robot_msgs::msg::SafetyStatus::SharedPtr msg) {
            std::lock_guard<std::mutex> lock(state_mutex_);
            latest_safety_ = *msg;
            have_safety_ = true;
        });

    diagnostics_sub_ = node_->create_subscription<diagnostic_msgs::msg::DiagnosticArray>(
        "/diagnostics", 10, [this](diagnostic_msgs::msg::DiagnosticArray::SharedPtr msg) {
            std::lock_guard<std::mutex> lock(state_mutex_);
            latest_diagnostics_ = *msg;
        });

    trigger_estop_client_ = node_->create_client<robot_msgs::srv::TriggerEstop>("trigger_estop");
    reset_estop_client_ = node_->create_client<robot_msgs::srv::ResetEstop>("reset_estop");

    move_pub_ = node_->create_publisher<trajectory_msgs::msg::JointTrajectory>(
        "/arm_controller/joint_trajectory", 10);
}

bool RobotGatewayService::isValidSession(const std::string& session_id) {
    std::lock_guard<std::mutex> lock(session_mutex_);
    return active_sessions_.count(session_id) > 0;
}

grpc::Status RobotGatewayService::DiscoverRobots(grpc::ServerContext* /*context*/,
                                                   const robot_gateway::v1::DiscoverRobotsRequest* /*request*/,
                                                   robot_gateway::v1::DiscoverRobotsResponse* response) {
    // Single-robot-per-gateway-instance simplification (matches
    // dashboard/backend's own single-robot assumption) -- a fleet
    // scenario would need this to actually enumerate multiple robots,
    // which is out of scope for this first implementation.
    auto* robot = response->add_robots();
    robot->set_robot_id("arm-0001");
    robot->set_display_name("Modular Arm (standard_5kg_850mm)");
    {
        std::lock_guard<std::mutex> lock(state_mutex_);
        robot->set_reachable(have_telemetry_ && have_safety_);
    }
    return grpc::Status::OK;
}

grpc::Status RobotGatewayService::Connect(grpc::ServerContext* /*context*/,
                                            const robot_gateway::v1::ConnectRequest* request,
                                            robot_gateway::v1::ConnectResponse* response) {
    if (request->auth_token() != auth_token_) {
        response->set_accepted(false);
        response->set_reason("invalid auth token");
        return grpc::Status::OK;  // application-level rejection, not a transport error
    }
    const std::string session_id = generateSessionId();
    {
        std::lock_guard<std::mutex> lock(session_mutex_);
        active_sessions_.insert(session_id);
    }
    response->set_accepted(true);
    response->set_session_id(session_id);
    return grpc::Status::OK;
}

grpc::Status RobotGatewayService::StreamTelemetry(grpc::ServerContext* context,
                                                     const robot_gateway::v1::StreamTelemetryRequest* request,
                                                     grpc::ServerWriter<robot_gateway::v1::TelemetrySnapshot>* writer) {
    if (!isValidSession(request->session_id())) {
        return grpc::Status(grpc::StatusCode::UNAUTHENTICATED, "invalid or expired session_id");
    }

    const double rate_hz = request->max_rate_hz() > 0.0 ? request->max_rate_hz() : 10.0;
    const auto period = std::chrono::duration<double>(1.0 / rate_hz);

    // Simple poll-and-push loop rather than a condition-variable wake-up
    // on new data -- see README.md's "What this doesn't do yet" for why
    // this is a reasonable v1 simplification (bounded by max_rate_hz
    // either way) rather than added complexity for a marginal latency
    // improvement.
    while (!context->IsCancelled()) {
        robot_gateway::v1::TelemetrySnapshot snapshot;
        {
            std::lock_guard<std::mutex> lock(state_mutex_);
            if (!have_telemetry_ || !have_safety_) {
                // Nothing to send yet -- diagnostics_node/estop_controller
                // haven't published a first message. Skip this cycle
                // rather than sending a snapshot full of default-constructed
                // zeros that would misleadingly look like real telemetry.
                continue;
            }
            for (const auto& jt : latest_telemetry_.joints) {
                auto* proto_joint = snapshot.add_joints();
                proto_joint->set_joint_name(jt.joint_name);
                proto_joint->set_position_rad(jt.position_rad);
                proto_joint->set_velocity_rad_s(jt.velocity_rad_s);
                proto_joint->set_current_a(jt.current_a);
                proto_joint->set_torque_estimate_nm(jt.torque_estimate_nm);
                proto_joint->set_winding_temp_c(jt.winding_temp_c);
                proto_joint->set_sto_active(jt.sto_active);
                proto_joint->set_fault(jt.fault);
                proto_joint->set_overcurrent_fault(jt.overcurrent_fault);
                proto_joint->set_overtemp_fault(jt.overtemp_fault);
            }
            auto* proto_safety = snapshot.mutable_safety();
            proto_safety->set_state(latest_safety_.state);
            proto_safety->set_estop_pressed(latest_safety_.estop_pressed);
            proto_safety->set_sto_required(latest_safety_.sto_required);
            proto_safety->set_collision_suspected(latest_safety_.collision_suspected);
            proto_safety->set_overcurrent(latest_safety_.overcurrent);
            proto_safety->set_overtemperature(latest_safety_.overtemperature);
            proto_safety->set_soft_limit_violation(latest_safety_.soft_limit_violation);
            proto_safety->set_hard_limit_violation(latest_safety_.hard_limit_violation);
            proto_safety->set_any_fault(latest_safety_.any_fault);
        }
        snapshot.set_timestamp_unix_ns(
            std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::system_clock::now().time_since_epoch())
                .count());

        if (!writer->Write(snapshot)) {
            break;  // client disconnected
        }
        std::this_thread::sleep_for(period);
    }
    return grpc::Status::OK;
}

grpc::Status RobotGatewayService::TriggerEstop(grpc::ServerContext* /*context*/,
                                                  const robot_gateway::v1::TriggerEstopRequest* request,
                                                  robot_gateway::v1::TriggerEstopResponse* response) {
    if (!isValidSession(request->session_id())) {
        return grpc::Status(grpc::StatusCode::UNAUTHENTICATED, "invalid or expired session_id");
    }
    if (!trigger_estop_client_->wait_for_service(std::chrono::seconds(2))) {
        return grpc::Status(grpc::StatusCode::UNAVAILABLE, "trigger_estop service unavailable (estop_controller not running?)");
    }

    auto req = std::make_shared<robot_msgs::srv::TriggerEstop::Request>();
    req->reason = request->reason();

    // Bridges the ROS2 async service-client callback (which fires on the
    // executor thread spinning in main.cpp) back to this gRPC worker
    // thread via a promise/future pair -- see the header comment on why
    // this two-thread arrangement exists at all.
    auto promise = std::make_shared<std::promise<bool>>();
    auto future = promise->get_future();
    trigger_estop_client_->async_send_request(
        req, [promise](rclcpp::Client<robot_msgs::srv::TriggerEstop>::SharedFuture result) {
            promise->set_value(result.get()->accepted);
        });

    if (future.wait_for(std::chrono::seconds(3)) != std::future_status::ready) {
        return grpc::Status(grpc::StatusCode::DEADLINE_EXCEEDED, "trigger_estop call timed out");
    }
    response->set_accepted(future.get());
    return grpc::Status::OK;
}

grpc::Status RobotGatewayService::ResetEstop(grpc::ServerContext* /*context*/,
                                                const robot_gateway::v1::ResetEstopRequest* request,
                                                robot_gateway::v1::ResetEstopResponse* response) {
    if (!isValidSession(request->session_id())) {
        return grpc::Status(grpc::StatusCode::UNAUTHENTICATED, "invalid or expired session_id");
    }
    if (!reset_estop_client_->wait_for_service(std::chrono::seconds(2))) {
        return grpc::Status(grpc::StatusCode::UNAVAILABLE, "reset_estop service unavailable (estop_controller not running?)");
    }

    auto req = std::make_shared<robot_msgs::srv::ResetEstop::Request>();
    req->operator_id = request->operator_id();

    auto promise = std::make_shared<std::promise<robot_msgs::srv::ResetEstop::Response::SharedPtr>>();
    auto future = promise->get_future();
    reset_estop_client_->async_send_request(
        req, [promise](rclcpp::Client<robot_msgs::srv::ResetEstop>::SharedFuture result) {
            promise->set_value(result.get());
        });

    if (future.wait_for(std::chrono::seconds(3)) != std::future_status::ready) {
        return grpc::Status(grpc::StatusCode::DEADLINE_EXCEEDED, "reset_estop call timed out");
    }
    auto result = future.get();
    response->set_accepted(result->accepted);
    response->set_state_after_reset(result->state_after_reset);
    return grpc::Status::OK;
}

grpc::Status RobotGatewayService::MoveJoint(grpc::ServerContext* /*context*/,
                                               const robot_gateway::v1::MoveJointRequest* request,
                                               robot_gateway::v1::MoveJointResponse* response) {
    if (!isValidSession(request->session_id())) {
        return grpc::Status(grpc::StatusCode::UNAUTHENTICATED, "invalid or expired session_id");
    }
    if (request->target_deg_size() != 6) {
        response->set_accepted(false);
        response->set_reason("target_deg must have exactly 6 entries (J1..J6)");
        return grpc::Status::OK;
    }

    // Uses the FollowJointTrajectory ACTION interface (not a raw topic
    // publish to /arm_controller/joint_trajectory) specifically because
    // the action gives a genuine accepted/rejected signal from
    // arm_controller -- a topic publish always "succeeds" in the sense
    // of being sent regardless of whether the controller actually acts
    // on it, which would make MoveJointResponse.accepted a lie rather
    // than a real answer. See header comment.
    using FollowJointTrajectory = control_msgs::action::FollowJointTrajectory;
    auto action_client = rclcpp_action::create_client<FollowJointTrajectory>(node_, "/arm_controller/follow_joint_trajectory");

    if (!action_client->wait_for_action_server(std::chrono::seconds(2))) {
        response->set_accepted(false);
        response->set_reason("arm_controller action server unavailable");
        return grpc::Status::OK;
    }

    trajectory_msgs::msg::JointTrajectory traj;
    traj.joint_names = {"joint1", "joint2", "joint3", "joint4", "joint5", "joint6"};
    trajectory_msgs::msg::JointTrajectoryPoint point;
    for (int i = 0; i < request->target_deg_size(); ++i) {
        point.positions.push_back(degToRad(request->target_deg(i)));
    }
    // Placeholder duration -- NOT derived from the S-curve profile's real
    // timing (which lives in the core stack's TrajectoryProfile, not
    // exposed to this node) -- see README.md's "What this doesn't do
    // yet". A fixed 2-second nominal move time is a safe, slow default,
    // not a tuned value.
    point.time_from_start.sec = 2;
    traj.points.push_back(point);

    FollowJointTrajectory::Goal goal;
    goal.trajectory = traj;

    auto goal_future = action_client->async_send_goal(goal);
    if (goal_future.wait_for(std::chrono::seconds(2)) != std::future_status::ready) {
        response->set_accepted(false);
        response->set_reason("timed out waiting for arm_controller to accept/reject the goal");
        return grpc::Status::OK;
    }
    auto goal_handle = goal_future.get();
    if (!goal_handle) {
        response->set_accepted(false);
        response->set_reason("arm_controller rejected the trajectory goal");
        return grpc::Status::OK;
    }
    response->set_accepted(true);
    return grpc::Status::OK;
}

grpc::Status RobotGatewayService::RunCalibration(grpc::ServerContext* /*context*/,
                                                     const robot_gateway::v1::RunCalibrationRequest* request,
                                                     robot_gateway::v1::RunCalibrationResponse* response) {
    if (!isValidSession(request->session_id())) {
        return grpc::Status(grpc::StatusCode::UNAUTHENTICATED, "invalid or expired session_id");
    }
    // Honest "not built yet" response rather than a fabricated success --
    // no calibration service exists anywhere in ros2_ws to call into
    // (checked before writing this; see README.md).
    response->set_accepted(false);
    response->set_status_message(
        "Calibration is not yet implemented in ros2_ws -- there is no calibration service for this "
        "RPC to call into. See robot_gateway/README.md.");
    return grpc::Status::OK;
}

grpc::Status RobotGatewayService::GetDiagnostics(grpc::ServerContext* /*context*/,
                                                    const robot_gateway::v1::GetDiagnosticsRequest* request,
                                                    robot_gateway::v1::GetDiagnosticsResponse* response) {
    if (!isValidSession(request->session_id())) {
        return grpc::Status(grpc::StatusCode::UNAUTHENTICATED, "invalid or expired session_id");
    }
    std::lock_guard<std::mutex> lock(state_mutex_);
    for (const auto& status : latest_diagnostics_.status) {
        auto* snap = response->add_diagnostics();
        snap->set_component(status.name);
        // diagnostic_msgs/DiagnosticStatus uses byte level constants
        // (OK=0, WARN=1, ERROR=2, STALE=3) -- translated to the proto's
        // string enum-ish field for a native Mac app's convenience.
        switch (status.level) {
            case diagnostic_msgs::msg::DiagnosticStatus::OK: snap->set_level("OK"); break;
            case diagnostic_msgs::msg::DiagnosticStatus::WARN: snap->set_level("WARN"); break;
            case diagnostic_msgs::msg::DiagnosticStatus::ERROR: snap->set_level("ERROR"); break;
            default: snap->set_level("STALE"); break;
        }
        snap->set_message(status.message);
    }
    return grpc::Status::OK;
}

}  // namespace robot_gateway
