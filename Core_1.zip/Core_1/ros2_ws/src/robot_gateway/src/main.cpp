// main.cpp
//
// Entry point: brings up the ROS2 node (spinning on a background thread)
// and the gRPC server (blocking on the main thread) -- see
// robot_gateway_node.hpp's "Threading model" comment for why this
// two-thread shape exists.
#include <iostream>
#include <thread>

#include "grpcpp/grpcpp.h"
#include "rclcpp/rclcpp.hpp"
#include "robot_gateway/robot_gateway_node.hpp"

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<rclcpp::Node>("robot_gateway_node");

    std::unique_ptr<robot_gateway::RobotGatewayService> service;
    try {
        service = std::make_unique<robot_gateway::RobotGatewayService>(node);
    } catch (const std::runtime_error& e) {
        // ROBOT_GATEWAY_AUTH_TOKEN missing -- see the constructor's
        // fail-closed check. Exit cleanly rather than starting unsecured.
        std::cerr << "[robot_gateway] " << e.what() << std::endl;
        rclcpp::shutdown();
        return 1;
    }

    // ROS2 executor on a background thread -- this is what actually
    // drives the subscription callbacks (telemetry/safety/diagnostics)
    // and the service-client response callbacks (trigger_estop/
    // reset_estop) that RobotGatewayService's RPC handlers block on via
    // promise/future, from whichever gRPC worker thread is handling that
    // particular call.
    rclcpp::executors::SingleThreadedExecutor executor;
    executor.add_node(node);
    std::thread ros_spin_thread([&executor]() { executor.spin(); });

    const std::string server_address = "0.0.0.0:50051";
    grpc::ServerBuilder builder;
    builder.AddListeningPort(server_address, grpc::InsecureServerCredentials());
    // NOTE: InsecureServerCredentials -- see README.md's "What this
    // doesn't do yet". This should be grpc::SslServerCredentials with a
    // real certificate before this is ever exposed beyond a trusted,
    // already-network-isolated Mac<->VM link (per
    // documentation/mac-ubuntu-bridge-architecture.md's Shared-networking
    // default, this link is not exposed to the wider LAN in the default
    // configuration -- but that's a property of the network mode, not of
    // this server, and shouldn't be relied on as the only protection).
    builder.RegisterService(service.get());

    std::unique_ptr<grpc::Server> server(builder.BuildAndStart());
    std::cout << "[robot_gateway] Listening on " << server_address << std::endl;

    server->Wait();  // blocks here for the process lifetime

    rclcpp::shutdown();
    ros_spin_thread.join();
    return 0;
}
