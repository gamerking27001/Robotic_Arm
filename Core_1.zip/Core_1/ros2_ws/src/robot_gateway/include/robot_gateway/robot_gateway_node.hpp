// robot_gateway_node.hpp
//
// Implements documentation/bridge_proto/robot_control.proto's
// RobotControlService (RPC contract) as a ROS2 node — the operator-facing
// half of the Mac↔Ubuntu bridge described in
// documentation/mac-ubuntu-bridge-architecture.md §5. This node's job is
// deliberately narrow: translate the curated gRPC surface into calls
// against the ROS2 interfaces that already exist and already carry real
// safety authority (estop_controller's services, arm_controller's
// trajectory topic) — it does NOT talk to robot_hardware_interface
// directly, and it does NOT re-implement or duplicate any safety logic.
// See the bridge architecture doc's "Safety boundary" section for why
// that constraint matters.
//
// Threading model: rclcpp needs its own executor thread (spinning
// subscriptions/service-client callbacks); grpc::Server's sync API blocks
// the calling thread per RPC (handled by gRPC's own internal thread
// pool). main.cpp runs the ROS2 executor on a background std::thread and
// grpc::Server::Wait() on the main thread — a standard, simple pattern
// for embedding a ROS2 node inside a process that also needs to block on
// something else, not something novel invented for this file.
//
// CONFIDENCE LEVEL: see README.md. Written carefully against documented
// rclcpp/grpc++ conventions, NOT compiled (no grpc++/protobuf headers or
// a working colcon+ROS2 install were available in the environment this
// was written in — the same constraint as the rest of ros2_ws, now
// compounded by gRPC's own toolchain also being unavailable).
#pragma once

#include <atomic>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_set>

#include "diagnostic_msgs/msg/diagnostic_array.hpp"
#include "rclcpp/rclcpp.hpp"
#include "robot_control.grpc.pb.h"  // generated from documentation/bridge_proto/robot_control.proto (see CMakeLists.txt)
#include "robot_msgs/msg/arm_telemetry.hpp"
#include "robot_msgs/msg/safety_status.hpp"
#include "robot_msgs/srv/reset_estop.hpp"
#include "robot_msgs/srv/trigger_estop.hpp"
#include "trajectory_msgs/msg/joint_trajectory.hpp"

namespace robot_gateway {

// Implements the generated RobotControlService::Service interface (sync
// gRPC API — each RPC below is called on a gRPC-managed worker thread,
// concurrently with others; internal state is protected accordingly).
class RobotGatewayService final : public robot_gateway::v1::RobotControlService::Service {
public:
    explicit RobotGatewayService(rclcpp::Node::SharedPtr node);

    // --- RobotControlService RPCs -----------------------------------
    grpc::Status DiscoverRobots(grpc::ServerContext* context, const robot_gateway::v1::DiscoverRobotsRequest* request,
                                 robot_gateway::v1::DiscoverRobotsResponse* response) override;

    grpc::Status Connect(grpc::ServerContext* context, const robot_gateway::v1::ConnectRequest* request,
                          robot_gateway::v1::ConnectResponse* response) override;

    // Server-streaming: blocks on this thread for the life of the stream,
    // pushing a TelemetrySnapshot each time fresh data is available (see
    // .cpp for how ROS2 subscription callbacks hand data to this thread).
    grpc::Status StreamTelemetry(grpc::ServerContext* context,
                                  const robot_gateway::v1::StreamTelemetryRequest* request,
                                  grpc::ServerWriter<robot_gateway::v1::TelemetrySnapshot>* writer) override;

    grpc::Status TriggerEstop(grpc::ServerContext* context, const robot_gateway::v1::TriggerEstopRequest* request,
                               robot_gateway::v1::TriggerEstopResponse* response) override;

    grpc::Status ResetEstop(grpc::ServerContext* context, const robot_gateway::v1::ResetEstopRequest* request,
                             robot_gateway::v1::ResetEstopResponse* response) override;

    grpc::Status MoveJoint(grpc::ServerContext* context, const robot_gateway::v1::MoveJointRequest* request,
                            robot_gateway::v1::MoveJointResponse* response) override;

    grpc::Status RunCalibration(grpc::ServerContext* context, const robot_gateway::v1::RunCalibrationRequest* request,
                                 robot_gateway::v1::RunCalibrationResponse* response) override;

    grpc::Status GetDiagnostics(grpc::ServerContext* context, const robot_gateway::v1::GetDiagnosticsRequest* request,
                                 robot_gateway::v1::GetDiagnosticsResponse* response) override;

private:
    // Session/auth: deliberately simple for v1 -- one shared operator
    // token (env var ROBOT_GATEWAY_AUTH_TOKEN, same fail-closed pattern
    // as dashboard/backend/main.py's DASHBOARD_*_API_KEY -- refuses to
    // start if unset, see main.cpp), one session_id issued per successful
    // Connect() call, tracked in a set so a restart invalidates all prior
    // sessions. This is NOT per-operator identity or RBAC -- a real
    // multi-operator deployment needs more than this; see README.md's
    // "What this doesn't do yet".
    bool isValidSession(const std::string& session_id);

    rclcpp::Node::SharedPtr node_;

    rclcpp::Subscription<robot_msgs::msg::ArmTelemetry>::SharedPtr telemetry_sub_;
    rclcpp::Subscription<robot_msgs::msg::SafetyStatus>::SharedPtr safety_sub_;
    rclcpp::Subscription<diagnostic_msgs::msg::DiagnosticArray>::SharedPtr diagnostics_sub_;
    rclcpp::Client<robot_msgs::srv::TriggerEstop>::SharedPtr trigger_estop_client_;
    rclcpp::Client<robot_msgs::srv::ResetEstop>::SharedPtr reset_estop_client_;
    rclcpp::Publisher<trajectory_msgs::msg::JointTrajectory>::SharedPtr move_pub_;

    // Latest-value cache, written by subscription callbacks (ROS2
    // executor thread), read by StreamTelemetry/GetDiagnostics (gRPC
    // worker threads) -- protected by state_mutex_ throughout.
    std::mutex state_mutex_;
    robot_msgs::msg::ArmTelemetry latest_telemetry_;
    robot_msgs::msg::SafetyStatus latest_safety_;
    diagnostic_msgs::msg::DiagnosticArray latest_diagnostics_;
    bool have_telemetry_ = false;
    bool have_safety_ = false;

    std::mutex session_mutex_;
    std::unordered_set<std::string> active_sessions_;
    std::string auth_token_;
};

}  // namespace robot_gateway
