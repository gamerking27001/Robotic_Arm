"""move_group.launch.py — §12.1/§12.2's MoveIt 2 planning node.

Loads the generated URDF (robot_description), the SRDF/kinematics/joint-limits/
controller-bridge config in this package, and starts move_group. Assumes
robot_hardware_interface's ros2_control_node + arm_controller are already
running (see robot_bringup/launch/robot_bringup.launch.py) — this launch file
only starts planning, not the hardware bridge.
"""
import os
import yaml
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node


def load_yaml(package_name, file_path):
    path = os.path.join(get_package_share_directory(package_name), file_path)
    with open(path, "r") as f:
        return yaml.safe_load(f)


def generate_launch_description():
    description_share = get_package_share_directory("robot_description")
    moveit_share = get_package_share_directory("robot_moveit_config")

    with open(os.path.join(description_share, "urdf", "generated_arm.urdf"), "r") as f:
        robot_description = {"robot_description": f.read()}

    with open(os.path.join(moveit_share, "config", "modular_arm_msme.srdf"), "r") as f:
        robot_description_semantic = {"robot_description_semantic": f.read()}

    kinematics_yaml = load_yaml("robot_moveit_config", "config/kinematics.yaml")
    joint_limits_yaml = load_yaml("robot_moveit_config", "config/joint_limits.yaml")
    controllers_yaml = load_yaml("robot_moveit_config", "config/moveit_controllers.yaml")

    ompl_planning = {
        "planning_pipelines": ["ompl"],
        "default_planning_pipeline": "ompl",
        "ompl": {
            "planning_plugins": ["ompl_interface/OMPLPlanner"],
            "request_adapters": [
                "default_planning_request_adapters/ResolveConstraintFrames",
                "default_planning_request_adapters/ValidateWorkspaceBounds",
                "default_planning_request_adapters/CheckStartStateBounds",
                "default_planning_request_adapters/CheckStartStateCollision",
            ],
            "response_adapters": [
                "default_planning_response_adapters/AddTimeOptimalParameterization",
            ],
        },
    }

    move_group_node = Node(
        package="moveit_ros_move_group",
        executable="move_group",
        output="screen",
        parameters=[
            robot_description,
            robot_description_semantic,
            kinematics_yaml,
            {"robot_description_planning": joint_limits_yaml},
            controllers_yaml,
            ompl_planning,
            {"publish_robot_description_semantic": True},
        ],
    )

    return LaunchDescription([move_group_node])
