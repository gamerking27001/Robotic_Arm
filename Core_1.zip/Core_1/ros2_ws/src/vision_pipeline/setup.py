from setuptools import find_packages, setup

package_name = 'vision_pipeline'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/vision_pipeline.launch.py']),
        ('share/' + package_name + '/config', ['config/vision_params.yaml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Robotic Arm Engineering',
    maintainer_email='engineering@example.com',
    description=(
        "Section 20.2/12.3 vision_node — wraps the standalone, "
        "independently-tested ../../../vision modules as a ROS2 node."
    ),
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'vision_node = vision_pipeline.vision_node:main',
        ],
    },
)
