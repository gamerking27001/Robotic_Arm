"""vision_pipeline.launch.py — starts vision_node with the params in
config/vision_params.yaml (§15.1's capability toggles)."""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    share = get_package_share_directory("vision_pipeline")
    params_file = os.path.join(share, "config", "vision_params.yaml")

    return LaunchDescription([
        Node(
            package="vision_pipeline",
            executable="vision_node",
            name="vision_node",
            output="screen",
            parameters=[params_file],
            remappings=[
                # Point at a wrist-mounted or overhead camera per §15.1;
                # default assumes a driver publishing on /camera/image_raw.
                ("image_raw", "/camera/image_raw"),
            ],
        ),
    ])
