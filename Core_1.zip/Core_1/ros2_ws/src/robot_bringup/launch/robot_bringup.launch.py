"""robot_bringup.launch.py

Extends §20.6's representative launch file with real Node() entries:
robot_state_publisher, ros2_control_node (loading robot_hardware_interface's
plugin via the URDF's <ros2_control> tag), joint_state_broadcaster,
arm_controller, estop_controller, safety_monitor_node, diagnostics_node.
move_group is deliberately launched separately
(robot_moveit_config/launch/move_group.launch.py) since planning is often
brought up/down independently of the hardware bridge.

Safety-authority fix: estop_controller (not safety_monitor_node) is what
now gives operator E-stop requests real authority over motion — see
estop_controller/README.md and robot_hardware_interface's header comments.
"""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    description_share = get_package_share_directory("robot_description")
    bringup_share = get_package_share_directory("robot_bringup")

    urdf_path = os.path.join(description_share, "urdf", "generated_arm.urdf")
    with open(urdf_path, "r") as f:
        robot_description_content = f.read()

    controllers_yaml = os.path.join(bringup_share, "config", "controllers.yaml")

    robot_state_publisher_node = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        name="robot_state_publisher",
        output="screen",
        parameters=[{"robot_description": robot_description_content}],
    )

    # §9.2/§20.1: the "MainController" role — here, ros2_control_node loads
    # robot_hardware_interface's RobotSystemInterface plugin (declared in the
    # URDF's <ros2_control> tag) as the CAN bridge to the core stack's
    # simulated joints.
    controller_manager_node = Node(
        package="controller_manager",
        executable="ros2_control_node",
        parameters=[{"robot_description": robot_description_content}, controllers_yaml],
        output="screen",
    )

    joint_state_broadcaster_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["joint_state_broadcaster"],
    )

    arm_controller_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["arm_controller"],
    )

    # Safety-authority fix: this controller is what gives operator
    # trigger_estop/reset_estop calls real authority over motion — see
    # estop_controller/README.md. Spawned alongside arm_controller since
    # both are ordinary ros2_control controllers loaded by the same
    # controller_manager instance above.
    estop_controller_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["estop_controller"],
    )

    diagnostics_node = Node(
        package="diagnostics",
        executable="diagnostics_node",
        name="diagnostics_node",
        output="screen",
    )

    # Passive status logger only as of the safety-authority fix — see
    # safety_monitor/src/safety_monitor_node.cpp's header comment.
    # trigger_estop/reset_estop now live on estop_controller (above).
    safety_monitor_node = Node(
        package="safety_monitor",
        executable="safety_monitor_node",
        name="safety_monitor_node",
        output="screen",
    )

    return LaunchDescription([
        robot_state_publisher_node,
        controller_manager_node,
        joint_state_broadcaster_spawner,
        arm_controller_spawner,
        estop_controller_spawner,
        diagnostics_node,
        safety_monitor_node,
        # move_group is launched separately:
        #   ros2 launch robot_moveit_config move_group.launch.py
    ])
