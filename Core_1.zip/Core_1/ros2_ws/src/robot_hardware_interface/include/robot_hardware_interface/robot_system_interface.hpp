// robot_hardware_interface/robot_system_interface.hpp
// §20.2: "robot_hardware_interface/ ros2_control hardware interface (CAN
// bridge)". This class IS the CAN bridge — it directly owns
// arm::hal::SimulatedCanBus + six arm::hal::SimulatedJointDriver instances
// (the same core-stack classes exercised by ../../../src/main.cpp) and
// exposes them through the standard ros2_control SystemInterface lifecycle
// (on_init/export_*_interfaces/on_activate/on_deactivate/read/write).
//
// Swapping the simulated joints for a real CAN transport means replacing
// `arm::hal::SimulatedJointDriver` with a real CAN-based implementation of
// `arm::hal::JointInterface` — this class's ros2_control-facing code does
// not change, since it only talks to the `JointInterface` abstraction.
//
// SAFETY ARCHITECTURE (fixed — see ros2_ws/README.md "Safety authority fix"):
// This class now owns the AUTHORITATIVE arm::safety::SafetyFsm and evaluates
// it once per control cycle, directly from real joint telemetry, inside
// read() — the same in-process pattern already verified end-to-end by
// arm_demo (../../../src/main.cpp) and dashboard/backend. write() gates every
// joint command on the resulting FSM state: commands are only forwarded to
// the joints when the FSM is in a state that permits motion. This closes a
// real bug found in this file's previous version: safety_monitor_node used
// to run its OWN, completely separate SafetyFsm instance with no path back
// to this class, so triggering E-stop updated a status topic but never
// actually stopped the robot. See estop_controller/ for how an operator's
// software E-stop request now reaches this loop (via a command interface,
// the standard realtime-safe ros2_control mechanism for exactly this).
//
// NOTE: written against the ros2_control (Humble/Jazzy) SystemInterface API
// from documented conventions; not compiled against a real ros2_control
// install in this environment — see ros2_ws/README.md. The safety-evaluation
// logic reused here (arm::safety::SafetyFsm) is the same class exercised by
// the verified arm_demo and dashboard/backend, so only the ros2_control
// plumbing around it (export_*_interfaces additions, read/write gating) is
// new/unverified — not the safety logic itself.
#pragma once

#include <array>
#include <memory>
#include <vector>

#include "core/robot_config.hpp"
#include "hal/can_bus_simulated.hpp"
#include "hal/simulated_joint_driver.hpp"
#include "hardware_interface/handle.hpp"
#include "hardware_interface/hardware_info.hpp"
#include "hardware_interface/system_interface.hpp"
#include "hardware_interface/types/hardware_interface_return_values.hpp"
#include "rclcpp/macros.hpp"
#include "rclcpp_lifecycle/state.hpp"
#include "safety/safety_fsm.hpp"

namespace robot_hardware_interface {

class RobotSystemInterface : public hardware_interface::SystemInterface {
public:
    RCLCPP_SHARED_PTR_DEFINITIONS(RobotSystemInterface)

    hardware_interface::CallbackReturn on_init(const hardware_interface::HardwareInfo& info) override;

    std::vector<hardware_interface::StateInterface> export_state_interfaces() override;
    std::vector<hardware_interface::CommandInterface> export_command_interfaces() override;

    hardware_interface::CallbackReturn on_activate(const rclcpp_lifecycle::State& previous_state) override;
    hardware_interface::CallbackReturn on_deactivate(const rclcpp_lifecycle::State& previous_state) override;

    hardware_interface::return_type read(const rclcpp::Time& time, const rclcpp::Duration& period) override;
    hardware_interface::return_type write(const rclcpp::Time& time, const rclcpp::Duration& period) override;

private:
    static constexpr std::size_t kNumJoints = arm::config::kNumJoints;

    arm::hal::SimulatedCanBus can_bus_;
    std::vector<std::unique_ptr<arm::hal::SimulatedJointDriver>> joints_;
    std::vector<std::string> joint_names_;  // populated from HardwareInfo (§20.6's ros2_control URDF tag)

    // ros2_control state/command buffers — export_*_interfaces() hands out
    // pointers into these, and read()/write() keep them in sync with the
    // underlying arm::hal::JointInterface.
    std::array<double, kNumJoints> hw_position_states_{};
    std::array<double, kNumJoints> hw_velocity_states_{};
    std::array<double, kNumJoints> hw_effort_states_{};
    std::array<double, kNumJoints> hw_position_commands_{};

    // --- Safety (see class-level comment above) --------------------------
    // The authoritative FSM. Evaluated once per read() from real telemetry;
    // write() refuses to forward commands unless it's in a move-permitting
    // state. This is the SAME class arm_demo already exercises — see
    // include/safety/safety_fsm.hpp.
    arm::safety::SafetyFsm safety_fsm_;

    // Non-joint ("GPIO-style") state interfaces reporting the authoritative
    // FSM state and per-check fault flags — double-encoded (0.0/1.0 for
    // booleans), per standard ros2_control GPIO interface convention (no
    // native bool/enum state interface type exists). estop_controller reads
    // these to rebuild a full robot_msgs/SafetyStatus for the rest of
    // ROS2 — the same fields safety_monitor_node used to compute itself
    // from its own (now-removed) disconnected SafetyFsm copy.
    double safety_state_ordinal_ = 0.0;  // static_cast<double>(arm::safety::RobotState)
    double safety_any_fault_ = 0.0;
    double safety_estop_pressed_ = 0.0;
    double safety_sto_required_ = 0.0;
    double safety_collision_suspected_ = 0.0;
    double safety_overcurrent_ = 0.0;
    double safety_overtemperature_ = 0.0;
    double safety_soft_limit_violation_ = 0.0;
    double safety_hard_limit_violation_ = 0.0;

    // Non-joint command interfaces — the realtime-safe channel an operator's
    // software E-stop request/reset arrives through, written each cycle by
    // estop_controller (see ../../estop_controller). 0.0 = no request,
    // 1.0 = request active; write() edge-triggers off these each cycle.
    double estop_request_cmd_ = 0.0;
    double estop_reset_request_cmd_ = 0.0;
    bool last_estop_request_ = false;
    bool last_estop_reset_request_ = false;

    // Hardware E-stop line (physical button, wired to a real safety board in
    // a real deployment). No physical line exists in this simulated build,
    // so this stays false — kept as a named field so a real CAN-based safety
    // board driver has an obvious place to wire into
    // (see firmware/safety_board/ for the corresponding firmware side).
    bool hardware_estop_line_active_ = false;

    // Runs safety_fsm_.evaluate() against every joint's current telemetry
    // and this cycle's estop command-interface values; called from read().
    void evaluateSafety();
};

}  // namespace robot_hardware_interface
