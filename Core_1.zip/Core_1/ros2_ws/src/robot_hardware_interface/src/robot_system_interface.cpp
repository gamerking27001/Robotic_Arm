#include "robot_hardware_interface/robot_system_interface.hpp"

#include "hardware_interface/types/hardware_interface_type_values.hpp"
#include "pluginlib/class_list_macros.hpp"
#include "rclcpp/logging.hpp"

namespace robot_hardware_interface {

namespace {
rclcpp::Logger logger() { return rclcpp::get_logger("robot_hardware_interface"); }
}  // namespace

hardware_interface::CallbackReturn RobotSystemInterface::on_init(const hardware_interface::HardwareInfo& info) {
    if (hardware_interface::SystemInterface::on_init(info) != hardware_interface::CallbackReturn::SUCCESS) {
        return hardware_interface::CallbackReturn::ERROR;
    }

    if (info_.joints.size() != kNumJoints) {
        RCLCPP_ERROR(logger(), "Expected %zu joints in the URDF ros2_control tag, got %zu", kNumJoints,
                     info_.joints.size());
        return hardware_interface::CallbackReturn::ERROR;
    }

    joint_names_.clear();
    for (const auto& joint : info_.joints) joint_names_.push_back(joint.name);

    // Directly instantiate the core stack's simulated CAN joints — this IS
    // the "CAN bridge" referenced in §20.2. A real deployment swaps this
    // block for a real-CAN-transport implementation of arm::hal::JointInterface.
    for (std::size_t i = 0; i < kNumJoints; ++i) {
        joints_.push_back(
            std::make_unique<arm::hal::SimulatedJointDriver>(static_cast<arm::config::JointId>(i), can_bus_));
    }

    hw_position_states_.fill(0.0);
    hw_velocity_states_.fill(0.0);
    hw_effort_states_.fill(0.0);
    hw_position_commands_.fill(0.0);

    return hardware_interface::CallbackReturn::SUCCESS;
}

std::vector<hardware_interface::StateInterface> RobotSystemInterface::export_state_interfaces() {
    std::vector<hardware_interface::StateInterface> state_interfaces;
    for (std::size_t i = 0; i < kNumJoints; ++i) {
        state_interfaces.emplace_back(joint_names_[i], hardware_interface::HW_IF_POSITION, &hw_position_states_[i]);
        state_interfaces.emplace_back(joint_names_[i], hardware_interface::HW_IF_VELOCITY, &hw_velocity_states_[i]);
        state_interfaces.emplace_back(joint_names_[i], hardware_interface::HW_IF_EFFORT, &hw_effort_states_[i]);
    }
    // Non-joint ("GPIO-style") state interfaces reporting the authoritative
    // safety state — see the class-level "SAFETY ARCHITECTURE" comment.
    // Same 3-arg StateInterface constructor as the joint ones above, just
    // with a non-joint interface_name in place of a joint name — this is
    // the standard ros2_control pattern for GPIO/non-actuator state
    // (e.g. force-torque sensors, digital I/O).
    state_interfaces.emplace_back("safety", "state_ordinal", &safety_state_ordinal_);
    state_interfaces.emplace_back("safety", "any_fault", &safety_any_fault_);
    state_interfaces.emplace_back("safety", "estop_pressed", &safety_estop_pressed_);
    state_interfaces.emplace_back("safety", "sto_required", &safety_sto_required_);
    state_interfaces.emplace_back("safety", "collision_suspected", &safety_collision_suspected_);
    state_interfaces.emplace_back("safety", "overcurrent", &safety_overcurrent_);
    state_interfaces.emplace_back("safety", "overtemperature", &safety_overtemperature_);
    state_interfaces.emplace_back("safety", "soft_limit_violation", &safety_soft_limit_violation_);
    state_interfaces.emplace_back("safety", "hard_limit_violation", &safety_hard_limit_violation_);
    return state_interfaces;
}

std::vector<hardware_interface::CommandInterface> RobotSystemInterface::export_command_interfaces() {
    std::vector<hardware_interface::CommandInterface> command_interfaces;
    for (std::size_t i = 0; i < kNumJoints; ++i) {
        command_interfaces.emplace_back(joint_names_[i], hardware_interface::HW_IF_POSITION,
                                         &hw_position_commands_[i]);
    }
    // Realtime-safe channel for estop_controller to request/clear a software
    // E-stop — see the class-level comment and estop_controller/README.md.
    command_interfaces.emplace_back("safety", "estop_request", &estop_request_cmd_);
    command_interfaces.emplace_back("safety", "estop_reset_request", &estop_reset_request_cmd_);
    return command_interfaces;
}

hardware_interface::CallbackReturn RobotSystemInterface::on_activate(
    const rclcpp_lifecycle::State& /*previous_state*/) {
    // Seed command buffers with current state so the first write() doesn't
    // command a step change from wherever the (simulated) joints happen to
    // be — standard ros2_control activation practice.
    for (std::size_t i = 0; i < kNumJoints; ++i) {
        hw_position_commands_[i] = hw_position_states_[i];
    }

    // Safety FSM boot sequence — same sequence as arm_demo and
    // dashboard/backend's robot_bridge_create() (§13.5's automatic startup:
    // PowerOn -> Homing -> Idle). Unlike those two, this hardware interface
    // has no separate "task start" signal from ros2_control (controllers
    // command motion continuously once activated, with no explicit
    // begin-move event at this layer) — so kTaskStart -> Running follows
    // immediately, making Running the steady operating state for as long as
    // this interface is active. write() (below) is what actually gates
    // motion from here on, based on safety_fsm_.state().
    safety_fsm_.handle(arm::safety::Event::kBootComplete);
    safety_fsm_.handle(arm::safety::Event::kHomingComplete);
    safety_fsm_.handle(arm::safety::Event::kTaskStart);
    safety_state_ordinal_ = static_cast<double>(safety_fsm_.state());
    safety_any_fault_ = 0.0;
    estop_request_cmd_ = 0.0;
    estop_reset_request_cmd_ = 0.0;
    last_estop_request_ = false;
    last_estop_reset_request_ = false;

    RCLCPP_INFO(logger(), "RobotSystemInterface activated (%zu joints), safety FSM: %s", kNumJoints,
                arm::safety::toString(safety_fsm_.state()).data());
    return hardware_interface::CallbackReturn::SUCCESS;
}

hardware_interface::CallbackReturn RobotSystemInterface::on_deactivate(
    const rclcpp_lifecycle::State& /*previous_state*/) {
    RCLCPP_INFO(logger(), "RobotSystemInterface deactivated");
    return hardware_interface::CallbackReturn::SUCCESS;
}

void RobotSystemInterface::evaluateSafety() {
    // Software E-stop request/reset, edge-triggered off the command
    // interfaces estop_controller writes each cycle (see the class-level
    // "SAFETY ARCHITECTURE" comment and estop_controller/README.md). Mirrors
    // dashboard/backend's robot_bridge_trigger_estop()/robot_bridge_reset_estop()
    // exactly, including the STO trigger/clear on every joint — that
    // function is real, tested code; this reuses its logic, not just its
    // shape.
    const bool estop_request_now = estop_request_cmd_ > 0.5;
    const bool estop_reset_now = estop_reset_request_cmd_ > 0.5;

    if (estop_request_now && !last_estop_request_) {
        RCLCPP_WARN(logger(), "Software E-stop requested via estop_controller");
        if (safety_fsm_.handle(arm::safety::Event::kEstopTriggered)) {
            for (auto& j : joints_) j->triggerSafeTorqueOff();  // §9.5: STO on every joint, not just the FSM label
        }
    }
    if (estop_reset_now && !last_estop_reset_request_) {
        RCLCPP_INFO(logger(), "E-stop reset requested via estop_controller");
        if (safety_fsm_.handle(arm::safety::Event::kEstopReset)) {
            for (auto& j : joints_) j->clearSafeTorqueOff();
            // Re-run the boot sequence back to Running — see on_activate()'s
            // comment on why Running (not Idle) is this layer's steady state.
            safety_fsm_.handle(arm::safety::Event::kBootComplete);
            safety_fsm_.handle(arm::safety::Event::kHomingComplete);
            safety_fsm_.handle(arm::safety::Event::kTaskStart);
        }
    }
    last_estop_request_ = estop_request_now;
    last_estop_reset_request_ = estop_reset_now;

    // Per-joint safety evaluation against real telemetry — the same
    // arm::safety::SafetyFsm::evaluate() call arm_demo and
    // dashboard/backend's robot_bridge_tick() already exercise, run here in
    // the actual real-time control loop instead of a disconnected copy.
    // commanded_torque_nm=0.0 matches both of those reference call sites
    // (this platform is position-controlled; a torque-controlled variant
    // would pass a real setpoint here instead).
    arm::safety::SafetyCheckResult aggregate{};
    for (std::size_t i = 0; i < kNumJoints; ++i) {
        const arm::hal::JointTelemetry t = joints_[i]->readTelemetry();
        const auto check = safety_fsm_.evaluate(t, arm::config::kJointSpecs[i], /*commanded_torque_nm=*/0.0,
                                                 hardware_estop_line_active_);
        aggregate.estop_pressed = aggregate.estop_pressed || check.estop_pressed;
        aggregate.sto_required = aggregate.sto_required || check.sto_required;
        aggregate.collision_suspected = aggregate.collision_suspected || check.collision_suspected;
        aggregate.overcurrent = aggregate.overcurrent || check.overcurrent;
        aggregate.overtemperature = aggregate.overtemperature || check.overtemperature;
        aggregate.soft_limit_violation = aggregate.soft_limit_violation || check.soft_limit_violation;
        aggregate.hard_limit_violation = aggregate.hard_limit_violation || check.hard_limit_violation;
    }
    safety_state_ordinal_ = static_cast<double>(safety_fsm_.state());
    safety_any_fault_ = aggregate.anyFault() ? 1.0 : 0.0;
    safety_estop_pressed_ = aggregate.estop_pressed ? 1.0 : 0.0;
    safety_sto_required_ = aggregate.sto_required ? 1.0 : 0.0;
    safety_collision_suspected_ = aggregate.collision_suspected ? 1.0 : 0.0;
    safety_overcurrent_ = aggregate.overcurrent ? 1.0 : 0.0;
    safety_overtemperature_ = aggregate.overtemperature ? 1.0 : 0.0;
    safety_soft_limit_violation_ = aggregate.soft_limit_violation ? 1.0 : 0.0;
    safety_hard_limit_violation_ = aggregate.hard_limit_violation ? 1.0 : 0.0;
}

hardware_interface::return_type RobotSystemInterface::read(const rclcpp::Time& /*time*/,
                                                             const rclcpp::Duration& period) {
    const double dt_s = period.seconds();
    for (std::size_t i = 0; i < kNumJoints; ++i) {
        joints_[i]->step(dt_s);  // advance the simulated plant (§11.3's real-time interpolation counterpart)
        const arm::hal::JointTelemetry t = joints_[i]->readTelemetry();
        hw_position_states_[i] = t.position_rad;
        hw_velocity_states_[i] = t.velocity_rad_s;
        hw_effort_states_[i] = t.torque_estimate_nm;
    }
    // Evaluated after stepping the plant so this cycle's telemetry reflects
    // the just-advanced state — same ordering dashboard/backend's
    // robot_bridge_tick() uses (step() then evaluate()).
    evaluateSafety();
    return hardware_interface::return_type::OK;
}

hardware_interface::return_type RobotSystemInterface::write(const rclcpp::Time& /*time*/,
                                                              const rclcpp::Duration& /*period*/) {
    // THE FIX: commands are only forwarded to the joints when the safety FSM
    // is in the one state that permits motion. Every other state (Fault,
    // EStop, Paused, PowerOn, Homing) holds the joints at their last
    // setpoint instead of blindly forwarding whatever the controller
    // (e.g. joint_trajectory_controller) is currently commanding — this is
    // the piece that was completely missing before: previously this
    // function forwarded hw_position_commands_ unconditionally, so
    // safety_monitor_node's E-stop had no actual effect on motion.
    if (safety_fsm_.state() == arm::safety::RobotState::kRunning) {
        for (std::size_t i = 0; i < kNumJoints; ++i) {
            joints_[i]->setPositionSetpoint(hw_position_commands_[i]);
        }
    }
    return hardware_interface::return_type::OK;
}

}  // namespace robot_hardware_interface

PLUGINLIB_EXPORT_CLASS(robot_hardware_interface::RobotSystemInterface, hardware_interface::SystemInterface)
