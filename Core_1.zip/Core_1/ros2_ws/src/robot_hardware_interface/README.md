# robot_hardware_interface

`ros2_control` `SystemInterface` plugin — the "CAN bridge" from §20.2.
Directly instantiates and drives the core stack's
`arm::hal::SimulatedJointDriver` / `arm::hal::SimulatedCanBus`
(`../../../include`, `../../../src`) rather than reimplementing the CAN
bridge. Swapping in real hardware means replacing `SimulatedJointDriver`
with a real CAN-transport implementation of `arm::hal::JointInterface` —
this class's `ros2_control`-facing code doesn't change.

## Safety authority fix

This class now owns the **authoritative** `arm::safety::SafetyFsm`,
evaluated every control cycle directly from real joint telemetry inside
`read()`. `write()` only forwards joint commands when the FSM is in a
state that permits motion (`Running`).

This closes a real bug: previously, `safety_monitor_node` ran its own,
completely separate `SafetyFsm` with no connection to this class — so
triggering E-stop updated a status topic but never actually stopped the
robot. See `../estop_controller/README.md` for how an operator's software
E-stop request now reaches this loop (via command interfaces), and
`../README.md`'s "Safety authority fix" section for the full picture
across all the affected packages.

See `include/robot_hardware_interface/robot_system_interface.hpp`'s
class-level comment for the full technical detail of what changed and why.

## Confidence level

Unchanged from before the fix: this is the one package in `ros2_ws` with
partial *real* verification (diffed against the actual `ros-controls/ros2_control`
jazzy source — see `../README.md`). The new `safety/*` state/command
interfaces added for this fix reuse the same confirmed `StateInterface`/
`CommandInterface` constructor, just with non-joint names — low-risk,
same confidence level as the rest of this file. The safety logic itself
(`arm::safety::SafetyFsm`) is the same class already exercised by the
verified `arm_demo` and `dashboard/backend` — only the `ros2_control`
plumbing calling into it here is new/unverified, not the logic itself.
