# ros2_ws — ROS2 integration layer

Implements §12 (ROS2/MoveIt 2 software stack), §18/§20.2 (package layout),
and §20.6 (launch file structure) from the design baseline: a
`ros2_control`-based hardware interface wrapping the core C++ stack
(`../include`, `../src`) as the CAN bridge, a MoveIt 2 planning configuration,
a URDF generated from the same `configs/arm_variant_standard.yaml` used by
`arm_demo`, and safety/diagnostics nodes bridging the core stack's
`safety::SafetyFsm` and joint telemetry onto ROS2 topics.

## Safety authority fix (read this if you read nothing else here)

A review pass found a real, serious bug in this workspace's original safety
wiring: `safety_monitor_node` ran its own `arm::safety::SafetyFsm` instance,
completely disconnected from `robot_hardware_interface`, which blindly
forwarded every joint command it received regardless of E-stop state. In
that original version, **calling `trigger_estop` updated a status topic but
never actually stopped the robot** — the two nodes' FSMs had no path
between them.

This is fixed now:

- `robot_hardware_interface`'s `RobotSystemInterface` owns the one
  authoritative `SafetyFsm`, evaluated every control cycle directly from
  real joint telemetry — the same in-process pattern already verified
  end-to-end by `arm_demo` and `dashboard/backend`. `write()` now refuses
  to forward commands unless the FSM is in a state that permits motion.
- A new package, `estop_controller/`, is what lets an operator's
  `trigger_estop`/`reset_estop` service call actually reach that FSM —
  via command interfaces, the standard realtime-safe ros2_control
  mechanism for exactly this, run in the same control loop as the hardware
  interface.
- `safety_monitor_node` is demoted to what it can honestly be from outside
  the control loop: a passive status logger. It no longer owns any FSM and
  cannot trigger or reset anything — see its file header for the full
  explanation.

Client code (the dashboard, any operator tooling) doesn't need to change —
`trigger_estop`/`reset_estop` are the same `robot_msgs` service types, just
served by `estop_controller` now instead of `safety_monitor_node`. Update
your service client's target node name if you'd hardcoded
`/safety_monitor_node/trigger_estop`-style fully-qualified names anywhere.

See `robot_hardware_interface/include/robot_hardware_interface/robot_system_interface.hpp`'s
class-level comment and `estop_controller/README.md` for the full technical
detail, including this fix's own confidence level (same "careful first
draft, not yet compiled" status as the rest of this workspace — see below).

## Read this before anything else: this workspace has not been built or run

Unlike the core stack (`arm_demo`) and firmware layer (`firmware_demo`),
**this code has not been compiled or tested**, because there is no ROS2
installation available in the environment this was built in — ROS2's apt
repository (`packages.ros.org`) isn't reachable from here, and there's no
existing ROS2 workspace to build against. Every file here was written
directly against the ROS2 Jazzy/Humble `ament_cmake` / `ros2_control` /
`moveit2` APIs from documented conventions, but **treat it as a careful first
draft that needs a real `colcon build` and real hardware-in-the-loop testing
before you trust it**, not as verified working code the way the other two
layers are.

If you have a ROS2 Jazzy or Humble environment:

```bash
# from a colcon workspace root containing this ros2_ws/src content:
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash
ros2 launch robot_bringup robot_bringup.launch.py
```

Expect to need to fix build errors — this hasn't been through that loop yet.

## What's actually been checked, without a full ROS2 install

Since there's no ROS2 install here, I did a bounded, honest attempt at partial
verification instead of leaving this entirely unchecked: cloned the real
`ros-controls/ros2_control` **jazzy** branch from GitHub and diffed
`robot_hardware_interface`'s code against the actual current source, then
tried an incremental `g++ -fsyntax-only` compile against real headers,
pulling in each dependency as it surfaced.

**Confirmed present and matching, byte-for-byte, in the real jazzy source:**
`hardware_interface::CallbackReturn`, `hardware_interface::return_type::OK`,
the `HW_IF_POSITION`/`HW_IF_VELOCITY`/`HW_IF_EFFORT` constants,
`export_state_interfaces()`/`export_command_interfaces()`/`read()` as
overridable virtuals (the first two are deprecated in favor of newer
`on_export_*` methods but still work — ros2_control's own back-compat path),
the `StateInterface`/`CommandInterface` 3-argument constructor via
`using Handle::Handle;`, and `HardwareInfo.joints[i].name` / the protected
`info_` member. So `robot_hardware_interface/src/robot_system_interface.cpp`
is checked against real current API, not just against my training-time
knowledge of it.

**Where verification hit a hard wall:** chasing the real `#include` chain
(`hardware_interface` → `joint_limits` → `libstatistics_collector` →
`rcpputils`/`rcutils`/`rcl`/`rmw`/`rosidl` → `realtime_tools` →
`pal_statistics`) eventually reached
`pal_statistics_msgs/msg/statistics.hpp` — a header that only exists after
ROS2's `rosidl` code generator runs against a `.msg` file during a real
`colcon build`. No amount of cloning source repos produces a *generated*
header; that step needs the actual build toolchain. This is exactly why
`safety_monitor_node.cpp` and `diagnostics_node.cpp` (which use
`robot_msgs`/`std_msgs`/`sensor_msgs`/`diagnostic_msgs` directly) couldn't be
checked the same way — every one of those needs the same codegen step.

**Net effect:** `robot_hardware_interface` carries real (if partial)
verification; everything else here is still an unverified first draft.

**On the safety-authority fix specifically:** the additions to
`robot_hardware_interface` (the new `safety/*` state and command
interfaces) reuse the exact same `StateInterface`/`CommandInterface` 3-arg
constructor confirmed above, just with a non-joint name in the first
position — a low-risk extension of already-checked API, not new surface.
`estop_controller`'s `controller_interface`/`realtime_tools` API usage,
however, was **not** part of this verification pass (it didn't exist yet
when the jazzy source was cloned and diffed) — treat it at the same
"careful first draft" confidence as the rest of this workspace. See
`estop_controller/README.md` for the specific spots most likely to need a
correction on first build.

## Package layout (§20.2)

| Package | Contents | Wraps / depends on |
|---|---|---|
| `robot_description` | URDF/Xacro model, RViz launch | `configs/arm_variant_standard.yaml` (DH params, joint limits) |
| `robot_msgs` | Custom messages (`JointTelemetry.msg`, `SafetyStatus.msg`, vision detection messages) | — |
| `robot_hardware_interface` | `ros2_control` `SystemInterface` plugin — the "CAN bridge" from §20.2, and (as of the safety authority fix above) the sole authority over the safety FSM and whether joint commands are actually forwarded | `arm::hal::JointInterface`, `arm::hal::SimulatedCanBus`, `arm::safety::SafetyFsm` (the **core stack**, `../include`) |
| `estop_controller` | **New.** `ros2_control` controller plugin bridging operator E-stop trigger/reset service calls into `robot_hardware_interface`'s realtime loop; republishes `safety_status` | `robot_hardware_interface`'s exported `safety/*` command/state interfaces |
| `robot_moveit_config` | SRDF, kinematics/joint-limits/controller YAML for MoveIt 2 | `robot_description`'s URDF |
| `safety_monitor` | Passive `safety_status` subscriber/logger only (no FSM authority — see the fix above) | `estop_controller`'s published `safety_status` |
| `diagnostics` | Aggregates joint telemetry into `diagnostic_msgs/DiagnosticArray` | `robot_msgs`, `robot_hardware_interface`'s published state |
| `vision_pipeline` | `vision_node` (§12.3) — subscribes to a camera topic, publishes part/barcode/object/quality-inspection detections | The standalone, **independently tested** `../../vision` Python modules (`vision/tests/`, 16/16 passing) |
| `robot_bringup` | Launch files, parameter YAMLs tying the above together | all of the above |
| `robot_gateway` | **New, least-verified package in this workspace** (no grpc++/protobuf toolchain was available either — see its own README). Operator-facing gRPC gateway for the Mac↔Ubuntu bridge (`documentation/mac-ubuntu-bridge-architecture.md`) — curated surface only, no new motion authority | `estop_controller`'s services, `arm_controller`'s action interface, `diagnostics_node`'s topic |
| `sim_network_hardware_interface` | Simulator-facing `ros2_control` plugin, sibling to `robot_hardware_interface` — proxies `read()`/`write()` over gRPC to a Mac-side simulator, exports identical `safety/*` interfaces so `estop_controller` needs no changes. Same compounded confidence caveat as `robot_gateway`, plus a new background-I/O-thread risk neither other hardware interface has — see its README | `arm::safety::SafetyFsm` (core stack), `documentation/bridge_proto/sim_hardware.proto` |

`vision_pipeline` is deliberately **not** included in `robot_bringup.launch.py`'s
default node list — it needs a real camera driver publishing `image_raw`,
which nothing in the real/simulated-CAN bringup provides, so launching it
there would just start a node with no image source. Launch it separately
once a camera driver is running: `ros2 launch vision_pipeline
vision_pipeline.launch.py` — see `documentation/simulation-stack-decision.md`
for how the MuJoCo/CoppeliaSim simulators (which replaced Gazebo) provide a
camera source for it instead.

`task_application_node` (application-specific, not specified in the source
doc beyond a launch-file reference) is not implemented — see "Out of scope"
below.

## What's real vs. what needs verification

- The **URDF generation** (`robot_description/scripts/generate_urdf.py`)
  reads the same `arm_variant_standard.yaml` the core stack reads, so the
  kinematic model ROS2/MoveIt sees is guaranteed consistent with `arm_demo`'s
  kinematics — this is checked by construction, not by running Xacro.
- The **hardware interface** (`robot_hardware_interface`) is written to
  directly instantiate `arm::motion::MotionController` and
  `arm::hal::SimulatedJointDriver` from the core stack inside `read()`/
  `write()`, so — once it compiles against a real `ros2_control` install —
  it inherits the core stack's already-verified kinematics/motion-profile
  behavior. The `ros2_control` plugin-export boilerplate (`PLUGINLIB_EXPORT_CLASS`,
  the interface export lists) is written from the standard pattern but is the
  part most likely to need small corrections against your exact ROS2 distro.
- The **vision node** (`vision_pipeline`) imports the standalone `vision/`
  modules via a monorepo-relative path (`Path(__file__).resolve().parents[4]`)
  — I verified that exact path-resolution logic and the resulting imports
  actually work by running them outside of ROS2 (no rclpy needed to check
  that math), so the only genuinely unverified part of this package is the
  `rclpy`/`cv_bridge`/`robot_msgs` plumbing itself, not the vision logic or
  the path wiring to reach it. The `vision/` modules it calls into carry
  their own 16/16-passing test suite (`vision/tests/`) that is completely
  independent of ROS2.
- **MoveIt config YAML** (SRDF planning groups, kinematics solver settings,
  controller mappings) follows the standard `moveit_configs_utils` layout but
  numeric tuning (OMPL planner parameters, controller gains) is left at
  reasonable defaults, not tuned against a real robot.
- **Gazebo config was removed** (previously `robot_description/gazebo`,
  `robot_description/worlds`, `robot_bringup/launch/gazebo_bringup.launch.py`)
  — the simulation stack was changed to MuJoCo + CoppeliaSim; see
  `documentation/simulation-stack-decision.md` for why and what replaces
  it. If you're looking for simulated-camera/IMU sensor bringup, that's
  now provided by the MuJoCo/CoppeliaSim integration instead.

## Out of scope

- `task_application_node` (§12.3's diagram references it as an
  application-specific node; no behavior is specified for it in the source
  doc, so it isn't implemented).
- Any actual `colcon build` / `rosdep` / CI verification — see the caveat
  above.
