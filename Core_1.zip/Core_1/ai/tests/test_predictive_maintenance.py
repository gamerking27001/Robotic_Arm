"""Synthetic-data test for predictive_maintenance: trains on a
generated fleet, then checks that a near-end-of-life feature vector
predicts a lower RUL than a fresh, healthy one, and that the model
declines to be falsely confident on a cold-start (unfitted) model."""
import shutil
import tempfile
from pathlib import Path

import numpy as np

from common.mlops import ModelRegistry
from common.feature_engineering import RollingJointFeatures
from services.predictive_maintenance.model import PredictiveMaintenanceModel
from services.predictive_maintenance.train import generate_synthetic_fleet, train_and_register


def test_rul_decreases_as_wear_features_worsen():
    X, y, feature_names = generate_synthetic_fleet(n_robots=6, seed=1)
    model = PredictiveMaintenanceModel(n_estimators=60).fit(X, y, feature_names)

    healthy = np.zeros(len(feature_names))
    worn = np.zeros(len(feature_names))
    for i, name in enumerate(feature_names):
        if name.startswith(("current_mean", "torque_mean", "temp_mean")):
            healthy[i] = X[:, i].min()
            worn[i] = X[:, i].max()

    healthy_pred = model.predict(healthy)
    worn_pred = model.predict(worn)
    assert worn_pred.rul_hours < healthy_pred.rul_hours


def test_prediction_interval_contains_point_estimate_and_is_ordered():
    X, y, feature_names = generate_synthetic_fleet(n_robots=4, seed=2)
    model = PredictiveMaintenanceModel(n_estimators=40).fit(X, y, feature_names)
    pred = model.predict(X[10])
    assert pred.lower_bound_hours <= pred.rul_hours <= pred.upper_bound_hours


def test_quantile_crossing_is_corrected_even_far_outside_training_distribution():
    # Regression test: independently-trained quantile regressors can
    # predict out of order (q50 > q90) on inputs far outside the
    # training distribution, which silently breaks the
    # lower<=mid<=upper invariant every caller relies on. Push a
    # wildly out-of-distribution feature vector through and confirm
    # predict() still returns a correctly ordered interval.
    X, y, feature_names = generate_synthetic_fleet(n_robots=4, seed=3)
    model = PredictiveMaintenanceModel(n_estimators=40).fit(X, y, feature_names)

    extreme = X.max(axis=0) * 50 + 1000  # far beyond anything seen in training
    pred = model.predict(extreme)
    assert pred.lower_bound_hours <= pred.rul_hours <= pred.upper_bound_hours
    assert pred.lower_bound_hours >= 0.0


def test_cold_start_model_reports_low_confidence_not_false_certainty():
    model = PredictiveMaintenanceModel()
    # not fitted -> _is_fleet_baseline stays True
    from services.predictive_maintenance.model import RULPrediction
    fake = RULPrediction(rul_hours=1000, lower_bound_hours=900, upper_bound_hours=1100, failure_probability_30d=0.01)
    assert model.confidence(fake) == 0.35


def test_registry_roundtrip_and_service_inference():
    tmp = Path(tempfile.mkdtemp())
    try:
        registry = ModelRegistry(tmp)
        train_and_register(registry, n_robots=6, seed=5)
        import sys
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
        from services.predictive_maintenance.service import PredictiveMaintenanceService

        svc = PredictiveMaintenanceService(registry)
        for _ in range(30):
            svc.observe("robot-1", "elbow", current_a=3.4, torque_nm=11.5, temp_c=68.0, velocity=55.0)
        insight = svc.run("robot-1", joint_name="elbow")
        assert insight.service_id == "predictive_maintenance"
        assert "remaining_useful_life_hours" in insight.payload
        assert 0.0 <= insight.confidence_score <= 1.0
    finally:
        shutil.rmtree(tmp)


def test_contributing_signals_present_and_flag_the_actually_elevated_feature():
    # §8.17: "Predictive maintenance and anomaly detection outputs
    # include contributing-signal breakdowns ... so an operator can
    # see why a model raised an alert." A joint with a sharply
    # elevated temperature (and otherwise-normal current/torque)
    # should have a temp-related feature among its top contributors,
    # not an arbitrary one.
    X, y, feature_names = generate_synthetic_fleet(n_robots=8, seed=6)
    model = PredictiveMaintenanceModel(n_estimators=60).fit(X, y, feature_names)
    assert model.healthy_reference is not None

    hot_vector = model.healthy_reference.copy()
    temp_mean_idx = feature_names.index("temp_mean")
    hot_vector[temp_mean_idx] = X[:, temp_mean_idx].max()  # push only temperature far from healthy

    signals = model.contributing_signals(hot_vector)
    assert len(signals) > 0
    assert any(name.startswith("temp") for name in signals)


def test_contributing_signals_empty_for_unfitted_cold_start_model():
    model = PredictiveMaintenanceModel()
    x = np.zeros(len(RollingJointFeatures.feature_names()))
    assert model.contributing_signals(x) == {}


def test_service_payload_includes_contributing_signals_key():
    tmp = Path(tempfile.mkdtemp())
    try:
        registry = ModelRegistry(tmp)
        train_and_register(registry, n_robots=6, seed=7)
        import sys
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
        from services.predictive_maintenance.service import PredictiveMaintenanceService

        svc = PredictiveMaintenanceService(registry)
        for _ in range(30):
            svc.observe("robot-1", "wrist", current_a=5.0, torque_nm=18.0, temp_c=80.0, velocity=55.0)
        insight = svc.run("robot-1", joint_name="wrist")
        assert "contributing_signals" in insight.payload
    finally:
        shutil.rmtree(tmp)
