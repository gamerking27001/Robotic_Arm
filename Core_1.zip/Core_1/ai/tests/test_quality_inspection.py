"""Tests for quality_inspection's AIService wrapper.

`cv2` IS installed in this sandbox (verified directly — see the
compliance-audit note in ai/README.md for how an earlier, unverified
"cv2 isn't installed" claim was caught and corrected). This file
tests the real, working inspection path with the same synthetic-
defect pattern `vision/tests/test_quality_inspection.py` uses (an
identical image passes, a conspicuous synthetic defect fails), plus
the two degraded-path guards (missing images, and the graceful
fallback if `cv2` genuinely isn't available in some other
environment) that don't depend on cv2 either way.
"""
import numpy as np

from services.quality_inspection.service import QualityInspectionService

try:
    import cv2

    _HAVE_CV2 = True
except ImportError:
    _HAVE_CV2 = False


def _make_golden_image():
    img = np.full((200, 300, 3), 200, dtype=np.uint8)
    cv2.rectangle(img, (50, 50), (250, 150), (120, 120, 120), thickness=-1)
    return img


def test_missing_images_returns_zero_confidence_not_a_crash():
    svc = QualityInspectionService()
    insight = svc.run("robot-1", part_id="part-42")
    assert insight.confidence_score == 0.0
    assert insight.payload["part_id"] == "part-42"
    assert insight.requires_human_review is True


def test_service_degrades_gracefully_if_vision_backend_is_unavailable():
    # Exercises the fallback path structurally (not by actually
    # uninstalling cv2, which IS present here) — the missing-images
    # guard above already covers "no image provided"; this covers
    # "an image was provided but is nonsense" without crashing.
    dummy = np.zeros((10, 10, 3), dtype="uint8")
    svc = QualityInspectionService()
    insight = svc.run("robot-1", test_image_bgr=dummy, golden_image_bgr=dummy, part_id="part-1")
    assert "part_id" in insight.payload
    if "note" in insight.payload:
        assert "vision backend unavailable" in insight.payload["note"]
    else:
        assert insight.payload["passed"] is True  # identical (all-zero) images -> passes


def test_identical_image_passes_with_high_confidence():
    if not _HAVE_CV2:
        return  # environment-dependent; skip rather than fail where cv2 genuinely isn't installed
    golden = _make_golden_image()
    svc = QualityInspectionService()
    insight = svc.run("robot-1", test_image_bgr=golden.copy(), golden_image_bgr=golden, part_id="part-1")
    assert insight.payload["passed"] is True
    assert insight.payload["anomaly_score"] < 0.001


def test_synthetic_defect_is_caught_and_flagged_for_review():
    if not _HAVE_CV2:
        return
    golden = _make_golden_image()
    defective = golden.copy()
    cv2.circle(defective, (150, 100), 20, (0, 0, 255), thickness=-1)  # conspicuous synthetic defect

    svc = QualityInspectionService()
    insight = svc.run("robot-1", test_image_bgr=defective, golden_image_bgr=golden, part_id="part-2")
    assert insight.payload["passed"] is False
    assert insight.payload["anomaly_score"] > 0.01
    # §8.6 Human Override: an auto-reject must be reversible, never final.
    assert insight.payload["auto_reject_reversible"] is True


def test_confidence_is_higher_further_from_the_pass_fail_threshold():
    if not _HAVE_CV2:
        return
    golden = _make_golden_image()
    svc = QualityInspectionService(pass_score_max=0.01)

    identical_insight = svc.run("robot-1", test_image_bgr=golden.copy(), golden_image_bgr=golden, part_id="p1")

    barely_defective = golden.copy()
    cv2.circle(barely_defective, (60, 60), 2, (0, 0, 255), thickness=-1)  # tiny defect, near the threshold
    borderline_insight = svc.run("robot-1", test_image_bgr=barely_defective, golden_image_bgr=golden, part_id="p2")

    # A confident pass (identical images, far from the threshold)
    # should be reported with higher confidence than a borderline case
    # close to the pass/fail boundary — that's the §8.6 confidence
    # signal actually doing its job, not just present in the schema.
    assert identical_insight.confidence_score >= borderline_insight.confidence_score
