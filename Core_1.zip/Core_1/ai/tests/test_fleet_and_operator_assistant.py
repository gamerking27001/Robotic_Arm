"""Tests for fleet_intelligence (cross-robot aggregation over the bus)
and operator_assistant (grounded retrieval, mandatory citation,
refusal on ungrounded queries)."""
from common.insights_bus import InProcessInsightsBus
from common.schemas import InsightType, make_insight
from services.fleet_intelligence.service import FleetIntelligenceService
from services.operator_assistant.service import OperatorAssistantService


def _publish_sample_fleet_insights(bus):
    bus.publish(make_insight(
        service_id="predictive_maintenance", robot_id="robot-1", insight_type=InsightType.PREDICTIVE_MAINTENANCE,
        payload={"joint_name": "elbow", "remaining_useful_life_hours": 40.0}, confidence_score=0.8,
    ))
    bus.publish(make_insight(
        service_id="predictive_maintenance", robot_id="robot-2", insight_type=InsightType.PREDICTIVE_MAINTENANCE,
        payload={"joint_name": "wrist", "remaining_useful_life_hours": 900.0}, confidence_score=0.8,
    ))
    for _ in range(3):
        bus.publish(make_insight(
            service_id="anomaly_detection", robot_id="robot-1", insight_type=InsightType.ANOMALY,
            payload={"is_anomaly": True}, confidence_score=0.9,
        ))
    bus.publish(make_insight(
        service_id="energy_optimization", robot_id="robot-1", insight_type=InsightType.ENERGY_OPTIMIZATION,
        payload={"energy_per_cycle_j": 120.0}, confidence_score=0.7,
    ))
    bus.publish(make_insight(
        service_id="energy_optimization", robot_id="robot-2", insight_type=InsightType.ENERGY_OPTIMIZATION,
        payload={"energy_per_cycle_j": 340.0}, confidence_score=0.7,
    ))
    bus.publish(make_insight(
        service_id="thermal_intelligence", robot_id="robot-3", insight_type=InsightType.THERMAL_FORECAST,
        payload={"forecast_temp_c": 95.0}, confidence_score=0.6,
    ))


def test_fleet_intelligence_ranks_maintenance_priority_by_lowest_rul():
    bus = InProcessInsightsBus()
    _publish_sample_fleet_insights(bus)
    svc = FleetIntelligenceService(bus)
    insight = svc.run("fleet", window_seconds=3600)
    ranking = insight.payload["maintenance_priority_ranking"]
    assert ranking[0]["robot_id"] == "robot-1"  # lower RUL sorts first


def test_fleet_intelligence_flags_bottleneck_from_repeated_anomalies():
    bus = InProcessInsightsBus()
    _publish_sample_fleet_insights(bus)
    svc = FleetIntelligenceService(bus)
    insight = svc.run("fleet")
    assert "robot-1" in insight.payload["bottleneck_candidates"]


def test_fleet_intelligence_ranks_energy_comparison_highest_consumer_first():
    bus = InProcessInsightsBus()
    _publish_sample_fleet_insights(bus)
    svc = FleetIntelligenceService(bus)
    insight = svc.run("fleet")
    comparison = insight.payload["energy_comparison_by_robot"]
    assert comparison[0]["robot_id"] == "robot-2"  # 340 J/cycle > robot-1's 120 J/cycle
    assert comparison[0]["mean_energy_per_cycle_j"] == 340.0


def test_fleet_intelligence_detects_idle_robot_from_recorded_activity():
    bus = InProcessInsightsBus()
    svc = FleetIntelligenceService(bus)

    t0 = 1000.0
    # robot-A: mostly moving -> high utilization, not idle
    svc.record_activity("robot-A", is_moving=True, timestamp=t0)
    svc.record_activity("robot-A", is_moving=True, timestamp=t0 + 10)
    svc.record_activity("robot-A", is_moving=True, timestamp=t0 + 20)
    # robot-B: never moving -> idle
    svc.record_activity("robot-B", is_moving=False, timestamp=t0)
    svc.record_activity("robot-B", is_moving=False, timestamp=t0 + 10)
    svc.record_activity("robot-B", is_moving=False, timestamp=t0 + 20)

    insight = svc.run("fleet")
    assert insight.payload["utilization_by_robot"]["robot-A"] == 1.0
    assert insight.payload["utilization_by_robot"]["robot-B"] == 0.0
    assert "robot-B" in insight.payload["idle_robots"]
    assert "robot-A" not in insight.payload["idle_robots"]


def test_fleet_intelligence_production_forecasting_is_honestly_null_not_fabricated():
    bus = InProcessInsightsBus()
    svc = FleetIntelligenceService(bus)
    insight = svc.run("fleet")
    assert insight.payload["production_forecasting"] is None


def test_operator_assistant_answers_grounded_maintenance_query_with_citations():
    bus = InProcessInsightsBus()
    _publish_sample_fleet_insights(bus)
    svc = OperatorAssistantService(bus)
    insight = svc.run("robot-1", question="What maintenance is due next week?")
    assert insight.payload["refused"] is False
    assert len(insight.payload["citations"]) >= 1
    assert "robot-1" in insight.payload["answer"]


def test_operator_assistant_answers_thermal_threshold_query():
    bus = InProcessInsightsBus()
    _publish_sample_fleet_insights(bus)
    svc = OperatorAssistantService(bus)
    insight = svc.run("robot-3", question="Show all robots exceeding 70C")
    assert insight.payload["refused"] is False
    assert "robot-3" in insight.payload["answer"]


def test_operator_assistant_refuses_ungrounded_query_rather_than_inventing_an_answer():
    bus = InProcessInsightsBus()  # empty bus — nothing to ground an answer in
    svc = OperatorAssistantService(bus)
    insight = svc.run("robot-1", question="What is the meaning of life?")
    assert insight.payload["refused"] is True
    assert insight.payload["answer"] is None
    assert insight.confidence_score == 0.0
