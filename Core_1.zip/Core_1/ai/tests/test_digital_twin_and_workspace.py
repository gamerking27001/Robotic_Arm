"""Tests for digital_twin_intelligence (residual monitoring) and
workspace_intelligence (LiDAR clustering + classification)."""
import numpy as np

from services.digital_twin_intelligence.service import DigitalTwinIntelligenceService
from services.workspace_intelligence.model import GeometricClusterClassifier
from services.workspace_intelligence.service import WorkspaceIntelligenceService


def test_digital_twin_small_deviation_is_low_alert_high_confidence():
    svc = DigitalTwinIntelligenceService(deviation_alert_threshold_mm=2.0)
    insight = svc.run("robot-1", twin_predicted_tcp_mm=[100.0, 50.0, 30.0], measured_tcp_mm=[100.2, 50.1, 30.0])
    assert insight.payload["recalibration_recommended"] is False
    assert insight.confidence_score > 0.7


def test_digital_twin_large_deviation_triggers_recalibration_flag():
    svc = DigitalTwinIntelligenceService(deviation_alert_threshold_mm=2.0)
    insight = svc.run("robot-1", twin_predicted_tcp_mm=[100.0, 50.0, 30.0], measured_tcp_mm=[112.0, 61.0, 30.0])
    assert insight.payload["recalibration_recommended"] is True
    assert insight.confidence_score < 0.5


def test_workspace_classifier_separates_pallet_from_human_shaped_cluster():
    rng = np.random.default_rng(0)
    # Human-shaped: tall, narrow footprint cluster
    human_pts = np.column_stack([
        rng.normal(0, 0.15, 200), rng.normal(0, 0.15, 200), rng.uniform(0, 1.7, 200),
    ])
    # Pallet-shaped: low, wide footprint cluster, offset in space
    pallet_pts = np.column_stack([
        rng.normal(5, 0.5, 200), rng.normal(5, 0.5, 200), rng.uniform(0, 0.15, 200),
    ])
    points = np.vstack([human_pts, pallet_pts])

    classifier = GeometricClusterClassifier(eps_m=0.4, min_samples=10)
    objects = classifier.classify(points)
    class_names = {o.class_name for o in objects}
    assert "human" in class_names
    assert len(objects) == 2


def test_workspace_service_reports_human_present_flag():
    rng = np.random.default_rng(1)
    human_pts = np.column_stack([
        rng.normal(0, 0.1, 150), rng.normal(0, 0.1, 150), rng.uniform(0, 1.7, 150),
    ]).tolist()
    svc = WorkspaceIntelligenceService(eps_m=0.4, min_samples=10)
    insight = svc.run("robot-1", points_xyz=human_pts)
    assert insight.payload["human_present"] is True


def test_workspace_service_handles_empty_scan():
    svc = WorkspaceIntelligenceService()
    insight = svc.run("robot-1", points_xyz=[])
    assert insight.payload["object_count"] == 0
    assert insight.payload["human_present"] is False
