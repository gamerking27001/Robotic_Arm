"""Synthetic-data test for anomaly_detection: a window matching the
normal-operation distribution must score low; a window with a sharply
elevated current/temperature signature (simulating a degrading
bearing) must score high and be flagged.

Test magnitudes were recalibrated after fixing the synthetic
generator to span the real robot's full per-joint torque range
(train.py's module docstring has the full story): a fixed "outlier"
value that was clearly anomalous against the OLD narrow ~7-9.5 Nm
training band (e.g. torque=20 Nm) is no longer guaranteed anomalous
now that the pooled training distribution spans 12-300 Nm across all
6 real joints — 20 Nm is a plausible NORMAL reading for a mid-size
joint. This was caught by actually re-running the old test values
against the new distribution, not assumed safe. Tests below use
magnitudes that exceed even the largest real joint's realistic
operating range, which stay genuinely anomalous regardless.
"""
import shutil
import tempfile
from pathlib import Path

import numpy as np

from common.feature_engineering import RollingJointFeatures
from common.mlops import ModelRegistry
from services.anomaly_detection.model import EdgeIsolationForestDetector, TinyAutoencoder
from services.anomaly_detection.train import generate_normal_operation_windows


def _make_window(current, torque, temp, velocity):
    w = RollingJointFeatures(window_size=50)
    rng = np.random.default_rng(0)
    for _ in range(60):
        w.push(current + rng.normal(0, 0.02), torque + rng.normal(0, 0.1), temp + rng.normal(0, 0.2), velocity + rng.normal(0, 1.0))
    return w.as_vector()


def test_isolation_forest_flags_clear_outlier_not_normal_window():
    X, feature_names = generate_normal_operation_windows(n_windows=400, seed=1)
    detector = EdgeIsolationForestDetector(contamination=0.03).fit(X, feature_names)

    normal_window = _make_window(2.1, 8.2, 37.0, 60.0)
    outlier_window = _make_window(60.0, 320.0, 130.0, 60.0)  # exceeds even the largest real joint's peak torque (300 Nm)

    normal_result = detector.score(normal_window)
    outlier_result = detector.score(outlier_window)

    assert outlier_result.anomaly_score > normal_result.anomaly_score
    assert outlier_result.is_anomaly is True


def test_autoencoder_reconstruction_error_separates_outlier():
    X, _ = generate_normal_operation_windows(n_windows=300, seed=2)
    ae = TinyAutoencoder(input_dim=X.shape[1], bottleneck_dim=3).fit(X, epochs=200)

    normal_window = _make_window(2.1, 8.2, 37.0, 60.0)
    outlier_window = _make_window(60.0, 320.0, 130.0, 60.0)

    normal_score = ae.score(normal_window).anomaly_score
    outlier_score = ae.score(outlier_window).anomaly_score
    assert outlier_score > normal_score


def test_pooled_across_joint_sizes_reduces_per_joint_sensitivity_disclosed_limitation():
    # Documents a real, disclosed limitation surfaced while fixing the
    # generator (see this file's module docstring and train.py's): a
    # value that would be a clear anomaly for a SMALL joint (e.g. 20
    # Nm on a 24 Nm-rated wrist joint) is not reliably flagged by this
    # POOLED-across-all-joint-sizes model, because 20 Nm is plausible
    # for a mid/large joint. A real deployment should train separate
    # models per joint or per joint-size-class rather than one pooled
    # model across the whole arm — this test exists so that limitation
    # stays visible (documented, verified, not silently "working") 
    # rather than being an unstated assumption someone discovers in
    # production.
    X, feature_names = generate_normal_operation_windows(n_windows=400, seed=1)
    detector = EdgeIsolationForestDetector(contamination=0.03).fit(X, feature_names)
    borderline_window = _make_window(current=8.0, torque=20.0, temp=40.0, velocity=60.0)
    result = detector.score(borderline_window)
    # Not asserting is_anomaly either way — the point is this value's
    # classification is genuinely ambiguous under the pooled model,
    # which is exactly the documented limitation, not a bug to fix here.
    assert 0.0 <= result.anomaly_score <= 1.0


def test_dismiss_suppresses_repeat_alert_on_same_signature():
    tmp = Path(tempfile.mkdtemp())
    try:
        registry = ModelRegistry(tmp)
        from services.anomaly_detection.train import train_and_register
        train_and_register(registry, seed=4)

        import sys
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
        from services.anomaly_detection.service import AnomalyDetectionService

        svc = AnomalyDetectionService(registry)
        for _ in range(60):
            svc.observe("robot-1", "elbow", current_a=60.0, torque_nm=320.0, temp_c=130.0, velocity=60.0)

        insight_before = svc.run("robot-1", joint_name="elbow")
        svc.dismiss("robot-1", "elbow")
        insight_after = svc.run("robot-1", joint_name="elbow")

        assert insight_after.payload["is_anomaly"] is False
    finally:
        shutil.rmtree(tmp)
