"""Tests for common/tcp_bus.py: real TCP sockets, real threads acting
as separate "processes" (edge gateway vs. cloud service), real
newline-delimited JSON frames — not function calls standing in for
network behavior."""
import time

from common.schemas import InsightType, make_insight
from common.tcp_bus import TCPBusClient, TCPBusServer


def _wait_until(predicate, timeout=3.0, interval=0.02):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if predicate():
            return True
        time.sleep(interval)
    return predicate()


def test_two_clients_exchange_an_insight_over_a_real_socket():
    server = TCPBusServer()
    server.start()
    try:
        publisher = TCPBusClient(server.host, server.port)
        subscriber = TCPBusClient(server.host, server.port)
        received = []
        subscriber.subscribe(InsightType.ANOMALY, lambda ins: received.append(ins))

        insight = make_insight(
            service_id="anomaly_detection", robot_id="robot-1", insight_type=InsightType.ANOMALY,
            payload={"is_anomaly": True}, confidence_score=0.9,
        )
        publisher.publish(insight)

        assert _wait_until(lambda: len(received) == 1)
        assert received[0].robot_id == "robot-1"
        assert received[0].payload == {"is_anomaly": True}
    finally:
        server.stop()


def test_publisher_does_not_receive_its_own_message_back():
    # Star-topology broker: publisher is excluded from the broadcast
    # of its own message (mirrors normal pub/sub semantics — a
    # service publishing an insight isn't also "subscribed to itself").
    server = TCPBusServer()
    server.start()
    try:
        client = TCPBusClient(server.host, server.port)
        received = []
        client.subscribe(None, lambda ins: received.append(ins))
        client.publish(make_insight(service_id="s", robot_id="r", insight_type=InsightType.ANOMALY, payload={}, confidence_score=0.5))
        time.sleep(0.3)
        assert len(received) == 0
    finally:
        server.stop()


def test_three_way_fanout_all_subscribers_receive_the_message():
    server = TCPBusServer()
    server.start()
    try:
        publisher = TCPBusClient(server.host, server.port)
        sub_a = TCPBusClient(server.host, server.port)
        sub_b = TCPBusClient(server.host, server.port)
        received_a, received_b = [], []
        sub_a.subscribe(None, lambda ins: received_a.append(ins))
        sub_b.subscribe(None, lambda ins: received_b.append(ins))

        publisher.publish(make_insight(service_id="s", robot_id="r", insight_type=InsightType.THERMAL_FORECAST, payload={"x": 1}, confidence_score=0.7))

        assert _wait_until(lambda: len(received_a) == 1 and len(received_b) == 1)
    finally:
        server.stop()


def test_server_side_history_survives_a_late_joining_client():
    server = TCPBusServer()
    server.start()
    try:
        publisher = TCPBusClient(server.host, server.port)
        publisher.publish(make_insight(service_id="s", robot_id="r", insight_type=InsightType.ENERGY_OPTIMIZATION, payload={"e": 1}, confidence_score=0.6))
        time.sleep(0.2)

        assert _wait_until(lambda: len(server.history(InsightType.ENERGY_OPTIMIZATION)) == 1)
        hist = server.history(InsightType.ENERGY_OPTIMIZATION)
        assert hist[0].payload == {"e": 1}
    finally:
        server.stop()


def test_client_disconnect_does_not_crash_the_server_or_other_clients():
    server = TCPBusServer()
    server.start()
    try:
        transient = TCPBusClient(server.host, server.port)
        survivor = TCPBusClient(server.host, server.port)
        received = []
        survivor.subscribe(None, lambda ins: received.append(ins))

        transient.close()
        time.sleep(0.2)

        # Server must still be alive and able to relay a new message
        # between the remaining/new clients after a peer vanished.
        publisher = TCPBusClient(server.host, server.port)
        publisher.publish(make_insight(service_id="s", robot_id="r", insight_type=InsightType.ANOMALY, payload={}, confidence_score=0.5))
        assert _wait_until(lambda: len(received) == 1)
    finally:
        server.stop()


def test_malformed_frame_is_dropped_not_crashing_the_broker():
    server = TCPBusServer()
    server.start()
    try:
        import socket

        raw = socket.create_connection((server.host, server.port))
        raw.sendall(b"not valid json at all\n")
        time.sleep(0.2)

        # Broker must still be responsive after receiving garbage.
        publisher = TCPBusClient(server.host, server.port)
        subscriber = TCPBusClient(server.host, server.port)
        received = []
        subscriber.subscribe(None, lambda ins: received.append(ins))
        publisher.publish(make_insight(service_id="s", robot_id="r", insight_type=InsightType.ANOMALY, payload={}, confidence_score=0.5))
        assert _wait_until(lambda: len(received) == 1)
        raw.close()
    finally:
        server.stop()
