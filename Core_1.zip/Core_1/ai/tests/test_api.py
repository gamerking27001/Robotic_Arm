"""Tests for common/api.py: §17.2's five principles, each checked as
a real behavior rather than a docstring claim."""
from common.api import ApiError, ApiRouter, ErrorCode, TokenScope, build_default_router
from common.insights_bus import InProcessInsightsBus
from common.schemas import InsightType, make_insight


def _echo_handler(robot_id, **kwargs):
    return {"robot_id": robot_id, "kwargs": kwargs}


def test_unversioned_or_unknown_route_is_not_found():
    router = ApiRouter()
    router.register("v1", "/foo/infer", _echo_handler)
    scope = TokenScope(role="operator")
    try:
        router.dispatch("v2", "/foo/infer", scope, robot_id="r1")
        assert False, "expected ApiError"
    except ApiError as e:
        assert e.code == ErrorCode.NOT_FOUND


def test_scoped_token_cannot_reach_out_of_scope_robot():
    router = ApiRouter()
    router.register("v1", "/foo/infer", _echo_handler)
    scope = TokenScope(role="operator", allowed_robot_ids={"robot-1"})
    try:
        router.dispatch("v1", "/foo/infer", scope, robot_id="robot-2")
        assert False, "expected ApiError"
    except ApiError as e:
        assert e.code == ErrorCode.PERMISSION

    ok = router.dispatch("v1", "/foo/infer", scope, robot_id="robot-1")
    assert ok["status"] == "ok"


def test_role_gated_route_rejects_wrong_role_but_admin_always_passes():
    router = ApiRouter()
    router.register("v1", "/pid/tune", _echo_handler, required_role="developer_integrator")
    operator_scope = TokenScope(role="operator")
    admin_scope = TokenScope(role="fleet_administrator")

    try:
        router.dispatch("v1", "/pid/tune", operator_scope, robot_id="r1")
        assert False, "expected ApiError"
    except ApiError as e:
        assert e.code == ErrorCode.PERMISSION

    ok = router.dispatch("v1", "/pid/tune", admin_scope, robot_id="r1")
    assert ok["status"] == "ok"


def test_idempotency_key_prevents_double_execution():
    call_count = {"n": 0}

    def counting_handler(robot_id, **kwargs):
        call_count["n"] += 1
        return {"n": call_count["n"]}

    router = ApiRouter()
    router.register("v1", "/deploy", counting_handler)
    scope = TokenScope(role="operator")

    r1 = router.dispatch("v1", "/deploy", scope, robot_id="r1", idempotency_key="deploy-abc")
    r2 = router.dispatch("v1", "/deploy", scope, robot_id="r1", idempotency_key="deploy-abc")
    assert call_count["n"] == 1  # handler only actually ran once
    assert r1 == r2

    r3 = router.dispatch("v1", "/deploy", scope, robot_id="r1", idempotency_key="deploy-xyz")
    assert call_count["n"] == 2  # a genuinely different key does run again


def test_handler_exception_becomes_typed_robot_rejected_error_not_a_raw_traceback():
    def broken_handler(robot_id, **kwargs):
        raise ValueError("simulated handler bug")

    router = ApiRouter()
    router.register("v1", "/broken", broken_handler)
    scope = TokenScope(role="operator")
    try:
        router.dispatch("v1", "/broken", scope, robot_id="r1")
        assert False, "expected ApiError"
    except ApiError as e:
        assert e.code == ErrorCode.ROBOT_REJECTED
        assert "simulated handler bug" in e.message


def test_build_default_router_wires_a_real_ai_service_end_to_end():
    from services.fleet_intelligence.service import FleetIntelligenceService

    bus = InProcessInsightsBus()
    bus.publish(make_insight(
        service_id="anomaly_detection", robot_id="robot-1", insight_type=InsightType.ANOMALY,
        payload={"is_anomaly": True}, confidence_score=0.9,
    ))
    fleet_svc = FleetIntelligenceService(bus)
    router = build_default_router({"fleet_intelligence": fleet_svc})
    scope = TokenScope(role="fleet_administrator")

    response = router.dispatch("v1", "/fleet_intelligence/infer", scope, robot_id="fleet")
    assert response["status"] == "ok"
    assert response["data"]["service_id"] == "fleet_intelligence"
