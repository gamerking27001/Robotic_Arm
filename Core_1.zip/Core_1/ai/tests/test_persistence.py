"""Tests for common/persistence.py: real SQLite (stdlib, on-disk file,
not :memory: for the persistence-specific tests) — insight storage,
threshold-crossing alert generation, deduplication, severity ranking,
and operator acknowledgment (§15.2, §17.1)."""
import os
import tempfile
import time

from common.persistence import InsightStore
from common.schemas import InsightType, make_insight


def test_insight_survives_a_simulated_process_restart():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    os.remove(path)  # start from a genuinely fresh file
    try:
        store1 = InsightStore(path)
        insight = make_insight(
            service_id="predictive_maintenance", robot_id="robot-1", insight_type=InsightType.PREDICTIVE_MAINTENANCE,
            payload={"joint_name": "elbow", "remaining_useful_life_hours": 500.0}, confidence_score=0.8,
        )
        store1.save_insight(insight)
        store1.close()  # simulates the process exiting

        store2 = InsightStore(path)  # simulates a fresh process reopening the same file
        rows = store2.query_insights(insight_type="predictive_maintenance", robot_id="robot-1")
        assert len(rows) == 1
        assert rows[0]["payload"]["remaining_useful_life_hours"] == 500.0
        store2.close()
    finally:
        if os.path.exists(path):
            os.remove(path)


def test_low_rul_insight_generates_a_warning_alert():
    store = InsightStore(":memory:")
    insight = make_insight(
        service_id="predictive_maintenance", robot_id="robot-1", insight_type=InsightType.PREDICTIVE_MAINTENANCE,
        payload={"joint_name": "elbow", "remaining_useful_life_hours": 100.0}, confidence_score=0.8,
    )
    store.save_insight(insight)
    alerts = store.list_alerts(robot_id="robot-1")
    assert len(alerts) == 1
    assert alerts[0].severity == "warning"
    assert "robot-1" in alerts[0].message
    assert not alerts[0].is_acknowledged


def test_critical_rul_generates_both_warning_and_critical_alerts_not_deduplicated_across_rules():
    # 100h crosses BOTH the <168h (warning) and <24h... wait 100 > 24
    # so only warning fires here; use a value under both thresholds.
    store = InsightStore(":memory:")
    insight = make_insight(
        service_id="predictive_maintenance", robot_id="robot-1", insight_type=InsightType.PREDICTIVE_MAINTENANCE,
        payload={"joint_name": "elbow", "remaining_useful_life_hours": 10.0}, confidence_score=0.9,
    )
    store.save_insight(insight)
    alerts = store.list_alerts(robot_id="robot-1")
    severities = {a.severity for a in alerts}
    assert severities == {"warning", "critical"}  # both rules' thresholds crossed by the same value


def test_repeated_crossings_do_not_spam_duplicate_open_alerts():
    store = InsightStore(":memory:")
    for _ in range(5):
        insight = make_insight(
            service_id="anomaly_detection", robot_id="robot-1", insight_type=InsightType.ANOMALY,
            payload={"joint_name": "elbow", "anomaly_score": 0.95}, confidence_score=0.9,
        )
        store.save_insight(insight)
    alerts = store.list_alerts(robot_id="robot-1")
    assert len(alerts) == 1  # not 5 — deduplicated against the still-open alert


def test_acknowledging_an_alert_allows_a_new_one_on_the_next_crossing():
    store = InsightStore(":memory:")
    insight = make_insight(
        service_id="anomaly_detection", robot_id="robot-1", insight_type=InsightType.ANOMALY,
        payload={"joint_name": "elbow", "anomaly_score": 0.95}, confidence_score=0.9,
    )
    store.save_insight(insight)
    first_alerts = store.list_alerts(robot_id="robot-1")
    assert len(first_alerts) == 1

    ok = store.acknowledge_alert(first_alerts[0].id, acknowledged_by="operator-jane")
    assert ok is True
    assert store.list_alerts(robot_id="robot-1", unacknowledged_only=True) == []

    store.save_insight(insight)  # same condition crosses again
    all_alerts = store.list_alerts(robot_id="robot-1")
    assert len(all_alerts) == 2  # the acknowledged one plus a fresh one


def test_acknowledge_is_idempotent_and_returns_false_on_second_call():
    store = InsightStore(":memory:")
    insight = make_insight(
        service_id="thermal_intelligence", robot_id="robot-1", insight_type=InsightType.THERMAL_FORECAST,
        payload={"joint_name": "wrist", "overheat_probability": 0.9}, confidence_score=0.8,
    )
    store.save_insight(insight)
    alert_id = store.list_alerts(robot_id="robot-1")[0].id

    assert store.acknowledge_alert(alert_id, "operator-a") is True
    assert store.acknowledge_alert(alert_id, "operator-b") is False  # already acknowledged — no-op, not an error


def test_alerts_ranked_critical_before_warning_before_info():
    store = InsightStore(":memory:")
    store.save_insight(make_insight(
        service_id="predictive_maintenance", robot_id="robot-1", insight_type=InsightType.PREDICTIVE_MAINTENANCE,
        payload={"joint_name": "a", "remaining_useful_life_hours": 100.0}, confidence_score=0.8,  # warning
    ))
    store.save_insight(make_insight(
        service_id="anomaly_detection", robot_id="robot-1", insight_type=InsightType.ANOMALY,
        payload={"joint_name": "b", "anomaly_score": 0.95}, confidence_score=0.8,  # critical
    ))
    alerts = store.list_alerts(robot_id="robot-1")
    assert alerts[0].severity == "critical"
    assert alerts[1].severity == "warning"


def test_non_crossing_insight_generates_no_alert():
    store = InsightStore(":memory:")
    insight = make_insight(
        service_id="predictive_maintenance", robot_id="robot-1", insight_type=InsightType.PREDICTIVE_MAINTENANCE,
        payload={"joint_name": "elbow", "remaining_useful_life_hours": 5000.0}, confidence_score=0.9,
    )
    store.save_insight(insight)
    assert store.list_alerts(robot_id="robot-1") == []


def test_custom_alert_rule_can_be_added_and_fires():
    store = InsightStore(":memory:")
    store.add_alert_rule(
        insight_type="energy_optimization", metric_name="efficiency_score", operator="<", threshold=0.3,
        severity="info", message_template="{robot_id}: efficiency below 30% ({efficiency_score})",
    )
    insight = make_insight(
        service_id="energy_optimization", robot_id="robot-1", insight_type=InsightType.ENERGY_OPTIMIZATION,
        payload={"efficiency_score": 0.1}, confidence_score=0.7,
    )
    store.save_insight(insight)
    alerts = store.list_alerts(robot_id="robot-1")
    assert len(alerts) == 1
    assert alerts[0].severity == "info"
