"""Tests for ai/common: schemas, insights bus, MLOps registry/drift, deployment gate."""
import shutil
import tempfile
import time
from pathlib import Path

import numpy as np

from common.deployment_gate import DeploymentGate, RolloutStage, ShadowModeResult
from common.insights_bus import InProcessInsightsBus
from common.mlops import ModelRegistry, RetrainingScheduler, population_stability_index
from common.schemas import ExecutionSite, InsightType, make_insight


def test_make_insight_clamps_confidence_and_flags_low_confidence_for_review():
    i = make_insight(
        service_id="svc", robot_id="r1", insight_type=InsightType.ANOMALY,
        payload={"x": 1}, confidence_score=1.4,
    )
    assert i.confidence_score == 1.0
    assert i.requires_human_review is False  # 1.0 >= default floor

    j = make_insight(
        service_id="svc", robot_id="r1", insight_type=InsightType.ANOMALY,
        payload={}, confidence_score=0.2,
    )
    assert j.requires_human_review is True


def test_insights_bus_publish_subscribe_and_history_filtering():
    bus = InProcessInsightsBus()
    received = []
    bus.subscribe(InsightType.ANOMALY, lambda ins: received.append(ins))
    bus.subscribe(InsightType.QUALITY_INSPECTION, lambda ins: received.append(ins))

    i1 = make_insight(service_id="a", robot_id="r1", insight_type=InsightType.ANOMALY, payload={}, confidence_score=0.9)
    i2 = make_insight(service_id="b", robot_id="r2", insight_type=InsightType.QUALITY_INSPECTION, payload={}, confidence_score=0.9)
    i3 = make_insight(service_id="c", robot_id="r1", insight_type=InsightType.THERMAL_FORECAST, payload={}, confidence_score=0.9)

    for i in (i1, i2, i3):
        bus.publish(i)

    assert len(received) == 2  # i3's type has no subscriber
    hist_r1 = bus.history(robot_id="r1")
    assert {h.insight_id for h in hist_r1} == {i1.insight_id, i3.insight_id}
    hist_anomaly = bus.history(InsightType.ANOMALY)
    assert len(hist_anomaly) == 1 and hist_anomaly[0].insight_id == i1.insight_id


def test_no_service_calls_another_service_directly_bus_is_the_only_channel():
    # Structural check on §8.2: a broken subscriber must never break
    # the bus for other subscribers (keeps services independently
    # testable/deployable).
    bus = InProcessInsightsBus()

    def broken(_insight):
        raise RuntimeError("simulated subscriber failure")

    good_received = []
    bus.subscribe(None, broken)
    bus.subscribe(None, lambda ins: good_received.append(ins))

    bus.publish(make_insight(service_id="s", robot_id="r", insight_type=InsightType.ANOMALY, payload={}, confidence_score=0.5))
    assert len(good_received) == 1


def test_model_registry_versions_and_rollback():
    tmp = Path(tempfile.mkdtemp())
    try:
        registry = ModelRegistry(tmp)
        v1 = registry.register("svc", artifact={"w": 1}, hyperparameters={}, training_dataset_hash="h1", metrics={"acc": 0.8})
        assert v1.version_id == 1
        assert registry.active_version("svc").version_id == 1

        v2 = registry.register("svc", artifact={"w": 2}, hyperparameters={}, training_dataset_hash="h2", metrics={"acc": 0.85})
        assert registry.active_version("svc").version_id == 2
        assert registry.load_artifact(v2) == {"w": 2}

        rolled_back = registry.rollback("svc")
        assert rolled_back.version_id == 1
        assert registry.active_version("svc").version_id == 1
    finally:
        shutil.rmtree(tmp)


def test_population_stability_index_detects_shift():
    rng = np.random.default_rng(0)
    reference = rng.normal(0, 1, 2000)
    same_dist = rng.normal(0, 1, 2000)
    shifted = rng.normal(3, 1, 2000)

    psi_same = population_stability_index(reference, same_dist)
    psi_shifted = population_stability_index(reference, shifted)
    assert psi_same < 0.1
    assert psi_shifted > 0.25
    assert psi_shifted > psi_same


def test_retraining_scheduler_interval_and_event_trigger():
    sched = RetrainingScheduler(interval_seconds=100)
    now = time.time()
    assert sched.is_due("svc", now=now) is True
    sched.mark_trained("svc", when=now)
    assert sched.is_due("svc", now=now + 50) is False
    assert sched.is_due("svc", now=now + 150) is True
    assert sched.event_triggered_retrain_needed({"drifted": True}) is True
    assert sched.event_triggered_retrain_needed({"drifted": False}, confirmed_failure=True) is True
    assert sched.event_triggered_retrain_needed({"drifted": False}) is False


def test_deployment_gate_full_success_path_to_fleet_wide():
    gate = DeploymentGate("svc", min_required_cycles=3)
    assert gate.stage == RolloutStage.CANDIDATE

    gate.enter_shadow_mode()
    assert gate.stage == RolloutStage.SHADOW_MODE

    improved = gate.evaluate_shadow_mode(ShadowModeResult(candidate_metric=10.0, incumbent_metric=5.0, safety_margin_ok=True))
    assert improved is True
    assert gate.stage == RolloutStage.STAGED_ROLLOUT

    for _ in range(2):
        result = gate.observe_staged_cycle(anomaly_detected=False)
        assert gate.stage == RolloutStage.STAGED_ROLLOUT
    final = gate.observe_staged_cycle(anomaly_detected=False)
    assert final.stable
    assert gate.stage == RolloutStage.FLEET_WIDE
    assert gate.is_authorized_for_fleet()
    assert len(gate.history) >= 3


def test_deployment_gate_rejects_regression_and_never_reaches_fleet():
    gate = DeploymentGate("svc")
    gate.enter_shadow_mode()
    improved = gate.evaluate_shadow_mode(ShadowModeResult(candidate_metric=1.0, incumbent_metric=5.0, safety_margin_ok=True))
    assert improved is False
    assert gate.stage == RolloutStage.REJECTED
    assert not gate.is_authorized_for_fleet()


def test_deployment_gate_auto_rollback_on_anomaly_during_staged_rollout():
    gate = DeploymentGate("svc", min_required_cycles=5)
    gate.enter_shadow_mode()
    gate.evaluate_shadow_mode(ShadowModeResult(10.0, 5.0, True))
    assert gate.stage == RolloutStage.STAGED_ROLLOUT

    gate.observe_staged_cycle(anomaly_detected=False)
    result = gate.observe_staged_cycle(anomaly_detected=True)
    assert result.anomaly_detected
    assert gate.stage == RolloutStage.ROLLED_BACK
    assert not gate.is_authorized_for_fleet()


def test_deployment_gate_cannot_skip_shadow_mode():
    gate = DeploymentGate("svc")
    try:
        gate.evaluate_shadow_mode(ShadowModeResult(1.0, 0.0, True))
        assert False, "expected RuntimeError for skipping shadow mode"
    except RuntimeError:
        pass
