"""Tests for the dependency-free NumpyGRUForecaster (§8.4 PRIMARY
model, no torch) and the hybrid edge(Holt)+cloud(GRU) service path."""
import shutil
import tempfile
from pathlib import Path

import numpy as np

from common.mlops import ModelRegistry
from services.thermal_intelligence.model import NumpyGRUForecaster
from services.thermal_intelligence.service import ThermalIntelligenceService
from services.thermal_intelligence.train import generate_synthetic_thermal_fleet, train_and_register


def test_gru_gradient_matches_finite_difference():
    # Regression-style correctness check on the hand-derived BPTT: an
    # earlier implementation used numerical differencing (correct but
    # ~250x slower); this confirms the analytic version agrees with
    # numerical differencing to high precision on a real forward pass.
    rng = np.random.default_rng(0)
    series = 40 + 0.3 * np.arange(30) + rng.normal(0, 0.2, 30)
    f = NumpyGRUForecaster(seq_len=8, hidden_size=4, seed=0)
    norm = (series - series.mean()) / series.std()
    X, Y = f._make_windows(norm)

    y_pred, cache = f._forward_sequence(X[0])
    grads = f._backward_sequence(cache, dL_dy=1.0)

    eps = 1e-5
    idx = (0,)
    f.Wy[idx] += eps
    y_plus, _ = f._forward_sequence(X[0])
    f.Wy[idx] -= 2 * eps
    y_minus, _ = f._forward_sequence(X[0])
    f.Wy[idx] += eps
    numeric = (y_plus - y_minus) / (2 * eps)

    assert abs(grads["Wy"][idx] - numeric) < 1e-4


def test_gru_fits_fast_and_discriminates_rising_from_flat_series():
    import time

    rng = np.random.default_rng(1)
    rising = list(40 + 1.2 * np.arange(50) + rng.normal(0, 0.3, 50))
    flat = list(40 + rng.normal(0, 0.3, 50))

    t0 = time.time()
    f_rising = NumpyGRUForecaster(seq_len=8, hidden_size=6, thermal_limit_c=90.0, seed=1).fit(rising, epochs=100, lr=0.3)
    elapsed = time.time() - t0
    assert elapsed < 15.0, f"GRU training took {elapsed:.1f}s — should be well under 15s for this size"

    f_flat = NumpyGRUForecaster(seq_len=8, hidden_size=6, thermal_limit_c=90.0, seed=1).fit(flat, epochs=100, lr=0.3)

    rising_forecast = f_rising.forecast(horizon_minutes=10)
    flat_forecast = f_flat.forecast(horizon_minutes=10)
    assert rising_forecast.overheat_probability > flat_forecast.overheat_probability


def test_fleet_wide_pooled_training_generalizes_across_synthetic_robots():
    X, Y, x_mean, x_std, forecaster = generate_synthetic_thermal_fleet(n_robots=6, seed=2)
    assert len(X) > 0
    forecaster.fit_on_windows(X[:80], Y[:80], x_mean, x_std, epochs=40, lr=0.25)
    preds = np.array([forecaster._forward_sequence(x)[0] for x in X[80:120]])
    # A trained model should beat a "predict the mean" baseline on held-out windows.
    baseline_mae = float(np.mean(np.abs(Y[80:120] - Y[:80].mean())))
    model_mae = float(np.mean(np.abs(preds - Y[80:120])))
    assert model_mae < baseline_mae


def test_hybrid_service_cross_checks_edge_and_deep_forecasts():
    tmp = Path(tempfile.mkdtemp())
    try:
        registry = ModelRegistry(tmp)
        train_and_register(registry, seed=5, epochs=40)

        svc = ThermalIntelligenceService(thermal_limit_c=90.0, registry=registry, deep=True)
        assert svc.deep_model is not None

        rng = np.random.default_rng(3)
        for t in 40 + 1.0 * np.arange(15) + rng.normal(0, 0.2, 15):
            svc.observe("robot-1", "elbow", float(t))

        insight = svc.run("robot-1", joint_name="elbow", horizon_minutes=5.0)
        assert insight.payload["source"] == "edge_holt_linear"
        if len(svc._deep_histories.get("robot-1:elbow", [])) >= svc.deep_model.seq_len:
            assert "cloud_deep_forecast" in insight.payload
            assert insight.payload["cloud_deep_forecast"]["source"] == "cloud_gru"
    finally:
        shutil.rmtree(tmp)


def test_service_without_registry_still_works_edge_only():
    svc = ThermalIntelligenceService(thermal_limit_c=90.0)  # no registry -> deep_model stays None
    assert svc.deep_model is None
    for t in [50 + 0.5 * i for i in range(20)]:
        svc.observe("robot-1", "wrist", t)
    insight = svc.run("robot-1", joint_name="wrist")
    assert "cloud_deep_forecast" not in insight.payload


def test_execution_site_is_always_hybrid_matching_spec_placement_table():
    # §8.14 marks Thermal Intelligence "Hybrid (edge + cloud)" as an
    # architectural placement, not something that flips per-instance
    # based on whether a deep model happens to be loaded — matches
    # anomaly_detection's identical always-HYBRID pattern.
    svc_edge_only = ThermalIntelligenceService(thermal_limit_c=90.0)
    svc_with_deep = ThermalIntelligenceService(thermal_limit_c=90.0, deep=True)
    assert svc_edge_only.execution_site.value == "hybrid"
    assert svc_with_deep.execution_site.value == "hybrid"
