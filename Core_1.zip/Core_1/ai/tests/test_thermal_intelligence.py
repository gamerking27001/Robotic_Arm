"""Synthetic-data test for thermal_intelligence: a rising temperature
trend must produce increasing overheat probability and a decreasing
remaining-safe-operating-time; a flat/stable trend must stay low."""
from services.thermal_intelligence.model import HoltLinearThermalForecaster
from services.thermal_intelligence.service import ThermalIntelligenceService


def test_rising_trend_increases_overheat_probability():
    f = HoltLinearThermalForecaster(thermal_limit_c=90.0)
    # Steep rise that actually approaches the thermal limit within the
    # forecast horizon — a shallow rise correctly stays low-probability
    # (see test_stable_trend below for that boundary case).
    temps = [40 + 1.2 * i for i in range(40)]
    for t in temps:
        f.update(t)
    forecast = f.forecast(horizon_minutes=15)
    assert forecast.forecast_temp_c > temps[-1]
    assert forecast.overheat_probability > 0.5
    assert forecast.remaining_safe_operating_minutes is not None
    assert forecast.remaining_safe_operating_minutes >= 0


def test_stable_trend_reports_low_overheat_probability():
    f = HoltLinearThermalForecaster(thermal_limit_c=90.0)
    for _ in range(40):
        f.update(45.0)  # flat, well below limit
    forecast = f.forecast(horizon_minutes=10)
    assert forecast.overheat_probability < 0.2


def test_service_end_to_end_produces_bounded_confidence():
    svc = ThermalIntelligenceService(thermal_limit_c=90.0)
    for t in [50 + 0.5 * i for i in range(30)]:
        svc.observe("robot-1", "wrist", t)
    insight = svc.run("robot-1", joint_name="wrist", horizon_minutes=5.0)
    assert 0.0 <= insight.confidence_score <= 1.0
    assert "cooling_strategy_recommendation" in insight.payload


def test_service_handles_no_history_gracefully():
    svc = ThermalIntelligenceService()
    insight = svc.run("robot-2", joint_name="waist")
    assert insight.confidence_score < 0.2
    assert insight.requires_human_review is True
