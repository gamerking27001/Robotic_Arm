"""Synthetic-data test for energy_optimization: higher peak
acceleration and idle-hold time must predict higher energy per
cycle, matching the physically-motivated synthetic generator."""
import shutil
import tempfile
from pathlib import Path

import numpy as np

from common.mlops import ModelRegistry
from services.energy_optimization.model import EnergyOptimizationModel
from services.energy_optimization.train import generate_synthetic_profiles, train_and_register


def test_higher_accel_and_idle_hold_increase_predicted_energy():
    X, y = generate_synthetic_profiles(n=600, seed=1)
    model = EnergyOptimizationModel().fit(X, y)

    efficient = np.array([60.0, 100.0, 0.5, 3.0, 0.0])
    wasteful = np.array([60.0, 700.0, 4.5, 3.0, 2.5])

    e1 = model.report(efficient).energy_per_cycle_j
    e2 = model.report(wasteful).energy_per_cycle_j
    assert e2 > e1


def test_fit_quality_is_reasonable_on_synthetic_data():
    X, y = generate_synthetic_profiles(n=800, seed=2)
    model = EnergyOptimizationModel().fit(X, y)
    assert model._r2 > 0.5  # physically-motivated synthetic data should fit well


def test_service_flags_high_idle_hold_suggestion():
    tmp = Path(tempfile.mkdtemp())
    try:
        registry = ModelRegistry(tmp)
        train_and_register(registry, seed=3)
        import sys
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
        from services.energy_optimization.service import EnergyOptimizationService

        svc = EnergyOptimizationService(registry)
        insight = svc.run(
            "robot-1", peak_velocity_deg_s=90, peak_accel_deg_s2=200,
            payload_kg=1.0, cycle_time_s=4.0, idle_hold_s=2.5,
        )
        assert any("idle-hold" in s for s in insight.payload["suggestions"])
    finally:
        shutil.rmtree(tmp)
