"""Tests for motion_optimization_rl: env safety-bound enforcement,
policy shapes, PPO's mechanics running end-to-end, and — most
importantly — that the DeploymentGate correctly refuses to promote a
policy that doesn't beat the classical baseline (§8.7.4)."""
import shutil
import tempfile
from pathlib import Path

import numpy as np

from common.deployment_gate import RolloutStage
from common.mlops import ModelRegistry
from services.motion_optimization_rl.env import JointLimits, ReachEnv
from services.motion_optimization_rl.policy import GaussianMLPPolicy
from services.motion_optimization_rl.ppo import PPOTrainer, compute_gae
from services.motion_optimization_rl.train import run_full_pipeline


def test_env_action_is_always_bounded_within_joint_limits():
    limits = JointLimits.uniform(n_joints=3, max_velocity_deg_s=100.0, max_accel_deg_s2=300.0)
    env = ReachEnv(n_joints=3, limits=limits, max_steps=50, seed=0)
    env.reset()
    rng = np.random.default_rng(0)
    for _ in range(50):
        raw_action = rng.uniform(-5, 5, 3)  # deliberately out-of-range input
        obs, reward, done, info = env.step(raw_action)
        assert np.all(np.abs(env.joint_velocities_deg_s) <= limits.max_velocity_deg_s + 1e-6)
        if done:
            env.reset()


def test_env_flags_limit_violation_and_penalizes_reward():
    limits = JointLimits.uniform(n_joints=2, max_torque_nm=1e-6)  # force an immediate torque-margin violation
    env = ReachEnv(n_joints=2, limits=limits, max_steps=20, seed=0)
    env.reset()
    obs, reward, done, info = env.step(np.array([0.5, 0.5]))
    assert info["limit_violation"] is True
    assert info["torque_violation"] is True
    assert reward < 0


def test_env_defaults_to_real_robot_joint_limits_not_invented_placeholders():
    # §6.3/tools/robot_params.py — the real 6-DOF arm's actual limits,
    # not a uniform made-up scalar. Spot-check against the exact
    # values transcribed into robot_params.py from robot_config.hpp.
    env = ReachEnv(n_joints=6, seed=0)
    np.testing.assert_allclose(env.limits.max_torque_nm, [240.0, 300.0, 120.0, 24.0, 24.0, 12.0])
    np.testing.assert_allclose(env.limits.max_velocity_deg_s, [180.0, 180.0, 180.0, 300.0, 300.0, 300.0])
    assert env.limits.min_position_deg[0] == -170.0 and env.limits.max_position_deg[0] == 170.0


def test_position_limit_is_enforced_and_flagged_as_a_violation():
    # Regression test for a real gap this file fixed: position limits
    # were never enforced at all in an earlier version of env.py —
    # only velocity/acceleration were. Force a joint hard against its
    # real position limit and confirm it's both clamped AND flagged.
    limits = JointLimits.uniform(n_joints=1, position_range_deg=10.0, max_velocity_deg_s=1000.0, max_accel_deg_s2=1e6)
    env = ReachEnv(n_joints=1, limits=limits, max_steps=50, dt=1.0, seed=0)
    env.reset()
    env.joint_angles_deg = np.array([9.5])  # start just inside the +10 deg limit
    env.joint_velocities_deg_s = np.array([0.0])
    obs, reward, done, info = env.step(np.array([1.0]))  # full-speed toward the limit
    assert info["position_violation"] is True
    assert info["limit_violation"] is True
    assert env.joint_angles_deg[0] <= 10.0 + 1e-9  # clamped, never exceeds the real limit


def test_policy_output_is_within_action_bounds():
    policy = GaussianMLPPolicy(obs_dim=8, act_dim=3, hidden_size=8, seed=0)
    rng = np.random.default_rng(0)
    obs = rng.normal(0, 1, 8)
    action, log_prob = policy.act(obs, rng)
    assert action.shape == (3,)
    assert np.all(action >= -1.0) and np.all(action <= 1.0)
    assert np.isfinite(log_prob)


def test_gae_reduces_to_reasonable_values_for_a_short_episode():
    rewards = [-1, -1, -1, 10]
    values = [0, 0, 0, 0]
    dones = [False, False, False, True]
    adv, returns = compute_gae(rewards, values, dones, gamma=0.99, lam=0.95)
    assert len(adv) == 4
    assert returns[-1] > returns[0]  # reward-heavy final step should dominate its own return


def test_ppo_update_runs_and_returns_finite_stats():
    env = ReachEnv(n_joints=2, max_steps=20, seed=0)
    policy = GaussianMLPPolicy(env.state_dim, env.action_dim, hidden_size=8, seed=0)
    trainer = PPOTrainer(env, policy, lr=1e-3, seed=0)
    traj = trainer.collect_rollout(n_episodes=3)
    stats = trainer.update(traj, epochs=2)
    assert np.isfinite(stats["mean_reward"])
    assert 0.0 <= stats["clip_fraction"] <= 1.0
    assert np.all(np.isfinite(policy.W1))


def test_entropy_bonus_prevents_log_std_from_collapsing():
    # Regression test for the diagnosed entropy-collapse failure mode
    # (see ppo.py's closing scope note): without an entropy bonus,
    # log_std should drift measurably downward over many updates;
    # with one, it should stay roughly stable. Run enough iterations
    # for the effect to be visible.
    env = ReachEnv(n_joints=2, max_steps=20, seed=1)

    policy_no_entropy = GaussianMLPPolicy(env.state_dim, env.action_dim, hidden_size=8, seed=1)
    trainer_no_entropy = PPOTrainer(env, policy_no_entropy, lr=8e-3, entropy_coef=0.0, seed=1)
    for _ in range(25):
        traj = trainer_no_entropy.collect_rollout(n_episodes=8)
        trainer_no_entropy.update(traj, epochs=3)

    env2 = ReachEnv(n_joints=2, max_steps=20, seed=1)
    policy_with_entropy = GaussianMLPPolicy(env2.state_dim, env2.action_dim, hidden_size=8, seed=1)
    trainer_with_entropy = PPOTrainer(env2, policy_with_entropy, lr=8e-3, entropy_coef=0.05, seed=1)
    for _ in range(25):
        traj = trainer_with_entropy.collect_rollout(n_episodes=8)
        trainer_with_entropy.update(traj, epochs=3)

    # A meaningfully higher entropy bonus should leave log_std no
    # lower (and typically higher) than the zero-entropy-bonus run —
    # the direction the bonus is designed to push, checked directly
    # rather than assumed from the formula alone.
    assert np.mean(policy_with_entropy.log_std) >= np.mean(policy_no_entropy.log_std) - 0.05


def test_deployment_gate_never_promotes_an_undertrained_policy_to_fleet():
    tmp = Path(tempfile.mkdtemp())
    try:
        registry = ModelRegistry(tmp)
        # Deliberately tiny training budget -> candidate should not
        # beat the classical baseline -> gate must land on REJECTED,
        # never FLEET_WIDE. This is the safety property that matters
        # more than whether the policy is actually good.
        policy, gate, metrics = run_full_pipeline(registry, n_iterations=2, seed=0)
        assert gate.stage in (RolloutStage.REJECTED, RolloutStage.ROLLED_BACK, RolloutStage.FLEET_WIDE)
        if gate.stage != RolloutStage.FLEET_WIDE:
            assert registry.active_version("motion_optimization_rl") is None
        else:
            assert registry.active_version("motion_optimization_rl") is not None
        assert len(gate.history) >= 1
    finally:
        shutil.rmtree(tmp)
