#!/usr/bin/env python3
"""ai/tests/run_tests.py

pytest isn't installed in this sandbox (no network access to install
it) — every test file here is still written in ordinary pytest style
(function-named `test_*`, plain `assert`) so `pytest ai/tests/` works
unmodified wherever pytest IS available. This is a small, dependency-
free collector/runner that gives the same signal here and now: import
every test_*.py, call every test_* function, report pass/fail/error
per test, and exit non-zero on any failure.
"""
from __future__ import annotations

import importlib.util
import sys
import traceback
from pathlib import Path

THIS_DIR = Path(__file__).resolve().parent
AI_ROOT = THIS_DIR.parent
sys.path.insert(0, str(AI_ROOT))


def discover_test_files():
    return sorted(THIS_DIR.glob("test_*.py"))


def run() -> int:
    total = 0
    failed = 0
    for test_file in discover_test_files():
        spec = importlib.util.spec_from_file_location(test_file.stem, test_file)
        module = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(module)  # type: ignore[union-attr]
        except Exception:
            print(f"[IMPORT ERROR] {test_file.name}")
            traceback.print_exc()
            failed += 1
            total += 1
            continue

        test_fns = [
            getattr(module, name) for name in dir(module)
            if name.startswith("test_") and callable(getattr(module, name))
        ]
        for fn in test_fns:
            total += 1
            try:
                fn()
                print(f"  ok   {test_file.name}::{fn.__name__}")
            except AssertionError as e:
                failed += 1
                print(f"  FAIL {test_file.name}::{fn.__name__}  {e}")
            except Exception:
                failed += 1
                print(f"  ERROR {test_file.name}::{fn.__name__}")
                traceback.print_exc()

    print(f"\n{total - failed}/{total} tests passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(run())
