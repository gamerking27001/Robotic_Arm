#!/usr/bin/env python3
"""ai/examples/run_api_demo.py — wires every AIService onto the §17.2
versioned router (common/api.py) behind role-scoped tokens, and fires
a few requests to show the scoping/idempotency/error-taxonomy
behavior for real. A FastAPI app would just be a thin HTTP shim in
front of `router.dispatch(...)` — see common/api.py's docstring.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from common.api import ApiError, TokenScope, build_default_router  # noqa: E402
from common.insights_bus import get_default_bus  # noqa: E402
from common.mlops import ModelRegistry  # noqa: E402
from services.energy_optimization.service import EnergyOptimizationService  # noqa: E402
from services.fleet_intelligence.service import FleetIntelligenceService  # noqa: E402
from services.predictive_maintenance.service import PredictiveMaintenanceService  # noqa: E402


def main() -> None:
    registry = ModelRegistry(Path(__file__).resolve().parents[1] / "mlops_store")
    bus = get_default_bus()

    services = {
        "predictive_maintenance": PredictiveMaintenanceService(registry, bus=bus),
        "energy_optimization": EnergyOptimizationService(registry, bus=bus),
        "fleet_intelligence": FleetIntelligenceService(bus=bus),
    }
    router = build_default_router(services)

    operator_scope = TokenScope(role="operator", allowed_robot_ids={"robot-01"})
    admin_scope = TokenScope(role="fleet_administrator")

    print("Operator token, in-scope robot -> allowed:")
    services["predictive_maintenance"].observe("robot-01", "elbow", 3.0, 10.0, 60.0, 55.0)
    resp = router.dispatch("v1", "/predictive_maintenance/infer", operator_scope, robot_id="robot-01", joint_name="elbow")
    print(" ", resp["status"], resp["data"]["remaining_useful_life_hours"] if "remaining_useful_life_hours" in resp["data"] else resp["data"])

    print("\nOperator token, OUT-of-scope robot -> rejected:")
    try:
        router.dispatch("v1", "/predictive_maintenance/infer", operator_scope, robot_id="robot-02", joint_name="elbow")
    except ApiError as e:
        print(" ", e.code.value, "-", e.message)

    print("\nOperator token requesting a fleet-wide (admin-only) route -> rejected, admin token -> allowed:")
    try:
        router.dispatch("v1", "/fleet_intelligence/infer", operator_scope, robot_id="fleet")
    except ApiError:
        print("  operator: rejected as expected (fleet-wide requires broader scope in a real deployment)")
    resp = router.dispatch("v1", "/fleet_intelligence/infer", admin_scope, robot_id="fleet")
    print("  admin:", resp["status"])

    print("\nRepeated deploy call with the same idempotency key -> handler runs once:")
    r1 = router.dispatch("v1", "/energy_optimization/infer", admin_scope, robot_id="robot-01",
                          idempotency_key="deploy-42", peak_velocity_deg_s=90, peak_accel_deg_s2=200,
                          payload_kg=1.0, cycle_time_s=4.0, idle_hold_s=1.0)
    r2 = router.dispatch("v1", "/energy_optimization/infer", admin_scope, robot_id="robot-01",
                          idempotency_key="deploy-42", peak_velocity_deg_s=999, peak_accel_deg_s2=999,
                          payload_kg=999, cycle_time_s=999, idle_hold_s=999)
    print("  same response returned both times:", r1["data"]["payload"] == r2["data"]["payload"])


if __name__ == "__main__":
    main()
