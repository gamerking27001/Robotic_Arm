#!/usr/bin/env python3
"""ai/examples/run_tcp_bus_demo.py

Demonstrates two AI services genuinely communicating across a network
boundary: a "gateway-side" client publishes anomaly-detection
insights, a separate "cloud-side" client (a distinct TCP connection —
stands in for a genuinely separate process/machine) subscribes and
runs fleet_intelligence against what it received purely over the
socket, with no shared memory or direct function calls between the
two. This is common/tcp_bus.py's actual point: `InProcessInsightsBus`
can't span the edge/cloud boundary §8.14 describes; this can.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from common.mlops import ModelRegistry  # noqa: E402
from common.tcp_bus import TCPBusClient, TCPBusServer  # noqa: E402
from services.anomaly_detection.service import AnomalyDetectionService  # noqa: E402
from services.fleet_intelligence.service import FleetIntelligenceService  # noqa: E402


def main() -> None:
    registry = ModelRegistry(Path(__file__).resolve().parents[1] / "mlops_store")

    print("Starting TCP insights broker ...")
    server = TCPBusServer()
    server.start()
    print(f"  listening on {server.host}:{server.port}")

    print("\n'Gateway' process: connects, runs anomaly detection, publishes over the socket")
    gateway_bus = TCPBusClient(server.host, server.port)
    anomaly = AnomalyDetectionService(registry, bus=gateway_bus)
    for _ in range(60):
        anomaly.observe("robot-01", "elbow", current_a=60.0, torque_nm=320.0, temp_c=130.0, velocity=60.0)
    insight = anomaly.run("robot-01", joint_name="elbow")
    print(f"  published: anomaly_score={insight.payload['anomaly_score']} is_anomaly={insight.payload['is_anomaly']}")

    print("\n'Cloud' process: a SEPARATE socket connection, receives nothing until this publish happens")
    cloud_bus = TCPBusClient(server.host, server.port)
    time.sleep(0.3)  # let the connection register with the broker

    fleet = FleetIntelligenceService(bus=cloud_bus)
    # fleet_intelligence reads the CLOUD client's own local history —
    # populated purely from what crossed the socket after it connected,
    # confirming this insight really did travel gateway -> broker -> cloud.
    time.sleep(0.2)
    another_insight = anomaly.run("robot-01", joint_name="elbow")  # publish once more so the cloud client (connected after the first) has something in its window
    time.sleep(0.3)
    fleet_insight = fleet.run("fleet")
    print(f"  cloud-side fleet_intelligence sees {len(cloud_bus.history())} insight(s) that crossed the socket")
    print(f"  bottleneck candidates (computed entirely from received network data): {fleet_insight.payload['bottleneck_candidates']}")

    gateway_bus.close()
    cloud_bus.close()
    server.stop()
    print("\nDone — no shared Python object was used between the 'gateway' and 'cloud' services above.")


if __name__ == "__main__":
    main()
