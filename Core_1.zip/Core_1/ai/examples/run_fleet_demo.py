#!/usr/bin/env python3
"""ai/examples/run_fleet_demo.py

End-to-end demo: a synthetic 3-robot fleet streams telemetry (shaped
like dashboard/backend/main.py's TelemetryOut / JointTelemetryOut —
see common/schemas.py's docstring) through every AI service in
ai/services/, each service publishes onto the shared AI Insights Bus
(§8.2), and Fleet Intelligence + the Operator Assistant read the
aggregated result back out — the same "Decision Support Dashboard"
pattern §8.2's architecture diagram describes.

Run:
    python3 ai/train_all.py        # once, to populate ai/mlops_store/
    python3 ai/examples/run_fleet_demo.py
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402

from common.insights_bus import get_default_bus  # noqa: E402
from common.mlops import ModelRegistry  # noqa: E402
from services.anomaly_detection.service import AnomalyDetectionService  # noqa: E402
from services.digital_twin_intelligence.service import DigitalTwinIntelligenceService  # noqa: E402
from services.energy_optimization.service import EnergyOptimizationService  # noqa: E402
from services.fleet_intelligence.service import FleetIntelligenceService  # noqa: E402
from services.motion_optimization_rl.policy_service import MotionOptimizationService  # noqa: E402
from services.operator_assistant.service import OperatorAssistantService  # noqa: E402
from services.predictive_maintenance.service import PredictiveMaintenanceService  # noqa: E402
from services.thermal_intelligence.service import ThermalIntelligenceService  # noqa: E402
from services.workspace_intelligence.service import WorkspaceIntelligenceService  # noqa: E402

JOINT_NAMES = ["waist", "shoulder", "elbow", "wrist_pitch", "wrist_roll", "wrist_yaw"]
ROBOT_IDS = ["robot-01", "robot-02", "robot-03"]


def simulate_fleet_tick(rng: np.random.Generator, robot_id: str, wear_level: float):
    """One telemetry sample per joint for one robot. `wear_level` in
    [0, 1] shifts current/torque/temperature the same way
    services/predictive_maintenance/train.py's synthetic generator
    does, so a "worn" robot in this demo is a worn robot to every
    service watching it, not just predictive maintenance."""
    out = []
    for name in JOINT_NAMES:
        current = 2.0 + 1.5 * wear_level + rng.normal(0, 0.05)
        torque = 8.0 + 4.0 * wear_level + rng.normal(0, 0.2)
        temp = 35.0 + 45.0 * wear_level + rng.normal(0, 0.5)
        velocity = 60.0 + rng.normal(0, 2.0)
        out.append((name, current, torque, temp, velocity))
    return out


def main() -> None:
    registry = ModelRegistry(Path(__file__).resolve().parents[1] / "mlops_store")
    bus = get_default_bus()
    rng = np.random.default_rng(123)

    pm = PredictiveMaintenanceService(registry, bus=bus)
    thermal = ThermalIntelligenceService(bus=bus)
    energy = EnergyOptimizationService(registry, bus=bus)
    anomaly = AnomalyDetectionService(registry, bus=bus, deep=True)
    twin = DigitalTwinIntelligenceService(bus=bus)
    workspace = WorkspaceIntelligenceService(bus=bus)
    motion = MotionOptimizationService(registry, bus=bus)
    fleet = FleetIntelligenceService(bus=bus)
    assistant = OperatorAssistantService(bus=bus)

    wear_levels = {"robot-01": 0.05, "robot-02": 0.85, "robot-03": 0.2}  # robot-02 is near end-of-life

    print("=== Streaming synthetic telemetry through the AI/ML services layer (§8) ===\n")
    for step in range(60):
        for robot_id in ROBOT_IDS:
            wear = wear_levels[robot_id]
            for name, current, torque, temp, velocity in simulate_fleet_tick(rng, robot_id, wear):
                pm.observe(robot_id, name, current, torque, temp, velocity)
                thermal.observe(robot_id, name, temp)
                anomaly.observe(robot_id, name, current, torque, temp, velocity)

    print("--- Predictive Maintenance (§8.3): per-joint RUL for the worn robot ---")
    for name, *_ in simulate_fleet_tick(rng, "robot-02", 0.85):
        insight = pm.run("robot-02", joint_name=name)
        print(f"  robot-02/{name}: RUL={insight.payload.get('remaining_useful_life_hours')}h "
              f"conf={insight.confidence_score:.2f} review={insight.requires_human_review}")

    print("\n--- Thermal Intelligence (§8.4): worn robot's forecast ---")
    t_insight = thermal.run("robot-02", joint_name="elbow", horizon_minutes=5.0)
    print(f"  {t_insight.payload}")

    print("\n--- Anomaly Detection (§8.10): edge+deep cross-check per robot ---")
    for robot_id in ROBOT_IDS:
        a_insight = anomaly.run(robot_id, joint_name="elbow")
        print(f"  {robot_id}: score={a_insight.payload['anomaly_score']} anomaly={a_insight.payload['is_anomaly']}")

    print("\n--- Energy Optimization (§8.5) ---")
    e_insight = energy.run("robot-01", peak_velocity_deg_s=90, peak_accel_deg_s2=250, payload_kg=1.5, cycle_time_s=3.5, idle_hold_s=1.8)
    print(f"  {e_insight.payload}")

    print("\n--- Digital Twin Intelligence (§8.8) ---")
    twin_insight = twin.run("robot-01", twin_predicted_tcp_mm=[300.0, 120.0, 400.0], measured_tcp_mm=[303.5, 121.0, 400.2])
    print(f"  {twin_insight.payload}")

    print("\n--- Workspace Intelligence (§8.9): LiDAR scan with a human-shaped cluster ---")
    human_pts = (rng.normal([1.0, 1.0, 0.85], [0.1, 0.1, 0.5], size=(150, 3))).tolist()
    ws_insight = workspace.run("robot-01", points_xyz=human_pts)
    print(f"  human_present={ws_insight.payload['human_present']}, objects={ws_insight.payload['object_count']}")

    print("\n--- Motion Optimization / RL (§8.7): candidate trajectory suggestion ---")
    m_insight = motion.run("robot-01", observation=[0.1] * 11)
    print(f"  {m_insight.payload}")

    print("\n--- Fleet Intelligence (§8.11): cross-robot aggregation ---")
    f_insight = fleet.run("fleet")
    print(f"  maintenance priority (top 3): {f_insight.payload['maintenance_priority_ranking'][:3]}")
    print(f"  bottleneck candidates: {f_insight.payload['bottleneck_candidates']}")

    print("\n--- Operator Assistant (§8.12): grounded natural-language queries ---")
    for q in ["What maintenance is due next week?", "Which robot consumed the most power today?", "What is your favorite color?"]:
        a_insight = assistant.run("robot-02", question=q)
        print(f"  Q: {q}")
        if a_insight.payload["refused"]:
            print(f"    (refused — {a_insight.payload['reason']})")
        else:
            print(f"    A: {a_insight.payload['answer']}  [{len(a_insight.payload['citations'])} citation(s)]")

    print(f"\nTotal insights published to the bus this run: {len(bus.history(limit=100000))}")


if __name__ == "__main__":
    main()
