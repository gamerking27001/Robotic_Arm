#!/usr/bin/env python3
"""ai/examples/run_alerts_demo.py

Demonstrates common/persistence.py's alerting pipeline end-to-end:
insights crossing a threshold become alerts, repeated crossings don't
spam duplicates, an operator acknowledges one, and — the actual
point of using SQLite instead of an in-memory structure — the store
is closed and reopened to prove the alert genuinely persisted.
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from common.persistence import InsightStore  # noqa: E402
from common.schemas import InsightType, make_insight  # noqa: E402


def main() -> None:
    db_path = Path(tempfile.mkdtemp()) / "demo_alerts.db"
    print(f"Using on-disk SQLite store at {db_path}\n")

    store = InsightStore(db_path)

    print("Publishing a low-RUL predictive-maintenance insight 3 times in a row ...")
    for _ in range(3):
        store.save_insight(make_insight(
            service_id="predictive_maintenance", robot_id="robot-01", insight_type=InsightType.PREDICTIVE_MAINTENANCE,
            payload={"joint_name": "elbow", "remaining_useful_life_hours": 12.0}, confidence_score=0.85,
        ))
    alerts = store.list_alerts(robot_id="robot-01")
    print(f"  -> {len(alerts)} alert(s) generated (not 3 x 2 rules = 6 — deduplicated against still-open alerts)")
    for a in alerts:
        print(f"     [{a.severity}] {a.message}")

    print("\nAcknowledging the critical one ...")
    critical = next(a for a in alerts if a.severity == "critical")
    store.acknowledge_alert(critical.id, acknowledged_by="operator-jane")
    print(f"  -> unacknowledged remaining: {len(store.list_alerts(robot_id='robot-01', unacknowledged_only=True))}")

    print("\nClosing the store (simulates the dashboard backend process exiting) ...")
    store.close()

    print("Reopening the SAME db file (simulates a fresh process starting) ...")
    store2 = InsightStore(db_path)
    reloaded = store2.list_alerts(robot_id="robot-01")
    print(f"  -> {len(reloaded)} alert(s) still there, {sum(a.is_acknowledged for a in reloaded)} acknowledged")
    store2.close()

    print("\nDone — the alert survived the simulated restart because it's on disk, not in a Python dict.")


if __name__ == "__main__":
    main()
