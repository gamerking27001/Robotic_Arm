"""ai/services/thermal_intelligence/train.py

Trains ONE shared NumpyGRUForecaster on a synthetic fleet's worth of
per-joint thermal histories (§8.4 "Trained centrally per robot
model/family"), pooling windows across many series so the trained
weights generalize across robots rather than overfitting one robot's
specific baseline temperature.
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common.mlops import ModelRegistry  # noqa: E402
from services.thermal_intelligence.model import NumpyGRUForecaster  # noqa: E402


def generate_synthetic_thermal_fleet(n_robots: int = 10, seq_len: int = 10, seed: int = 11):
    """Per-robot thermal series: a baseline temperature plus a duty-
    cycle-driven ramp, some robots running hotter/faster than others
    — enough diversity that a shared model has to learn the general
    shape (ramp-then-plateau under load) rather than one robot's
    specific numbers."""
    rng = np.random.default_rng(seed)
    all_windows_x, all_windows_y = [], []
    pooled_values = []

    for _ in range(n_robots):
        baseline = rng.uniform(28, 38)
        ramp_rate = rng.uniform(0.1, 0.6)
        plateau = rng.uniform(55, 80)
        n_steps = rng.integers(60, 120)
        t = np.arange(n_steps)
        series = baseline + (plateau - baseline) * (1 - np.exp(-ramp_rate * t / 20.0)) + rng.normal(0, 0.4, n_steps)
        pooled_values.append(series)

    all_values = np.concatenate(pooled_values)
    x_mean, x_std = float(all_values.mean()), max(float(all_values.std()), 1e-6)

    forecaster = NumpyGRUForecaster(seq_len=seq_len, hidden_size=6, seed=seed)
    for series in pooled_values:
        norm = (series - x_mean) / x_std
        X, Y = forecaster._make_windows(norm)
        if len(X) == 0:
            continue
        all_windows_x.append(X)
        all_windows_y.append(Y)

    X = np.vstack(all_windows_x)
    Y = np.concatenate(all_windows_y)
    return X, Y, x_mean, x_std, forecaster


def train_and_register(registry: ModelRegistry, seed: int = 11, epochs: int = 80) -> NumpyGRUForecaster:
    X, Y, x_mean, x_std, forecaster = generate_synthetic_thermal_fleet(seed=seed)
    # Subsample for training-time tractability — the full pooled set
    # can run to several hundred windows; a few hundred iterations
    # over a representative subsample converges the shared weights
    # without a multi-minute training script.
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(X), size=min(120, len(X)), replace=False)
    forecaster.fit_on_windows(X[idx], Y[idx], x_mean, x_std, epochs=epochs, lr=0.25)

    preds = np.array([forecaster._forward_sequence(x)[0] for x in X])
    mae_normalized = float(np.mean(np.abs(preds - Y)))

    h = hashlib.sha256(X.tobytes() + Y.tobytes()).hexdigest()[:16]
    registry.register(
        service_id="thermal_intelligence_deep",
        artifact=forecaster,
        hyperparameters={"seq_len": forecaster.seq_len, "hidden_size": forecaster.hidden_size, "epochs": epochs},
        training_dataset_hash=h,
        metrics={"train_mae_normalized": mae_normalized, "n_windows": len(X)},
    )
    return forecaster


if __name__ == "__main__":
    reg = ModelRegistry(Path(__file__).resolve().parents[2] / "mlops_store")
    import time

    t0 = time.time()
    train_and_register(reg)
    print(f"trained in {time.time() - t0:.1f}s -> {reg.active_version('thermal_intelligence_deep')}")
