"""ai/services/thermal_intelligence/service.py — §8.4 as an AIService.

Hybrid edge+cloud execution, matching the spec's own placement table
exactly: "Distilled model at the edge for low-latency warning; full
model in the cloud for heat-map/fleet analysis." Concretely:

  - Edge path (always on): HoltLinearThermalForecaster. Genuinely
    zero-training, O(1)-state, real-time — this is the "distilled
    version deployable to the gateway" the spec asks for, not a
    placeholder for a real edge model.
  - Cloud path (`deep=True`, needs a registered
    thermal_intelligence_deep model): NumpyGRUForecaster, §8.4's
    PRIMARY recommended model family, trained centrally across a
    fleet (see train.py) — the "full model" providing the deeper,
    cross-robot-generalized forecast.

Both are real, trained, and cross-checked against each other, the
same pattern already used in anomaly_detection/service.py.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, Optional

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common.base_service import AIService  # noqa: E402
from common.mlops import ModelRegistry  # noqa: E402
from common.schemas import ExecutionSite, InsightType  # noqa: E402
from services.thermal_intelligence.model import HoltLinearThermalForecaster, NumpyGRUForecaster  # noqa: E402


class ThermalIntelligenceService(AIService):
    service_id = "thermal_intelligence"
    insight_type = InsightType.THERMAL_FORECAST
    execution_site = ExecutionSite.HYBRID  # §8.14: "Hybrid (edge + cloud)" — architectural placement, not conditional on whether a call happens to have a deep model loaded

    def __init__(self, thermal_limit_c: float = 90.0, bus=None, registry: Optional[ModelRegistry] = None, deep: bool = False, store=None):
        super().__init__(bus=bus, store=store)
        self.thermal_limit_c = thermal_limit_c
        self.deep = deep
        self._edge_forecasters: Dict[str, HoltLinearThermalForecaster] = {}
        self._deep_histories: Dict[str, list] = {}

        self.deep_model: Optional[NumpyGRUForecaster] = None
        if deep and registry is not None:
            version = registry.active_version("thermal_intelligence_deep")
            self.deep_model = registry.load_artifact(version) if version else None

    def _edge_forecaster_for(self, robot_id: str, joint_name: str) -> HoltLinearThermalForecaster:
        key = f"{robot_id}:{joint_name}"
        if key not in self._edge_forecasters:
            self._edge_forecasters[key] = HoltLinearThermalForecaster(thermal_limit_c=self.thermal_limit_c)
        return self._edge_forecasters[key]

    def observe(self, robot_id: str, joint_name: str, winding_temp_c: float) -> None:
        self._edge_forecaster_for(robot_id, joint_name).update(winding_temp_c)
        if self.deep_model is not None:
            key = f"{robot_id}:{joint_name}"
            hist = self._deep_histories.setdefault(key, [])
            hist.append(winding_temp_c)
            if len(hist) > self.deep_model.seq_len:
                hist.pop(0)

    def infer(self, robot_id: str, joint_name: str = "", horizon_minutes: float = 5.0, **kwargs: Any) -> Dict[str, Any]:
        edge_forecaster = self._edge_forecaster_for(robot_id, joint_name)
        try:
            edge_forecast = edge_forecaster.forecast(horizon_minutes)
        except RuntimeError:
            return self._result({"joint_name": joint_name, "note": "insufficient history"}, confidence_score=0.05)

        strategy = edge_forecaster.cooling_strategy(edge_forecast)
        margin = max(self.thermal_limit_c - edge_forecast.forecast_temp_c, 1.0)
        confidence = float(max(0.05, min(0.97, 1.0 - edge_forecast.forecast_interval_c / (2 * margin))))

        payload: Dict[str, Any] = {
            "joint_name": joint_name,
            "horizon_minutes": horizon_minutes,
            "forecast_temp_c": round(edge_forecast.forecast_temp_c, 2),
            "forecast_interval_c": round(edge_forecast.forecast_interval_c, 2),
            "overheat_probability": round(edge_forecast.overheat_probability, 4),
            "remaining_safe_operating_minutes": (
                round(edge_forecast.remaining_safe_operating_minutes, 1)
                if edge_forecast.remaining_safe_operating_minutes is not None
                else None
            ),
            "cooling_strategy_recommendation": strategy,
            "source": "edge_holt_linear",
        }

        if self.deep_model is not None:
            key = f"{robot_id}:{joint_name}"
            hist = self._deep_histories.get(key, [])
            if len(hist) >= self.deep_model.seq_len:
                self.deep_model._history = list(hist)
                deep_forecast = self.deep_model.forecast(horizon_minutes)
                payload["cloud_deep_forecast"] = {
                    "forecast_temp_c": round(deep_forecast.forecast_temp_c, 2),
                    "overheat_probability": round(deep_forecast.overheat_probability, 4),
                    "source": "cloud_gru",
                }
                # Cross-check: agreement between the two independent
                # models raises confidence; disagreement lowers it —
                # same cross-check principle as anomaly_detection.
                agree = abs(edge_forecast.forecast_temp_c - deep_forecast.forecast_temp_c) < 5.0
                confidence = float(min(0.97, confidence * 1.1)) if agree else float(confidence * 0.6)

        return self._result(payload, confidence)
