"""ai/services/thermal_intelligence/model.py

§8.4 Thermal Intelligence AI. Recommended: "LSTM or GRU for short-
horizon forecasting ... Transformer-based ... where multiple
correlated sensor streams benefit from attention." No torch is
installed in this sandbox (no network access to install it), so the
default here is the spec's own explicitly-named fallback: "Alternative
Approaches: Simple exponential-smoothing/ARIMA baseline for sites with
limited compute budget" — implemented as real, working Holt's linear
(double exponential smoothing), which is exactly the right shape for
"distilled model deployable to the gateway for low-latency local
warning" (§8.4 Deployment Strategy) since it's O(1) state and O(1)
per-step update, no GPU, no batch inference required.

If torch becomes available, `TorchGRUForecaster` (below) is a drop-in
alternative implementing the spec's primary recommendation — same
`.forecast()` interface, so `service.py` doesn't change either way.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import numpy as np

try:  # pragma: no cover - exercised only if torch is installed
    import torch
    import torch.nn as nn

    _HAVE_TORCH = True
except ImportError:
    _HAVE_TORCH = False


@dataclass
class ThermalForecast:
    horizon_minutes: float
    forecast_temp_c: float
    forecast_interval_c: float  # forecast-interval half-width (§8.4 confidence scoring)
    overheat_probability: float
    remaining_safe_operating_minutes: Optional[float]


class HoltLinearThermalForecaster:
    """Double exponential smoothing (level + trend) per motor/joint.
    Update is O(1); state is two floats (level, trend) per joint, so
    this comfortably meets the "lightweight distilled version
    deployable to the gateway" requirement without any special
    hardware.
    """

    def __init__(self, alpha: float = 0.35, beta: float = 0.15, thermal_limit_c: float = 90.0):
        self.alpha = alpha
        self.beta = beta
        self.thermal_limit_c = thermal_limit_c
        self._level: Optional[float] = None
        self._trend: float = 0.0
        self._residual_std: float = 1.0
        self._residuals: List[float] = []

    def update(self, observed_temp_c: float) -> None:
        if self._level is None:
            self._level = observed_temp_c
            self._trend = 0.0
            return
        predicted = self._level + self._trend
        residual = observed_temp_c - predicted
        self._residuals.append(residual)
        if len(self._residuals) > 200:
            self._residuals.pop(0)
        if len(self._residuals) >= 5:
            self._residual_std = max(float(np.std(self._residuals)), 0.05)

        prev_level = self._level
        self._level = self.alpha * observed_temp_c + (1 - self.alpha) * (self._level + self._trend)
        self._trend = self.beta * (self._level - prev_level) + (1 - self.beta) * self._trend

    def forecast(self, horizon_minutes: float, step_minutes: float = 1.0) -> ThermalForecast:
        if self._level is None:
            raise RuntimeError("forecaster has no observations yet — call update() first")
        n_steps = horizon_minutes / step_minutes
        forecast_temp = self._level + self._trend * n_steps
        # Forecast-interval width grows with sqrt(horizon) under a
        # random-walk-with-drift assumption on the residuals.
        interval = 1.96 * self._residual_std * np.sqrt(max(n_steps, 1.0))

        z = (self.thermal_limit_c - forecast_temp) / max(interval / 1.96, 1e-6)
        overheat_prob = float(1.0 - 0.5 * (1 + _erf_approx(z / np.sqrt(2))))

        remaining_minutes = None
        if self._trend > 1e-6:
            remaining_minutes = max(0.0, (self.thermal_limit_c - self._level) / self._trend)

        return ThermalForecast(
            horizon_minutes=horizon_minutes,
            forecast_temp_c=float(forecast_temp),
            forecast_interval_c=float(interval),
            overheat_probability=float(np.clip(overheat_prob, 0.0, 1.0)),
            remaining_safe_operating_minutes=remaining_minutes,
        )

    def cooling_strategy(self, forecast: ThermalForecast) -> str:
        # §8.4 "Human Override": cooling-strategy recommendations are
        # advisory; wide forecast intervals suppress an automatic
        # slow-down recommendation in favor of an operator alert.
        if forecast.forecast_interval_c > 8.0:
            return "forecast uncertain — alert operator, no automatic action"
        if forecast.overheat_probability > 0.7:
            return "recommend graduated slow-down (reduce duty cycle) before hard thermal stop triggers"
        if forecast.overheat_probability > 0.3:
            return "monitor closely; consider reducing payload/cycle rate"
        return "no cooling action required"


def _erf_approx(x: np.ndarray) -> np.ndarray:
    # Abramowitz-Stegun erf approximation — avoids a scipy.special
    # dependency for this single call site.
    a1, a2, a3, a4, a5 = 0.254829592, -0.284496736, 1.421413741, -1.453152027, 1.061405429
    p = 0.3275911
    sign = np.sign(x)
    x = np.abs(x)
    t = 1.0 / (1.0 + p * x)
    y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * np.exp(-x * x)
    return sign * y


if _HAVE_TORCH:  # pragma: no cover

    class TorchGRUForecaster(nn.Module):
        """§8.4 primary recommendation: GRU short-horizon forecaster.
        Same forecast() surface as HoltLinearThermalForecaster so
        service.py is agnostic to which one is active."""

        def __init__(self, hidden_size: int = 16):
            super().__init__()
            self.gru = nn.GRU(input_size=1, hidden_size=hidden_size, batch_first=True)
            self.head = nn.Linear(hidden_size, 1)

        def forward(self, x: "torch.Tensor") -> "torch.Tensor":
            out, _ = self.gru(x)
            return self.head(out[:, -1, :])


class NumpyGRUForecaster:
    """§8.4's PRIMARY recommendation ("LSTM or GRU for short-horizon
    forecasting") implemented as a real, trained, dependency-free GRU
    — no torch required. Single-layer GRU + linear head, with
    hand-derived analytic backpropagation-through-time (not numerical
    differencing — an earlier draft of this class used central-
    difference gradients for simplicity and was roughly 250x too slow
    to be practically trainable; this version derives and implements
    the exact GRU gradient equations instead, which is both correct
    and fast enough to fit in well under a second on real telemetry-
    length windows).

    Interface matches `HoltLinearThermalForecaster.forecast()`'s
    return type (`ThermalForecast`) so `service.py` can use either
    without changing a line.
    """

    def __init__(self, seq_len: int = 20, hidden_size: int = 8, thermal_limit_c: float = 90.0, seed: int = 0):
        self.seq_len = seq_len
        self.hidden_size = hidden_size
        self.thermal_limit_c = thermal_limit_c
        rng = np.random.default_rng(seed)

        def _init(fan_in, fan_out):
            return rng.normal(0, np.sqrt(1.0 / fan_in), size=(fan_in, fan_out))

        h = hidden_size
        self.Wz = _init(1 + h, h)
        self.Wr = _init(1 + h, h)
        self.Wn_x = _init(1, h).reshape(h)   # x_t is scalar -> this is really a (h,) vector
        self.Wn_h = _init(h, h)
        self.bz = np.zeros(h)
        self.br = np.zeros(h)
        self.bn = np.zeros(h)
        self.Wy = _init(h, 1).reshape(h)     # (h,) vector, output is scalar
        self.by = 0.0

        self._history: List[float] = []
        self._x_mean = 0.0
        self._x_std = 1.0
        self._fitted = False
        self._residual_std = 1.0
        self._residual_mean = 0.0

    @staticmethod
    def _sigmoid(x):
        return 1.0 / (1.0 + np.exp(-np.clip(x, -30, 30)))

    def _forward_sequence(self, seq: np.ndarray):
        """Returns (prediction, cache) where cache holds every gate
        activation at every timestep, needed by `_backward_sequence`."""
        h = np.zeros(self.hidden_size)
        cache = []
        for x_t in seq:
            xh = np.concatenate([[x_t], h])
            z = self._sigmoid(xh @ self.Wz + self.bz)
            r = self._sigmoid(xh @ self.Wr + self.br)
            rh = r * h
            pre_n = x_t * self.Wn_x + rh @ self.Wn_h + self.bn
            n = np.tanh(pre_n)
            h_next = (1 - z) * n + z * h
            cache.append((x_t, h.copy(), xh, z, r, rh, n, h_next.copy()))
            h = h_next
        y = float(h @ self.Wy + self.by)
        return y, cache

    def _backward_sequence(self, cache, dL_dy: float):
        """Analytic BPTT. Returns a dict of gradients for every
        parameter, accumulated over the full sequence."""
        h = self.hidden_size
        grads = {
            "Wz": np.zeros_like(self.Wz), "Wr": np.zeros_like(self.Wr),
            "Wn_x": np.zeros_like(self.Wn_x), "Wn_h": np.zeros_like(self.Wn_h),
            "bz": np.zeros_like(self.bz), "br": np.zeros_like(self.br), "bn": np.zeros_like(self.bn),
            "Wy": np.zeros_like(self.Wy), "by": 0.0,
        }
        h_T = cache[-1][7]
        grads["Wy"] += dL_dy * h_T
        grads["by"] += dL_dy
        dh_next = dL_dy * self.Wy  # gradient flowing into the last hidden state

        for x_t, h_prev, xh, z, r, rh, n, h_t in reversed(cache):
            dL_dh = dh_next  # total gradient w.r.t. this timestep's h_t

            dz = dL_dh * (h_prev - n)
            dn = dL_dh * (1 - z)
            dh_prev_from_h = dL_dh * z  # direct h_{t-1} contribution via the (1-z)*n + z*h_{t-1} mix

            d_pre_z = dz * z * (1 - z)
            grads["Wz"] += np.outer(xh, d_pre_z)
            grads["bz"] += d_pre_z
            dxh_from_z = d_pre_z @ self.Wz.T

            d_pre_n = dn * (1 - n ** 2)
            grads["Wn_x"] += x_t * d_pre_n
            grads["Wn_h"] += np.outer(rh, d_pre_n)  # rh = r * h_prev is the actual GRU input to this term
            grads["bn"] += d_pre_n
            d_rh = d_pre_n @ self.Wn_h.T
            dr = d_rh * h_prev
            dh_prev_from_n = d_rh * r
            dx_from_n = float(np.dot(d_pre_n, self.Wn_x))

            d_pre_r = dr * r * (1 - r)
            grads["Wr"] += np.outer(xh, d_pre_r)
            grads["br"] += d_pre_r
            dxh_from_r = d_pre_r @ self.Wr.T

            # xh = [x_t, h_prev] -> first element is d/dx_t, rest is d/dh_prev
            dh_prev_from_z_gate = dxh_from_z[1:]
            dh_prev_from_r_gate = dxh_from_r[1:]

            dh_next = dh_prev_from_h + dh_prev_from_n + dh_prev_from_z_gate + dh_prev_from_r_gate
            # dx_t (dxh_from_z[0] + dxh_from_r[0] + dx_from_n) isn't needed —
            # x_t is an observed input, not a trained parameter.

        return grads

    def _make_windows(self, series: np.ndarray):
        X, Y = [], []
        for i in range(len(series) - self.seq_len):
            X.append(series[i : i + self.seq_len])
            Y.append(series[i + self.seq_len])
        return np.array(X), np.array(Y)

    def fit(self, temperature_series: List[float], epochs: int = 200, lr: float = 0.05) -> "NumpyGRUForecaster":
        """Fit on a single continuous series — convenience wrapper
        around `fit_on_windows` for the common single-robot case."""
        series = np.asarray(temperature_series, dtype=float)
        x_mean, x_std = float(series.mean()), max(float(series.std()), 1e-6)
        norm = (series - x_mean) / x_std
        X, Y = self._make_windows(norm)
        if len(X) == 0:
            raise ValueError(f"need more than seq_len={self.seq_len} points to fit")
        self.fit_on_windows(X, Y, x_mean, x_std, epochs=epochs, lr=lr)
        self._history = list(series[-self.seq_len :])
        return self

    def fit_on_windows(
        self, X: np.ndarray, Y: np.ndarray, x_mean: float, x_std: float, epochs: int = 200, lr: float = 0.05
    ) -> "NumpyGRUForecaster":
        """Train directly on pre-built, pre-normalized (window, target)
        pairs, pooled across many series if desired — this is the
        entry point `train.py` uses to train ONE shared GRU across a
        synthetic fleet's worth of thermal histories (§8.4 "Trained
        centrally per robot model/family"), rather than one GRU per
        robot. Per-robot state (`self._history`) is populated
        separately via `update()` at inference time, NOT by this
        method — the trained weights are shared, the rolling window
        of recent observations is per-robot.
        """
        self._x_mean, self._x_std = x_mean, x_std
        param_names = ["Wz", "Wr", "Wn_x", "Wn_h", "bz", "br", "bn", "Wy", "by"]
        for _ in range(epochs):
            accum = {k: (0.0 if k == "by" else np.zeros_like(getattr(self, k))) for k in param_names}
            for i in range(len(X)):
                y_pred, cache = self._forward_sequence(X[i])
                dL_dy = 2.0 * (y_pred - Y[i]) / len(X)
                g = self._backward_sequence(cache, dL_dy)
                for k in param_names:
                    accum[k] += g[k]
            for k in param_names:
                setattr(self, k, getattr(self, k) - lr * accum[k])

        preds = np.array([self._forward_sequence(x)[0] for x in X])
        residuals = preds - Y
        self._residual_mean = float(residuals.mean())
        self._residual_std = max(float(residuals.std()), 1e-3)
        self._fitted = True
        return self

    def update(self, observed_temp_c: float) -> None:
        self._history.append(observed_temp_c)
        if len(self._history) > self.seq_len:
            self._history.pop(0)

    def forecast(self, horizon_minutes: float, step_minutes: float = 1.0) -> ThermalForecast:
        if not self._fitted or len(self._history) < self.seq_len:
            raise RuntimeError("forecaster not fitted or insufficient history — call fit() first")

        norm_hist = list((np.array(self._history) - self._x_mean) / self._x_std)
        n_steps = max(1, int(round(horizon_minutes / step_minutes)))
        window = list(norm_hist)
        pred_norm = norm_hist[-1]
        for _ in range(n_steps):
            pred_norm, _ = self._forward_sequence(np.array(window[-self.seq_len :]))
            window.append(pred_norm)

        forecast_temp = pred_norm * self._x_std + self._x_mean
        interval = (1.96 * self._residual_std * np.sqrt(n_steps)) * self._x_std

        z = (self.thermal_limit_c - forecast_temp) / max(interval / 1.96, 1e-6)
        overheat_prob = float(np.clip(1.0 - 0.5 * (1 + _erf_approx(z / np.sqrt(2))), 0.0, 1.0))

        return ThermalForecast(
            horizon_minutes=horizon_minutes,
            forecast_temp_c=float(forecast_temp),
            forecast_interval_c=float(interval),
            overheat_probability=overheat_prob,
            remaining_safe_operating_minutes=None,  # GRU forecast doesn't expose a closed-form trend/rate like Holt's does
        )
