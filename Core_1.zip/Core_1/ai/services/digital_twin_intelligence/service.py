"""ai/services/digital_twin_intelligence/service.py

§8.8 Digital Twin Intelligence AI. "Recommended Models: Statistical
residual monitoring (twin-predicted state compared against measured
state) as the primary method; lightweight anomaly-detection model
layered on top for pattern-level drift."

The residual monitor compares the Digital Twin's forward-kinematics
prediction (what robotic_arm_core's `arm::kinematics::DhKinematics`
would produce for the commanded joint angles — see
include/kinematics/dh_kinematics.hpp) against measured joint state.
This service takes both vectors directly rather than recomputing FK
itself, so it stays decoupled from the C++ kinematics implementation
(matches §8.2's "independently deployable and testable" service
boundary) while still consuming its output.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import numpy as np  # noqa: E402

from common.base_service import AIService  # noqa: E402
from common.mlops import population_stability_index  # noqa: E402
from common.schemas import ExecutionSite, InsightType  # noqa: E402


class DigitalTwinIntelligenceService(AIService):
    service_id = "digital_twin_intelligence"
    insight_type = InsightType.DIGITAL_TWIN_DEVIATION
    execution_site = ExecutionSite.HYBRID  # edge for the real-time residual check, cloud for trend

    def __init__(self, deviation_alert_threshold_mm: float = 2.0, bus=None):
        super().__init__(bus=bus)
        self.deviation_alert_threshold_mm = deviation_alert_threshold_mm
        self._residual_history: Dict[str, List[float]] = {}

    def infer(
        self,
        robot_id: str,
        twin_predicted_tcp_mm: Optional[List[float]] = None,
        measured_tcp_mm: Optional[List[float]] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        if twin_predicted_tcp_mm is None or measured_tcp_mm is None:
            return self._result({"note": "missing twin/measured pose"}, confidence_score=0.0)

        predicted = np.asarray(twin_predicted_tcp_mm, dtype=float)
        measured = np.asarray(measured_tcp_mm, dtype=float)
        deviation_mm = float(np.linalg.norm(predicted - measured))

        history = self._residual_history.setdefault(robot_id, [])
        history.append(deviation_mm)
        if len(history) > 500:
            history.pop(0)

        drifted = False
        psi = 0.0
        if len(history) >= 60:
            reference = np.array(history[: len(history) // 2])
            current = np.array(history[len(history) // 2 :])
            psi = population_stability_index(reference, current, bins=8)
            drifted = psi > 0.25

        needs_recalibration = deviation_mm > self.deviation_alert_threshold_mm or drifted
        # Deviation score doubles as the confidence signal, per spec:
        # a LOW deviation score IS high confidence the twin remains
        # accurate, so we invert it for the insight's confidence_score.
        confidence = float(np.clip(1.0 - deviation_mm / (5 * self.deviation_alert_threshold_mm), 0.02, 0.99))

        payload = {
            "deviation_mm": round(deviation_mm, 3),
            "drift_psi": round(psi, 4),
            "recalibration_recommended": needs_recalibration,
            # §8.8 Human Override: recalibration is always operator-
            # initiated via the guided workflow — never triggered here.
            "note": "recalibration requires operator-initiated guided workflow (§5.6); never automatic",
        }
        return self._result(payload, confidence)
