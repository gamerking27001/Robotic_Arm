"""ai/services/workspace_intelligence/model.py

§8.9 Workspace Intelligence AI (LiDAR). "Recommended Models:
Lightweight 3D object detection on point-cloud/voxel representations
(e.g., PointPillars-class architectures) ... Alternative Approaches:
classical clustering/segmentation for simpler static-obstacle
mapping."

A PointPillars-class detector needs a labeled industrial point-cloud
training set and a GPU, neither of which exists in this environment —
same honest constraint the existing vision/object_detection module
in this repo already documents for 2D YOLO detection. This module
implements the spec's own named alternative for real: DBSCAN
clustering over a raw point cloud, followed by a rule-based classifier
over each cluster's geometric signature (footprint, height, aspect
ratio, point density) into the output categories §8.9 lists (human,
box, pallet, machine, conveyor, forklift, robot). Swap
`GeometricClusterClassifier` for a trained PointPillars model without
touching service.py — same `.classify()` -> List[WorkspaceObject]
interface.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np
from sklearn.cluster import DBSCAN

CLASS_NAMES = ("human", "box", "pallet", "machine", "conveyor", "forklift", "robot", "unknown")


@dataclass
class WorkspaceObject:
    class_name: str
    confidence: float
    centroid_m: np.ndarray
    footprint_m2: float
    height_m: float
    point_count: int


class GeometricClusterClassifier:
    """DBSCAN clustering + rule-based geometric classification.
    Deliberately conservative on the human class per §8.9's Human
    Override rule: "low-confidence human classification defaults to
    the conservative (safety-zone-triggering) interpretation" — this
    class only ever *raises* toward "human" under ambiguity, never
    away from it.
    """

    def __init__(self, eps_m: float = 0.25, min_samples: int = 8):
        self.eps_m = eps_m
        self.min_samples = min_samples

    def classify(self, points_xyz: np.ndarray) -> List[WorkspaceObject]:
        if len(points_xyz) == 0:
            return []
        labels = DBSCAN(eps=self.eps_m, min_samples=self.min_samples).fit_predict(points_xyz)
        objects: List[WorkspaceObject] = []
        for label in set(labels):
            if label == -1:  # DBSCAN noise label — not a real object
                continue
            cluster = points_xyz[labels == label]
            objects.append(self._classify_cluster(cluster))
        return objects

    def _classify_cluster(self, cluster: np.ndarray) -> WorkspaceObject:
        centroid = cluster.mean(axis=0)
        xy_span = cluster[:, :2].max(axis=0) - cluster[:, :2].min(axis=0)
        footprint = float(max(xy_span[0], 1e-3) * max(xy_span[1], 1e-3))
        height = float(cluster[:, 2].max() - cluster[:, 2].min())
        aspect = float(max(xy_span) / max(min(xy_span), 1e-3))
        n = len(cluster)

        # Rule-based geometric signature classification — heights and
        # footprints are the dominant discriminators for a top-down
        # industrial LiDAR scan, consistent with §8.9's stated
        # limitation ("distinguishing a human from a narrow fixture").
        candidates = []
        if 1.4 <= height <= 2.1 and footprint <= 0.6 and aspect <= 2.5:
            candidates.append(("human", 0.55))
        if 0.3 <= height <= 1.8 and footprint <= 4.0 and 0.8 <= aspect <= 4.0 and n > 40:
            candidates.append(("forklift", 0.5))
        if height <= 0.3 and footprint > 0.5:
            candidates.append(("pallet", 0.7))
        if 0.2 <= height <= 1.2 and footprint <= 1.0:
            candidates.append(("box", 0.65))
        if height > 2.1 and footprint > 1.0:
            candidates.append(("machine", 0.55))
        if height <= 1.0 and footprint > 4.0:
            candidates.append(("conveyor", 0.5))

        if not candidates:
            class_name, conf = "unknown", 0.3
        else:
            class_name, conf = max(candidates, key=lambda c: c[1])

        # Human-safety conservatism: ANY ambiguity (more than one
        # candidate, or low top confidence) that includes a
        # human-compatible geometric signature promotes the whole
        # detection to "human" — never the reverse.
        human_compatible = 1.2 <= height <= 2.2 and footprint <= 0.8
        if human_compatible and (class_name != "human" or conf < 0.7):
            class_name, conf = "human", max(conf, 0.4)

        return WorkspaceObject(
            class_name=class_name,
            confidence=conf,
            centroid_m=centroid,
            footprint_m2=footprint,
            height_m=height,
            point_count=n,
        )
