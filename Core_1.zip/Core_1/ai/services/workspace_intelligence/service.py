"""ai/services/workspace_intelligence/service.py — §8.9 as an
AIService. Edge/gateway execution (human-detection latency directly
affects safety-zone responsiveness). Explicit, structural note per
§6.3 and §8.9 Human Override: this service's output feeds
software-level safety-zone AWARENESS only. It is never a substitute
for a hardware-rated safety function, and this file contains no path
to the E-stop/STO chain (ros2_ws/src/estop_controller) at all.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import numpy as np  # noqa: E402

from common.base_service import AIService  # noqa: E402
from common.schemas import ExecutionSite, InsightType  # noqa: E402
from services.workspace_intelligence.model import GeometricClusterClassifier  # noqa: E402


class WorkspaceIntelligenceService(AIService):
    service_id = "workspace_intelligence"
    insight_type = InsightType.WORKSPACE_OBJECT
    execution_site = ExecutionSite.EDGE

    def __init__(self, eps_m: float = 0.25, min_samples: int = 8, bus=None):
        super().__init__(bus=bus)
        self.classifier = GeometricClusterClassifier(eps_m=eps_m, min_samples=min_samples)

    def infer(self, robot_id: str, points_xyz: List[List[float]] | None = None, **kwargs: Any) -> Dict[str, Any]:
        points = np.asarray(points_xyz if points_xyz is not None else [], dtype=float)
        objects = self.classifier.classify(points)

        human_present = any(o.class_name == "human" for o in objects)
        overall_confidence = float(np.mean([o.confidence for o in objects])) if objects else 0.5

        payload = {
            "object_count": len(objects),
            "human_present": human_present,  # drives conservative safety-zone-awareness upstream, not shown here
            "objects": [
                {
                    "class_name": o.class_name,
                    "confidence": round(o.confidence, 3),
                    "centroid_m": [round(v, 3) for v in o.centroid_m.tolist()],
                    "footprint_m2": round(o.footprint_m2, 3),
                    "height_m": round(o.height_m, 3),
                    "point_count": o.point_count,
                }
                for o in objects
            ],
        }
        return self._result(payload, overall_confidence)
