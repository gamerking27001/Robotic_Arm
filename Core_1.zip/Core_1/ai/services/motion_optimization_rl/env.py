"""ai/services/motion_optimization_rl/env.py

§8.7.1 "Training happens entirely inside the Simulation Engine, never
against the physical robot" and §8.7.3's exact state/action/reward
design. This repo's real simulation engine lives in
`simulation/mujoco` and `simulation/coppeliasim` (full physics,
requires those external simulators to actually run) — this env is a
lightweight, dependency-free numpy stand-in exposing the SAME
state/action/reward contract described in §8.7.3, so the RL pipeline
in this package (ppo.py, train.py) is real and runnable end-to-end in
any environment, while staying a drop-in replacement target for the
real MuJoCo/CoppeliaSim-backed environment later (same `step()` /
`reset()` / observation and action shapes).

Joint limits — the safety-critical numbers the policy's action space
is bounded by — come from `tools/robot_params.py`, the SAME single
canonical source `ros2_ws/src/robot_description/scripts/generate_urdf.py`,
`simulation/mujoco/generate_mjcf.py`, and `cad/freecad/generate_arm_cad.py`
already import from, rather than a separately-invented set of numbers.
This was a real integration gap in an earlier version of this file —
it used a uniform, made-up `JointLimits(max_velocity_deg_s=120, ...)`
scalar applied identically to every joint, when the real 6-DOF arm's
joints range from 180 to 300 deg/s and 12 to 300 Nm peak torque
(§6.3's 1.5x-margin-inclusive `peak_output_torque_nm`, transcribed
into `tools/robot_params.py`'s new `PEAK_TORQUE_NM` from
`include/core/robot_config.hpp`'s `kJointSpecs` — see that module's
docstring for the exact provenance). Fixed here.

A second real gap fixed in the same pass: joint POSITION limits were
never enforced at all in `step()` — only velocity/acceleration were
clipped. A policy could previously drive `joint_angles_deg` to an
arbitrarily large value with no penalty, which is not a real
constraint any physical or simulated arm actually has. Now enforced
and treated as a limit violation, same severity as a torque violation.

Task: point-to-point reaching. Defaults to the real arm's full 6-DOF
joint set (`n_joints=None` → `tools.robot_params.NUM_JOINTS`); pass a
smaller `n_joints` to train faster on a joint subset for development
(uses the first N of the real 6 joints' limits, not synthetic ones).
"""
from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "tools"))
import robot_params  # noqa: E402


@dataclass
class JointLimits:
    """Per-joint safety bounds, as numpy arrays (one entry per joint).
    Use `from_robot_params()` for the real arm's actual limits (the
    default `ReachEnv` uses), or `uniform()` for a synthetic scenario
    (tests deliberately forcing a violation, a smaller joint count for
    a fast demo unrelated to the real robot's specific numbers)."""

    min_position_deg: np.ndarray
    max_position_deg: np.ndarray
    max_velocity_deg_s: np.ndarray
    max_torque_nm: np.ndarray
    max_accel_deg_s2: np.ndarray

    @classmethod
    def from_robot_params(cls, n_joints: Optional[int] = None) -> "JointLimits":
        n = n_joints or robot_params.NUM_JOINTS
        if n > robot_params.NUM_JOINTS:
            raise ValueError(f"n_joints={n} exceeds the real robot's {robot_params.NUM_JOINTS} joints")
        limits = robot_params.JOINT_LIMITS[:n]
        return cls(
            min_position_deg=np.array([lim[0] for lim in limits], dtype=float),
            max_position_deg=np.array([lim[1] for lim in limits], dtype=float),
            max_velocity_deg_s=np.array([lim[2] for lim in limits], dtype=float),
            max_torque_nm=np.array(robot_params.PEAK_TORQUE_NM[:n], dtype=float),
            # No per-joint max-acceleration parameter exists anywhere
            # in this repo's canonical data (robot_config.hpp doesn't
            # specify one either) — this is a documented, uniform
            # engineering default, not transcribed from a source.
            max_accel_deg_s2=np.full(n, 400.0),
        )

    @classmethod
    def uniform(
        cls,
        n_joints: int,
        max_velocity_deg_s: float = 120.0,
        max_accel_deg_s2: float = 400.0,
        max_torque_nm: float = 40.0,
        position_range_deg: float = 180.0,
    ) -> "JointLimits":
        """Synthetic, uniform-across-joints limits — for tests/demos
        that deliberately want a controlled scenario decoupled from
        the real robot's specific per-joint numbers (e.g. forcing an
        immediate torque violation with a tiny max_torque_nm)."""
        return cls(
            min_position_deg=np.full(n_joints, -position_range_deg),
            max_position_deg=np.full(n_joints, position_range_deg),
            max_velocity_deg_s=np.full(n_joints, max_velocity_deg_s),
            max_torque_nm=np.full(n_joints, max_torque_nm),
            max_accel_deg_s2=np.full(n_joints, max_accel_deg_s2),
        )


class ReachEnv:
    """State (§8.7.3): joint angles and velocities, TCP-proxy pose
    (here: forward sum of joint angles, a 1D stand-in for a full FK
    chain — see the Note below), target waypoint, torque margin, and
    a collision-distance estimate (simplified to distance from a
    fixed keep-out joint-angle region).

    Action (§8.7.3): per-joint velocity delta, BOUNDED within the
    same joint position/velocity/acceleration/torque limits the
    Motion Planner already enforces (JointLimits above, real per-joint
    values by default) — enforced by clipping in `step()`, exactly the
    "deliberate safety design choice" the spec describes: the policy
    cannot request a motion the platform would not already accept
    from a human-authored program.

    Reward (§8.7.3): weighted sum of negative cycle time (a per-step
    time penalty), a negative jerk/smoothness penalty, a large
    negative penalty for any collision/limit violation, and a
    completion bonus for reaching the target within tolerance.

    Note on fidelity: this is intentionally a simplified point-mass /
    integrator model of joint dynamics, not the real DH/rigid-body
    kinematics in include/kinematics/dh_kinematics.hpp — swapping in
    that engine (or the real MuJoCo backend in simulation/mujoco) is
    future work flagged honestly here rather than glossed over. What
    IS real: the joint limits themselves, and the fact that the policy
    genuinely cannot exceed them, in either position, velocity, or
    torque.
    """

    def __init__(
        self,
        n_joints: Optional[int] = None,
        limits: Optional[JointLimits] = None,
        dt: float = 0.05,
        max_steps: int = 200,
        target_tolerance_deg: float = 2.0,
        keepout_center_deg: float | None = None,
        keepout_radius_deg: float = 15.0,
        seed: int = 0,
    ):
        self.n_joints = n_joints or robot_params.NUM_JOINTS
        self.limits = limits or JointLimits.from_robot_params(self.n_joints)
        if len(self.limits.min_position_deg) != self.n_joints:
            raise ValueError(
                f"limits cover {len(self.limits.min_position_deg)} joints, env has n_joints={self.n_joints}"
            )
        self.dt = dt
        self.max_steps = max_steps
        self.target_tolerance_deg = target_tolerance_deg
        self.keepout_center_deg = keepout_center_deg
        self.keepout_radius_deg = keepout_radius_deg
        self._rng = np.random.default_rng(seed)

        self.action_dim = self.n_joints
        self.state_dim = 3 * self.n_joints + 2  # angles, velocities, target + torque_margin + collision_dist

        self.joint_angles_deg = np.zeros(self.n_joints)
        self.joint_velocities_deg_s = np.zeros(self.n_joints)
        self.target_deg = np.zeros(self.n_joints)
        self._step_count = 0
        self._prev_action = np.zeros(self.n_joints)

    def reset(self) -> np.ndarray:
        # Sample within the REAL per-joint position range (previously
        # a fixed +/-60 deg regardless of joint — some real joints
        # can't even reach that, others go much further).
        self.joint_angles_deg = self._rng.uniform(self.limits.min_position_deg, self.limits.max_position_deg)
        self.joint_velocities_deg_s = np.zeros(self.n_joints)
        self.target_deg = self._rng.uniform(self.limits.min_position_deg, self.limits.max_position_deg)
        self._step_count = 0
        self._prev_action = np.zeros(self.n_joints)
        return self._observe()

    def _observe(self) -> np.ndarray:
        torque_margin = self._torque_margin()
        collision_dist = self._collision_distance()
        return np.concatenate(
            [
                self.joint_angles_deg / 180.0,
                self.joint_velocities_deg_s / self.limits.max_velocity_deg_s,
                (self.target_deg - self.joint_angles_deg) / 180.0,
                [torque_margin, collision_dist],
            ]
        )

    def _torque_margin(self) -> float:
        # Simplified: torque proportional to |velocity| (viscous-friction-like);
        # per-joint margin = 1 - used/rated (each joint compared against
        # ITS OWN rated torque, not a shared global value — J1's 240 Nm
        # capacity and J6's 12 Nm capacity are very different things).
        # The env-level margin is the most-constrained joint's margin.
        est_torque = np.abs(self.joint_velocities_deg_s) * 0.15
        per_joint_margin = 1.0 - est_torque / self.limits.max_torque_nm
        return float(np.min(per_joint_margin))

    def _collision_distance(self) -> float:
        if self.keepout_center_deg is None:
            return 1.0
        d = float(np.linalg.norm(self.joint_angles_deg - self.keepout_center_deg))
        return float(np.clip(d / self.keepout_radius_deg - 1.0, -1.0, 1.0))

    def step(self, action: np.ndarray) -> Tuple[np.ndarray, float, bool, Dict]:
        # ACTION CLIPPING — the safety-critical lines in this file.
        action = np.clip(action, -1.0, 1.0) * self.limits.max_velocity_deg_s
        max_delta = self.limits.max_accel_deg_s2 * self.dt
        action = np.clip(
            action,
            self.joint_velocities_deg_s - max_delta,
            self.joint_velocities_deg_s + max_delta,
        )

        self.joint_velocities_deg_s = action
        proposed_angles = self.joint_angles_deg + self.joint_velocities_deg_s * self.dt

        # POSITION-LIMIT enforcement — previously absent entirely (see
        # this file's module docstring). A physical/simulated arm has
        # a hard mechanical stop at its joint limits; a policy driving
        # into one is a real limit violation, not just "went out of
        # frame" the way the unclamped version silently allowed.
        position_violation = bool(np.any(proposed_angles < self.limits.min_position_deg) or np.any(proposed_angles > self.limits.max_position_deg))
        self.joint_angles_deg = np.clip(proposed_angles, self.limits.min_position_deg, self.limits.max_position_deg)
        self._step_count += 1

        torque_margin = self._torque_margin()
        collision_dist = self._collision_distance()
        torque_violation = torque_margin < 0.0
        collision = collision_dist < 0.0
        limit_violation = torque_violation or position_violation

        jerk = float(np.sum(np.abs(action - self._prev_action)))
        self._prev_action = action

        dist_to_target = float(np.linalg.norm(self.target_deg - self.joint_angles_deg))
        reached = dist_to_target < self.target_tolerance_deg

        # §8.7.3 reward: weighted sum, negative cycle time (per-step
        # time cost), negative jerk/smoothness penalty, large negative
        # penalty for collision/limit violation, completion bonus.
        reward = -0.05  # cycle-time cost per step
        reward += -0.002 * jerk
        reward += -5.0 if (limit_violation or collision) else 0.0
        reward += 10.0 if reached else 0.0
        reward += -0.001 * dist_to_target

        done = reached or (self._step_count >= self.max_steps) or limit_violation or collision
        info = {
            "reached": reached,
            "limit_violation": limit_violation,
            "position_violation": position_violation,
            "torque_violation": torque_violation,
            "collision": collision,
            "dist_to_target_deg": dist_to_target,
        }
        return self._observe(), reward, done, info
