"""ai/services/motion_optimization_rl/policy_service.py

§8.7 as an AIService: inference-only wrapper around a registered
policy. §8.14 placement: "Training: Cloud. Inference: Edge/gateway
alongside the Motion Planner." This class is the inference half only
— training is train.py, run offline/in the cloud.

Critically: `infer()` returns a SUGGESTED trajectory delta and
projected metrics. It does not, and structurally cannot, command the
robot — there is no import of, or handle to, the motion controller
anywhere in this file. Per §7.5/§8.1, a suggested trajectory still
has to pass ordinary simulation-validated collision/limit checking
before deployment, same as any human-authored program.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import numpy as np  # noqa: E402

from common.base_service import AIService  # noqa: E402
from common.mlops import ModelRegistry  # noqa: E402
from common.schemas import ExecutionSite, InsightType  # noqa: E402
from services.motion_optimization_rl.policy import GaussianMLPPolicy  # noqa: E402


class MotionOptimizationService(AIService):
    service_id = "motion_optimization_rl"
    insight_type = InsightType.MOTION_OPTIMIZATION
    execution_site = ExecutionSite.EDGE  # inference placement; training is cloud-side (train.py)

    def __init__(self, registry: ModelRegistry, bus=None):
        super().__init__(bus=bus)
        version = registry.active_version(self.service_id)
        self.policy: Optional[GaussianMLPPolicy] = registry.load_artifact(version) if version else None
        self._model_version = version.version_id if version else None
        self._rng = np.random.default_rng(0)

    def infer(self, robot_id: str, observation: Optional[List[float]] = None, **kwargs: Any) -> Dict[str, Any]:
        if self.policy is None or observation is None:
            return self._result(
                {"note": "no fleet-authorized policy available — fall back to classical trajectory (§7.4)"},
                confidence_score=0.0,
            )
        obs = np.asarray(observation, dtype=float)
        action, _log_prob = self.policy.act(obs, self._rng, deterministic=True)

        payload = {
            "model_version": self._model_version,
            # Bounded [-1, 1] per joint — the caller maps this back to
            # the same velocity/accel/torque-limited command space the
            # Motion Planner already enforces (env.py's action clip),
            # never an unconstrained joint command.
            "suggested_joint_velocity_delta_normalized": [round(float(a), 4) for a in action],
            "note": "candidate trajectory — subject to standard simulation-validated collision/limit gate (§7.5) before deployment",
        }
        # §8.7 confidence: shadow-mode performance delta rather than a
        # per-inference score. Surfacing that here requires the gate
        # transcript; a fixed, conservative default is used absent it.
        return self._result(payload, confidence_score=0.55)
