"""ai/services/motion_optimization_rl/train.py

§8.7.1 architecture end-to-end: train in simulation (env.py) -> log
checkpoints (ModelRegistry) -> offline evaluation -> shadow mode vs
the classical baseline -> staged rollout -> fleet-wide (all via
DeploymentGate). Nothing here ever drives a physical robot; this
script's only output is a registered artifact and a gate transcript.
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common.deployment_gate import DeploymentGate, ShadowModeResult  # noqa: E402
from common.mlops import ModelRegistry  # noqa: E402
from services.motion_optimization_rl.env import ReachEnv  # noqa: E402
from services.motion_optimization_rl.policy import GaussianMLPPolicy  # noqa: E402
from services.motion_optimization_rl.ppo import PPOTrainer  # noqa: E402


def classical_baseline_metric(env: ReachEnv, n_episodes: int = 20, seed: int = 0) -> float:
    """§7.4's S-curve/classical trajectory optimizer, stood in here by
    a simple proportional controller straight-line-to-target — the
    'currently deployed program' the candidate RL policy is shadow-
    compared against (§8.7.4)."""
    rng = np.random.default_rng(seed)
    total = 0.0
    for _ in range(n_episodes):
        obs = env.reset()
        done = False
        ep_reward = 0.0
        while not done:
            error = env.target_deg - env.joint_angles_deg
            action = np.clip(error / 90.0, -1.0, 1.0)  # proportional controller, bounded like any policy action
            obs, r, done, _ = env.step(action)
            ep_reward += r
        total += ep_reward
    return total / n_episodes


def train_candidate_policy(n_iterations: int = 20, n_joints: int = 3, seed: int = 0):
    env = ReachEnv(n_joints=n_joints, max_steps=60, seed=seed)
    policy = GaussianMLPPolicy(env.state_dim, env.action_dim, hidden_size=24, seed=seed)
    trainer = PPOTrainer(env, policy, lr=5e-3, entropy_coef=0.02, seed=seed)

    history = []
    for _ in range(n_iterations):
        traj = trainer.collect_rollout(n_episodes=8)
        stats = trainer.update(traj, epochs=2)
        history.append(stats["mean_reward"])
    return policy, env, history


def run_full_pipeline(registry: ModelRegistry, n_iterations: int = 20, seed: int = 0):
    policy, env, history = train_candidate_policy(n_iterations=n_iterations, seed=seed)

    dataset_hash = hashlib.sha256(np.array(history).tobytes()).hexdigest()[:16]
    version = registry.register(
        service_id="motion_optimization_rl",
        artifact=policy,
        hyperparameters={"algo": "PPO", "lr": 5e-3, "hidden_size": 24, "n_iterations": n_iterations},
        training_dataset_hash=dataset_hash,
        metrics={"final_mean_reward": history[-1], "first_mean_reward": history[0]},
        activate=False,  # §8.7.4: never activated directly — must clear the gate first
    )

    gate = DeploymentGate(service_id="motion_optimization_rl", min_required_cycles=10)
    gate.enter_shadow_mode()

    candidate_metric = _evaluate_policy(env, policy, n_episodes=15, seed=seed + 1)
    incumbent_metric = classical_baseline_metric(env, n_episodes=15, seed=seed + 1)
    passed = gate.evaluate_shadow_mode(
        ShadowModeResult(candidate_metric, incumbent_metric, safety_margin_ok=True)
    )

    if passed:
        rng = np.random.default_rng(seed + 2)
        for _ in range(gate.min_required_cycles):
            obs = env.reset()
            done = False
            violated = False
            while not done:
                action, _ = policy.act(obs, rng, deterministic=True)
                obs, _r, done, info = env.step(action)
                violated = violated or info["limit_violation"] or info["collision"]
            gate.observe_staged_cycle(anomaly_detected=violated)
            if gate.stage.value in ("fleet_wide", "rolled_back"):
                break

    if gate.is_authorized_for_fleet():
        registry.register(
            service_id="motion_optimization_rl",
            artifact=policy,
            hyperparameters={"algo": "PPO", "lr": 5e-3, "hidden_size": 24, "n_iterations": n_iterations},
            training_dataset_hash=dataset_hash,
            metrics={"final_mean_reward": history[-1], "gate_stage": gate.stage.value},
            activate=True,
        )

    return policy, gate, {"candidate_metric": candidate_metric, "incumbent_metric": incumbent_metric}


def _evaluate_policy(env: ReachEnv, policy: GaussianMLPPolicy, n_episodes: int, seed: int) -> float:
    rng = np.random.default_rng(seed)
    total = 0.0
    for _ in range(n_episodes):
        obs = env.reset()
        done = False
        ep_reward = 0.0
        while not done:
            action, _ = policy.act(obs, rng, deterministic=True)
            obs, r, done, _ = env.step(action)
            ep_reward += r
        total += ep_reward
    return total / n_episodes


if __name__ == "__main__":
    reg = ModelRegistry(Path(__file__).resolve().parents[2] / "mlops_store")
    policy, gate, metrics = run_full_pipeline(reg, n_iterations=15)
    print("gate stage:", gate.stage.value)
    print("metrics:", metrics)
    for event in gate.history:
        print(f"  {event.from_stage.value} -> {event.to_stage.value}: {event.reason}")
