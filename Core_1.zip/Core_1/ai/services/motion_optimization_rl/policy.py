"""ai/services/motion_optimization_rl/policy.py

§8.7.2: "Policy network: 2-layer MLP, 256 units/layer ... kept small
so inference meets real-time latency budgets." This implementation
uses a smaller hidden width by default (see `hidden_size` — 256 units
is the production target the spec names; this demo defaults smaller
purely so a full PPO training run completes in seconds on a numpy-
only, no-GPU sandbox, which is disclosed here rather than silently
substituted). Diagonal-Gaussian continuous-action policy, hand-
implemented forward/backward pass (tanh hidden layers, linear mean
head, learned log_std parameter) — no autodiff framework, since torch
isn't installed in this environment.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Tuple

import numpy as np


class GaussianMLPPolicy:
    def __init__(self, obs_dim: int, act_dim: int, hidden_size: int = 32, seed: int = 0):
        self.obs_dim = obs_dim
        self.act_dim = act_dim
        self.hidden_size = hidden_size
        rng = np.random.default_rng(seed)

        def _init(fan_in, fan_out):
            return rng.normal(0, np.sqrt(2.0 / fan_in), size=(fan_in, fan_out))

        self.W1 = _init(obs_dim, hidden_size)
        self.b1 = np.zeros(hidden_size)
        self.W2 = _init(hidden_size, hidden_size)
        self.b2 = np.zeros(hidden_size)
        self.W3 = _init(hidden_size, act_dim)
        self.b3 = np.zeros(act_dim)
        self.log_std = np.full(act_dim, -0.5)  # learned, state-independent, per §8.7.2 convention

    def _forward(self, obs: np.ndarray):
        h1 = np.tanh(obs @ self.W1 + self.b1)
        h2 = np.tanh(h1 @ self.W2 + self.b2)
        mean = h2 @ self.W3 + self.b3
        return h1, h2, mean

    def act(self, obs: np.ndarray, rng: np.random.Generator, deterministic: bool = False) -> Tuple[np.ndarray, float]:
        _, _, mean = self._forward(obs)
        std = np.exp(self.log_std)
        if deterministic:
            action = mean
        else:
            action = mean + rng.normal(0, 1, size=self.act_dim) * std
        log_prob = _gaussian_log_prob(action, mean, std)
        return np.clip(action, -1.0, 1.0), log_prob

    def log_prob(self, obs: np.ndarray, action: np.ndarray) -> float:
        _, _, mean = self._forward(obs)
        std = np.exp(self.log_std)
        return _gaussian_log_prob(action, mean, std)

    def backward_logprob(self, obs: np.ndarray, action: np.ndarray) -> Dict[str, np.ndarray]:
        """Analytic gradient of log pi(action | obs) w.r.t. every
        parameter, for a single (obs, action) pair. Used by ppo.py to
        build the clipped-surrogate policy gradient without an
        autodiff framework: d(log N(a; mu, std))/d(mu) = (a - mu) / std^2,
        then standard tanh-MLP backprop from there.
        """
        h1, h2, mean = self._forward(obs)
        std = np.exp(self.log_std)

        d_mean = (action - mean) / (std ** 2)  # d(log_prob)/d(mean), shape (act_dim,)
        d_logstd = ((action - mean) ** 2 / (std ** 2)) - 1.0  # d(log_prob)/d(log_std)

        d_W3 = np.outer(h2, d_mean)
        d_b3 = d_mean
        d_h2 = (d_mean @ self.W3.T) * (1 - h2 ** 2)

        d_W2 = np.outer(h1, d_h2)
        d_b2 = d_h2
        d_h1 = (d_h2 @ self.W2.T) * (1 - h1 ** 2)

        d_W1 = np.outer(obs, d_h1)
        d_b1 = d_h1

        return {
            "W1": d_W1, "b1": d_b1, "W2": d_W2, "b2": d_b2, "W3": d_W3, "b3": d_b3, "log_std": d_logstd,
        }

    def apply_gradients(self, grads: Dict[str, np.ndarray], lr: float, max_grad_norm: float = 1.0) -> None:
        # Global-norm gradient clipping — standard PPO stabilization
        # practice, not part of §8.7.2's named hyperparameter table but
        # necessary for a hand-backpropped policy with a learnable,
        # potentially-small log_std: without it, a single high-advantage
        # transition with low current variance can produce an
        # exploding step. Clipping the global norm (rather than each
        # tensor separately) preserves the gradient's direction.
        total_sq = sum(float(np.sum(g ** 2)) for g in grads.values())
        norm = np.sqrt(total_sq)
        if norm > max_grad_norm:
            scale = max_grad_norm / (norm + 1e-8)
            grads = {k: g * scale for k, g in grads.items()}

        self.W1 += lr * grads["W1"]
        self.b1 += lr * grads["b1"]
        self.W2 += lr * grads["W2"]
        self.b2 += lr * grads["b2"]
        self.W3 += lr * grads["W3"]
        self.b3 += lr * grads["b3"]
        self.log_std += lr * grads["log_std"]
        self.log_std = np.clip(self.log_std, -1.5, 0.3)


def _gaussian_log_prob(x: np.ndarray, mean: np.ndarray, std: np.ndarray) -> float:
    var = std ** 2
    return float(np.sum(-0.5 * np.log(2 * np.pi * var) - 0.5 * ((x - mean) ** 2) / var))
