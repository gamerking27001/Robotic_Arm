"""ai/services/predictive_maintenance/train.py

Synthetic degradation-history generator + training script. There is
no real fleet telemetry history available in this environment (the
spec's own "Training Data Requirements" row calls for 3-6 months of
per-robot history), so this generates physically-plausible synthetic
degradation curves — monotonically rising current draw / winding
temperature / torque ripple as a joint's bearing/gearbox wears, with
noise — and trains against those. Swap `generate_synthetic_fleet()`
for a query against the real TimescaleDB telemetry store (§17.1) once
field data exists; nothing else in this file changes.

Each simulated "robot life" is now anchored to one of the real 6
joints' actual peak torque rating (`tools/robot_params.py`'s
`PEAK_TORQUE_NM`, transcribed from `include/core/robot_config.hpp`)
rather than a single flat baseline applied regardless of joint. An
earlier version of this generator used a fixed ~8 Nm torque baseline
for every simulated robot, which only resembles the real arm's
smallest wrist joints (J4-J6, 12-24 Nm) and badly understates the
base/shoulder joints (J1-J2, 240-300 Nm) — meaning the trained model
had never seen a training example in the magnitude range those joints
actually operate in. Fixed by drawing each simulated life's baseline
proportional to a real joint's peak torque (nominal operating point
modeled as roughly 15-35% of peak, a plausible duty-cycle fraction,
not itself a value transcribed from any spec source).
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import List, Tuple

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "tools"))
from common.feature_engineering import RollingJointFeatures  # noqa: E402
from common.mlops import ModelRegistry  # noqa: E402
from services.predictive_maintenance.model import PredictiveMaintenanceModel, dataset_hash  # noqa: E402
import robot_params  # noqa: E402


def _simulate_one_robot_life(
    rng: np.random.Generator, peak_torque_nm: float, life_hours: float = 4000.0, dt_hours: float = 4.0
):
    """One synthetic robot-joint life: baseline current/torque/temp
    with a wear trend that accelerates as end-of-life approaches
    (a simple accelerating-hazard curve), plus sensor noise.
    `peak_torque_nm` anchors the torque (and, via a fixed torque
    constant, current) baseline to a specific real joint's rated
    capacity — see this module's docstring for why that matters."""
    n_steps = int(life_hours / dt_hours)
    t = np.linspace(0, life_hours, n_steps)
    wear = (t / life_hours) ** 2.2  # accelerating degradation curve

    nominal_torque = peak_torque_nm * rng.uniform(0.15, 0.35)  # plausible duty-cycle operating point
    torque_noise_std = max(nominal_torque * 0.025, 0.05)
    base_torque = nominal_torque * (1.0 + 0.5 * wear) + rng.normal(0, torque_noise_std, n_steps)

    # Motor current scales with torque via an assumed torque constant
    # (Nm/A) that varies by joint size — larger joints use higher-
    # current, higher-torque-constant motors; this is a simplified,
    # documented proportionality, not a transcribed motor spec.
    torque_constant_nm_per_a = max(peak_torque_nm / 100.0, 2.0)
    base_current = base_torque / torque_constant_nm_per_a + rng.normal(0, 0.05, n_steps)

    base_temp = 35.0 + 30.0 * wear + rng.normal(0, 0.5, n_steps)
    base_velocity = 60.0 + rng.normal(0, 2.0, n_steps)  # commanded profile, wear-independent

    rul_hours = life_hours - t
    return t, base_current, base_torque, base_temp, base_velocity, rul_hours


def generate_synthetic_fleet(
    n_robots: int = 12, seed: int = 42
) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    rng = np.random.default_rng(seed)
    X_rows: List[np.ndarray] = []
    y_rows: List[float] = []
    feature_names = RollingJointFeatures.feature_names()

    for i in range(n_robots):
        # Cycle through the real 6 joints' peak-torque ratings so the
        # training set spans the whole real fleet, not one arbitrary
        # joint size repeated n_robots times.
        peak_torque_nm = robot_params.PEAK_TORQUE_NM[i % len(robot_params.PEAK_TORQUE_NM)]
        life_hours = rng.uniform(3000, 5000)
        t, current, torque, temp, velocity, rul = _simulate_one_robot_life(rng, peak_torque_nm, life_hours)
        window = RollingJointFeatures(window_size=50)
        for j in range(len(t)):
            window.push(current[j], torque[j], temp[j], velocity[j])
            if j < 20:  # let the window fill before using it as a training row
                continue
            feats = window.features()
            X_rows.append(np.array([feats[k] for k in feature_names]))
            y_rows.append(rul[j])

    X = np.vstack(X_rows)
    y = np.array(y_rows)
    return X, y, feature_names


def train_and_register(registry: ModelRegistry, n_robots: int = 12, seed: int = 42) -> PredictiveMaintenanceModel:
    X, y, feature_names = generate_synthetic_fleet(n_robots=n_robots, seed=seed)
    n = len(X)
    split = int(n * 0.8)
    idx = np.random.default_rng(seed).permutation(n)
    train_idx, val_idx = idx[:split], idx[split:]

    model = PredictiveMaintenanceModel().fit(X[train_idx], y[train_idx], feature_names)

    preds = np.array([model.predict(x).rul_hours for x in X[val_idx]])
    mae = float(np.mean(np.abs(preds - y[val_idx])))
    within_interval = 0
    for x, true_y in zip(X[val_idx], y[val_idx]):
        p = model.predict(x)
        within_interval += int(p.lower_bound_hours <= true_y <= p.upper_bound_hours)
    coverage = within_interval / len(val_idx)

    registry.register(
        service_id="predictive_maintenance",
        artifact=model,
        hyperparameters={
            "n_estimators": model.n_estimators,
            "max_depth": model.max_depth,
            "learning_rate": model.learning_rate,
            "quantiles": model.QUANTILES,
        },
        training_dataset_hash=dataset_hash(X, y),
        metrics={"val_mae_hours": mae, "val_interval_coverage": coverage, "n_train_rows": len(train_idx)},
    )
    return model


if __name__ == "__main__":
    reg = ModelRegistry(Path(__file__).resolve().parents[2] / "mlops_store")
    m = train_and_register(reg)
    v = reg.active_version("predictive_maintenance")
    print(f"registered predictive_maintenance v{v.version_id}: {v.metrics}")
