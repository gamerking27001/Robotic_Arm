"""ai/services/predictive_maintenance/service.py

§8.3 wrapped as an AIService: consumes a rolling telemetry window per
joint and emits a maintenance-scheduling insight. Batch/hourly
inference per the spec ("a missed prediction cycle has no safety
consequence") — this class is called once per joint per inference
cycle, not driven off every single telemetry tick.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, Optional

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common.base_service import AIService  # noqa: E402
from common.feature_engineering import RollingJointFeatures  # noqa: E402
from common.mlops import ModelRegistry  # noqa: E402
from common.schemas import ExecutionSite, InsightType  # noqa: E402
from services.predictive_maintenance.model import PredictiveMaintenanceModel  # noqa: E402


class PredictiveMaintenanceService(AIService):
    service_id = "predictive_maintenance"
    insight_type = InsightType.PREDICTIVE_MAINTENANCE
    execution_site = ExecutionSite.CLOUD  # §8.14: cloud, batch inference, no real-time constraint

    def __init__(self, registry: ModelRegistry, bus=None, store=None):
        super().__init__(bus=bus, store=store)
        self.registry = registry
        self._windows: Dict[str, RollingJointFeatures] = {}
        version = registry.active_version(self.service_id)
        self.model: Optional[PredictiveMaintenanceModel] = (
            registry.load_artifact(version) if version else None
        )
        self._model_version = version.version_id if version else None

    def _window_for(self, robot_id: str, joint_name: str) -> RollingJointFeatures:
        key = f"{robot_id}:{joint_name}"
        if key not in self._windows:
            self._windows[key] = RollingJointFeatures(window_size=50)
        return self._windows[key]

    def observe(self, robot_id: str, joint_name: str, current_a: float, torque_nm: float, temp_c: float, velocity: float) -> None:
        self._window_for(robot_id, joint_name).push(current_a, torque_nm, temp_c, velocity)

    def infer(self, robot_id: str, joint_name: str = "", **kwargs: Any) -> Dict[str, Any]:
        if self.model is None:
            # §8.3 "cold-start robots use a fleet-wide baseline model
            # until sufficient robot-specific history accumulates" —
            # here that means: explicitly low confidence, not a crash.
            return self._result(
                {"joint_name": joint_name, "note": "no fleet baseline model registered yet"},
                confidence_score=0.1,
            )
        window = self._window_for(robot_id, joint_name)
        x = window.as_vector()
        prediction = self.model.predict(x)
        confidence = self.model.confidence(prediction)
        contributing = self.model.contributing_signals(x)
        payload = {
            "joint_name": joint_name,
            "model_version": self._model_version,
            "remaining_useful_life_hours": round(prediction.rul_hours, 1),
            "rul_lower_bound_hours": round(prediction.lower_bound_hours, 1),
            "rul_upper_bound_hours": round(prediction.upper_bound_hours, 1),
            "failure_probability_30d": round(prediction.failure_probability_30d, 4),
            "maintenance_recommendation": self._recommendation(prediction.rul_hours),
            # §8.17 XAI: which telemetry features are driving THIS
            # prediction, not just a bare RUL number.
            "contributing_signals": contributing,
        }
        return self._result(payload, confidence)

    @staticmethod
    def _recommendation(rul_hours: float) -> str:
        # §8.3 "Human Override": this is a recommendation surfaced to
        # an operator/technician, never an auto-scheduled dispatch.
        if rul_hours < 168:
            return "schedule technician within 1 week"
        if rul_hours < 720:
            return "schedule technician within next maintenance window"
        return "no action required"
