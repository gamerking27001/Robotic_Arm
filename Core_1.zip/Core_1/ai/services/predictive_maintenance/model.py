"""ai/services/predictive_maintenance/model.py

§8.3 Predictive Maintenance AI. Recommended models: "Gradient
Boosting / XGBoost (tabular degradation features), LSTM or Temporal
Convolutional Network (raw time-series sequences)". XGBoost isn't
installed in this environment (no network access to pip install it),
so the default here is sklearn's GradientBoostingRegressor — which is
the same family the spec names as the "Alternative ... simpler
baseline" path, with one difference: we use its native quantile loss
to get the prediction interval the spec calls for ("Model-native
prediction interval (gradient boosting quantile regression)"),
rather than falling back to Random Forest. If xgboost is importable,
it's used instead — see `_HAVE_XGBOOST` below — with no other code
change required.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import numpy as np
from sklearn.ensemble import GradientBoostingRegressor

try:  # pragma: no cover - exercised only if xgboost is installed
    import xgboost as xgb

    _HAVE_XGBOOST = True
except ImportError:
    _HAVE_XGBOOST = False


@dataclass
class RULPrediction:
    rul_hours: float
    lower_bound_hours: float
    upper_bound_hours: float
    failure_probability_30d: float

    @property
    def interval_width(self) -> float:
        return self.upper_bound_hours - self.lower_bound_hours


class PredictiveMaintenanceModel:
    """Gradient-boosted quantile regressors predicting Remaining
    Useful Life (RUL, in hours) from rolling-window telemetry
    features (ai/common/feature_engineering.py). Three regressors
    (10th / 50th / 90th percentile) give the point estimate plus a
    genuine model-native prediction interval, rather than a single
    point estimate dressed up with an arbitrary +/- band.
    """

    QUANTILES = (0.1, 0.5, 0.9)

    def __init__(self, n_estimators: int = 150, max_depth: int = 3, learning_rate: float = 0.08):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.learning_rate = learning_rate
        self._models: Dict[float, object] = {}
        self.feature_names: list[str] = []
        self.healthy_reference: Optional[np.ndarray] = None
        self._is_fleet_baseline = True  # §8.3 "cold-start robots use a fleet-wide baseline"

    def _make_regressor(self, quantile: float):
        if _HAVE_XGBOOST:  # pragma: no cover
            return xgb.XGBRegressor(
                n_estimators=self.n_estimators,
                max_depth=self.max_depth,
                learning_rate=self.learning_rate,
                objective="reg:quantileerror",
                quantile_alpha=quantile,
            )
        return GradientBoostingRegressor(
            loss="quantile",
            alpha=quantile,
            n_estimators=self.n_estimators,
            max_depth=self.max_depth,
            learning_rate=self.learning_rate,
            random_state=0,
        )

    def fit(self, X: np.ndarray, y_rul_hours: np.ndarray, feature_names: list[str]) -> "PredictiveMaintenanceModel":
        self.feature_names = list(feature_names)
        for q in self.QUANTILES:
            model = self._make_regressor(q)
            model.fit(X, y_rul_hours)
            self._models[q] = model
        # §8.17 contributing-signal breakdown needs a "healthy" baseline
        # to measure deviation from — the mean feature vector among
        # the healthiest (highest-RUL) 20% of training rows, i.e. what
        # "normal" actually looks like for this joint family, not an
        # arbitrary zero vector.
        healthy_mask = y_rul_hours >= np.percentile(y_rul_hours, 80)
        self.healthy_reference = X[healthy_mask].mean(axis=0)
        self._is_fleet_baseline = False
        return self

    def predict(self, x: np.ndarray) -> RULPrediction:
        if not self._models:
            raise RuntimeError("model not fitted — call fit() or load a fleet baseline first")
        x2d = x.reshape(1, -1)
        raw_lo = float(self._models[0.1].predict(x2d)[0])
        raw_mid = float(self._models[0.5].predict(x2d)[0])
        raw_hi = float(self._models[0.9].predict(x2d)[0])

        # Independently-trained quantile regressors can "cross"
        # (predict q10 > q50, etc.), especially on inputs far outside
        # the training distribution — sorting is the standard fix
        # (see e.g. Chernozhukov et al.'s quantile rearrangement) and
        # is essential here: an un-sorted crossing would silently
        # violate the invariant every caller of this class relies on
        # (lower_bound <= rul_hours <= upper_bound).
        lo, mid, hi = sorted([raw_lo, raw_mid, raw_hi])
        lo, mid, hi = max(0.0, lo), max(0.0, mid), max(0.0, hi)
        # Failure probability inside a 30-day (720h) horizon, derived
        # from where the predicted-RUL distribution sits relative to
        # that horizon rather than a second, separately-trained model.
        horizon_h = 720.0
        spread = max(hi - lo, 1e-6)
        z = np.clip((horizon_h - mid) / spread, -30.0, 30.0)
        failure_prob = float(1.0 / (1.0 + np.exp(z)))  # logistic approx of P(RUL < horizon)
        return RULPrediction(mid, lo, hi, failure_prob)

    def confidence(self, prediction: RULPrediction) -> float:
        """Narrower interval (relative to the point estimate) = higher
        confidence. This is the §8.3 confidence score surfaced
        alongside the RUL estimate, and directly drives whether the
        insight requires human review (ai/common/schemas.make_insight).
        """
        if self._is_fleet_baseline:
            return 0.35  # explicit, low, cold-start confidence — never silently "sure"
        rel_width = prediction.interval_width / max(prediction.rul_hours, 1.0)
        return float(np.clip(1.0 - rel_width / 2.0, 0.05, 0.98))

    def contributing_signals(self, x: np.ndarray, reference: Optional[np.ndarray] = None, top_k: int = 3) -> Dict[str, float]:
        """§8.17: "Predictive maintenance and anomaly detection outputs
        include contributing-signal breakdowns ... not just a bare
        prediction, so an operator can see why a model raised an
        alert." Combines the q50 model's global feature importances
        (which features the model relies on in general) with this
        specific instance's deviation from a healthy reference point
        (which of those features is actually elevated right now) —
        importance alone would flag the same features on every
        prediction regardless of whether they're actually anomalous
        for this joint at this moment.
        """
        if self._is_fleet_baseline or not self.feature_names:
            return {}
        model = self._models[0.5]
        importances = getattr(model, "feature_importances_", None)
        if importances is None:  # pragma: no cover - only if a model type without this attr is swapped in
            return {}

        ref = reference if reference is not None else (self.healthy_reference if self.healthy_reference is not None else np.zeros_like(x))
        deviation = np.abs(x - ref)
        # Normalize deviation onto a comparable scale across features
        # with very different natural units (amps vs. degrees C vs.
        # rate-of-change), then weight by how much the model actually
        # relies on each feature globally.
        deviation_norm = deviation / (np.abs(ref).clip(min=1.0) + 1.0)
        signal_strength = importances * deviation_norm

        top_idx = np.argsort(-signal_strength)[:top_k]
        return {self.feature_names[i]: round(float(signal_strength[i]), 4) for i in top_idx if signal_strength[i] > 0}


def dataset_hash(X: np.ndarray, y: np.ndarray) -> str:
    h = hashlib.sha256()
    h.update(X.tobytes())
    h.update(y.tobytes())
    return h.hexdigest()[:16]
