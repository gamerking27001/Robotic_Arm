"""ai/services/operator_assistant/service.py

§8.12 Operator Assistance AI. "Alternative Approaches: A fixed-
template query builder (no LLM) — more constrained and predictable,
considered as a fallback if grounding reliability does not meet the
bar for production use." No LLM (hosted or local) is reachable from
this sandbox — no network access and no API key configured — so this
implements exactly that named fallback for real: structured retrieval
over the platform's own data (the Insights Bus + a small alert/robot
registry) followed by template-based summarization, with the same
mandatory-grounding contract the spec requires of the LLM path:

    "Every answer is required to cite the underlying telemetry/alert
    record it was grounded in; an answer that cannot be grounded in
    retrieved data is refused rather than generated."

Swapping in a real RAG-over-LLM pipeline later means adding a
generation step AFTER retrieval, still gated by the same "no
retrieved records -> refuse" rule — retrieval.py's contract doesn't
change.
"""
from __future__ import annotations

import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common.base_service import AIService  # noqa: E402
from common.insights_bus import InsightsBus  # noqa: E402
from common.schemas import AIInsight, ExecutionSite, InsightType  # noqa: E402


class GroundingRefusal(Exception):
    """Raised internally when a query cannot be grounded in any
    retrieved record — caught by infer() and turned into an explicit
    'cannot answer' insight rather than ever falling through to a
    model-invented answer (there is no generative model here to fall
    through to, but the refusal path is real and tested regardless)."""


class OperatorAssistantService(AIService):
    service_id = "operator_assistant"
    insight_type = InsightType.OPERATOR_ANSWER
    execution_site = ExecutionSite.CLOUD

    def __init__(self, bus: InsightsBus | None = None):
        super().__init__(bus=bus)

    # --- retrieval -----------------------------------------------------

    def _retrieve_maintenance(self, robot_id: Optional[str], within_days: float = 7.0) -> List[AIInsight]:
        cutoff = time.time() - 3600 * 24 * 30
        items = [
            i for i in self.bus.history(InsightType.PREDICTIVE_MAINTENANCE, robot_id=robot_id, limit=1000)
            if i.timestamp >= cutoff
        ]
        horizon_hours = within_days * 24
        return [i for i in items if (i.payload.get("remaining_useful_life_hours") or 1e9) <= horizon_hours]

    def _retrieve_thermal_over(self, threshold_c: float) -> List[AIInsight]:
        items = self.bus.history(InsightType.THERMAL_FORECAST, limit=1000)
        return [i for i in items if (i.payload.get("forecast_temp_c") or -1e9) > threshold_c]

    def _retrieve_energy(self, robot_id: Optional[str]) -> List[AIInsight]:
        return self.bus.history(InsightType.ENERGY_OPTIMIZATION, robot_id=robot_id, limit=1000)

    def _retrieve_anomalies(self, robot_id: Optional[str]) -> List[AIInsight]:
        items = self.bus.history(InsightType.ANOMALY, robot_id=robot_id, limit=1000)
        return [i for i in items if i.payload.get("is_anomaly")]

    # --- query handling --------------------------------------------------

    def infer(self, robot_id: str, question: str = "", **kwargs: Any) -> Dict[str, Any]:
        try:
            answer, citations = self._answer(question, robot_id)
        except GroundingRefusal as exc:
            return self._result(
                {"question": question, "answer": None, "refused": True, "reason": str(exc)},
                confidence_score=0.0,
            )

        payload = {
            "question": question,
            "answer": answer,
            "refused": False,
            # §8.12 "Every answer is required to cite the underlying
            # telemetry/alert record it was grounded in" — enforced
            # structurally: `answer` is never returned without at
            # least one citation.
            "citations": citations,
        }
        confidence = min(0.95, 0.5 + 0.1 * len(citations))
        return self._result(payload, confidence)

    def _answer(self, question: str, robot_id: str) -> tuple[str, List[Dict[str, Any]]]:
        q = question.lower()

        if "maintenance" in q and "due" in q:
            records = self._retrieve_maintenance(robot_id=None, within_days=7.0)
            if not records:
                raise GroundingRefusal("no predictive-maintenance records within the next 7 days were retrieved")
            lines = [
                f"{r.robot_id} joint {r.payload.get('joint_name')}: "
                f"{r.payload.get('remaining_useful_life_hours')}h RUL"
                for r in records
            ]
            return "Maintenance due within 7 days: " + "; ".join(lines), _cite(records)

        m = re.search(r"exceed(?:ing|s)?\s+(\d+)", q)
        if m and ("°c" in q or "temp" in q or "hot" in q or "exceed" in q):
            threshold = float(m.group(1))
            records = self._retrieve_thermal_over(threshold)
            if not records:
                raise GroundingRefusal(f"no thermal forecast records above {threshold}C were retrieved")
            names = sorted({r.robot_id for r in records})
            return f"Robots exceeding {threshold}C forecast: {', '.join(names)}", _cite(records)

        if "power" in q or "energy" in q:
            records = self._retrieve_energy(robot_id=None)
            if not records:
                raise GroundingRefusal("no energy-optimization records were retrieved")
            worst = max(records, key=lambda r: r.payload.get("energy_per_cycle_j", 0.0))
            return (
                f"{worst.robot_id} consumed the most energy per cycle: "
                f"{worst.payload.get('energy_per_cycle_j')} J",
                _cite([worst]),
            )

        if "why did" in q and "stop" in q:
            records = self._retrieve_anomalies(robot_id=robot_id)
            if not records:
                raise GroundingRefusal(f"no anomaly records found for {robot_id}")
            latest = max(records, key=lambda r: r.timestamp)
            signals = latest.payload.get("contributing_signals", {})
            return (
                f"{robot_id}'s most recent flagged anomaly (score "
                f"{latest.payload.get('anomaly_score')}) points to: {signals}",
                _cite([latest]),
            )

        raise GroundingRefusal(
            "question did not match a supported grounded query template "
            "(maintenance-due / thermal-threshold / energy / stop-reason)"
        )


def _cite(insights: List[AIInsight]) -> List[Dict[str, Any]]:
    return [
        {"insight_id": i.insight_id, "service_id": i.service_id, "robot_id": i.robot_id, "timestamp": i.timestamp}
        for i in insights
    ]
