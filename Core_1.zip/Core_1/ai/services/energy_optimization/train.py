"""ai/services/energy_optimization/train.py — synthetic bench-
characterized motion-profile -> energy dataset (§8.5 "Training Data
Requirements: Per-robot-model energy-profile baseline (bench-
characterized)")."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common.mlops import ModelRegistry  # noqa: E402
from services.energy_optimization.model import EnergyOptimizationModel, FEATURE_NAMES  # noqa: E402


def generate_synthetic_profiles(n: int = 800, seed: int = 7):
    rng = np.random.default_rng(seed)
    peak_v = rng.uniform(30, 180, n)          # deg/s
    peak_a = rng.uniform(50, 800, n)          # deg/s^2
    payload = rng.uniform(0.0, 5.0, n)        # kg
    cycle_time = rng.uniform(1.5, 8.0, n)     # s
    idle_hold = rng.uniform(0.0, 3.0, n)      # s

    X = np.column_stack([peak_v, peak_a, payload, cycle_time, idle_hold])

    # Physically-motivated synthetic energy model: kinetic term
    # (~v^2), a nonlinear payload*accel interaction term, and a
    # constant idle-hold-current term, plus noise.
    energy = (
        0.02 * peak_v ** 1.6
        + 0.0009 * (peak_a * (1 + 0.4 * payload)) ** 1.15
        + 15.0 * idle_hold
        + 6.0 * cycle_time
        + rng.normal(0, 8.0, n)
    )
    energy = np.clip(energy, 5.0, None)
    return X, energy


def train_and_register(registry: ModelRegistry, seed: int = 7) -> EnergyOptimizationModel:
    X, y = generate_synthetic_profiles(seed=seed)
    split = int(0.8 * len(X))
    model = EnergyOptimizationModel().fit(X[:split], y[:split])
    val_r2 = model._r2

    import hashlib

    h = hashlib.sha256(X.tobytes() + y.tobytes()).hexdigest()[:16]
    registry.register(
        service_id="energy_optimization",
        artifact=model,
        hyperparameters={"features": FEATURE_NAMES},
        training_dataset_hash=h,
        metrics={"train_r2": val_r2},
    )
    return model


if __name__ == "__main__":
    reg = ModelRegistry(Path(__file__).resolve().parents[2] / "mlops_store")
    train_and_register(reg)
    print(reg.active_version("energy_optimization"))
