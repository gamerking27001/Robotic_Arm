"""ai/services/energy_optimization/model.py

§8.5 Energy Optimization AI. "Recommended Models: Regression (energy
as a function of motion-profile parameters) and Gradient Boosting for
non-linear efficiency-curve fitting." RL is explicitly deferred by
the spec itself ("not recommended for the first deployment" — see
the module docstring in services/motion_optimization_rl for where RL
*is* used), so this module intentionally implements only the
regression/GB path.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score


FEATURE_NAMES = ["peak_velocity_deg_s", "peak_accel_deg_s2", "payload_kg", "cycle_time_s", "idle_hold_s"]


@dataclass
class EfficiencyReport:
    energy_per_cycle_j: float
    efficiency_score: float  # 0-1, relative to the fleet's best observed profile for this task
    suggestions: List[str]
    r2: float


class EnergyOptimizationModel:
    """A linear baseline (fast, interpretable, matches most of a
    motion profile's near-linear energy response) plus a gradient-
    boosting residual model for the non-linear component (payload x
    acceleration interaction, mostly) — this is the §8.5 "Regression
    ... and Gradient Boosting for non-linear efficiency-curve fitting"
    pairing implemented literally as two stacked models rather than
    one model asked to do both jobs.
    """

    def __init__(self):
        self.linear = LinearRegression()
        self.residual_gb = GradientBoostingRegressor(n_estimators=120, max_depth=3, random_state=0)
        self._best_energy_per_cycle: float = np.inf
        self._fitted = False

    def fit(self, X: np.ndarray, y_energy_j: np.ndarray) -> "EnergyOptimizationModel":
        self.linear.fit(X, y_energy_j)
        residual = y_energy_j - self.linear.predict(X)
        self.residual_gb.fit(X, residual)
        self._best_energy_per_cycle = float(np.percentile(y_energy_j, 5))  # robust "best observed" baseline
        self._fitted = True
        preds = self.predict_energy(X)
        self._r2 = float(r2_score(y_energy_j, preds))
        return self

    def predict_energy(self, X: np.ndarray) -> np.ndarray:
        return self.linear.predict(X) + self.residual_gb.predict(X)

    def report(self, x: np.ndarray) -> EfficiencyReport:
        if not self._fitted:
            raise RuntimeError("model not fitted")
        energy = float(self.predict_energy(x.reshape(1, -1))[0])
        efficiency = float(np.clip(self._best_energy_per_cycle / max(energy, 1e-6), 0.0, 1.0))

        feats = dict(zip(FEATURE_NAMES, x.tolist()))
        suggestions: List[str] = []
        if feats["idle_hold_s"] > 1.0:
            suggestions.append("reduce idle-hold current during dwell segments")
        if feats["peak_accel_deg_s2"] > 400.0:
            suggestions.append("reduce peak acceleration — current profile is energy-dominant, not cycle-time-dominant")
        if not suggestions:
            suggestions.append("profile is already near the fleet-observed efficiency frontier")

        return EfficiencyReport(
            energy_per_cycle_j=energy,
            efficiency_score=efficiency,
            suggestions=suggestions,
            r2=self._r2,
        )
