"""ai/services/energy_optimization/service.py — §8.5 as an AIService.
Cloud, batch/report-driven (§8.14), advisory only — suggestions are
never auto-applied; a suggested motion-profile change must pass
through the same simulation-validated deployment flow as any other
program change (§7.5), same as every other AI-suggested change."""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, Optional

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import numpy as np  # noqa: E402

from common.base_service import AIService  # noqa: E402
from common.mlops import ModelRegistry  # noqa: E402
from common.schemas import ExecutionSite, InsightType  # noqa: E402
from services.energy_optimization.model import EnergyOptimizationModel, FEATURE_NAMES  # noqa: E402


class EnergyOptimizationService(AIService):
    service_id = "energy_optimization"
    insight_type = InsightType.ENERGY_OPTIMIZATION
    execution_site = ExecutionSite.CLOUD

    def __init__(self, registry: ModelRegistry, bus=None):
        super().__init__(bus=bus)
        version = registry.active_version(self.service_id)
        self.model: Optional[EnergyOptimizationModel] = registry.load_artifact(version) if version else None
        self._model_version = version.version_id if version else None

    def infer(
        self,
        robot_id: str,
        peak_velocity_deg_s: float = 0.0,
        peak_accel_deg_s2: float = 0.0,
        payload_kg: float = 0.0,
        cycle_time_s: float = 0.0,
        idle_hold_s: float = 0.0,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        if self.model is None:
            return self._result({"note": "no trained model registered"}, confidence_score=0.05)

        x = np.array([peak_velocity_deg_s, peak_accel_deg_s2, payload_kg, cycle_time_s, idle_hold_s])
        report = self.model.report(x)
        confidence = float(np.clip(report.r2, 0.05, 0.97))
        payload = {
            "model_version": self._model_version,
            "energy_per_cycle_j": round(report.energy_per_cycle_j, 2),
            "efficiency_score": round(report.efficiency_score, 3),
            "suggestions": report.suggestions,
        }
        return self._result(payload, confidence)
