"""ai/services/anomaly_detection/service.py — §8.10 as an AIService.
Hybrid edge+cloud: this class defaults to the edge IsolationForest
path (near-real-time flagging); `deep=True` routes the same feature
vector through the cloud autoencoder for a second opinion, matching
the spec's "Hybrid, as described above" execution placement.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, Optional

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import numpy as np  # noqa: E402

from common.base_service import AIService  # noqa: E402
from common.feature_engineering import RollingJointFeatures  # noqa: E402
from common.mlops import ModelRegistry  # noqa: E402
from common.schemas import ExecutionSite, InsightType  # noqa: E402
from services.anomaly_detection.model import EdgeIsolationForestDetector, TinyAutoencoder  # noqa: E402


class AnomalyDetectionService(AIService):
    service_id = "anomaly_detection"
    insight_type = InsightType.ANOMALY
    execution_site = ExecutionSite.HYBRID

    def __init__(self, registry: ModelRegistry, bus=None, deep: bool = False, store=None):
        super().__init__(bus=bus, store=store)
        self.deep = deep
        self._windows: Dict[str, RollingJointFeatures] = {}

        edge_version = registry.active_version("anomaly_detection_edge")
        self.edge_model: Optional[EdgeIsolationForestDetector] = (
            registry.load_artifact(edge_version) if edge_version else None
        )
        deep_version = registry.active_version("anomaly_detection_deep")
        self.deep_model: Optional[TinyAutoencoder] = (
            registry.load_artifact(deep_version) if deep_version else None
        )

        # False-positive feedback loop (§8.10 Human Override): a
        # dismissed anomaly is remembered so this exact operating
        # point doesn't immediately re-trigger — a stand-in for the
        # real retraining-cycle feedback described in the spec.
        self._dismissed_signatures: set[str] = set()

    def _window_for(self, robot_id: str, joint_name: str) -> RollingJointFeatures:
        key = f"{robot_id}:{joint_name}"
        if key not in self._windows:
            self._windows[key] = RollingJointFeatures(window_size=50)
        return self._windows[key]

    def observe(self, robot_id: str, joint_name: str, current_a: float, torque_nm: float, temp_c: float, velocity: float) -> None:
        self._window_for(robot_id, joint_name).push(current_a, torque_nm, temp_c, velocity)

    def dismiss(self, robot_id: str, joint_name: str) -> None:
        """Operator dismissal (§8.10 Human Override) — logged and used
        to reduce future false-positive rates on this exact window."""
        window = self._window_for(robot_id, joint_name)
        self._dismissed_signatures.add(_signature(window.as_vector()))

    def infer(self, robot_id: str, joint_name: str = "", **kwargs: Any) -> Dict[str, Any]:
        window = self._window_for(robot_id, joint_name)
        x = window.as_vector()

        if self.edge_model is None:
            return self._result({"joint_name": joint_name, "note": "no edge model registered"}, confidence_score=0.05)

        edge_result = self.edge_model.score(x)
        if _signature(x) in self._dismissed_signatures:
            edge_result.is_anomaly = False

        payload: Dict[str, Any] = {
            "joint_name": joint_name,
            "anomaly_score": round(edge_result.anomaly_score, 4),
            "is_anomaly": edge_result.is_anomaly,
            "contributing_signals": edge_result.contributing_features,
            "source": "edge_isolation_forest",
        }
        confidence = edge_result.anomaly_score  # the score itself is the confidence signal, per spec

        if self.deep and self.deep_model is not None:
            deep_result = self.deep_model.score(x)
            payload["deep_review"] = {
                "anomaly_score": round(deep_result.anomaly_score, 4),
                "is_anomaly": deep_result.is_anomaly,
                "source": "cloud_autoencoder",
            }
            # Cross-check: only escalate confidence when both models agree.
            confidence = float((edge_result.anomaly_score + deep_result.anomaly_score) / 2.0)

        return self._result(payload, confidence)


def _signature(x) -> str:
    return ",".join(f"{v:.2f}" for v in x)
