"""ai/services/anomaly_detection/train.py — trains both the edge
IsolationForest and the cloud TinyAutoencoder on the SAME synthetic
normal-operation dataset (unsupervised, per §8.10: "Trained on
normal-operation data only").

Each simulated "normal operation" window is now anchored to one of
the real 6 joints' actual peak torque rating (`tools/robot_params.py`'s
`PEAK_TORQUE_NM`), cycled across windows, rather than a single flat
~7-9.5 Nm baseline applied regardless of joint. An earlier version
used that flat baseline for every window; since it only resembles the
real arm's smallest wrist joints (12-24 Nm), a live reading from J1 or
J2 (240-300 Nm) would have looked like an extreme outlier against this
model's training distribution EVERY time, regardless of whether
anything was actually wrong — exactly the "Novel-but-benign operating
conditions... flagged as anomalous" failure case §8.10 itself names,
except systematically for two-thirds of the real joints rather than
as an occasional edge case. Fixed the same way as the
predictive_maintenance generator: baseline proportional to a real
joint's peak torque.
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "tools"))
from common.feature_engineering import RollingJointFeatures  # noqa: E402
from common.mlops import ModelRegistry  # noqa: E402
from services.anomaly_detection.model import EdgeIsolationForestDetector, TinyAutoencoder  # noqa: E402
import robot_params  # noqa: E402


def generate_normal_operation_windows(n_windows: int = 1500, seed: int = 3) -> tuple[np.ndarray, list[str]]:
    rng = np.random.default_rng(seed)
    feature_names = RollingJointFeatures.feature_names()
    rows = []
    for i in range(n_windows):
        peak_torque_nm = robot_params.PEAK_TORQUE_NM[i % len(robot_params.PEAK_TORQUE_NM)]
        nominal_torque = peak_torque_nm * rng.uniform(0.15, 0.35)  # same duty-cycle assumption as predictive_maintenance
        torque_constant_nm_per_a = max(peak_torque_nm / 100.0, 2.0)

        window = RollingJointFeatures(window_size=50)
        torque_base = nominal_torque
        current_base = torque_base / torque_constant_nm_per_a
        temp_base = rng.uniform(32.0, 42.0)
        vel_base = rng.uniform(50.0, 70.0)
        torque_noise_std = max(torque_base * 0.03, 0.05)
        current_noise_std = max(current_base * 0.03, 0.03)
        for _ in range(60):
            window.push(
                current_base + rng.normal(0, current_noise_std),
                torque_base + rng.normal(0, torque_noise_std),
                temp_base + rng.normal(0, 0.4),
                vel_base + rng.normal(0, 1.5),
            )
        feats = window.features()
        rows.append([feats[k] for k in feature_names])
    return np.array(rows), feature_names


def train_and_register(registry: ModelRegistry, seed: int = 3):
    X, feature_names = generate_normal_operation_windows(seed=seed)
    h = hashlib.sha256(X.tobytes()).hexdigest()[:16]

    edge = EdgeIsolationForestDetector().fit(X, feature_names)
    registry.register(
        service_id="anomaly_detection_edge",
        artifact=edge,
        hyperparameters={"contamination": 0.02, "n_estimators": 100},
        training_dataset_hash=h,
        metrics={"n_train_windows": len(X)},
    )

    deep = TinyAutoencoder(input_dim=X.shape[1]).fit(X)
    registry.register(
        service_id="anomaly_detection_deep",
        artifact=deep,
        hyperparameters={"bottleneck_dim": 3, "epochs": 300},
        training_dataset_hash=h,
        metrics={"n_train_windows": len(X)},
    )
    return edge, deep


if __name__ == "__main__":
    reg = ModelRegistry(Path(__file__).resolve().parents[2] / "mlops_store")
    train_and_register(reg)
    print(reg.active_version("anomaly_detection_edge"))
    print(reg.active_version("anomaly_detection_deep"))
