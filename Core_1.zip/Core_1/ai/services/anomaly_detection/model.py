"""ai/services/anomaly_detection/model.py

§8.10 Anomaly Detection AI. "Isolation Forest (fast, effective
baseline for tabular telemetry features), Autoencoder / Variational
Autoencoder (reconstruction-error-based detection for higher-
dimensional or sequence data)". Deployment: "Lightweight Isolation
Forest at the edge ... heavier autoencoder/VAE models in the cloud."

Both are implemented for real here: IsolationForest (sklearn) is
genuinely lightweight enough to run at the edge; the autoencoder is a
small numpy-only (no torch dependency) 2-layer bottleneck network
trained with plain gradient descent — deliberately minimal, since its
role in this codebase is to demonstrate the reconstruction-error path
on higher-dimensional feature vectors, not to be a state-of-the-art
VAE.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
from sklearn.ensemble import IsolationForest


@dataclass
class AnomalyResult:
    anomaly_score: float  # higher = more anomalous, roughly in [0, 1]
    is_anomaly: bool
    contributing_features: dict  # feature_name -> |z-score|, top contributors


class EdgeIsolationForestDetector:
    """§8.10 edge path — trained once on normal-operation data only
    (unsupervised, per spec), no labeled failure examples required."""

    def __init__(self, contamination: float = 0.02, n_estimators: int = 100):
        self.model = IsolationForest(
            contamination=contamination, n_estimators=n_estimators, random_state=0
        )
        self._feature_names: list[str] = []
        self._mu: Optional[np.ndarray] = None
        self._sigma: Optional[np.ndarray] = None

    def fit(self, X_normal: np.ndarray, feature_names: list[str]) -> "EdgeIsolationForestDetector":
        self._feature_names = list(feature_names)
        self._mu = X_normal.mean(axis=0)
        self._sigma = np.clip(X_normal.std(axis=0), 1e-6, None)
        self.model.fit(X_normal)
        return self

    def score(self, x: np.ndarray) -> AnomalyResult:
        raw = -self.model.score_samples(x.reshape(1, -1))[0]  # higher = more anomalous
        # squash IsolationForest's raw score onto [0, 1] via a logistic
        # centered on the model's own decision threshold (offset_)
        centered = raw + self.model.offset_
        score01 = float(1.0 / (1.0 + np.exp(-8.0 * centered)))
        is_anom = bool(self.model.predict(x.reshape(1, -1))[0] == -1)

        z = np.abs((x - self._mu) / self._sigma)
        top_idx = np.argsort(-z)[:3]
        contributing = {self._feature_names[i]: float(z[i]) for i in top_idx}

        return AnomalyResult(score01, is_anom, contributing)


class TinyAutoencoder:
    """Minimal 2-layer bottleneck autoencoder, pure numpy, trained
    with full-batch gradient descent (MSE loss). This is the §8.10
    cloud-side "deeper, cross-signal analysis" path for higher-
    dimensional feature vectors."""

    def __init__(self, input_dim: int, bottleneck_dim: int = 3, seed: int = 0):
        rng = np.random.default_rng(seed)
        scale = np.sqrt(2.0 / input_dim)
        self.W1 = rng.normal(0, scale, size=(input_dim, bottleneck_dim))
        self.b1 = np.zeros(bottleneck_dim)
        self.W2 = rng.normal(0, scale, size=(bottleneck_dim, input_dim))
        self.b2 = np.zeros(input_dim)
        self._recon_error_std = 1.0

    @staticmethod
    def _tanh(x):
        return np.tanh(x)

    def _forward(self, X: np.ndarray):
        h = self._tanh(X @ self.W1 + self.b1)
        out = h @ self.W2 + self.b2
        return h, out

    def fit(self, X_normal: np.ndarray, epochs: int = 300, lr: float = 0.02) -> "TinyAutoencoder":
        X = X_normal.astype(float)
        n = len(X)
        for _ in range(epochs):
            h, out = self._forward(X)
            err = out - X
            grad_W2 = h.T @ err / n
            grad_b2 = err.mean(axis=0)
            grad_h = (err @ self.W2.T) * (1 - h ** 2)
            grad_W1 = X.T @ grad_h / n
            grad_b1 = grad_h.mean(axis=0)

            self.W2 -= lr * grad_W2
            self.b2 -= lr * grad_b2
            self.W1 -= lr * grad_W1
            self.b1 -= lr * grad_b1

        _, out = self._forward(X)
        recon_errors = np.mean((out - X) ** 2, axis=1)
        self._recon_error_std = max(float(np.std(recon_errors)), 1e-6)
        self._recon_error_mean = float(np.mean(recon_errors))
        return self

    def score(self, x: np.ndarray) -> AnomalyResult:
        _, out = self._forward(x.reshape(1, -1))
        recon_error = float(np.mean((out[0] - x) ** 2))
        z = (recon_error - self._recon_error_mean) / self._recon_error_std
        score01 = float(1.0 / (1.0 + np.exp(-z)))
        return AnomalyResult(score01, is_anomaly=z > 3.0, contributing_features={})
