"""ai/services/fleet_intelligence/service.py

§8.11 Fleet Intelligence AI. "Cloud-only — this is inherently a
cross-robot, cross-site aggregation service." Unlike every other
service in ai/services/, this one is explicitly allowed to read
across the Insights Bus's history (§8.2: "The Decision Support
Dashboard subscribes to this bus and is the only consumer that
aggregates across services" — Fleet Intelligence is the other
sanctioned cross-robot aggregator the spec names, at §8.11, and it
still only ever reads insight history, never calls another service's
methods directly).

§8.11's Output row names six things: "Production bottleneck
identification, idle-robot detection, utilization and OEE-style
metrics, energy comparison across robots, maintenance-priority
ranking, production forecasting." Five of six are implemented below.
`production_forecasting` is the one honestly-scoped exception: it
needs a per-robot cycle-count time series to forecast against, and no
service in ai/ currently publishes one (the platform doc's own
Fleet Management module, §17.1's `programs`/`robots` tables, would be
the real source) — rather than fabricate a forecast from data that
doesn't exist, this returns `null` with an explicit reason so a
caller can tell the difference between "forecast: stable" and
"forecast: not computed."
"""
from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import numpy as np  # noqa: E402

from common.base_service import AIService  # noqa: E402
from common.insights_bus import InsightsBus  # noqa: E402
from common.schemas import ExecutionSite, InsightType  # noqa: E402


class FleetIntelligenceService(AIService):
    service_id = "fleet_intelligence"
    insight_type = InsightType.FLEET_INSIGHT
    execution_site = ExecutionSite.CLOUD

    # Idle-robot threshold: a robot with an activity fraction (moving
    # time / observed time) below this over the aggregation window is
    # flagged idle. §8.11 output: "idle-robot detection".
    IDLE_UTILIZATION_THRESHOLD = 0.05

    def __init__(self, bus: InsightsBus | None = None):
        super().__init__(bus=bus)
        # Per-robot activity ledger, fed by `record_activity()` — kept
        # local to this service rather than on the bus, since raw
        # move/idle ticks are high-frequency plumbing, not an
        # insight any other service needs to subscribe to.
        self._activity_active_seconds: Dict[str, float] = {}
        self._activity_total_seconds: Dict[str, float] = {}
        self._activity_last_ts: Dict[str, float] = {}

    def record_activity(self, robot_id: str, is_moving: bool, timestamp: Optional[float] = None) -> None:
        """Feed one telemetry sample's move-state into the utilization
        ledger — e.g. from `TelemetryOut.move_active` in
        dashboard/backend/main.py. Call this on every telemetry poll,
        same cadence as `observe()` on the other services."""
        now = timestamp if timestamp is not None else time.time()
        last = self._activity_last_ts.get(robot_id)
        dt = max(0.0, now - last) if last is not None else 0.0
        self._activity_total_seconds[robot_id] = self._activity_total_seconds.get(robot_id, 0.0) + dt
        if is_moving:
            self._activity_active_seconds[robot_id] = self._activity_active_seconds.get(robot_id, 0.0) + dt
        self._activity_last_ts[robot_id] = now

    def _utilization(self) -> Dict[str, float]:
        return {
            rid: round(self._activity_active_seconds.get(rid, 0.0) / total, 4)
            for rid, total in self._activity_total_seconds.items()
            if total > 0
        }

    def infer(self, robot_id: str = "fleet", window_seconds: float = 3600.0, **kwargs: Any) -> Dict[str, Any]:
        cutoff = time.time() - window_seconds
        maint = [
            i for i in self.bus.history(InsightType.PREDICTIVE_MAINTENANCE, limit=5000)
            if i.timestamp >= cutoff
        ]
        anomalies = [
            i for i in self.bus.history(InsightType.ANOMALY, limit=5000)
            if i.timestamp >= cutoff and i.payload.get("is_anomaly")
        ]
        quality = [
            i for i in self.bus.history(InsightType.QUALITY_INSPECTION, limit=5000)
            if i.timestamp >= cutoff
        ]
        energy = [
            i for i in self.bus.history(InsightType.ENERGY_OPTIMIZATION, limit=5000)
            if i.timestamp >= cutoff and i.payload.get("energy_per_cycle_j") is not None
        ]

        # Maintenance-priority ranking: lowest RUL first.
        priority = sorted(
            (
                {"robot_id": i.robot_id, "joint_name": i.payload.get("joint_name"),
                 "remaining_useful_life_hours": i.payload.get("remaining_useful_life_hours")}
                for i in maint
                if i.payload.get("remaining_useful_life_hours") is not None
            ),
            key=lambda r: r["remaining_useful_life_hours"],
        )[:10]

        anomaly_counts: Dict[str, int] = {}
        for i in anomalies:
            anomaly_counts[i.robot_id] = anomaly_counts.get(i.robot_id, 0) + 1

        pass_rates: Dict[str, List[bool]] = {}
        for i in quality:
            pass_rates.setdefault(i.robot_id, []).append(bool(i.payload.get("passed")))
        quality_summary = {
            rid: {"n_inspections": len(v), "pass_rate": float(np.mean(v)) if v else None}
            for rid, v in pass_rates.items()
        }

        # Energy comparison across robots (§8.11 output).
        energy_by_robot: Dict[str, List[float]] = {}
        for i in energy:
            energy_by_robot.setdefault(i.robot_id, []).append(float(i.payload["energy_per_cycle_j"]))
        energy_comparison = sorted(
            (
                {"robot_id": rid, "mean_energy_per_cycle_j": round(float(np.mean(v)), 2), "n_samples": len(v)}
                for rid, v in energy_by_robot.items()
            ),
            key=lambda r: r["mean_energy_per_cycle_j"],
            reverse=True,  # highest energy consumer first
        )

        # Utilization / idle-robot detection (§8.11 output).
        utilization = self._utilization()
        idle_robots = [rid for rid, frac in utilization.items() if frac < self.IDLE_UTILIZATION_THRESHOLD]

        payload = {
            "window_seconds": window_seconds,
            "maintenance_priority_ranking": priority,
            "anomaly_counts_by_robot": anomaly_counts,
            "quality_summary_by_robot": quality_summary,
            "energy_comparison_by_robot": energy_comparison,
            "utilization_by_robot": utilization,
            "idle_robots": idle_robots,
            "bottleneck_candidates": [rid for rid, c in anomaly_counts.items() if c >= 3],
            "production_forecasting": None,  # honestly not computed — see module docstring
        }
        n_total = len(maint) + len(anomalies) + len(quality) + len(energy) + len(utilization)
        confidence = float(np.clip(n_total / 50.0, 0.1, 0.95))
        return self._result(payload, confidence)
