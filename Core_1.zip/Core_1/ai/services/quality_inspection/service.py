"""ai/services/quality_inspection/service.py

§8.6 Quality Inspection AI, wrapped as an AIService. Per the platform
doc's own instruction ("Quality inspection is powered by the computer
vision capability set detailed in full in Section 9 ... This
subsection summarizes it against the platform-wide AI service
template"), this does NOT reimplement inspection — it wraps this
repo's already-built, already-tested `vision/quality_inspection`
module (see robotic_arm_core/vision/README.md: "16/16 tests pass
against real synthetic image/point data") and adapts its output onto
the AI Insights Bus with the §8.6 confidence-routing behaviour: a
low-confidence detection is routed to human review rather than
auto-rejected.

`cv2` (opencv-python-headless) IS installed in this sandbox — this
was verified directly (`import cv2; cv2.__version__` → 4.13.0), not
assumed. An earlier version of this docstring incorrectly claimed
otherwise, based on a package check (see ai/requirements.txt's
history) that covered numpy/scipy/sklearn/pandas/xgboost/torch/
pydantic/fastapi but never actually checked cv2 — that was a real
documentation bug, caught and fixed by testing the claim rather than
propagating it. The `import` is still deferred into `infer()` rather
than done at module load time regardless, since that's good practice
independent of whether cv2 happens to be present: it keeps this
service importable (and every OTHER AI service's test collection
un-broken) in any environment where `cv2` genuinely isn't installed,
with a clear, actionable "vision backend unavailable" note as the
failure mode rather than an import-time crash.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common.base_service import AIService  # noqa: E402
from common.schemas import ExecutionSite, InsightType  # noqa: E402

_VISION_QI_DIR = Path(__file__).resolve().parents[3] / "vision" / "quality_inspection"


class QualityInspectionService(AIService):
    service_id = "quality_inspection"
    insight_type = InsightType.QUALITY_INSPECTION
    execution_site = ExecutionSite.EDGE  # §8.14: must complete within the robot cycle-time budget

    def __init__(self, diff_threshold: int = 30, pass_score_max: float = 0.01, bus=None):
        super().__init__(bus=bus)
        self.diff_threshold = diff_threshold
        self.pass_score_max = pass_score_max

    def infer(
        self,
        robot_id: str,
        test_image_bgr: Optional[np.ndarray] = None,
        golden_image_bgr: Optional[np.ndarray] = None,
        part_id: str = "",
        **kwargs: Any,
    ) -> Dict[str, Any]:
        if test_image_bgr is None or golden_image_bgr is None:
            return self._result({"part_id": part_id, "note": "missing test/golden image"}, confidence_score=0.0)

        if str(_VISION_QI_DIR) not in sys.path:
            sys.path.insert(0, str(_VISION_QI_DIR))
        try:
            from quality_inspection import inspect_against_golden  # noqa: E402
        except ImportError as exc:  # pragma: no cover - depends on cv2 availability
            return self._result(
                {"part_id": part_id, "note": f"vision backend unavailable: {exc}"},
                confidence_score=0.0,
            )

        result = inspect_against_golden(
            test_image_bgr, golden_image_bgr, diff_threshold=self.diff_threshold, pass_score_max=self.pass_score_max
        )

        # §8.6: "Per-detection confidence from the model's native
        # output head; low-confidence detections are routed to a
        # human review queue rather than auto-rejected." The classical
        # detector doesn't emit a native confidence, so distance from
        # the pass/fail threshold (relative margin) stands in for it —
        # a borderline anomaly_score is exactly the case that should
        # route to human review, not a hard reject.
        margin = abs(result.anomaly_score - self.pass_score_max)
        confidence = float(np.clip(margin / max(self.pass_score_max, 1e-6), 0.05, 0.97))

        payload = {
            "part_id": part_id,
            "anomaly_score": round(result.anomaly_score, 5),
            "passed": result.passed,
            "auto_reject_reversible": True,  # §8.6 Human Override
        }
        return self._result(payload, confidence)
