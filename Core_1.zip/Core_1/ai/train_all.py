#!/usr/bin/env python3
"""ai/train_all.py — trains and registers every learned model in
ai/services/ against the shared ModelRegistry at ai/mlops_store/, in
dependency order. Run this once before examples/run_fleet_demo.py (or
let the demo train on first run — it calls the same functions).
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from common.mlops import ModelRegistry  # noqa: E402


def main() -> None:
    registry = ModelRegistry(Path(__file__).resolve().parent / "mlops_store")

    print("[1/4] predictive_maintenance ...")
    from services.predictive_maintenance.train import train_and_register as train_pm
    t0 = time.time()
    train_pm(registry)
    print(f"      done in {time.time() - t0:.1f}s -> {registry.active_version('predictive_maintenance')}")

    print("[2/5] thermal_intelligence (shared NumpyGRUForecaster, cloud cross-check model) ...")
    from services.thermal_intelligence.train import train_and_register as train_thermal
    t0 = time.time()
    train_thermal(registry)
    print(f"      done in {time.time() - t0:.1f}s -> {registry.active_version('thermal_intelligence_deep')}")

    print("[3/5] energy_optimization ...")
    from services.energy_optimization.train import train_and_register as train_energy
    t0 = time.time()
    train_energy(registry)
    print(f"      done in {time.time() - t0:.1f}s -> {registry.active_version('energy_optimization')}")

    print("[4/5] anomaly_detection (edge + deep) ...")
    from services.anomaly_detection.train import train_and_register as train_anomaly
    t0 = time.time()
    train_anomaly(registry)
    print(f"      done in {time.time() - t0:.1f}s")
    print(f"      edge -> {registry.active_version('anomaly_detection_edge')}")
    print(f"      deep -> {registry.active_version('anomaly_detection_deep')}")

    print("[5/5] motion_optimization_rl (PPO + staged deployment gate) ...")
    from services.motion_optimization_rl.train import run_full_pipeline
    t0 = time.time()
    _policy, gate, metrics = run_full_pipeline(registry, n_iterations=15)
    print(f"      done in {time.time() - t0:.1f}s, gate stage = {gate.stage.value}, metrics = {metrics}")

    print("\nAll registries written to ai/mlops_store/.")
    print("(digital_twin_intelligence, workspace_intelligence, quality_inspection,")
    print(" fleet_intelligence, and operator_assistant don't require offline training — see their service.py.)")


if __name__ == "__main__":
    main()
