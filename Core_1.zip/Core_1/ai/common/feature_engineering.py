"""ai/common/feature_engineering.py

Shared rolling-window feature extraction over TelemetrySample streams
(§4.1 monitored parameters -> §8.3 "rolling statistics, rate-of-
change" hand-engineered features). Used by predictive maintenance,
anomaly detection, and digital twin intelligence so all three compute
these features the same way instead of drifting apart.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List

import numpy as np

from .schemas import TelemetrySample


@dataclass
class RollingJointFeatures:
    """Fixed-size rolling window per joint, producing the tabular
    feature vector gradient-boosting models (§8.3) expect: mean, std,
    min, max, and first-difference rate-of-change per raw signal."""

    window_size: int = 50
    _current: Deque[float] = field(default_factory=deque)
    _torque: Deque[float] = field(default_factory=deque)
    _temp: Deque[float] = field(default_factory=deque)
    _velocity: Deque[float] = field(default_factory=deque)

    def push(self, current_a: float, torque_nm: float, temp_c: float, velocity: float) -> None:
        for dq, v in (
            (self._current, current_a),
            (self._torque, torque_nm),
            (self._temp, temp_c),
            (self._velocity, velocity),
        ):
            dq.append(v)
            while len(dq) > self.window_size:
                dq.popleft()

    def _stats(self, dq: Deque[float], name: str) -> Dict[str, float]:
        if len(dq) == 0:
            return {f"{name}_mean": 0.0, f"{name}_std": 0.0, f"{name}_roc": 0.0}
        arr = np.asarray(dq, dtype=float)
        roc = float(arr[-1] - arr[0]) / max(len(arr) - 1, 1)
        return {
            f"{name}_mean": float(arr.mean()),
            f"{name}_std": float(arr.std()),
            f"{name}_roc": roc,
        }

    def features(self) -> Dict[str, float]:
        out: Dict[str, float] = {}
        out.update(self._stats(self._current, "current"))
        out.update(self._stats(self._torque, "torque"))
        out.update(self._stats(self._temp, "temp"))
        out.update(self._stats(self._velocity, "velocity"))
        return out

    def as_vector(self) -> np.ndarray:
        f = self.features()
        return np.array([f[k] for k in sorted(f)], dtype=float)

    @staticmethod
    def feature_names() -> List[str]:
        base = ["current", "torque", "temp", "velocity"]
        names = []
        for b in base:
            names.extend([f"{b}_mean", f"{b}_roc", f"{b}_std"])
        return sorted(names)


def joint_summary(sample: TelemetrySample, joint_index: int) -> Dict[str, float]:
    """Pull a single joint's raw signals out of a TelemetrySample —
    every service that only cares about one joint at a time (e.g. a
    per-joint predictive-maintenance model) goes through this rather
    than indexing the sample's parallel arrays directly."""
    return {
        "position_deg": sample.position_deg[joint_index],
        "velocity_deg_s": sample.velocity_deg_s[joint_index],
        "current_a": sample.current_a[joint_index],
        "torque_estimate_nm": sample.torque_estimate_nm[joint_index],
        "winding_temp_c": sample.winding_temp_c[joint_index],
    }
