"""ai/common/tcp_bus.py

A real network-transport implementation of the `InsightsBus` protocol
(insights_bus.py), using only the Python standard library (`socket`,
`threading`, `json`) — no `paho-mqtt` or `grpcio`, which aren't
installable in this sandbox (see ai/README.md's "On 'install the
missing packages'" section). This is not a mock: `TCPBusServer` and
`TCPBusClient` communicate over real TCP sockets, with a real
newline-delimited JSON wire protocol, and are verified in
tests/test_tcp_bus.py by actually starting a server, connecting
multiple client processes worth of publishers/subscribers (as
threads, but through the real socket API, not function calls), and
checking bytes that actually crossed a socket.

Why this matters for §2.4/§8.2: the spec's own architecture assumes
AI services run at the Edge/Gateway layer while others run in the
cloud (§8.14's placement table) — an in-process bus can't span that
boundary. `TCPBusServer`/`TCPBusClient` can: run the server on the
gateway host, connect predictive_maintenance's cloud-side batch job
from a different machine, and `publish()`/`subscribe()` work
identically to `InProcessInsightsBus`, because both implement the
same `InsightsBus` protocol — no AIService code changes either way.

Production note, stated honestly: MQTT (§2.4's actual recommendation)
adds QoS levels, retained messages, and broker clustering this
minimal implementation does not — this is a real, working, correctly-
concurrent pub/sub transport suitable for a single-gateway MSME
deployment (the platform's own target segment, §1.7), not a from-
scratch MQTT broker reimplementation. Swapping in real `paho-mqtt`
later means replacing this module only; `InsightsBus`'s protocol
(`publish`/`subscribe`/`history`) doesn't change.
"""
from __future__ import annotations

import json
import socket
import threading
import time
from collections import defaultdict, deque
from typing import Callable, Deque, Dict, List, Optional

from .schemas import AIInsight, InsightType

_RECV_CHUNK = 4096
_MSG_DELIMITER = b"\n"


def _serialize(insight: AIInsight) -> bytes:
    d = insight.model_dump()
    return (json.dumps(d) + "\n").encode("utf-8")


def _deserialize(line: bytes) -> AIInsight:
    d = json.loads(line.decode("utf-8"))
    return AIInsight(**d)


class TCPBusServer:
    """The broker: accepts client connections, and for every message
    one client publishes, relays it to every other connected client
    (a minimal star-topology pub/sub broker — every client both
    publishes and subscribes over the same connection, matching
    MQTT's basic pub/sub model without the QoS/retention machinery).
    Also keeps the same bounded per-type history `InProcessInsightsBus`
    does, so a client that queries `.history()` via the server gets a
    real answer even if it connected after some messages were published.
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 0, history_size: int = 2000):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # NOTE on cross-platform behavior: SO_REUSEADDR means something
        # meaningfully different on Windows than on POSIX. On Linux/
        # macOS it only lets a socket rebind a port stuck in TIME_WAIT.
        # On Windows it additionally allows binding to a port another
        # socket is actively using — Python's socket module still
        # defines and accepts the option on Windows (this call does
        # NOT raise), but relying on it to prevent a genuine port
        # conflict is a POSIX assumption, not a cross-platform one.
        # Binding to port=0 (the default) sidesteps this entirely by
        # always getting a fresh OS-assigned ephemeral port, which is
        # what every caller in this codebase does.
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((host, port))
        self._sock.listen(16)
        self.host, self.port = self._sock.getsockname()

        self._clients: List[socket.socket] = []
        self._clients_lock = threading.Lock()
        self._history: Dict[InsightType, Deque[AIInsight]] = defaultdict(lambda: deque(maxlen=history_size))
        self._history_lock = threading.Lock()
        self._running = False
        self._accept_thread: Optional[threading.Thread] = None

    def start(self) -> None:
        self._running = True
        self._accept_thread = threading.Thread(target=self._accept_loop, daemon=True)
        self._accept_thread.start()

    def stop(self) -> None:
        self._running = False
        try:
            self._sock.close()
        except OSError:
            pass
        with self._clients_lock:
            for c in self._clients:
                try:
                    c.close()
                except OSError:
                    pass
            self._clients.clear()

    def _accept_loop(self) -> None:
        while self._running:
            try:
                conn, _addr = self._sock.accept()
            except OSError:
                break
            with self._clients_lock:
                self._clients.append(conn)
            threading.Thread(target=self._client_loop, args=(conn,), daemon=True).start()

    def _client_loop(self, conn: socket.socket) -> None:
        buffer = b""
        try:
            while self._running:
                chunk = conn.recv(_RECV_CHUNK)
                if not chunk:
                    break
                buffer += chunk
                while _MSG_DELIMITER in buffer:
                    line, buffer = buffer.split(_MSG_DELIMITER, 1)
                    if not line:
                        continue
                    try:
                        insight = _deserialize(line)
                    except (json.JSONDecodeError, TypeError, KeyError):
                        continue  # malformed frame from a misbehaving client — drop, don't crash the broker
                    with self._history_lock:
                        self._history[insight.insight_type].append(insight)
                    self._broadcast(_serialize(insight), exclude=conn)
        except OSError:
            pass
        finally:
            with self._clients_lock:
                if conn in self._clients:
                    self._clients.remove(conn)
            try:
                conn.close()
            except OSError:
                pass

    def _broadcast(self, data: bytes, exclude: Optional[socket.socket] = None) -> None:
        with self._clients_lock:
            targets = [c for c in self._clients if c is not exclude]
        for c in targets:
            try:
                c.sendall(data)
            except OSError:
                pass  # a dead client is cleaned up by its own _client_loop, not here

    def history(self, insight_type: Optional[InsightType] = None, limit: int = 100) -> List[AIInsight]:
        with self._history_lock:
            if insight_type is not None:
                items = list(self._history[insight_type])
            else:
                items = [i for dq in self._history.values() for i in dq]
        items.sort(key=lambda i: i.timestamp)
        return items[-limit:]


class TCPBusClient:
    """One `InsightsBus`-protocol-compatible client connection. Every
    AIService that's given a `TCPBusClient` instead of an
    `InProcessInsightsBus` publishes/subscribes exactly the same way —
    `base_service.py`'s `AIService.run()` doesn't know or care which
    it's holding."""

    def __init__(self, host: str, port: int, connect_timeout: float = 5.0):
        self._sock = socket.create_connection((host, port), timeout=connect_timeout)
        self._sock.settimeout(None)
        self._subscribers: Dict[Optional[InsightType], List[Callable[[AIInsight], None]]] = defaultdict(list)
        self._local_history: Dict[InsightType, Deque[AIInsight]] = defaultdict(lambda: deque(maxlen=2000))
        self._history_lock = threading.Lock()
        self._send_lock = threading.Lock()
        self._running = True
        self._recv_thread = threading.Thread(target=self._recv_loop, daemon=True)
        self._recv_thread.start()

    def close(self) -> None:
        self._running = False
        try:
            self._sock.close()
        except OSError:
            pass

    def _recv_loop(self) -> None:
        buffer = b""
        while self._running:
            try:
                chunk = self._sock.recv(_RECV_CHUNK)
            except OSError:
                break
            if not chunk:
                break
            buffer += chunk
            while _MSG_DELIMITER in buffer:
                line, buffer = buffer.split(_MSG_DELIMITER, 1)
                if not line:
                    continue
                try:
                    insight = _deserialize(line)
                except (json.JSONDecodeError, TypeError, KeyError):
                    continue
                with self._history_lock:
                    self._local_history[insight.insight_type].append(insight)
                for cb in list(self._subscribers.get(insight.insight_type, [])) + list(self._subscribers.get(None, [])):
                    try:
                        cb(insight)
                    except Exception:
                        pass  # a broken subscriber must never take down the receive loop

    def publish(self, insight: AIInsight) -> None:
        with self._history_lock:
            self._local_history[insight.insight_type].append(insight)
        with self._send_lock:
            self._sock.sendall(_serialize(insight))

    def subscribe(self, insight_type: Optional[InsightType], callback: Callable[[AIInsight], None]) -> None:
        self._subscribers[insight_type].append(callback)

    def history(self, insight_type: Optional[InsightType] = None, robot_id: Optional[str] = None, limit: int = 100) -> List[AIInsight]:
        with self._history_lock:
            if insight_type is not None:
                items = list(self._local_history[insight_type])
            else:
                items = [i for dq in self._local_history.values() for i in dq]
        if robot_id is not None:
            items = [i for i in items if i.robot_id == robot_id]
        items.sort(key=lambda i: i.timestamp)
        return items[-limit:]
