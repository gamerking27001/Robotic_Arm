"""ai/common/base_service.py

Common contract every §8.3-§8.12 AI service implements, so the
platform-wide guarantees in §8.1 ("AI never issues a motion command
directly") and §8.17 (human-in-the-loop, confidence thresholds, audit
logging) are enforced once, here, rather than re-implemented (and
potentially forgotten) in each of the ten services.
"""
from __future__ import annotations

import abc
from typing import Any, Dict, Optional

from .insights_bus import InsightsBus, get_default_bus
from .persistence import InsightStore
from .schemas import AIInsight, ExecutionSite, InsightType, make_insight


class AIService(abc.ABC):
    """Base class for every AI/ML service in ai/services/.

    Subclasses implement `infer()` only. Publishing to the bus,
    confidence-based human-review routing, the service/execution-
    site tagging on every insight, and (when a store is provided)
    persistence + alert-rule evaluation are handled here so no
    subclass can accidentally skip any of them.
    """

    service_id: str
    insight_type: InsightType
    execution_site: ExecutionSite = ExecutionSite.CLOUD
    confidence_floor_for_autonomy: float = 0.6

    def __init__(self, bus: Optional[InsightsBus] = None, store: Optional[InsightStore] = None):
        self.bus = bus or get_default_bus()
        # `store` is opt-in and defaults to None (no persistence) —
        # every existing call site across ai/ and dashboard/ that
        # doesn't pass one keeps working exactly as before; passing
        # one is how a caller opts into §17.1/§15.2 durable alerting.
        self.store = store

    @abc.abstractmethod
    def infer(self, robot_id: str, **kwargs: Any) -> Dict[str, Any]:
        """Run inference and return (payload, confidence_score) via
        `self._result(payload, confidence)` — see subclasses."""
        raise NotImplementedError

    def _result(self, payload: Dict[str, Any], confidence_score: float) -> Dict[str, Any]:
        return {"payload": payload, "confidence_score": confidence_score}

    def run(self, robot_id: str, **kwargs: Any) -> AIInsight:
        """Run inference, wrap it as an AIInsight, publish it on the
        bus, persist it (if a store is configured — this is also
        where alert rules get evaluated, see
        InsightStore.save_insight), and return it. This is the only
        way a service's output should leave the service (§8.2:
        publish-only, no direct service-to-service calls)."""
        result = self.infer(robot_id=robot_id, **kwargs)
        insight = make_insight(
            service_id=self.service_id,
            robot_id=robot_id,
            insight_type=self.insight_type,
            payload=result["payload"],
            confidence_score=result["confidence_score"],
            execution_site=self.execution_site,
            confidence_floor_for_autonomy=self.confidence_floor_for_autonomy,
        )
        self.bus.publish(insight)
        if self.store is not None:
            self.store.save_insight(insight)
        return insight
