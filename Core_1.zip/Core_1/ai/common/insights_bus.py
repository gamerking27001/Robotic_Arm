"""ai/common/insights_bus.py

§8.2: "All AI services communicate exclusively through the AI Insights
Bus ... individual AI services never call each other directly, which
keeps each service independently deployable and testable."

This is an in-process pub/sub implementation of that bus: topic is
insight_type, payload is AIInsight. It's deliberately transport-
agnostic — swap `InProcessInsightsBus` for an MQTT- or gRPC-backed
implementation of the same `InsightsBus` protocol (§2.4: MQTT/gRPC is
the real transport in production) without touching a single AI
service, because every service only ever calls `bus.publish(...)`.
"""
from __future__ import annotations

import logging
import threading
from collections import defaultdict, deque
from typing import Callable, Deque, Dict, List, Optional, Protocol

from .schemas import AIInsight, InsightType

logger = logging.getLogger("ai.insights_bus")

Subscriber = Callable[[AIInsight], None]


class InsightsBus(Protocol):
    def publish(self, insight: AIInsight) -> None: ...

    def subscribe(
        self, insight_type: Optional[InsightType], callback: Subscriber
    ) -> None: ...

    def history(
        self,
        insight_type: Optional[InsightType] = None,
        robot_id: Optional[str] = None,
        limit: int = 100,
    ) -> List[AIInsight]: ...


class InProcessInsightsBus:
    """Thread-safe in-process pub/sub bus with a bounded per-type
    ring buffer, so the Decision Support Dashboard / Fleet Intelligence
    (the only consumers allowed to aggregate across services, §8.2)
    can query recent history rather than only reacting to live events.
    """

    def __init__(self, history_size: int = 2000) -> None:
        self._lock = threading.RLock()
        self._subscribers: Dict[Optional[InsightType], List[Subscriber]] = defaultdict(list)
        self._history: Dict[InsightType, Deque[AIInsight]] = defaultdict(
            lambda: deque(maxlen=history_size)
        )
    def publish(self, insight: AIInsight) -> None:
        with self._lock:
            self._history[insight.insight_type].append(insight)
            subs = list(self._subscribers.get(insight.insight_type, [])) + list(
                self._subscribers.get(None, [])  # None == wildcard subscriber
            )
        for cb in subs:
            try:
                cb(insight)
            except Exception:  # a broken subscriber must not break the bus
                logger.exception(
                    "insights_bus subscriber raised while handling %s from %s",
                    insight.insight_type,
                    insight.service_id,
                )

    def subscribe(
        self, insight_type: Optional[InsightType], callback: Subscriber
    ) -> None:
        with self._lock:
            self._subscribers[insight_type].append(callback)

    def history(
        self,
        insight_type: Optional[InsightType] = None,
        robot_id: Optional[str] = None,
        limit: int = 100,
    ) -> List[AIInsight]:
        with self._lock:
            if insight_type is not None:
                items = list(self._history[insight_type])
            else:
                items = [i for dq in self._history.values() for i in dq]
        if robot_id is not None:
            items = [i for i in items if i.robot_id == robot_id]
        items.sort(key=lambda i: i.timestamp)
        return items[-limit:]


_default_bus: Optional[InProcessInsightsBus] = None
_default_bus_lock = threading.Lock()


def get_default_bus() -> InProcessInsightsBus:
    """Process-wide default bus, so services and the demo script don't
    each need to thread a bus instance through by hand. Real
    deployments inject an MQTT/gRPC-backed bus explicitly instead."""
    global _default_bus
    with _default_bus_lock:
        if _default_bus is None:
            _default_bus = InProcessInsightsBus()
        return _default_bus
