"""ai/common — shared framework for every AI/ML service (§8.2, §8.13).

Nothing in this package issues a motion command. That line is drawn
structurally: no module here imports the motion/kinematics/gateway
stack, and DeploymentGate (deployment_gate.py) is the only path by
which a learned artifact's output is allowed to reach the physical
robot at all — and even then, only via the same simulation-validated
program deployment flow every human-authored program already goes
through (see robotic_arm_core §7.5 and the platform doc §7.5/§17.3).
"""
