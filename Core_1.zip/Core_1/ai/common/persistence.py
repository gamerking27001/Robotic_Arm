"""ai/common/persistence.py

§17.1's database ER diagram defines `ALERTS` (id, robot_id, severity,
triggered_at, acknowledged_at) and `ALERT_RULES` (id, metric_name,
condition, severity) entities, and §15.2 requires "alarm entries
ranked by severity and requiring explicit operator acknowledgment for
red-tier events before they clear." Neither existed anywhere in ai/:
every insight lived only in `InProcessInsightsBus`'s in-memory ring
buffer, gone on restart, and nothing ever turned an insight crossing a
dangerous threshold into an actual alert an operator could see and
acknowledge. This closes that gap with real SQLite persistence
(`sqlite3`, stdlib — no new dependency) rather than another in-memory
structure.

Schema, and one disclosed deviation from the ER diagram: `ALERT_RULES`
in the spec's diagram has only (metric_name, condition, severity) —
not enough to disambiguate which insight_type's payload a metric name
belongs to once multiple services can produce a field with the same
name. This adds an `insight_type` column to `alert_rules` for that
reason, and splits the spec's single free-form `condition` string into
`operator`/`threshold` columns so rule evaluation never has to `eval()`
an untrusted string — both are additive, not a violation of the
spec's field set.
"""
from __future__ import annotations

import json
import sqlite3
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from .schemas import AIInsight, ExecutionSite, InsightType

_SCHEMA = """
CREATE TABLE IF NOT EXISTS insights (
    insight_id TEXT PRIMARY KEY,
    service_id TEXT NOT NULL,
    robot_id TEXT NOT NULL,
    timestamp REAL NOT NULL,
    insight_type TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    confidence_score REAL NOT NULL,
    execution_site TEXT NOT NULL,
    requires_human_review INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_insights_robot_type ON insights(robot_id, insight_type);
CREATE INDEX IF NOT EXISTS idx_insights_timestamp ON insights(timestamp);

CREATE TABLE IF NOT EXISTS alert_rules (
    id TEXT PRIMARY KEY,
    insight_type TEXT NOT NULL,
    metric_name TEXT NOT NULL,
    operator TEXT NOT NULL CHECK (operator IN ('>', '>=', '<', '<=', '==')),
    threshold REAL NOT NULL,
    severity TEXT NOT NULL CHECK (severity IN ('info', 'warning', 'critical')),
    message_template TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS alerts (
    id TEXT PRIMARY KEY,
    robot_id TEXT NOT NULL,
    severity TEXT NOT NULL CHECK (severity IN ('info', 'warning', 'critical')),
    message TEXT NOT NULL,
    triggered_at REAL NOT NULL,
    acknowledged_at REAL,
    acknowledged_by TEXT,
    source_insight_id TEXT NOT NULL,
    rule_id TEXT NOT NULL,
    FOREIGN KEY (source_insight_id) REFERENCES insights(insight_id),
    FOREIGN KEY (rule_id) REFERENCES alert_rules(id)
);
CREATE INDEX IF NOT EXISTS idx_alerts_robot ON alerts(robot_id);
CREATE INDEX IF NOT EXISTS idx_alerts_unacked ON alerts(acknowledged_at);
"""

_OPS = {
    ">": lambda v, t: v > t,
    ">=": lambda v, t: v >= t,
    "<": lambda v, t: v < t,
    "<=": lambda v, t: v <= t,
    "==": lambda v, t: v == t,
}

# Default rules seeded on first use — thresholds chosen to match the
# recommendation language each service already uses internally
# (predictive_maintenance._recommendation, thermal's cooling_strategy
# escalation points, anomaly_detection's own severity framing).
_DEFAULT_RULES = [
    ("predictive_maintenance", "remaining_useful_life_hours", "<", 168.0, "warning",
     "{robot_id}/{joint_name}: remaining useful life under 1 week ({remaining_useful_life_hours}h)"),
    ("predictive_maintenance", "remaining_useful_life_hours", "<", 24.0, "critical",
     "{robot_id}/{joint_name}: remaining useful life under 24h ({remaining_useful_life_hours}h) — schedule technician immediately"),
    ("anomaly", "anomaly_score", ">", 0.85, "critical",
     "{robot_id}/{joint_name}: high-confidence anomaly detected (score {anomaly_score})"),
    ("thermal_forecast", "overheat_probability", ">", 0.7, "critical",
     "{robot_id}/{joint_name}: overheat probability {overheat_probability} within forecast horizon"),
    ("digital_twin_deviation", "deviation_mm", ">", 5.0, "warning",
     "{robot_id}: digital twin deviation {deviation_mm}mm — recalibration recommended"),
]


@dataclass
class Alert:
    id: str
    robot_id: str
    severity: str
    message: str
    triggered_at: float
    acknowledged_at: Optional[float]
    acknowledged_by: Optional[str]
    source_insight_id: str
    rule_id: str

    @property
    def is_acknowledged(self) -> bool:
        return self.acknowledged_at is not None


class InsightStore:
    """SQLite-backed persistence for insights and the alerts derived
    from them. One store per process is typical (see
    `dashboard/backend/ai_routes.py` for the intended wiring), but the
    underlying file can be shared/reopened across restarts — that's
    the entire point: `InProcessInsightsBus` history is gone the
    moment the process exits, this isn't.
    """

    def __init__(self, db_path: str | Path = ":memory:"):
        self.db_path = str(db_path)
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        if self.db_path != ":memory:":
            # WAL (write-ahead logging) journal mode: readers don't
            # block writers and vice versa, which matters more on
            # Windows than POSIX — Windows' default rollback-journal
            # locking is stricter about concurrent file access (a
            # second process opening the same db file while one holds
            # a write transaction is more likely to hit "database is
            # locked" than on Linux/macOS). No-op / unnecessary for
            # ":memory:" databases, which is why this is guarded.
            self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(_SCHEMA)
        self._conn.commit()
        self._seed_default_rules_if_empty()

    def close(self) -> None:
        self._conn.close()

    def _seed_default_rules_if_empty(self) -> None:
        cur = self._conn.execute("SELECT COUNT(*) FROM alert_rules")
        if cur.fetchone()[0] > 0:
            return
        for insight_type, metric, op, threshold, severity, template in _DEFAULT_RULES:
            self.add_alert_rule(insight_type, metric, op, threshold, severity, template)

    # --- alert rules -----------------------------------------------------

    def add_alert_rule(
        self, insight_type: str, metric_name: str, operator: str, threshold: float,
        severity: str, message_template: str,
    ) -> str:
        if operator not in _OPS:
            raise ValueError(f"unsupported operator {operator!r}; must be one of {sorted(_OPS)}")
        rule_id = uuid.uuid4().hex
        self._conn.execute(
            "INSERT INTO alert_rules (id, insight_type, metric_name, operator, threshold, severity, message_template) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (rule_id, insight_type, metric_name, operator, threshold, severity, message_template),
        )
        self._conn.commit()
        return rule_id

    def _rules_for(self, insight_type: str) -> List[sqlite3.Row]:
        self._conn.row_factory = sqlite3.Row
        cur = self._conn.execute("SELECT * FROM alert_rules WHERE insight_type = ?", (insight_type,))
        return cur.fetchall()

    # --- insights + alert evaluation -----------------------------------

    def save_insight(self, insight: AIInsight) -> None:
        """Persist an insight, then evaluate every alert rule scoped
        to its insight_type against its payload — a rule fires exactly
        once per crossing (deduplicated against any existing
        UNACKNOWLEDGED alert for the same robot+rule, so a metric
        sitting above threshold for many consecutive insights doesn't
        spam a new alert every single time)."""
        d = insight.model_dump()
        self._conn.execute(
            "INSERT OR REPLACE INTO insights "
            "(insight_id, service_id, robot_id, timestamp, insight_type, payload_json, confidence_score, execution_site, requires_human_review) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                d["insight_id"], d["service_id"], d["robot_id"], d["timestamp"], d["insight_type"],
                json.dumps(d["payload"]), d["confidence_score"], d["execution_site"], int(d["requires_human_review"]),
            ),
        )
        self._conn.commit()
        self._evaluate_rules(insight)

    def _evaluate_rules(self, insight: AIInsight) -> None:
        insight_type_value = insight.insight_type.value if hasattr(insight.insight_type, "value") else insight.insight_type
        for rule in self._rules_for(insight_type_value):
            value = insight.payload.get(rule["metric_name"])
            if value is None or not isinstance(value, (int, float)):
                continue
            if not _OPS[rule["operator"]](value, rule["threshold"]):
                continue
            if self._has_open_alert(insight.robot_id, rule["id"]):
                continue  # already alerting on this condition for this robot — don't spam duplicates
            try:
                message = rule["message_template"].format(robot_id=insight.robot_id, **insight.payload)
            except (KeyError, IndexError):
                message = f"{insight.robot_id}: {rule['metric_name']}={value} crossed {rule['operator']}{rule['threshold']}"
            self._create_alert(insight.robot_id, rule["severity"], message, insight.insight_id, rule["id"])

    def _has_open_alert(self, robot_id: str, rule_id: str) -> bool:
        cur = self._conn.execute(
            "SELECT 1 FROM alerts WHERE robot_id = ? AND rule_id = ? AND acknowledged_at IS NULL LIMIT 1",
            (robot_id, rule_id),
        )
        return cur.fetchone() is not None

    def _create_alert(self, robot_id: str, severity: str, message: str, source_insight_id: str, rule_id: str) -> str:
        alert_id = uuid.uuid4().hex
        self._conn.execute(
            "INSERT INTO alerts (id, robot_id, severity, message, triggered_at, acknowledged_at, acknowledged_by, source_insight_id, rule_id) "
            "VALUES (?, ?, ?, ?, ?, NULL, NULL, ?, ?)",
            (alert_id, robot_id, severity, message, time.time(), source_insight_id, rule_id),
        )
        self._conn.commit()
        return alert_id

    # --- queries -----------------------------------------------------

    def query_insights(
        self, insight_type: Optional[str] = None, robot_id: Optional[str] = None, limit: int = 100,
    ) -> List[Dict[str, Any]]:
        self._conn.row_factory = sqlite3.Row
        query = "SELECT * FROM insights WHERE 1=1"
        params: List[Any] = []
        if insight_type is not None:
            query += " AND insight_type = ?"
            params.append(insight_type)
        if robot_id is not None:
            query += " AND robot_id = ?"
            params.append(robot_id)
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(query, params).fetchall()
        return [
            {**dict(r), "payload": json.loads(r["payload_json"]), "requires_human_review": bool(r["requires_human_review"])}
            for r in rows
        ]

    def list_alerts(self, robot_id: Optional[str] = None, unacknowledged_only: bool = False, limit: int = 100) -> List[Alert]:
        self._conn.row_factory = sqlite3.Row
        # Severity ranking (§15.2 "ranked by severity") — critical
        # first, then warning, then info, newest within each tier first.
        query = (
            "SELECT * FROM alerts WHERE 1=1"
            + (" AND robot_id = ?" if robot_id else "")
            + (" AND acknowledged_at IS NULL" if unacknowledged_only else "")
            + " ORDER BY CASE severity WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2 END, triggered_at DESC"
            + " LIMIT ?"
        )
        params = ([robot_id] if robot_id else []) + [limit]
        rows = self._conn.execute(query, params).fetchall()
        return [Alert(**{k: r[k] for k in r.keys()}) for r in rows]

    def acknowledge_alert(self, alert_id: str, acknowledged_by: str) -> bool:
        """§15.2: "requiring explicit operator acknowledgment for
        red-tier events before they clear from the active alarm
        list." Returns False if the alert doesn't exist or is already
        acknowledged (idempotent — acknowledging twice isn't an error,
        but only the first call actually changes anything)."""
        cur = self._conn.execute(
            "UPDATE alerts SET acknowledged_at = ?, acknowledged_by = ? WHERE id = ? AND acknowledged_at IS NULL",
            (time.time(), acknowledged_by, alert_id),
        )
        self._conn.commit()
        return cur.rowcount > 0
