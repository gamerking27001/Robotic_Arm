"""ai/common/api.py

§17.2 "API Design Philosophy" implemented as a transport-agnostic
request router, so it's real and testable in this sandbox (no
network access to install FastAPI) and a thin FastAPI/gRPC adapter
can sit in front of it later without re-implementing any of the
five principles the spec lists:

  - Protocol matched to pattern: out of scope for this file (that's
    a transport decision — REST/gRPC/WebSocket/MQTT, §2.4); this
    router only implements what's protocol-independent underneath.
  - Versioned contracts: every route is registered under an explicit
    version prefix (`/v1/...`); calling an unversioned or unknown
    version is a `not_found` error, not silent fallback.
  - Idempotent command endpoints: `dispatch()` takes an optional
    `idempotency_key`; a repeated key returns the ORIGINAL response
    without re-invoking the handler, so a retried request after a
    dropped connection can't double-fire a side-effecting call.
  - Least-privilege scoping: every call is checked against a
    `TokenScope` (role + robot/site set) BEFORE the handler runs, at
    the router level — a handler is never reached with an
    out-of-scope request, so a compromised or buggy handler can't
    accidentally leak past the scope check.
  - Explicit error taxonomy: `ApiError.code` is restricted to the
    six values §17.2 names — validation, permission, not_found,
    conflict, robot_unreachable, robot_rejected — so every client
    error path is one of six known shapes, never an ad-hoc string.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, Optional, Set


class ErrorCode(str, Enum):
    VALIDATION = "validation"
    PERMISSION = "permission"
    NOT_FOUND = "not_found"
    CONFLICT = "conflict"
    ROBOT_UNREACHABLE = "robot_unreachable"
    ROBOT_REJECTED = "robot_rejected"


class ApiError(Exception):
    def __init__(self, code: ErrorCode, message: str):
        super().__init__(message)
        self.code = code
        self.message = message

    def to_dict(self) -> Dict[str, str]:
        return {"error_code": self.code.value, "message": self.message}


@dataclass
class TokenScope:
    """§12.4/§17.2 least-privilege scoping: a token is bound to a role
    (§3.3's role model) and a bounded robot/site set — never a blanket
    grant — at issuance time, not just enforced in application logic."""

    role: str
    allowed_robot_ids: Optional[Set[str]] = None  # None == fleet-wide (Fleet Administrator only)

    def permits(self, robot_id: Optional[str], required_role: Optional[str] = None) -> bool:
        if required_role is not None and self.role != required_role and self.role != "fleet_administrator":
            return False
        if robot_id is None or self.allowed_robot_ids is None:
            return True
        return robot_id in self.allowed_robot_ids


@dataclass
class Route:
    version: str
    path: str
    handler: Callable[..., Dict[str, Any]]
    required_role: Optional[str] = None


class ApiRouter:
    def __init__(self):
        self._routes: Dict[tuple, Route] = {}
        self._idempotency_cache: Dict[str, Dict[str, Any]] = {}

    def register(self, version: str, path: str, handler: Callable[..., Dict[str, Any]], required_role: Optional[str] = None) -> None:
        self._routes[(version, path)] = Route(version, path, handler, required_role)

    def dispatch(
        self,
        version: str,
        path: str,
        scope: TokenScope,
        robot_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        route = self._routes.get((version, path))
        if route is None:
            raise ApiError(ErrorCode.NOT_FOUND, f"no route registered for {version}{path}")

        if not scope.permits(robot_id, route.required_role):
            raise ApiError(ErrorCode.PERMISSION, f"token scope does not permit {version}{path} for robot_id={robot_id!r}")

        if idempotency_key is not None:
            cache_key = f"{version}:{path}:{idempotency_key}"
            if cache_key in self._idempotency_cache:
                return self._idempotency_cache[cache_key]

        try:
            result = route.handler(robot_id=robot_id, **kwargs)
        except ApiError:
            raise
        except Exception as exc:  # noqa: BLE001 - deliberately broad: any handler failure becomes a typed error
            raise ApiError(ErrorCode.ROBOT_REJECTED, f"handler raised: {exc}") from exc

        response = {"status": "ok", "data": result, "timestamp": time.time()}
        if idempotency_key is not None:
            self._idempotency_cache[f"{version}:{path}:{idempotency_key}"] = response
        return response


def build_default_router(services: Dict[str, Any]) -> ApiRouter:
    """Wires every AIService's `.run()` onto a versioned §17.2 route,
    e.g. dispatch("v1", "/predictive_maintenance/infer", scope, robot_id=...).
    `services` maps service_id -> AIService instance (see
    examples/run_api_demo.py for a fully wired example)."""
    router = ApiRouter()
    for service_id, service in services.items():

        def _make_handler(svc):
            def _handler(robot_id: str, **kwargs: Any) -> Dict[str, Any]:
                insight = svc.run(robot_id=robot_id, **kwargs)
                return insight.model_dump()
            return _handler

        router.register("v1", f"/{service_id}/infer", _make_handler(service))
    return router
