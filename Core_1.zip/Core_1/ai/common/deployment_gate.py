"""ai/common/deployment_gate.py

§8.7.4 "Sim-to-Real Transfer and Safety-Gated Deployment": "A trained
policy never goes directly from simulation to unsupervised fleet-wide
use." §8.13 generalizes the same gate to every learned model in the
platform, not just RL policies.

This module is the load-bearing safety mechanism of the whole ai/
package: it is the ONLY path by which a candidate model/policy is
allowed to move from "trained" to "affecting a robot's behavior", and
every state transition requires an explicit, checkable condition to
pass — there is no direct SHADOW -> FLEET_WIDE edge, and any anomaly
during or after rollout drops the state machine straight back to the
prior artifact, unconditionally.

This governs learned artifacts only (predictive-maintenance models,
anomaly detectors, RL motion policies, ...). It is not a robot motion
interface and never will be: nothing in this file, or anywhere in
ai/, calls into the motion controller (include/motion/) or the ROS2
gateway. A candidate trajectory produced by the motion-optimization
service (§8.7) still has to pass the ordinary simulation-validated
collision/limit check (§7.5) before deployment — this gate controls
whether the *policy that produced the trajectory* is trusted enough
to be asked at all.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, List, Optional


class RolloutStage(str, Enum):
    CANDIDATE = "candidate"
    SHADOW_MODE = "shadow_mode"
    STAGED_ROLLOUT = "staged_rollout"
    FLEET_WIDE = "fleet_wide"
    REJECTED = "rejected"
    ROLLED_BACK = "rolled_back"


@dataclass
class ShadowModeResult:
    """Logged performance of a candidate compared to the currently
    deployed artifact, on live telemetry, without ever commanding the
    robot (§8.7.4 "Shadow Mode")."""

    candidate_metric: float
    incumbent_metric: float
    safety_margin_ok: bool

    @property
    def improved(self) -> bool:
        # Metric convention: higher is better (e.g. -cycle_time, or
        # -RUL_prediction_error). Callers normalize their own metric.
        return self.candidate_metric > self.incumbent_metric and self.safety_margin_ok


@dataclass
class StagedRolloutMonitorResult:
    cycles_observed: int
    cycles_required: int
    anomaly_detected: bool

    @property
    def stable(self) -> bool:
        return self.cycles_observed >= self.cycles_required and not self.anomaly_detected


@dataclass
class GateEvent:
    timestamp: float
    from_stage: RolloutStage
    to_stage: RolloutStage
    reason: str


class DeploymentGate:
    """One gate instance per (service_id, robot-or-fleet scope). Call
    sequence mirrors §8.7.4's diagram exactly:

        candidate -> shadow_mode -> [staged_rollout] -> fleet_wide
                                  \\-> rejected
                       [staged_rollout] -> rolled_back (on anomaly)

    Every transition is logged (`self.history`) so the audit trail
    §8.17 requires ("every deployment-gate decision ... is logged")
    is a property of using this class, not something a caller has to
    remember to do separately.
    """

    REQUIRED_STABLE_CYCLES = 25

    def __init__(self, service_id: str, min_required_cycles: Optional[int] = None):
        self.service_id = service_id
        self.stage = RolloutStage.CANDIDATE
        self.min_required_cycles = min_required_cycles or self.REQUIRED_STABLE_CYCLES
        self.history: List[GateEvent] = []
        self._cycles_observed = 0

    def _transition(self, to_stage: RolloutStage, reason: str) -> None:
        self.history.append(
            GateEvent(time.time(), self.stage, to_stage, reason)
        )
        self.stage = to_stage

    def enter_shadow_mode(self) -> None:
        if self.stage != RolloutStage.CANDIDATE:
            raise RuntimeError(f"cannot enter shadow mode from {self.stage}")
        self._transition(RolloutStage.SHADOW_MODE, "candidate registered for shadow evaluation")

    def evaluate_shadow_mode(self, result: ShadowModeResult) -> bool:
        if self.stage != RolloutStage.SHADOW_MODE:
            raise RuntimeError(f"not in shadow mode (currently {self.stage})")
        if result.improved:
            self._cycles_observed = 0
            self._transition(
                RolloutStage.STAGED_ROLLOUT,
                f"shadow mode improvement {result.candidate_metric:.4f} > "
                f"{result.incumbent_metric:.4f}, safety margin OK",
            )
            return True
        self._transition(
            RolloutStage.REJECTED,
            f"shadow mode regression or unsafe "
            f"(candidate={result.candidate_metric:.4f}, "
            f"incumbent={result.incumbent_metric:.4f}, "
            f"safety_margin_ok={result.safety_margin_ok})",
        )
        return False

    def observe_staged_cycle(self, anomaly_detected: bool) -> StagedRolloutMonitorResult:
        if self.stage != RolloutStage.STAGED_ROLLOUT:
            raise RuntimeError(f"not in staged rollout (currently {self.stage})")
        if anomaly_detected:
            self._transition(
                RolloutStage.ROLLED_BACK,
                "anomaly detected during staged rollout — automatic, immediate rollback",
            )
            return StagedRolloutMonitorResult(self._cycles_observed, self.min_required_cycles, True)

        self._cycles_observed += 1
        result = StagedRolloutMonitorResult(
            self._cycles_observed, self.min_required_cycles, False
        )
        if result.stable:
            self._transition(
                RolloutStage.FLEET_WIDE,
                f"{self._cycles_observed} consecutive clean cycles — promoting to fleet-wide via OTA",
            )
        return result

    def rollback(self, reason: str) -> None:
        """Any anomaly during or after rollout — immediate, automatic,
        does not wait for operator action (§8.7.4 'Automatic
        Rollback' row)."""
        self._transition(RolloutStage.ROLLED_BACK, reason)

    def is_authorized_for_fleet(self) -> bool:
        return self.stage == RolloutStage.FLEET_WIDE

    def summary(self) -> Dict[str, object]:
        return {
            "service_id": self.service_id,
            "stage": self.stage.value,
            "cycles_observed": self._cycles_observed,
            "history": [
                {
                    "timestamp": e.timestamp,
                    "from": e.from_stage.value,
                    "to": e.to_stage.value,
                    "reason": e.reason,
                }
                for e in self.history
            ],
        }
