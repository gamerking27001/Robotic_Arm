"""ai/common/mlops.py

§8.13 MLOps pipeline, generalized across every service in §8.3-§8.12
rather than reimplemented per-service:

  Versioning     -> ModelRegistry
  Monitoring     -> FeatureMonitor (input-distribution tracking)
  Drift Detection-> population_stability_index() + FeatureMonitor.check_drift
  Retraining     -> RetrainingScheduler (interval + event-triggered)
  Rollback       -> ModelRegistry.rollback() (reuses the same staged
                    gating pattern as DeploymentGate, see
                    deployment_gate.py's module docstring)

No ML framework (MLflow, Prometheus) is available in this sandbox, so
this is a real, working, dependency-free stand-in with the same
contract: every artifact is versioned, every version is diffable
against its predecessor, and nothing is deployed by silently
overwriting the previous version.
"""
from __future__ import annotations

import json
import pickle
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np


@dataclass
class ModelVersion:
    version_id: int
    service_id: str
    created_at: float
    hyperparameters: Dict[str, Any]
    training_dataset_hash: str
    metrics: Dict[str, float]
    artifact_path: str
    status: str = "registered"  # registered -> active -> retired | rejected


class ModelRegistry:
    """File-backed model registry: one JSON manifest per service plus
    a pickled artifact per version, under `store_dir`. This is the
    §8.13 "Versioning" row — every trained model artifact, its
    hyperparameters, and its training dataset snapshot hash are
    logged and linked to a unique version ID.
    """

    def __init__(self, store_dir: str | Path):
        self.store_dir = Path(store_dir)
        self.store_dir.mkdir(parents=True, exist_ok=True)

    def _manifest_path(self, service_id: str) -> Path:
        return self.store_dir / f"{service_id}.manifest.json"

    def _load_manifest(self, service_id: str) -> List[Dict[str, Any]]:
        p = self._manifest_path(service_id)
        if not p.exists():
            return []
        return json.loads(p.read_text(encoding="utf-8"))

    def _save_manifest(self, service_id: str, entries: List[Dict[str, Any]]) -> None:
        # Explicit encoding="utf-8": Path.write_text()/.read_text()
        # default to the platform's locale encoding, which on Windows
        # is frequently a codepage other than UTF-8 (e.g. cp1252) —
        # without this, a hyperparameter value or joint name containing
        # a non-ASCII character could round-trip incorrectly, or raise
        # a UnicodeDecodeError, on Windows specifically while working
        # fine on Linux/macOS. Caught by an explicit cross-platform
        # audit, not by hitting the failure — see ai/README.md's
        # Windows-compatibility note.
        self._manifest_path(service_id).write_text(json.dumps(entries, indent=2), encoding="utf-8")

    def register(
        self,
        service_id: str,
        artifact: Any,
        hyperparameters: Dict[str, Any],
        training_dataset_hash: str,
        metrics: Dict[str, float],
        activate: bool = True,
    ) -> ModelVersion:
        entries = self._load_manifest(service_id)
        version_id = (entries[-1]["version_id"] + 1) if entries else 1
        artifact_path = self.store_dir / f"{service_id}.v{version_id}.pkl"
        with open(artifact_path, "wb") as f:
            pickle.dump(artifact, f)

        if activate:
            for e in entries:
                if e["status"] == "active":
                    e["status"] = "retired"

        mv = ModelVersion(
            version_id=version_id,
            service_id=service_id,
            created_at=time.time(),
            hyperparameters=hyperparameters,
            training_dataset_hash=training_dataset_hash,
            metrics=metrics,
            artifact_path=str(artifact_path),
            status="active" if activate else "registered",
        )
        entries.append(mv.__dict__)
        self._save_manifest(service_id, entries)
        return mv

    def active_version(self, service_id: str) -> Optional[ModelVersion]:
        for e in reversed(self._load_manifest(service_id)):
            if e["status"] == "active":
                return ModelVersion(**e)
        return None

    def load_artifact(self, version: ModelVersion) -> Any:
        # `artifact_path` is persisted as an absolute path at register()
        # time. That breaks the moment this repo (including
        # `ai/mlops_store/*.manifest.json`) is copied, unzipped, or
        # checked out somewhere other than the exact machine/directory
        # it was generated on — the manifests shipped in this repo were
        # generated under a different path than wherever they're being
        # loaded from now, so the literal absolute path won't exist.
        # Fall back to resolving the artifact by filename inside this
        # registry's own `store_dir`, which is where `register()`
        # actually writes the .pkl file — that's portable across
        # machines/checkouts as long as the manifest and its .pkl files
        # are kept together (which they always are, since both live in
        # `store_dir`).
        path = Path(version.artifact_path)
        if not path.exists():
            path = self.store_dir / path.name
        with open(path, "rb") as f:
            return pickle.load(f)

    def rollback(self, service_id: str) -> Optional[ModelVersion]:
        """Revert to the previous 'retired' version — the same
        rollback contract §8.13 says every deployed model gets,
        generalized from the RL staged-rollout gate (§8.7.4)."""
        entries = self._load_manifest(service_id)
        active_idx = next(
            (i for i, e in enumerate(entries) if e["status"] == "active"), None
        )
        if active_idx is None or active_idx == 0:
            return None
        entries[active_idx]["status"] = "rejected"
        prior = entries[active_idx - 1]
        prior["status"] = "active"
        self._save_manifest(service_id, entries)
        return ModelVersion(**prior)


def population_stability_index(
    reference: np.ndarray, current: np.ndarray, bins: int = 10
) -> float:
    """PSI drift statistic (§8.13 "Drift Detection": "population
    stability index"). PSI < 0.1: no significant shift. 0.1-0.25:
    moderate shift, worth watching. > 0.25: significant shift, should
    trigger retraining."""
    reference = np.asarray(reference, dtype=float)
    current = np.asarray(current, dtype=float)
    edges = np.histogram_bin_edges(reference, bins=bins)
    ref_counts, _ = np.histogram(reference, bins=edges)
    cur_counts, _ = np.histogram(current, bins=edges)

    ref_pct = np.clip(ref_counts / max(len(reference), 1), 1e-6, None)
    cur_pct = np.clip(cur_counts / max(len(current), 1), 1e-6, None)
    return float(np.sum((cur_pct - ref_pct) * np.log(cur_pct / ref_pct)))


@dataclass
class FeatureMonitor:
    """§8.13 "Monitoring": tracks input-feature distributions per
    service so drift can be measured against a frozen reference
    window rather than compared to whatever arrived most recently."""

    reference_window: Optional[np.ndarray] = None
    drift_threshold: float = 0.25

    def set_reference(self, features: np.ndarray) -> None:
        self.reference_window = np.asarray(features, dtype=float)

    def check_drift(self, features: np.ndarray) -> Dict[str, Any]:
        if self.reference_window is None:
            self.set_reference(features)
            return {"psi": 0.0, "drifted": False, "note": "reference window initialized"}
        psi = population_stability_index(self.reference_window, features)
        return {"psi": psi, "drifted": psi > self.drift_threshold}


class RetrainingScheduler:
    """§8.13 "Retraining": scheduled (interval) plus event-triggered
    (confirmed failure / operator-labeled false positive / drift)."""

    def __init__(self, interval_seconds: float):
        self.interval_seconds = interval_seconds
        self._last_trained: Dict[str, float] = {}

    def is_due(self, service_id: str, now: Optional[float] = None) -> bool:
        now = now if now is not None else time.time()
        last = self._last_trained.get(service_id, 0.0)
        return (now - last) >= self.interval_seconds

    def mark_trained(self, service_id: str, when: Optional[float] = None) -> None:
        self._last_trained[service_id] = when if when is not None else time.time()

    def event_triggered_retrain_needed(
        self, drift_result: Dict[str, Any], confirmed_failure: bool = False
    ) -> bool:
        return bool(drift_result.get("drifted")) or confirmed_failure
