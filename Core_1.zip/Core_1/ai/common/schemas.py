"""ai/common/schemas.py

Wire-format schemas shared by every AI service. Two concerns kept
deliberately separate:

  - AIInsight: the §8.2 AI Insights Bus envelope — the ONLY thing a
    service is allowed to publish. Fixed field set:
    {service_id, robot_id, timestamp, insight_type, payload,
    confidence_score}, exactly as specified.

  - TelemetrySample: the AI layer's view of a robot's live state.
    Field names mirror dashboard/backend/main.py's TelemetryOut /
    JointTelemetryOut and ros2_ws robot_msgs/JointTelemetry.msg
    exactly, so a real telemetry stream from either layer can be fed
    into these services without a translation layer.

pydantic is used when available (matches the platform doc's stated
stack, §14.1) but every schema also works as a plain dataclass so this
package has zero hard dependency on it — this sandbox has neither
pydantic nor network access to install it, and the fallback path is
exercised by every test in ai/tests, not just declared in a comment.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, List, Optional

try:  # pragma: no cover - exercised only when pydantic is installed
    from pydantic import BaseModel, ConfigDict, Field, field_validator

    _HAVE_PYDANTIC = True
except ImportError:  # pragma: no cover
    _HAVE_PYDANTIC = False


class InsightType(str, Enum):
    """Closed set of insight_type values — new AI services register a
    new member here rather than emitting an ad-hoc string, so every
    bus subscriber (Decision Support Dashboard, Fleet Intelligence,
    the operator assistant's retrieval index) can rely on a known
    vocabulary (§8.2)."""

    PREDICTIVE_MAINTENANCE = "predictive_maintenance"
    THERMAL_FORECAST = "thermal_forecast"
    ENERGY_OPTIMIZATION = "energy_optimization"
    QUALITY_INSPECTION = "quality_inspection"
    MOTION_OPTIMIZATION = "motion_optimization"
    DIGITAL_TWIN_DEVIATION = "digital_twin_deviation"
    WORKSPACE_OBJECT = "workspace_object"
    ANOMALY = "anomaly"
    FLEET_INSIGHT = "fleet_insight"
    OPERATOR_ANSWER = "operator_answer"


class ExecutionSite(str, Enum):
    """§8.14 edge/cloud placement — attached to every insight so a
    consumer (or an auditor) can see where the inference actually ran,
    not just where the spec says it should."""

    EDGE = "edge"
    CLOUD = "cloud"
    HYBRID = "hybrid"


def _new_id() -> str:
    return uuid.uuid4().hex


if _HAVE_PYDANTIC:  # pragma: no cover

    class AIInsight(BaseModel):
        # use_enum_values: keeps `.model_dump()`'s output identical in
        # shape to the dataclass fallback below (plain strings, not
        # enum instances) -- without this, the two branches would
        # silently disagree on what model_dump()["insight_type"] is.
        model_config = ConfigDict(use_enum_values=True)

        insight_id: str = Field(default_factory=_new_id)
        service_id: str
        robot_id: str
        timestamp: float = Field(default_factory=time.time)
        insight_type: InsightType
        payload: Dict[str, Any]
        confidence_score: float
        execution_site: ExecutionSite = ExecutionSite.CLOUD
        requires_human_review: bool = False

        @field_validator("confidence_score")
        @classmethod
        def _clamp(cls, v: float) -> float:
            # Deliberately NOT declared as Field(ge=0, le=1): pydantic
            # enforces ge/le BEFORE a field_validator runs, so an
            # out-of-range input would raise ValidationError instead of
            # reaching this clamp at all -- silently diverging from the
            # dataclass fallback below, which always clamps rather than
            # ever raising. Both branches must have the same contract.
            return max(0.0, min(1.0, float(v)))

        def model_dump_public(self) -> Dict[str, Any]:
            # pydantic's own `.model_dump()` already does this; kept as
            # an explicit alias so callers written against the
            # dataclass fallback's `.model_dump()` name work unmodified
            # against either branch.
            return self.model_dump()

    class TelemetrySample(BaseModel):
        robot_id: str
        timestamp: float = Field(default_factory=time.time)
        joint_names: List[str]
        position_deg: List[float]
        velocity_deg_s: List[float]
        current_a: List[float]
        torque_estimate_nm: List[float]
        winding_temp_c: List[float]
        sto_active: List[bool]
        fault: List[bool]
        ambient_temp_c: float = 25.0

else:

    @dataclass
    class AIInsight:  # type: ignore[no-redef]
        service_id: str
        robot_id: str
        insight_type: "InsightType"
        payload: Dict[str, Any]
        confidence_score: float
        insight_id: str = field(default_factory=_new_id)
        timestamp: float = field(default_factory=time.time)
        execution_site: "ExecutionSite" = ExecutionSite.CLOUD
        requires_human_review: bool = False

        def __post_init__(self) -> None:
            self.confidence_score = max(0.0, min(1.0, float(self.confidence_score)))
            if isinstance(self.insight_type, str):
                self.insight_type = InsightType(self.insight_type)
            if isinstance(self.execution_site, str):
                self.execution_site = ExecutionSite(self.execution_site)

        def model_dump(self) -> Dict[str, Any]:
            d = asdict(self)
            d["insight_type"] = self.insight_type.value
            d["execution_site"] = self.execution_site.value
            return d

    @dataclass
    class TelemetrySample:  # type: ignore[no-redef]
        robot_id: str
        joint_names: List[str]
        position_deg: List[float]
        velocity_deg_s: List[float]
        current_a: List[float]
        torque_estimate_nm: List[float]
        winding_temp_c: List[float]
        sto_active: List[bool]
        fault: List[bool]
        timestamp: float = field(default_factory=time.time)
        ambient_temp_c: float = 25.0

        def model_dump(self) -> Dict[str, Any]:
            return asdict(self)


def make_insight(
    *,
    service_id: str,
    robot_id: str,
    insight_type: "InsightType",
    payload: Dict[str, Any],
    confidence_score: float,
    execution_site: "ExecutionSite" = ExecutionSite.CLOUD,
    confidence_floor_for_autonomy: float = 0.6,
) -> "AIInsight":
    """Construct an AIInsight and apply the platform-wide confidence-
    routing rule (§8.6, §8.9, §8.10, §8.17): anything below the floor
    is flagged for human review rather than silently trusted."""

    requires_review = confidence_score < confidence_floor_for_autonomy
    return AIInsight(
        service_id=service_id,
        robot_id=robot_id,
        insight_type=insight_type,
        payload=payload,
        confidence_score=confidence_score,
        execution_site=execution_site,
        requires_human_review=requires_review,
    )
