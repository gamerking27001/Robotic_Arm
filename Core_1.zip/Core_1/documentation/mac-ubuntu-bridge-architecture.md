# Mac ↔ Ubuntu Bridge Architecture

This resolves the fixed development-environment requirement: Mac (host)
→ Parallels Desktop → Ubuntu 24.04.3 LTS → ROS2, with MuJoCo and
CoppeliaSim running on the Mac (not the VM), bridged to ROS2 in the VM.
Every decision below states the choice, the alternatives considered, and
why — per how this whole project has been scoped.

**Status: architecture decided, not yet built.** Nothing in this
document has a running gateway process behind it. See "What's actually
built vs. designed" at the bottom.

---

## 1. ROS2 Distribution — Jazzy Jalisco

**Decision: ROS2 Jazzy Jalisco.** The design baseline
(`documentation/design-baseline.md` §12.2) says "Humble or Jazzy" without
committing — but the fixed requirement pins Ubuntu to **24.04.3
(Noble)**, and that alone decides it: **Humble Hawksbill targets Ubuntu
22.04 (Jammy), not 24.04.** Per ROS2's own REP 2000 target-platform
mapping, Jazzy is the release built and tested against Noble. Running
Humble on Ubuntu 24.04 would mean either an unsupported/patched install
or a mismatched base image — not a real option once the Ubuntu version
was fixed.

- **Ubuntu compatibility:** Jazzy is the only one of the two actually
  targeting 24.04 — decisive on its own.
- **Stability:** Jazzy is a Long Term Support release (2029 EOL),
  matching the multi-year horizon a hardware product needs.
- **Package availability:** as the current Ubuntu-24.04-targeted LTS,
  Jazzy has the active binary package mirror; Humble's 22.04-built
  packages aren't the right target for a 24.04 base.
- **MoveIt 2 / ros2_control compatibility:** both are actively
  maintained against Jazzy; this repo's `robot_moveit_config` and
  `robot_hardware_interface` were already written against Jazzy's API
  (see `ros2_ws/README.md`'s verification notes).
- **Foxglove compatibility:** `foxglove_bridge` supports Jazzy directly;
  no version-specific concern here.
- **Simulation compatibility:** not a discriminator between Humble/Jazzy
  specifically — MuJoCo/CoppeliaSim are external to ROS2's own
  versioning either way (see §5 below).

## 2. Real-Time: PREEMPT_RT Helps, Doesn't Change the Actual Requirement

The design baseline (§12.2) recommends `ROS2 ... on a PREEMPT_RT-patched
Linux host`. That's worth doing — it reduces scheduling jitter for
planning/telemetry work in the VM — but it must not be read as making
the VM a real-time safety controller. This project's own fixed
requirement is explicit and unambiguous on this point, and it matches
what's already built: **the safety-critical current loop and STO
response live in firmware (`firmware/joint_foc`, `firmware/safety_board`
— see their READMEs' "host-independent operation" framing), independent
of whatever's happening in the VM, in Parallels, or on the Mac.**
PREEMPT_RT on the Ubuntu VM is a quality-of-service improvement for
planning/telemetry, not a substitute for that separation — a VM freeze,
a Parallels hiccup, or a dropped network link must never be able to stop
the safety-board firmware from doing its job, and nothing in this
architecture changes that.

## 3. Parallels Networking Mode — Different Modes for Different Stages

The brief is explicit that one mode isn't right for every stage — here's
the actual breakdown:

### Default for development: Shared Network (NAT)

Recommended as the default. Parallels' Shared mode gives the VM a
private IP behind the Mac's own network stack, but critically, the **Mac
host itself can reach the VM directly** over Parallels' internal virtual
switch — this isn't NAT-traversal from the internet's perspective, it's
local host↔VM traffic that Parallels routes directly. For the primary
Mac↔VM link (the one used constantly during development), this is
simpler and more reliable than Bridged, and it has a real secondary
benefit: it keeps the VM's ROS2 DDS discovery traffic **off the physical
LAN entirely** — worth caring about because `ROS_DOMAIN_ID` collisions
between your VM and someone else's robot on the same office/lab Wi-Fi
are a real, common, and often confusing failure mode (two unrelated
ROS2 graphs suddenly seeing each other's nodes). Shared mode sidesteps
that by construction during normal development.

### Switch to Bridged when: a real Ethernet-connected robot controller, or another physical machine, needs to reach the VM directly

Once a real robot controller (design baseline §9.7: "Ethernet —
Controller-to-host (ROS2) communication") is on the bench, or a
teammate's machine needs to run Foxglove or anything else against your
VM's ROS2 graph, Bridged gives the VM a real LAN IP, on equal footing
with any other device on the network — necessary for the robot
controller's Ethernet link and the VM to find each other without NAT in
the way, and for full DDS multicast participation with external devices.

**Concrete gotcha worth knowing before switching:** if the Mac's primary
connection is Wi-Fi (the common case for a laptop), Bridged-over-Wi-Fi
has a well-known extra wrinkle — the VM's bridged traffic appears on the
Wi-Fi network under a second (virtual) MAC address sharing the same
physical radio, and **some access points/routers actively block or drop
this** as a MAC-spoofing protection measure. This isn't a Parallels bug,
it's how a lot of consumer/office Wi-Fi gear behaves — worth testing
early (`ping` the VM from another device) rather than discovering it
mid-integration. Bridged over a wired Ethernet connection on the Mac
doesn't have this problem.

### Host-Only: not recommended as a primary mode here

Host-Only (VM reachable from the Mac only, no LAN, no internet) is more
restrictive than needed — the VM still needs internet access for
`apt`/`rosdep`/package installs during development. It's a reasonable
*additional* isolation option for a locked-down production deployment
image, but not the right default for active development.

## 4. DDS Discovery — Sidestep Multicast Reliability Issues Entirely

Regardless of networking mode, **don't rely on multicast-based DDS
discovery working reliably through a hypervisor's virtual networking** —
this is the single most common practical ROS2-in-a-VM pain point
(nodes that don't discover each other, topics that don't appear,
intermittent visibility), and it compounds with the Wi-Fi-bridged issue
in §3. Two concrete, well-documented fixes — pick one:

- **CycloneDDS with an explicit static peer list**
  (`ROS_STATIC_PEERS` or the equivalent XML `<Peers>` config) — tells
  each participant exactly which IPs to talk to, bypassing multicast
  discovery entirely. CycloneDDS is a mature, commonly-used RMW for
  exactly this kind of "discovery across network segments" scenario, and
  its config surface is simpler than Fast DDS's XML profiles for this
  specific use case.
- **Fast DDS Discovery Server** — a lightweight, unicast, centrally-known
  discovery server process, purpose-built by the Fast DDS project for
  exactly this problem (nodes across NAT/routed/virtualized network
  segments). Fast DDS is ROS2's default RMW in most distros including
  Jazzy, so this avoids an RMW switch if that's preferred.

Either way, the practical recommendation is the same: **set this up once
during initial environment bring-up, don't wait to hit the multicast
failure mode first.**

### Troubleshooting checklist (both networking mode issues and DDS issues)

- `ros2 topic list` shows nothing from the Mac side → check `ROS_DOMAIN_ID`
  matches on both ends, then check whether discovery is multicast-based
  (§4) before assuming it's a firewall problem.
- Nodes discover each other intermittently → classic multicast-through-VM
  symptom; switch to static peers/Discovery Server (§4) rather than
  debugging multicast further.
- VM unreachable from Mac after a Bridged-network switch → check for the
  Wi-Fi MAC-filtering gotcha (§3) before assuming a Parallels
  misconfiguration.
- Works on `localhost` inside the VM but not from the Mac → confirm the
  VM's firewall (`ufw` if enabled) isn't blocking the relevant ports;
  DDS uses a range of UDP ports per participant, not a single fixed one.
- High latency / packet loss specifically over Bridged-Wi-Fi → expected
  to be worse than Shared mode or wired Bridged; if this matters for a
  specific workflow (e.g. teleoperation-adjacent testing), prefer wired
  Ethernet into the Mac for that session.

## 5. Bridge Protocol — Two Separate Paths, Not One

The brief's suggested diagram (gRPC + WebSocket, ROS2 Gateway,
everything flowing through one bridge) was a starting sketch, not a
requirement to copy — evaluating it against the alternatives leads to a
**split** architecture instead, because Foxglove and a native operator
app genuinely need different things from a bridge.

### Foxglove: keep its own dedicated path — `foxglove_bridge`, unchanged

This was already the right answer in this conversation's first message
and nothing here changes it: Foxglove's whole purpose is deep
visualization/debugging across the graph, so restricting its access
would defeat the point. `ros2 run foxglove_bridge foxglove_bridge`
(WebSocket) in the VM, Foxglove Studio on the Mac connects directly. No
custom gateway needed for this path.

### Native Mac app / operator control surface: a curated gRPC gateway

| Option | Verdict | Why |
|---|---|---|
| Raw DDS to the Mac | Rejected | Fixed requirement explicitly disallows ROS2 running natively on macOS — there's no DDS participant on the Mac side to talk to. |
| Foxglove/rosbridge-style WebSocket, full graph | Rejected for this path | Exposes the entire ROS2 graph by default — the brief explicitly wants the bridge to expose only curated functionality, not the whole graph. Right fit for Foxglove itself, wrong fit for an operator app that should only be able to do specific, audited things. |
| REST | Rejected as primary | Fine for one-shot commands, weak for the required telemetry *streaming* responsibility without bolting on SSE/WebSocket anyway. |
| MQTT | Rejected as primary | Good pub/sub telemetry fit (already used at the joint-level diagnostics bus per design baseline §19.5), but weak for the RPC-shaped responsibilities (discovery, connect, invoke-a-service-and-get-a-typed-response) the brief also wants. |
| **gRPC** | **Selected** | Strongly-typed contract via protobuf (self-documenting, versioned), native bidirectional streaming (covers both one-shot commands and telemetry streaming in one framework), good client library support across Swift/Python/C++/Node — relevant since the native Mac app's language isn't decided yet either. |
| Plain custom WebSocket | Considered, not selected | Would work, but hand-rolling schema validation to get gRPC's type safety back is strictly more work for a worse result. |

**Decision: a `robot_gateway` ROS2 node in the VM, exposing a gRPC
service** with a small, deliberately limited surface — see the `.proto`
sketch below. It only exposes what the brief's "Mac Bridge
Responsibilities" section actually lists (discovery, status, telemetry,
config, calibration, diagnostics, authorized service/action invocation)
— not the raw graph.

### Safety boundary — reuses existing safety authority, doesn't add a new path

This is the important part: `robot_gateway` must **never** get a more
privileged path to motion than the dashboard already has. Concretely, it
calls the *same* `trigger_estop`/`reset_estop` services `estop_controller`
already exposes (see `ros2_ws/src/estop_controller/README.md`), and the
*same* `arm_controller` trajectory interface — it doesn't touch
`robot_hardware_interface` directly, and it doesn't get a new
motion-authority path that bypasses the safety FSM already built. A
compromised or buggy `robot_gateway` process is exactly as constrained as
a compromised dashboard session — see `documentation/design-baseline.md`
§14 and `ros2_ws/README.md`'s safety-authority-fix section for why that
constraint is load-bearing, not incidental.

## 6. Resolving Last Round's Open Question: How MuJoCo/CoppeliaSim Actually Connect

`simulation/coppeliasim/README.md` deliberately left open whether
CoppeliaSim (and MuJoCo) present themselves to ROS2 as a network-proxy
`ros2_control` hardware interface, or a simpler topic mirror — flagged
as belonging to this bridge design, not decidable in isolation.
Resolving it now: **network-proxy hardware interface**, via a *second*,
separate gRPC service distinct from the operator-facing one above.

Reasoning: MuJoCo/CoppeliaSim aren't operator tools, they're standing in
for the robot itself — the same role `robot_hardware_interface` plays
against the simulated CAN bus today. The architecturally consistent
answer is for them to keep playing that role, just over a network
instead of an in-process call. Concretely:

- A new `sim_network_hardware_interface` `ros2_control` `SystemInterface`
  plugin (parallel to, not replacing, the existing
  `robot_hardware_interface` — selected via the URDF's
  `<ros2_control><hardware><plugin>` tag, same mechanism the removed
  Gazebo integration used to swap in `gz_ros2_control`) opens a
  persistent gRPC bidirectional stream to whichever simulator is running
  on the Mac, each control cycle: send joint position commands, receive
  joint telemetry — same shape `RobotSystemInterface::read()`/`write()`
  already has, just proxied over the network instead of talking to
  `arm::hal::SimulatedJointDriver` directly.
- This reuses the *same* safety-authority pattern already built (§5's
  safety boundary applies here too): the network hardware interface
  still owns and evaluates `arm::safety::SafetyFsm` locally in the VM,
  exactly like `RobotSystemInterface` does now — the Mac-side simulator
  only ever sees "what position to go to," never "whether it's safe to
  move," which stays a VM-side, network-independent decision. A dropped
  network connection to the Mac should read as a fault/stale-telemetry
  condition, not silently freeze the safety evaluation.

**This is a real, non-trivial new component** (`sim_network_hardware_interface`)
— resolving the architecture question doesn't mean it's built. See below.

## What's actually built vs. designed (read this before assuming more exists)

**Designed, and now a first draft exists (uncompiled — see its own README):**
- `robot_gateway` — `ros2_ws/src/robot_gateway/` implements
  `RobotControlService` against `estop_controller`/`arm_controller`/
  `diagnostics_node`. This is the least-verified package in the whole
  repo: on top of the usual "no ROS2 install" caveat, there was also no
  `grpc++`/`protobuf` toolchain available to compile the generated
  bindings this package depends on. Get it through a real `colcon build`
  before trusting any of it — see `robot_gateway/README.md`'s specific
  list of likely trouble spots.
- `sim_network_hardware_interface` — `ros2_ws/src/sim_network_hardware_interface/`
  implements the `ros2_control` plugin side of §6's design, exporting the
  identical `safety/*` interface names `robot_hardware_interface` does so
  `estop_controller` et al. work unchanged against either one. Same
  compounded confidence caveat as `robot_gateway`, plus a new risk neither
  of the other hardware interfaces had: a background gRPC I/O thread
  feeding the real-time `read()`/`write()` cycle through mutex-protected
  buffers. See its README for exactly what that adds and a concrete honest
  limitation (no local `triggerSafeTorqueOff()` — see that README's "What
  happens on a dropped connection" section). Not yet wired into
  `generate_urdf.py` (which still only emits the real/simulated-CAN
  plugin) — see that README's "URDF wiring" section for what's needed.

**Designed, not built:**
- (nothing left in this category on the ROS2/bridge side — see the
  Mac-side item below for the one remaining real gap)

**Built, but the least independently-checkable code in this project:**
- `simulation/mujoco/mac_sim_server.py` — the Mac-side gRPC server
  completing `SimulationHardwareService`'s other half for MuJoCo. Steps
  the already-generated `generated_arm.xml` forward each cycle against
  received `JointCommand`s, reports real MuJoCo telemetry back
  (`qfrc_actuator` for torque; motor current/winding temp honestly
  zeroed rather than fabricated, since MuJoCo doesn't model them). See
  `simulation/mujoco/README.md` — this file got a Python syntax check and
  a careful read, nothing more; no Mac, no MuJoCo, no grpc tooling were
  available to actually run it.
- `simulation/coppeliasim/coppeliasim_sim_server.py` — the same server
  role for CoppeliaSim, structurally different (an external ZMQ Remote
  API client against an already-running CoppeliaSim instance, rather than
  an embedded physics library). Same confidence caveat as the MuJoCo
  version, compounded further — see `simulation/coppeliasim/README.md`
  for why CoppeliaSim's remote API is the single most likely thing in
  this whole simulation stack to need a version-specific fix.
- Any actual Discovery Server / CycloneDDS static-peer configuration
- Any actual Parallels VM (nothing here was tested against a real
  Parallels/Ubuntu/ROS2 install — no such environment was available
  while writing this)

**A starting contract sketch, not a compiled/tested one:**
`robot_gateway.proto` in this directory — written carefully, matching
protobuf3 syntax conventions, but not run through `protoc` (not
available in this environment). Treat it as a strong starting draft for
what `robot_gateway` should expose, not a verified-compilable artifact.

**Already real, reused by this design rather than reinvented:**
- `estop_controller`'s services (§5's safety boundary)
- `foxglove_bridge`'s standard usage pattern (§5, Foxglove path)
- Jazzy's actual REP 2000 platform mapping (§1 — this one's just factual
  research, not something built)
