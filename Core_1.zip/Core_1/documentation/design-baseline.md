# Design Baseline — "Modular Industrial Robotic Arm for MSMEs"

**This is the authoritative source document** every `§N.N`-style comment
throughout this codebase (`include/`, `src/`, `ros2_ws/`, `firmware/`,
`dashboard/`) refers back to. It was supplied by the project owner as a
PDF and is transcribed here in full so those section references actually
point at something real in the repo, instead of a document that only
existed outside it.

**Cross-validation note (added when this file was checked in):** every
motor/gearbox/power/RPM/encoder value already in
`include/core/robot_config.hpp`'s `kJointSpecs` table was checked
field-by-field against this document's §6.2 table — all match exactly.
J1/J2 joint limits also match §20.5's config snippet exactly. What's
**still genuinely unresolved** even in this full document: J3–J6 DH
parameters and J3–J6 joint angle limits — §20.5's config snippet
truncates at exactly the same point here (`"# ... J3-J6 continued"`) as
in every prior extraction, and no other section supplies those numbers.
The `PLACEHOLDER_` markers on those specific values in `robot_config.hpp`
remain honest placeholders, not something this fuller document resolved.

**Simulation stack decision (post-dates this document):** §19.3 below
recommends Gazebo, and that's what was originally built into
`ros2_ws/src/robot_description/gazebo/`. That's since been superseded —
see `documentation/simulation-stack-decision.md` for why and what
replaced it. Treat §19.3's Gazebo recommendation as historical context
for that decision, not current guidance.

---

## 1. Project Overview

### 1.1 Purpose

This document specifies the engineering baseline for a production-ready,
modular, 6-axis industrial robotic arm targeted at Micro, Small, and
Medium Enterprises (MSMEs). The objective is to displace expensive
imported collaborative and industrial manipulators with a domestically
serviceable, modular platform that matches typical MSME payload and
workspace needs while cutting acquisition and maintenance cost through
standardized, field-replaceable modules.

### 1.2 Target MSMEs

- Small-batch electronics and PCB assembly houses (pick-and-place,
  screwdriving, inspection).
- Sheet-metal and light-fabrication shops (part handling, deburring,
  spot-tending for CNC/press-brake).
- Packaging and palletizing lines in food, FMCG, and pharma SMEs.
- Job-shop welding and finishing operations requiring flexible fixturing.
- Educational and vocational training centers requiring an affordable,
  serviceable teaching platform.

### 1.3 Industrial Applications

| Application | Typical Payload | Notes |
|---|---|---|
| Pick-and-place / kitting | 1–3 kg | High cycle rate, repeatability-critical |
| Machine tending (CNC/press) | 3–5 kg | Duty-cycle and IP rating critical near coolant |
| Screwdriving / assembly | 1–2 kg | Requires torque-controlled end effector |
| Palletizing (light) | 5 kg | Larger reach, moderate speed |
| Arc welding (light gauge) | 3–4 kg (torch + cable) | Requires TCP-accurate path control |
| Inspection / quality checks | 0.5–1 kg (camera payload) | Precision positioning over speed |

### 1.4 Design Philosophy

- **Modularity first**: every joint, the base, the controller, and the
  end-effector interface are standardized and field-swappable without
  full robot disassembly.
- **Serviceability over peak performance**: components are chosen for
  MTTR (mean time to repair) and local serviceability rather than
  maximum achievable spec, since MSME buyers cannot tolerate multi-week
  OEM turnaround for repairs.
- **Open control stack**: ROS2-based software avoids vendor lock-in and
  allows MSME integrators to extend functionality without proprietary
  SDKs.
- **Design for local manufacture**: mechanical components favor
  processes (3-axis CNC, sheet metal, off-the-shelf bearings/fasteners)
  available from regional manufacturing vendors, avoiding exotic
  materials or processes.

### 1.5 Key Specifications (Summary)

| Parameter | Target Value |
|---|---|
| Degrees of Freedom | 6 |
| Payload (nominal) | 5 kg |
| Reach | 850 mm |
| Repeatability | ±0.03 mm |
| Rated Power | 48 VDC, ~800 W peak |
| Weight | ≤ 22 kg |
| IP Rating | IP54 (base/forearm), IP65 optional wrist kit |

### 1.6 Commercial Objectives

- Bill-of-materials cost target substantially below equivalent imported
  5 kg-class collaborative arms, achieved primarily through
  joint-module standardization (three joint sizes cover all six axes)
  and local sourcing of motors, gearboxes, and electronics.
- Field service model based on module exchange (swap a joint or the
  controller, not a full-robot RMA) to minimize MSME downtime.
- A common software/electronics platform reused across a family of arms
  (payload variants) to spread NRE (non-recurring engineering) cost
  across volume.

---

## 2. Robot Specifications

### 2.1 Full Specification Table

| Parameter | Specification |
|---|---|
| Payload (nominal / peak) | 5 kg / 8 kg (reduced reach) |
| Reach | 850 mm |
| Repeatability | ±0.03 mm |
| Pose Accuracy | ±0.15 mm (post-calibration) |
| Maximum TCP Speed | 1.5 m/s |
| Maximum Joint Speed (J1–J3) | 180°/s |
| Maximum Joint Speed (J4–J6) | 300°/s |
| Typical Cycle Time (25 mm pick-place, 1 kg) | ≤ 0.55 s |
| Workspace Volume | ~1.9 m³ (hemispherical, minus base exclusion) |
| Mounting Options | Floor, table, inverted (ceiling), wall bracket |
| Power Requirement | 48 VDC nominal, 800 W peak, 100–240 VAC input via external PSU |
| Robot Weight | ≤ 22 kg (excluding controller) |
| Controller Weight | ≤ 4 kg |
| IP Rating | IP54 standard; IP65 wrist option for wash-down environments |
| Duty Cycle | 100% continuous at rated payload; peak torque limited to 2 s bursts |
| Ambient Operating Temperature | 0–45°C |
| Acoustic Noise | < 65 dB(A) at 1 m, typical operation |

### 2.2 Comparison with Existing Collaborative and Industrial Robots

| Class | Typical Payload | Typical Repeatability | Typical Price Positioning | This Design |
|---|---|---|---|---|
| Entry Cobot (3–5 kg class) | 3–5 kg | ±0.03–0.05 mm | Mid-high | Matches payload/repeatability, targets a materially lower price point via modular joints |
| Mid Industrial Arm (6-axis, caged) | 5–20 kg | ±0.02–0.05 mm | High | This design targets the lower end of this band without requiring a safety cage for light-duty tasks |
| Desktop/Educational Arms | < 1 kg | ±0.1–0.5 mm | Low | This design exceeds desktop-class capability while remaining serviceable by MSME technicians |

The recommended configuration positions the arm between desktop-class
and full industrial-class robots — a "right-sized" payload/repeatability
envelope covering the majority of MSME automation tasks without the
cost structure of a caged industrial cell.

---

## 3. Mechanical Design

### 3.1 Robot Architecture

A serial 6-axis anthropomorphic arm (shoulder-elbow-wrist configuration)
is recommended over parallel/SCARA architectures for MSME use because it
offers the broadest task generality (arbitrary orientation at the TCP),
which matters more to a multi-purpose MSME cell than the higher speed of
SCARA or the higher stiffness of parallel kinematics for a narrow task
set.

DIAGRAM PLACEHOLDER — REQUIRES CAD/ENGINEERING DRAWING: kinematic chain
diagram, Base Module → J1 (Waist, Yaw) → J2 (Shoulder, Pitch) → J3
(Elbow, Pitch) → J4 (Wrist Roll) → J5 (Wrist Pitch) → J6 (Wrist
Roll/Flange) → End Effector Interface.

### 3.2 Modular Construction

The arm is decomposed into a small number of standardized,
field-replaceable assemblies:

| Module | Contents | Interchangeable Across |
|---|---|---|
| Base Module | J1 actuator, base electronics bay, main power input | All arm variants (5/8/12 kg family) |
| Large Joint Module (J1–J3) | Actuator + gearbox + encoder + housing, common envelope | J1, J2, J3 (identical part number) |
| Small Joint Module (J4–J6) | Actuator + gearbox + encoder + housing, common envelope | J4, J5, J6 (identical part number) |
| Link Set | Upper arm and forearm structural links | Reach variants (short/standard/long) |
| Wrist/Flange Module | Tool-changer interface, wrist sensors | All end-effector types |
| Controller Pack | Motion controller, drives, safety board | All arm variants |

Standardizing on two joint sizes (rather than six unique joints) is the
single largest driver of both BOM cost reduction and spare-parts
simplicity for MSME service.

DIAGRAM PLACEHOLDER — REQUIRES CAD/ENGINEERING DRAWING: module stack-up,
Controller Pack + Base Module + Large Joint Module ×3 (interleaved with
Link Set: Upper Arm / Forearm) + Small Joint Module ×3 + Wrist/Flange
Module + End Effector (interchangeable).

### 3.3 Link Design

Links are hollow, ribbed extrusions/castings with a central cable
channel sized for the CAN/power harness bundle plus 30% spare fill for
future sensor additions. Flanged, dowelled joint interfaces ensure
repeatable module replacement without re-calibration of link geometry
(only joint-zero calibration is required after a module swap).

### 3.4 Structural Materials

| Material | Stiffness (Rel.) | Weight (Rel.) | Machinability | Cost (Rel.) | Recommended Use |
|---|---|---|---|---|---|
| Aluminium 6061-T6 | Baseline | Baseline | Excellent | Low | Primary structural material — links, joint housings |
| Steel (mild/alloy) | 3x | 2.9x | Good | Low | High-load base mounting plate, fasteners, shafts |
| Carbon Fiber (tube/laminate) | 2–2.5x (axial) | 0.5x | Poor (specialized) | High | Reserved for optional long-reach forearm variant only |

**Decision:** Aluminium 6061-T6 for all standard links and housings —
best balance of stiffness-to-weight, machinability on 3-axis CNC, and
cost predictability for MSME-scale manufacturing. Carbon fiber is
offered only as an optional upgrade for the long-reach (1100 mm) variant
where mass at the wrist strongly impacts dynamics.

### 3.5 Manufacturing Methods

- **Joint housings**: 3-axis CNC-machined from 6061 billet or plate
  stock; no 5-axis machining required, keeping the process accessible
  to regional job shops.
- **Links**: CNC-machined or extruded-and-machined aluminium;
  sheet-metal covers for cable routing.
- **Base**: cast or welded steel plate for mounting stiffness,
  powder-coated.
- **Fasteners/bearings**: commodity metric standards (DIN/ISO)
  throughout — no proprietary fastener sizes.

### 3.6 Modular Replacement Strategy

Every joint module mounts via a common 4-bolt flange pattern with a
keyed alignment dowel and a single quick-disconnect harness connector
(power + CAN). A joint replacement is designed to be completed by a
trained technician in under 30 minutes without full arm disassembly,
followed by an automated joint-zero calibration routine run from the
controller.

### 3.7 Maintenance Considerations

- Grease/lubrication points are accessible externally without housing
  disassembly on all large joints.
- Wear items (belts where used, brushes — none, since brushless motors
  are standard) are limited to bearings and gearbox lubrication, both
  serviceable at scheduled intervals.
- Cable harnesses use keyed, latching connectors at every module
  boundary to prevent mis-wiring during field service.

---

## 4. Degrees of Freedom (DOF)

### 4.1 Configuration Comparison

| DOF | Task Generality | Cost | Control Complexity | Typical MSME Fit |
|---|---|---|---|---|
| 4 DOF | Limited to planar/SCARA-like tasks, fixed tool orientation constraints | Lowest | Low | Pick-place with fixed orientation only |
| 5 DOF | Missing one wrist rotation — cannot achieve arbitrary TCP orientation | Low-medium | Medium | Constrained-orientation tasks (e.g., vertical dispensing) |
| 6 DOF | Full 6D pose control (position + orientation) | Medium | Medium-high | General-purpose pick-place, assembly, machine tending, welding |
| 7 DOF | Adds redundant elbow joint for obstacle avoidance/singularity handling | Highest | High | Constrained workcells with obstacles; rarely needed for open MSME cells |

### 4.2 Recommendation

**6 DOF is recommended** as the standard configuration. It is the
minimum DOF count that gives full 6D pose control (required for
arbitrary tool orientation in assembly, welding, and inspection tasks),
while avoiding the redundant-joint control complexity (null-space motion
planning) and added cost of a 7-DOF design that most open, uncaged MSME
work cells do not need. A 4-DOF SCARA-derivative variant may be offered
later as a lower-cost product-line variant for strictly planar
pick-and-place applications, but is out of scope for this baseline.

### 4.3 Kinematic Chain

DIAGRAM PLACEHOLDER — REQUIRES CAD/ENGINEERING DRAWING: coordinate-frame
diagram — WorldFrame → BaseFrame → [J1:Yaw] → Link1Frame → [J2:Pitch] →
Link2Frame → [J3:Pitch] → Link3Frame → [J4:Roll] → Link4Frame →
[J5:Pitch] → Link5Frame → [J6:Roll] → ToolCenterPoint.

Denavit-Hartenberg parameters are defined per joint module and stored in
the controller's configuration file (see Section 20) so that reach
variants (short/standard/long link sets) are handled purely through
configuration, not firmware changes.

---

## 5. Joint Design

### 5.1 Joint Hierarchy

DIAGRAM PLACEHOLDER — REQUIRES CAD/ENGINEERING DRAWING: joint hierarchy
tree — ArmAssembly → {LargeJointModuleType: J1-Waist, J2-Shoulder,
J3-Elbow (Motor+HarmonicDrive/CycloidalDrive+Cross-Roller/Angular-Contact
Bearing)}, {SmallJointModuleType: J4-WristRoll, J5-WristPitch,
J6-FlangeRoll (Motor+HarmonicDrive/PlanetaryDrive+Angular-Contact/Deep-
Groove Bearing)}.

### 5.2 Per-Joint Design Summary

| Joint | Type | Bearing Selection | Shaft Design | Backlash Reduction |
|---|---|---|---|---|
| J1 (Waist) | Large module, cross-roller output bearing | Cross-roller bearing (high moment capacity) | Hollow through-shaft for cable pass-through | Zero-backlash strain wave gearbox |
| J2 (Shoulder) | Large module, cross-roller output bearing | Cross-roller bearing | Hollow through-shaft | Zero-backlash strain wave gearbox |
| J3 (Elbow) | Large module, angular-contact pair | Angular-contact ball bearing pair (preloaded) | Hollow through-shaft | Cycloidal gearbox (low backlash) |
| J4 (Wrist Roll) | Small module, angular-contact pair | Angular-contact ball bearing pair | Hollow through-shaft | Zero-backlash strain wave gearbox |
| J5 (Wrist Pitch) | Small module, angular-contact pair | Angular-contact ball bearing pair | Solid shaft | Zero-backlash strain wave gearbox |
| J6 (Flange Roll) | Small module, deep-groove pair | Deep-groove ball bearing pair | Hollow through-shaft (tool signal pass-through) | Planetary gearbox (compact) |

### 5.3 Housing, Limits, and Serviceability

All joint housings are split-shell aluminium castings/machined parts
with an externally accessible lubrication port. Mechanical hard stops
are integrated into the housing (not relying on gearbox internals) to
protect the gearbox from over-travel damage. Software soft limits are
set at 90% of mechanical range as the primary operational boundary (see
Section 14).

### 5.4 Lubrication

Large joints (J1–J3) use grease-packed gearboxes with a 2,000-hour
re-grease interval; small wrist joints (J4–J6) use sealed-for-life
gearboxes to minimize wrist-end mass and simplify service on the
lowest-torque, highest-speed joints.

### 5.5 Gearbox Technology Comparison

| Gearbox Type | Backlash | Efficiency | Torque Density | Cost | Best Fit |
|---|---|---|---|---|---|
| Harmonic (Strain Wave) | Near-zero (arcmin-class) | 80–90% | High | Medium-high | J1, J2, J4, J5 — precision-critical joints |
| Cycloidal | Very low | 85–92% | Very high | Medium | J3 — high torque, shock-tolerant elbow |
| Planetary | Low-moderate | 90–97% | Medium-high | Low-medium | J6 — compact, cost-sensitive flange joint |
| Belt Drive | Moderate (tensioner-dependent) | 95%+ | Low-medium | Low | Not used in baseline (backlash unsuitable for repeatability target) |
| Worm Gear | Low (but high friction) | 50–70% | High (self-locking) | Low | Not used in baseline (poor efficiency, not needed given brake-equipped motors) |
| Direct Drive | Zero | ~100% | Low (needs large-diameter motor) | High | Not used in baseline (motor cost/size penalty outweighs benefit at this payload class) |

### 5.6 Gearbox Recommendation by Joint

| Joint | Recommended Gearbox | Rationale |
|---|---|---|
| J1 | Harmonic drive, ratio ~101:1 | High torque, near-zero backlash needed at base of kinematic chain (error amplifies outward) |
| J2 | Harmonic drive, ratio ~101:1 | Highest static torque joint (full arm moment arm); precision critical |
| J3 | Cycloidal, ratio ~81:1 | Handles shock loading from payload/tool contact better than harmonic |
| J4 | Harmonic drive, ratio ~51:1 | Precision wrist orientation, moderate torque |
| J5 | Harmonic drive, ratio ~51:1 | Precision wrist orientation |
| J6 | Planetary, ratio ~31:1 | Lower precision requirement at flange roll; cost/mass optimized |

---

## 6. Actuators & Motors

### 6.1 Motor Technology Comparison

| Motor Type | Torque Density | Controllability | Cost | Recommended Use |
|---|---|---|---|---|
| BLDC Servo | High | Good (trapezoidal/FOC) | Low-medium | J4–J6 (small joints) |
| AC Servo (PMSM w/ integrated drive) | High | Excellent (FOC, high bandwidth) | High | Not used in baseline (integrated drives complicate modularity) |
| Closed-loop Stepper | Medium | Good at low speed, weak at high speed/torque | Low | Not used (torque/speed envelope insufficient for J1–J3) |
| PMSM (frameless-adjacent, discrete drive) | High | Excellent (FOC via external drive) | Medium | J1–J3 (large joints) |
| Frameless Motor (rotor/stator only) | Highest (integration-dependent) | Excellent | Medium-high | Reserved for future compact wrist redesign |

**Decision:** PMSM motors with external FOC drives for J1–J3 (best
torque density and controllability for the highest-load joints), and
compact BLDC servos for J4–J6 (lower torque needs, tighter packaging).

### 6.2 Per-Joint Motor Sizing

| Joint | Rated Torque (Nm, output) | Peak Torque (Nm, output) | Rated Motor RPM | Gear Ratio | Encoder Resolution | Motor Power |
|---|---|---|---|---|---|---|
| J1 | 120 | 240 | 3,000 | 101:1 | 20-bit absolute | 200 W |
| J2 | 150 | 300 | 3,000 | 101:1 | 20-bit absolute | 250 W |
| J3 | 60 | 120 | 3,000 | 81:1 | 20-bit absolute | 150 W |
| J4 | 12 | 24 | 4,000 | 51:1 | 17-bit absolute | 60 W |
| J5 | 12 | 24 | 4,000 | 51:1 | 17-bit absolute | 60 W |
| J6 | 6 | 12 | 4,000 | 31:1 | 17-bit absolute | 40 W |

### 6.3 Torque Calculation Methodology

Required output torque per joint is derived from:

1. **Static load**: worst-case payload + tool + downstream link mass at
   maximum reach, computed from the full kinematic/mass model at the
   joint's worst-case pose.
2. **Dynamic load**: peak acceleration torque at maximum rated joint
   acceleration (assumed 3x the continuous-duty acceleration to size
   peak torque).
3. **Friction/efficiency derating**: gearbox efficiency (see Section
   5.4) applied as a torque multiplier to determine required motor-side
   torque.
4. **Design margin**: a 1.5x margin is applied on top of the computed
   peak torque requirement to accommodate mechanical wear, temperature
   derating, and unmodeled dynamic loads.

Peak torque figures in Section 6.2 already include this 1.5x margin over
the computed dynamic worst case.

### 6.4 Thermal Requirements

All motors are sized for continuous operation at rated torque without
exceeding a 100°C winding temperature at 45°C ambient, verified via
thermal simulation and validated with a thermocouple-instrumented
prototype run at duty-cycle-representative load profiles. Large joints
(J1–J2) include a finned aluminium heat-spreader housing section for
passive cooling; forced-air cooling is not required at this payload
class.

---

## 7. Sensors

### 7.1 Sensor Catalogue

| Sensor | Purpose | Placement | Accuracy | Interface |
|---|---|---|---|---|
| Absolute Encoder | Joint position feedback (power-cycle safe, no homing) | Motor-side of every joint | 17–20 bit | SPI/BiSS-C |
| Incremental Encoder | High-resolution velocity feedback (commutation backup) | Motor-side, co-located with absolute encoder | Quadrature, 4000+ CPR | Differential digital |
| Torque Sensor | Joint-level torque sensing for force-limited operation | J2, J3 (highest-load joints) | ±1% FS | Analog/CAN |
| Force-Torque Sensor | TCP-level 6-axis force/torque for contact tasks | Wrist flange (optional module) | ±0.25 N / ±5 mNm | RS485/EtherCAT |
| IMU | Base/link vibration and tilt monitoring | Base module | ±0.05° tilt | SPI/I2C |
| Limit Switches | Hard mechanical-limit backup to software limits | Each joint end-of-travel | N/A (digital) | GPIO |
| Hall Sensors | Coarse rotor position for commutation startup | Integrated in motor | N/A | Digital |
| Current Sensors | Per-phase motor current for FOC and overcurrent protection | Each motor drive stage | ±1% FS | Analog (ADC) |
| Temperature Sensors | Winding and gearbox temperature monitoring | Motor windings, gearbox housing | ±2°C | Analog/I2C |
| Vibration Sensors | Predictive-maintenance monitoring (optional) | Large joint housings | N/A | I2C/SPI |
| Vision Camera (RGB) | Part localization, QC, guidance | Wrist-mounted or overhead | N/A (task-dependent) | USB3/GigE |
| Depth Camera | 3D part pose estimation, bin-picking | Wrist-mounted or overhead | ±2 mm at 0.5 m (typical) | USB3 |
| LiDAR (optional) | Workspace/obstacle mapping for mobile-base variants | Base perimeter | Sub-cm (application-dependent) | Ethernet |
| Safety Sensors | Speed/torque-limited zone monitoring, presence detection | Perimeter/base-mounted | N/A | Safety-rated digital I/O |

### 7.2 Recommended Interface Standards

All joint-local sensors (encoders, current, temperature) are aggregated
at the joint module's local sensing PCB and reported upstream over CAN,
keeping the module self-contained and reducing wiring complexity at the
arm-to-controller boundary to a single CAN + power trunk (see Section
9).

---

## 8. End Effectors

### 8.1 Interchangeable Tooling Catalogue

| End Effector | Typical Use | Actuation | Notes |
|---|---|---|---|
| Parallel Gripper | General pick-place, box/part handling | Electric (servo) or pneumatic | Most common default tool |
| Vacuum Gripper | Flat/non-porous parts, packaging | Pneumatic (venturi) or electric pump | Requires onboard/host vacuum supply |
| Magnetic Gripper | Ferrous sheet-metal parts | Electropermanent magnet | Zero standby power for permanent-magnet variant |
| Soft Gripper | Irregular/delicate parts (food, produce) | Pneumatic (soft actuator) | Requires low-pressure pneumatic supply |
| Pneumatic Gripper | High-force clamping, general fixtures | Pneumatic (double-acting) | Requires host shop-air supply |
| Electric Gripper | Precision force-controlled grasping | Servo-electric | Preferred where force feedback is needed |
| Welding Torch | Light-gauge arc welding | N/A (process tool) | Requires TCP-accurate path control, torch collision model |
| Screwdriver (Electric) | Fastening/assembly | Servo-electric with torque feedback | Integrated torque monitoring for quality traceability |
| Pick-and-Place Tool | High-speed small-part handling | Vacuum or mini-gripper | Optimized for cycle time over force |
| Suction Cups (multi-cup array) | Large flat panel handling | Pneumatic | Used with vacuum gripper base |
| CNC Tool (deburring/spindle) | Light machining/finishing | Electric spindle | Requires force-controlled contact for consistent finish |
| Inspection Camera | In-process quality inspection | N/A (sensor tool) | Often paired with ring-light illumination |

### 8.2 Modular Tool-Changing Mechanism

A standardized quick-change flange (mechanical dovetail/ball-lock
coupling plus a spring-loaded pogo-pin electrical/data interface) allows
tool swap in under 10 seconds without requiring the robot to be powered
down. The tool-side half of the coupling carries an identification
EEPROM so the controller auto-detects the mounted tool and loads its
corresponding tool-center-point offset and mass/inertia parameters.

DIAGRAM PLACEHOLDER — REQUIRES CAD/ENGINEERING DRAWING: tool-changer
signal flow — WristFlange → Quick-ChangeCoupling → {ToolIDEEPROM →
Controller:Auto-load TCP/MassParams, ToolPowerPins, ToolData-CAN/I2C}.

---

## 9. Electronics Architecture

### 9.1 System Overview

DIAGRAM PLACEHOLDER — REQUIRES ENGINEERING DRAWING (electrical block
diagram): 48V Power Supply → Power Distribution Board → {Joint1Drive..
Joint6Drive (via CAN Bus each) , Ethernet-Host/ROS2, Digital I/O Module,
Safety Board} ; Safety Board → Emergency Stop Circuit; Main Controller
sits between Power Distribution Board and the joint drives/Ethernet/IO/
Safety Board.

### 9.2 Main Controller

The main controller hosts real-time joint trajectory interpolation,
kinematics, and safety supervision, and bridges to a host computer
(running ROS2) over Ethernet for higher-level planning and vision
integration (see Sections 10–11).

### 9.3 Motor Drivers

Each joint module integrates its own local FOC drive stage (current loop
closed locally at >10 kHz), receiving position/velocity/torque setpoints
from the main controller over CAN. This distributes control-loop
computation and simplifies the main controller's real-time budget to
trajectory-level (position/velocity) updates rather than raw
current-loop control.

### 9.4 Power Distribution

A central 48 VDC bus (from an external 100–240 VAC input supply) is
distributed to each joint drive through a fused, individually-switched
power distribution board, allowing any single joint to be electrically
isolated for service without powering down the full arm.

### 9.5 Safety Circuits

- **Emergency Stop**: dual-channel, hardware-wired (not
  software-mediated) E-stop loop that directly cuts motor bus power via
  a safety relay, independent of the main controller's firmware state.
- **Safe Torque Off (STO)**: each joint drive implements a dual-channel
  STO input per IEC 61800-5-2, allowing torque removal without a full
  power cycle.
- **Relay Design**: force-guided (mechanically-linked) safety relays
  are used in the E-stop chain so that contact-welding failure is
  detectable, per category 3 safety architecture guidance.

### 9.6 Signal Conditioning

Analog sensor signals (current, torque, temperature) are conditioned
(filtered, level-shifted) locally on each joint's sensing PCB before
digitization, minimizing noise pickup across the trunk cable to the main
controller.

### 9.7 Communication Buses

| Bus | Use in This Design | Rationale |
|---|---|---|
| CAN Bus | Joint-to-controller command/feedback (primary) | Deterministic, robust in industrial EMI environments, low wiring complexity |
| EtherCAT | Reserved for future high-axis-count/higher-bandwidth variant | Higher bandwidth than CAN but adds cost/complexity not justified at 6-axis baseline |
| Ethernet | Controller-to-host (ROS2) communication | Standard, high-bandwidth link for vision/planning data |
| USB | Camera and peripheral connections at host computer | Standard for commodity vision sensors |
| RS485 | Optional force-torque sensor and legacy end-effector interfaces | Common industrial sensor interface standard |

DIAGRAM PLACEHOLDER — REQUIRES ENGINEERING DRAWING: communication
topology — HostComputer-ROS2 —Ethernet→ MainController —CANBusTrunk ×6→
{Joint1..Joint6}; HostComputer-ROS2 —USB3/GigE→ VisionCamera;
MainController —RS485→ Force-TorqueSensor-Optional; MainController
—EtherCAT-FutureVariant→ Higher-Axis-CountGateway.

### 9.8 PCB Architecture Recommendation

A three-board-family architecture is recommended: (1) a common **Joint
Drive PCB** (identical for large and small joints, populated differently
for current rating), (2) a **Main Controller PCB** hosting the real-time
MCU and Ethernet/CAN interfaces, and (3) a **Safety Board** implementing
the E-stop/STO logic independently of the main controller's firmware, so
a firmware fault cannot defeat the safety function.

---

## 10. Embedded System

### 10.1 Controller Comparison

| Controller | Role Fit | Rationale |
|---|---|---|
| STM32 (H7-class) | Joint drive real-time control (FOC current loop) | Deterministic real-time performance, mature motor-control peripheral set (advanced timers, ADC) |
| ESP32 | Not used for motion-critical paths | Reserved for optional wireless diagnostics/configuration interface only |
| Raspberry Pi CM5 | Host computer for ROS2 stack, vision preprocessing | Sufficient compute for ROS2 nodes and moderate vision workloads at lower cost/power than Jetson |
| NVIDIA Jetson (Orin Nano class) | Optional upgrade host for heavier CV workloads (YOLO, pose estimation) | Only justified when the Computer Vision module (Section 15) is fitted with real-time deep-learning inference requirements |
| RP2040 | Auxiliary I/O / tool-side microcontroller | Low-cost, sufficient for end-effector-local logic (tool ID, simple grippers) |

### 10.2 Controller Responsibility Mapping

DIAGRAM PLACEHOLDER — REQUIRES ENGINEERING DRAWING: controller
responsibility mapping — STM32-Per-JointDrive —Current/torque loop,
10kHz+→ MotionControl; RaspberryPiCM5/Jetson —Trajectory planning,
kinematics→ MotionControl, —Image processing, detection→ Vision,
—ROS2, Ethernet, CAN bridge→ Communication, —Logging, health
monitoring→ Diagnostics; SafetyBoardMCU —STO, E-stop, limit
monitoring→ Safety.

- **Motion Control**: distributed between per-joint STM32 current-loop
  control and host-side trajectory/kinematics computation.
- **Vision**: host computer (CM5 baseline, Jetson optional upgrade).
- **Safety**: dedicated safety board MCU, electrically and logically
  independent of the motion-control path.
- **Communication**: host computer bridges ROS2 (Ethernet) to the CAN
  joint bus.
- **Diagnostics**: host computer aggregates joint telemetry
  (temperature, current, vibration) for logging and predictive
  maintenance.

---

## 11. Software Architecture

### 11.1 Layered Overview

DIAGRAM PLACEHOLDER — REQUIRES ENGINEERING DRAWING: layered architecture
— AppLayer {ROS2ApplicationNodes} → MotionLayer {MotionController-
TrajectoryInterpolation, KinematicsLibrary-FK/IK, TrajectoryPlanner,
CollisionDetection, DiagnosticsService, ConfigurationSystem} →
Firmware {JointFirmware-FOC+LocalSafetyChecks}.

### 11.2 Firmware

Per-joint firmware implements the FOC current loop, local
overcurrent/over-temperature protection, and reports state upstream over
CAN at a fixed telemetry rate, remaining fully functional (including STO
response) even if the host computer is disconnected.

### 11.3 Motion Controller

The host-side motion controller consumes joint-space or Cartesian-space
trajectory targets and performs real-time interpolation, publishing
per-joint setpoints to the CAN bus at the joint-drive update rate.

### 11.4 Kinematics (Forward/Inverse)

Forward kinematics uses the DH-parameter chain (Section 4.3) to compute
TCP pose from joint angles; inverse kinematics uses a closed-form
analytical solution (available for this 6-DOF spherical-wrist
configuration) with a numerical (Jacobian-based) fallback solver for
edge cases near singularities.

### 11.5 Trajectory & Path Planning

Trajectory generation (time-parameterization of a given path, see
Section 13) is handled in the motion controller; higher-level path/task
planning (e.g., pick sequence, obstacle-aware path selection) is handled
in ROS2 (MoveIt 2, see Section 12) at the application layer.

### 11.6 Collision Detection

A software collision model (simplified convex-hull representation of the
arm and known static workspace obstacles) is checked during trajectory
planning; runtime collision detection also uses joint torque-sensor
deviation from the expected dynamic-model torque as a secondary
contact-detection signal (see Section 14).

### 11.7 Diagnostics & Configuration

A configuration system stores robot geometry (DH parameters, link
masses/inertias), calibration offsets, and joint-specific tuning
(PID/feedforward gains) in versioned configuration files (see Section
20), loaded at controller startup and re-loaded automatically after a
module swap.

---

## 12. Operating System

### 12.1 Comparison

| OS/Framework | Real-Time Capability | Ecosystem | Recommended Role |
|---|---|---|---|
| ROS2 (on Linux RT) | Soft real-time (with rt-kernel patch) | Large robotics ecosystem (MoveIt 2, drivers, simulation) | Host-level application, planning, vision |
| Linux RT (PREEMPT_RT) | Near-hard real-time on general-purpose OS | Standard Linux tooling | Host OS underlying ROS2 |
| FreeRTOS | Hard real-time, small footprint | Broad MCU support | Per-joint STM32 firmware |
| Zephyr RTOS | Hard real-time, modern driver model | Growing but smaller than FreeRTOS in motor-control space | Considered for future firmware revision; FreeRTOS chosen for baseline due to existing motor-control library maturity |

### 12.2 Recommended Software Stack

**ROS2 Humble/Jazzy** on a **PREEMPT_RT-patched Linux host**, with
**FreeRTOS** on each joint's STM32 for hard-real-time current-loop
control. This combination gives the application layer a mature
planning/simulation ecosystem (MoveIt 2, Gazebo, RViz) while keeping the
safety-critical current loop on a deterministic, hard-real-time MCU
independent of host OS jitter.

### 12.3 ROS2 Node Architecture

DIAGRAM PLACEHOLDER — REQUIRES ENGINEERING DRAWING: ROS2 node graph —
robot_driver_node-CAN Bridge, joint_state_publisher, MoveIt2-
MotionPlanning, vision_node, safety_monitor_node, estop_interface_node,
diagnostics_node, task_application_node (interconnections not specified
further in source).

---

## 13. Motion Planning

### 13.1 Control Modes

| Mode | Use Case |
|---|---|
| Joint Control | Point-to-point moves, calibration, teach-mode jogging |
| Cartesian Control | TCP-space linear/circular moves for path-accurate tasks (welding, dispensing) |
| Velocity Control | Continuous-path tracking, conveyor tracking |
| Torque Control | Compliant/force-limited tasks (assembly, contact-rich operations) |

### 13.2 Control Algorithms

- **PID**: baseline position-loop control at each joint, tuned per
  joint-module type (large/small share gain families, individually
  trimmed per link mass).
- **Feedforward Control**: velocity and acceleration feedforward terms
  (from the trajectory profile) are added to the PID output to reduce
  tracking lag on fast moves.
- **Model Predictive Control (MPC)**: reserved as an optional upgrade
  path for high-speed/high-accuracy Cartesian tracking (e.g., precision
  welding); not required for the baseline pick-place/assembly task
  envelope.

### 13.3 Motion Profiles

| Profile | Characteristics | Recommended Use |
|---|---|---|
| Trapezoidal | Constant acceleration segments, simple to compute | Default profile for general pick-place moves |
| S-Curve | Jerk-limited acceleration ramps, smoother dynamics | Recommended for payload-sensitive or vibration-sensitive tasks (e.g., handling delicate parts, camera-in-motion inspection) |

**Recommendation**: S-curve profiles as the system default, since jerk
limiting reduces mechanical wear and vibration-induced settling time,
directly benefiting both repeatability and gearbox service life — a
worthwhile trade for the modest added trajectory-computation complexity.

### 13.4 Motion Control Pipeline

DIAGRAM PLACEHOLDER — REQUIRES ENGINEERING DRAWING: motion control
pipeline — TaskCommand → PathPlanner-MoveIt2 → TrajectoryProfileGenerator
-S-Curve → Real-TimeInterpolator → Per-JointSetpoints →
JointFOCCurrentLoop → EncoderFeedback (closes the loop back into the
current loop).

### 13.5 Operational State Machine

DIAGRAM PLACEHOLDER — REQUIRES ENGINEERING DRAWING: operational state
machine — states {PowerOn, Homing, Idle, Running, Paused, Fault, EStop}.
Transitions: PowerOn→Homing (auto), Homing→Idle (auto), Idle→Running
(task_start), Running→Idle (task_complete), Running→Paused
(pause_command), Paused→Running (resume_command), Running→Fault
(error_detected), Paused→Fault (error_detected), Fault→Idle
(fault_cleared), {Idle,Running,Paused,Fault}→EStop (estop_triggered),
EStop→PowerOn (estop_reset).

*(This matches `arm::safety::SafetyFsm` in `include/safety/safety_fsm.hpp`
exactly — states, transitions, and event names all correspond 1:1.)*

---

## 14. Safety System

### 14.1 Safety Functions

| Function | Implementation |
|---|---|
| Emergency Stop | Dual-channel hardwired loop, direct motor-bus power cutoff |
| Safe Torque Off (STO) | Per-joint dual-channel STO per IEC 61800-5-2 |
| Collision Detection | Torque-deviation monitoring (dynamic model vs. measured torque) with configurable sensitivity |
| Current Monitoring | Per-phase overcurrent protection at each joint drive, hardware and firmware thresholds |
| Thermal Protection | Winding/gearbox temperature monitoring with graduated derate-then-stop response |
| Software Limits | Joint-space soft limits at 90% of mechanical range, enforced in the motion controller |
| Mechanical Stops | Hard end-of-travel stops built into joint housings, independent of software/gearbox |
| Safety Zones | Configurable speed/torque-limited zones via workspace monitoring (camera/light-curtain input, optional) |

### 14.2 Safety System Architecture

DIAGRAM PLACEHOLDER — REQUIRES ENGINEERING DRAWING: safety system
architecture — {SafetyZoneSensor-Optional, TorqueDeviationMonitor,
ThermalMonitor} → SafetyBoardMCU; E-StopButton → Force-GuidedSafetyRelay
→ 48VMotorBusPower (direct cutoff path); SafetyBoardMCU → Dual-Channel
STO → {Joint1STOInput, Joint2STOInput, ..., JointNSTOInput}.

### 14.3 Applicable Industrial Standards

- **ISO 10218-1/-2**: robot and robot-system safety requirements —
  informs the E-stop, STO, and speed/separation-monitoring design
  baseline.
- **ISO/TS 15066**: collaborative robot operation, power/force limiting
  — referenced for the torque-deviation collision-detection thresholds
  when the arm is configured for uncaged, human-shared operation.
- **IEC 60204-1**: electrical equipment of machines — informs the power
  distribution, E-stop circuit, and wiring practices in Section 9.
- **IEC 61800-5-2**: adjustable-speed electrical power drive systems,
  safety requirements — governs the STO implementation at each joint
  drive.

Formal certification against these standards (by an accredited body) is
a pre-production milestone tracked separately from this engineering
baseline, but the electrical and mechanical safety architecture in this
document is designed to the requirements of the referenced standards
from the outset rather than retrofitted later.

---

## 15. Computer Vision (Optional)

### 15.1 Capability Modules

| Capability | Sensor | Processing | Typical Use |
|---|---|---|---|
| Part Localization | RGB or depth camera | Classical CV (edge/blob) or lightweight CNN | Pick-place with variable part position |
| Object Detection | RGB camera | YOLO-class detector (TensorRT-accelerated on Jetson variant) | Multi-SKU bin picking, sorting |
| Pose Estimation | Depth camera | Point-cloud registration / learned pose networks | Bin-picking with unknown orientation |
| Visual Servoing | Wrist RGB camera | Closed-loop image-based control | Fine alignment correction during approach |
| Barcode Reading | RGB camera | Standard barcode/QR decode libraries | Traceability, kitting verification |
| Quality Inspection | RGB or depth camera | Classical CV or CNN-based defect detection | In-line QC checks |

### 15.2 Integration Notes

Vision processing runs on the host computer (Section 10); the CM5
baseline handles classical CV and lightweight-model inference adequately
for most MSME tasks (barcode reading, fixed-pose part detection), while
bin-picking or multi-class detection workloads are the primary driver
for upgrading to the Jetson Orin Nano-class host variant.

---

## 16. Modular Design Strategy

### 16.1 Upgrade/Replacement Modules

| Module | Upgrade Path | Field-Replaceable |
|---|---|---|
| Joint Module | Higher-torque variant within same envelope (payload upgrade) | Yes — common flange/harness interface |
| Controller | Compute upgrade (CM5 → Jetson) without re-wiring the arm | Yes — standardized Ethernet/CAN interface to arm |
| End Effector | Any cataloged tool (Section 8) via quick-change coupling | Yes — tool-agnostic flange |
| Vision Module | Add/upgrade wrist or overhead camera | Yes — standardized mounting + USB3/GigE interface |
| Base | Fixed floor/table mount → mobile-base integration | Yes — standardized base bolt pattern and power/data pass-through |
| Arm Links | Short/standard/long reach variants | Yes — common joint-to-link flange, configuration-file reach parameter |
| Communication Module | CAN-only → CAN + EtherCAT gateway (future higher-axis-count variants) | Yes — modular bus gateway board |

### 16.2 Strategic Rationale

Restricting the design to two joint-module sizes, one flange standard,
and one controller-to-arm interface standard means a single spares
inventory (roughly six SKUs: 2 joint types, 1 controller, 1–3 link-set
lengths, 1 base, 1 tool-changer flange) covers the entire product family
and the large majority of field-service events, which is the primary
lever for keeping MSME total cost of ownership low relative to imported
arms with proprietary, single-source spare parts.

---

## 17. Manufacturing

### 17.1 Component Manufacturing Methods

| Component Class | Method | Notes |
|---|---|---|
| Joint housings, link bodies | 3-axis CNC machining (6061 aluminium) | No 5-axis requirement; regional job-shop compatible |
| Base plate | Sheet metal (steel) or cast/machined aluminium | Steel preferred for mounting stiffness and vibration damping |
| Cable covers, cosmetic panels | Sheet metal, powder-coated | Low-cost, replaceable if cosmetically damaged |
| Structural brackets (base, mounting) | Cast or welded steel | High-stiffness, low-cost at low-moderate volume |
| Cable channel inserts, tool-changer bushings | 3D printed (nylon/PA-CF) or injection-molded at volume | 3D printing for prototype/low-volume; tooling for scaled production |
| Bearings | Commodity metric (DIN/ISO) angular-contact, cross-roller, deep-groove | Multi-source availability, no custom bearing designs |
| Fasteners | Standard metric (ISO 4762 socket-head, etc.), locking compound at vibration-prone joints | Avoids proprietary fastener stock |

### 17.2 Assembly Sequence (High-Level)

1. Base module assembly and power/E-stop wiring verification.
2. Joint module pre-assembly and bench-test (motor, gearbox, encoder,
   drive electronics) prior to arm integration.
3. Sequential joint-to-link stack-up (J1 → J6), torque-spec fastener
   installation, cable harness routing through link channels.
4. Wrist/flange module and tool-changer installation.
5. Controller pack installation and system-level wiring.
6. Power-on self-test, joint-zero calibration, and full-range motion
   verification.
7. Repeatability/accuracy verification against the specification in
   Section 2.1 (laser tracker or comparable metrology).
8. Final safety-function verification (E-stop, STO, soft/hard limits)
   before release.

### 17.3 Tolerances

Joint flange mating features are held to ±0.02 mm (locating
dowels/bores) to preserve repeatability across module swaps without
requiring full kinematic recalibration; general structural machining
uses standard ISO 2768-m tolerances elsewhere.

### 17.4 Maintenance Access

All scheduled-maintenance points (grease ports, connector harnesses,
fuse/relay access on the power distribution board) are reachable without
removing structural covers, and joint modules are designed for
single-technician removal/replacement given the 30-minute field-swap
target in Section 3.6.

### 17.5 Deployment Workflow

DIAGRAM PLACEHOLDER — REQUIRES ENGINEERING DRAWING: deployment workflow
— FactoryAssembly+QC → Crate&ShipToSite → SiteUnpacking&Inspection →
MechanicalMounting → Power&SafetyWiring → Power-OnSelf-Test →
Joint-ZeroCalibration → SafetyFunctionVerification →
RepeatabilityVerification → End-EffectorInstallation →
Task/ApplicationConfiguration → CommissioningSign-Off →
ProductionOperation.

---

## 18. Repository Structure

```
/
├── firmware/          # Per-joint STM32 FOC firmware, safety board firmware
├── ros2_ws/            # ROS2 workspace: drivers, planning, application packages
├── motion_controller/  # Real-time trajectory interpolation and kinematics library
├── drivers/            # CAN/EtherCAT bus drivers, joint communication protocol
├── hardware/           # Electrical schematics, wiring diagrams, BOM references
├── pcb/                 # PCB design sources (joint drive, controller, safety board)
├── mechanical/          # Mechanical design specifications, tolerances, materials
├── cad/                 # CAD source files for links, housings, base, tooling
├── simulation/           # Gazebo/RViz simulation models and test scenarios
├── vision/                # Vision pipeline: detection, pose estimation, calibration
├── dashboard/             # Web-based operator/diagnostics dashboard
├── documentation/         # Design records, calibration procedures, safety documentation
├── deployment/            # Commissioning scripts, site setup runbooks
├── testing/               # Hardware-in-loop, repeatability, and safety validation suites
└── tools/                 # Internal engineering/manufacturing tooling scripts
```

**Repo mapping note (added when this file was checked in):** the actual
`robotic_arm_core` repo diverges from this layout in a few honest ways —
`motion_controller/` and `drivers/` logic live inside `include/`/`src/`
rather than as separate top-level directories; `hardware/`, `pcb/`,
`mechanical/`, `deployment/`, and `testing/` still don't exist (the
physical/electrical design proper was never built, only the software
stack); `simulation/` exists as its own top-level directory now (MuJoCo/
CoppeliaSim integrations), diverging from this document's original
`robot_description/gazebo`-nested placement in a good way, not a drift.
`cad/` now exists too, but only as a parametric placeholder-geometry
skeleton (`cad/freecad/`) — see that directory's README for exactly what
it is and, more importantly, is not (real mechanical design). This is
worth reconciling further, deliberately, once real mechanical/electrical
design work actually starts, rather than letting placeholder geometry be
mistaken for it.

| Directory | Purpose |
|---|---|
| `firmware/` | Real-time joint control firmware (FreeRTOS) and independent safety board firmware |
| `ros2_ws/` | All ROS2 packages: hardware interface, MoveIt 2 config, application nodes |
| `motion_controller/` | Host-side trajectory interpolation, forward/inverse kinematics library |
| `drivers/` | Low-level bus drivers and the joint communication protocol implementation |
| `hardware/` | Electrical schematics, harness diagrams, and component BOM references |
| `pcb/` | PCB layout sources and fabrication outputs for all three board families |
| `mechanical/` | Mechanical specifications: materials, tolerances, load calculations |
| `cad/` | Solid-model source files for all mechanical components and assemblies |
| `simulation/` | Simulation models used for planning validation and digital-twin testing |
| `vision/` | Camera calibration, detection, and pose-estimation pipeline code |
| `dashboard/` | Operator-facing web dashboard for status, diagnostics, and configuration |
| `documentation/` | Engineering records, calibration procedures, and safety compliance docs |
| `deployment/` | Site commissioning scripts and installation runbooks |
| `testing/` | Automated and hardware-in-the-loop validation test suites |
| `tools/` | Internal scripts supporting engineering and manufacturing workflows |

---

## 19. Recommended Technology Stack

### 19.1 Firmware

| Layer | Technology |
|---|---|
| Language | C++ |
| Build System | PlatformIO |
| HAL | STM32 HAL |
| RTOS | FreeRTOS |

### 19.2 Middleware

| Layer | Technology |
|---|---|
| Robotics Middleware | ROS2 (Humble or Jazzy) |
| Motion Planning Framework | MoveIt 2 |

### 19.3 Simulation

| Layer | Technology |
|---|---|
| Physics Simulation | Gazebo |
| Visualization | RViz |
| Planning Validation | MoveIt 2 (simulated execution) |

*(Superseded — see the note at the top of this file and
`documentation/simulation-stack-decision.md`.)*

### 19.4 Backend & Dashboard

| Layer | Technology |
|---|---|
| Backend API | FastAPI |
| Frontend | React + TypeScript |

### 19.5 Communication

| Layer | Technology |
|---|---|
| Joint Bus (primary) | CANopen |
| Future High-Bandwidth Option | EtherCAT |
| Diagnostics/Telemetry | MQTT |

### 19.6 Vision

| Layer | Technology |
|---|---|
| Core CV Library | OpenCV |
| Object Detection | YOLO (class of models) |
| Inference Acceleration | TensorRT (on Jetson-equipped variant) |

### 19.7 CAD & Electrical Design

| Layer | Technology |
|---|---|
| Mechanical CAD | SolidWorks (primary), Fusion 360 / FreeCAD (alternate/collaborator tooling) |
| Electrical/PCB Design | KiCad |

### 19.8 Version Control

| Layer | Technology |
|---|---|
| Source Control | Git |

---

## 20. Codebase Blueprint

### 20.1 Architecture Overview

| Component | Responsibility |
|---|---|
| `motion_controller/kinematics` | Forward/inverse kinematics library (analytical + Jacobian fallback) |
| `motion_controller/trajectory` | S-curve/trapezoidal trajectory generation and real-time interpolation |
| `drivers/can_bus` | CAN transport layer and joint communication protocol (setpoints, telemetry) |
| `drivers/joint_hal` | Hardware abstraction layer presenting a uniform joint interface regardless of joint-module type |
| `ros2_ws/robot_hardware_interface` | ROS2 ros2_control-compatible hardware interface bridging to `drivers/` |
| `ros2_ws/moveit_config` | MoveIt 2 configuration package (kinematics plugin, planning groups, controllers) |
| `firmware/joint_foc` | Per-joint FOC current-loop firmware and local safety checks |
| `firmware/safety_board` | Independent safety-board firmware (E-stop, STO, limit monitoring) |
| `vision/pipeline` | Camera calibration, detection, and pose-estimation nodes |
| `dashboard/backend` | FastAPI service exposing robot state, diagnostics, and configuration endpoints |
| `dashboard/frontend` | React/TypeScript operator dashboard |

### 20.2 ROS2 Package Layout

```
ros2_ws/
├── src/
│   ├── robot_description/          # URDF/Xacro models, per-variant reach configs
│   ├── robot_hardware_interface/   # ros2_control hardware interface (CAN bridge)
│   ├── robot_moveit_config/        # MoveIt 2 planning configuration
│   ├── robot_bringup/              # Launch files, parameter YAMLs
│   ├── robot_msgs/                 # Custom message/service definitions
│   ├── vision_pipeline/            # Detection/pose-estimation nodes
│   ├── safety_monitor/             # Safety state aggregation and E-stop interface node
│   └── diagnostics/                # Telemetry aggregation and logging node
```

### 20.3 Motion/Kinematics Library Interface (Representative)

```cpp
// motion_controller/kinematics/kinematics_interface.hpp
class KinematicsInterface {
public:
    virtual JointPose ForwardKinematics(const JointAngles& angles) const = 0;
    virtual std::optional<JointAngles> InverseKinematics(
        const JointPose& target_pose,
        const JointAngles& seed_angles) const = 0;
    virtual Jacobian ComputeJacobian(const JointAngles& angles) const = 0;
    virtual ~KinematicsInterface() = default;
};
```

### 20.4 Joint Hardware Abstraction Layer (Representative)

```cpp
// drivers/joint_hal/joint_interface.hpp
class JointInterface {
public:
    virtual void SetPositionSetpoint(double radians) = 0;
    virtual void SetVelocitySetpoint(double radians_per_sec) = 0;
    virtual void SetTorqueSetpoint(double newton_meters) = 0;
    virtual JointTelemetry ReadTelemetry() const = 0;  // position, velocity, current, temp
    virtual bool TriggerSafeTorqueOff() = 0;
    virtual ~JointInterface() = default;
};
```

*(Matches `arm::hal::JointInterface` in `include/hal/joint_interface.hpp`
functionally — method names differ only in casing convention:
`setPositionSetpoint` vs. `SetPositionSetpoint`, etc.)*

### 20.5 Configuration File Structure (Representative)

```yaml
# documentation/config/arm_variant_standard.yaml
robot_variant: "standard_5kg_850mm"
dh_parameters:
  - joint: J1
    a: 0.0
    d: 0.284
    alpha: 1.5708
  - joint: J2
    a: 0.400
    d: 0.0
    alpha: 0.0
  # ... J3-J6 continued
joint_limits:
  J1: { min_deg: -170, max_deg: 170, max_speed_deg_s: 180 }
  J2: { min_deg: -95, max_deg: 95, max_speed_deg_s: 180 }
  # ... J3-J6 continued
calibration_offsets_file: "calibration/arm_0001_offsets.yaml"
tool_changer:
  default_tool: "parallel_gripper_v1"
  tool_library_path: "config/tool_library/"
```

*(This is the exact truncation point referenced at the top of this
file — J3–J6 DH parameters and joint limits are not given anywhere in
the source document.)*

### 20.6 Launch File Structure (Representative)

```python
# ros2_ws/src/robot_bringup/launch/robot_bringup.launch.py
def generate_launch_description():
    return LaunchDescription([
        Node(package='robot_hardware_interface', executable='can_bridge_node'),
        Node(package='robot_moveit_config', executable='move_group'),
        Node(package='safety_monitor', executable='safety_monitor_node'),
        Node(package='diagnostics', executable='diagnostics_node'),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(['robot_description', 'display.launch.py'])
        ),
    ])
```

### 20.7 Deployment Configuration (Representative)

```yaml
# deployment/site_commissioning/commissioning_checklist.yaml
steps:
  - power_on_self_test
  - joint_zero_calibration
  - safety_function_verification: [estop, sto_all_joints, soft_limits, hard_limits]
  - repeatability_verification: { target_mm: 0.03, sample_points: 20 }
  - tool_changer_verification
  - network_connectivity_check: { ros2_domain_id: required, host_ip: required }
  - sign_off: { technician_id: required, date: required }
```

*End of Document.*
