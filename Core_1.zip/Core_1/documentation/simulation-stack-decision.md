# Simulation Stack Decision — MuJoCo + CoppeliaSim (replacing Gazebo)

## What changed and when

The design baseline (`documentation/design-baseline.md`, §19.3) specifies
Gazebo, and that's what was originally built: `ros2_ws/src/robot_description/gazebo/`
(a Gazebo-flavored URDF generator), `robot_description/worlds/msme_cell.sdf`,
and `robot_bringup/launch/gazebo_bringup.launch.py`, bridging camera/IMU
topics via `ros_gz_bridge`.

That's been removed. The project's development environment requirement
was fixed as Mac + Parallels Desktop + Ubuntu 24.04.3 + ROS2, with
**MuJoCo and CoppeliaSim running on the Mac host** (not the Ubuntu VM) as
the simulation backends, bridged to ROS2 in the VM — a materially
different architecture than a single Gazebo instance running inside the
same Linux environment as ROS2 itself. Given that requirement, running
Gazebo *as well* would mean maintaining three simulator integrations
instead of one for no clear benefit, so it was removed rather than kept
alongside the other two.

## What replaces it (status: MJCF generation done, CoppeliaSim + bridge not started)

1. **MJCF generation — done.** `simulation/mujoco/generate_mjcf.py`
   generates an MJCF model from the same canonical DH/joint-limit source
   as the URDF generator. Cross-checked numerically against the URDF
   output (every joint limit and DH offset matches exactly) — but
   **never loaded into MuJoCo itself** (no network access to install the
   `mujoco` package in this environment). See
   `simulation/mujoco/README.md` for exactly what's confirmed vs. still
   needs a real MuJoCo install to check.
2. **CoppeliaSim scene/model — approach decided, geometry done, ROS2
   wiring deliberately deferred.** `simulation/coppeliasim/` imports the
   same canonical URDF via CoppeliaSim's own URDF importer (rather than
   writing a third independent DH-table-driven generator — see that
   directory's README for why), plus a setup script for joint control
   modes. How CoppeliaSim actually talks to ROS2 over the network is
   correctly left as an open question belonging to the bridge work below,
   not decided prematurely — see `simulation/coppeliasim/README.md`'s
   "Open architectural question" section.
3. **The actual Mac↔Ubuntu bridge — architecture decided, half built.**
   See `documentation/mac-ubuntu-bridge-architecture.md`: ROS2 Jazzy
   (forced by the Ubuntu 24.04 requirement), Parallels networking mode
   (Shared for development, Bridged once real hardware/other machines
   need direct access), DDS discovery via static peers/Discovery Server
   (sidesteps multicast-through-VM reliability issues), and a two-path
   bridge — `foxglove_bridge` unchanged for Foxglove, a new curated gRPC
   `robot_gateway` for an operator-facing native app, and a separate gRPC
   stream for the simulator-facing `sim_network_hardware_interface` this
   section's CoppeliaSim/MuJoCo connection needs. Contract sketches in
   `documentation/bridge_proto/`. As of this update, `robot_gateway`,
   `sim_network_hardware_interface`, and **both** simulator-side servers
   (`simulation/mujoco/mac_sim_server.py`,
   `simulation/coppeliasim/coppeliasim_sim_server.py`) exist as real (if
   uncompiled/unrun) code — the full bridge, both directions, is now at
   least a complete first draft end to end.

## What this means for `vision_pipeline` right now

The removed Gazebo bridge was `vision_pipeline`'s only source of a
simulated camera feed (`image_raw`, bridged from `gz-sim`'s camera
sensor). With that gone and MuJoCo/CoppeliaSim not yet built,
**`vision_pipeline` currently has no simulated image source at all** —
it still works standalone against the independently-tested `vision/`
Python modules (16/16 tests passing, no ROS2/simulator dependency), but
the ROS2 node itself has nothing to subscribe to until either a real
camera driver or the new simulator integration exists. Worth knowing if
you go looking for it.

## Open decision still needed

Which simulator's camera/sensor output becomes `vision_pipeline`'s
development-time image source — MuJoCo's renderer, CoppeliaSim's vision
sensor, or both — isn't decided yet. Worth resolving as part of building
whichever simulator integration comes first.
