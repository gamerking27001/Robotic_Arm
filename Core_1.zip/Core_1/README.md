# robotic_arm_core

A modern C++20 implementation of the "Modular Industrial Robotic Arm for
MSMEs" engineering baseline, built in three layers:

**Changelog note:** a review pass found and fixed a real safety-authority
bug in `ros2_ws` — the ROS2 layer's E-stop previously updated a status
topic without actually being able to stop the robot. See
`ros2_ws/README.md`'s "Safety authority fix" section before relying on
anything E-stop-related in that layer. The same pass added dashboard
authentication (previously "No auth"), Docker/systemd deployment
scaffolding, and a CI workflow that runs a real ROS2 `colcon build` against
`ros2_ws` for the first time — see `deploy/README.md`.

- **`include/`, `src/`** — the host-level **core stack**: kinematics, motion
  planning, a joint hardware-abstraction layer, and the safety state machine,
  running against a simulated CAN bus / simulated joint dynamics. Builds and
  runs (`arm_demo`) — verified.
- **`firmware/`** — the **per-joint FOC control loop + independent safety
  board firmware** (§9.3, §11.2, §14, §9.8), host-simulated on real OS
  threads at real timing rates. Builds and runs (`firmware_demo`) — verified.
  See `firmware/README.md` for its own scope notes.
- **`ros2_ws/`** — the **ROS2 integration layer** (§12, §18, §20.2): a
  `ros2_control` hardware interface wrapping the core stack, a MoveIt 2
  planning config, a URDF generated from the same config the core stack
  reads, and safety/diagnostics nodes. **Not built or run** — there's no
  ROS2 installation in this environment. See `ros2_ws/README.md` before
  trusting any of it; treat it as a careful first draft, not verified code.
- **`dashboard/`** — the **operator dashboard** (§19.4, §20.1): a FastAPI
  backend (`dashboard/backend`) that wraps the core stack via a small C ABI
  + ctypes (no ROS2 dependency), a React+TypeScript frontend
  (`dashboard/frontend`), and a second web app, `dashboard/commissioning-wizard`
  (§17.5/§20.7's deployment checklist, mostly automated against the live
  backend). All **built, run, and integration-tested** — real HTTP/WebSocket
  requests against a live server, and two real bugs (safety evaluation
  timing, STO never actually clearing) caught and fixed in the process. The
  backend also mounts `dashboard/backend/ai_routes.py`, a set of read-only
  endpoints surfacing the `ai/` layer's insights (predictive maintenance,
  thermal forecast, anomaly detection, fleet summary, a grounded Q&A
  endpoint) fed by the same live telemetry poll — the FastAPI decorator
  layer itself wasn't run end-to-end (no `fastapi` install available in
  this sandbox), though everything under it was: 17/17 tests firing real
  HTTP requests and adapter logic at a stdlib-only server exposing the same
  routes and auth scheme, in `dashboard/backend/tests/`. Also adds two
  operator-facing routes for real, on-disk (SQLite) severity-ranked alerts
  derived from AI insights crossing a threshold, with an
  acknowledgment endpoint correctly gated stricter than the read routes. See
  each package's own README.
- **`mobile/ArmOperatorApp`** — a **true native Android app** (React Native),
  same operator dashboard functionality. Real scaffolding from
  `@react-native-community/cli`, real `npm install`, clean `tsc`, and 4/4
  component tests passing against `react-test-renderer` — but the actual
  Android/Gradle build could not be verified (Google's package servers and
  even `services.gradle.org` aren't reachable here). See
  `mobile/ArmOperatorApp/README.md` for exactly where verification stops.
- **`desktop/windows`** — a **native desktop app** (Electron), wrapping the
  already-tested `dashboard/frontend` bundle unmodified. The most thoroughly
  verified new piece: real Windows `.exe` and Linux binaries were actually
  packaged and (the Linux one) run and **screenshotted** rendering live
  telemetry through a real backend — two real proxy bugs found and fixed
  along the way. See `desktop/windows/README.md`.
- **`vision/`** — the **computer vision layer** (§15, marked *Optional* in
  the source doc): calibration, part localization, barcode/QR reading,
  quality inspection, pose estimation, and object detection, each with
  classical-CV or trained-ML implementations. **Built and tested** —
  32/32 tests pass against real synthetic image/point data with known
  ground truth. Object detection has three implementations behind one
  auto-selecting factory (`detector_factory.py`): a real
  `onnxruntime`-backed YOLOv8 inference pipeline (`YOLOOnnxDetector` —
  standard letterbox preprocessing, raw-output decode, NMS, all verified
  against hand-constructed synthetic model outputs with known ground
  truth), a real trained HOG+SVM detector (`HOGSVMDetector`, genuinely
  learns shape not just color), and the original color-blob classical
  fallback. `ros2_ws/src/vision_pipeline`'s vision node now goes through
  this factory instead of hardcoding a detector, so pointing a ROS2
  parameter at a real exported `.onnx` file is the entire step needed to
  run real YOLO inference — no code changes downstream. What's NOT
  possible in this environment: exercising `YOLOOnnxDetector` against an
  actual trained model, since there's no network access to export or
  download `.onnx` weights, and no way to even construct a synthetic one
  for testing (the `onnx` package itself isn't installable either) — see
  `vision/README.md` for the precise line between what's verified and
  what's structurally correct but unexercised.
- **`ai/`** — the **AI/ML services layer** (§8 of the companion "Industrial
  Robotics Operating Platform for MSMEs" doc): predictive maintenance,
  thermal forecasting (a real hand-derived GRU, gradient-checked, no torch —
  see below), energy optimization, quality inspection (wraps `vision/`),
  motion-optimization reinforcement learning (PPO, hand-implemented in
  numpy), digital twin residual monitoring, LiDAR workspace classification,
  anomaly detection, fleet-wide aggregation, and a grounded operator-
  assistant Q&A service — all ten independent, communicating only through a
  shared Insights Bus (in-process by default, or a real stdlib-only TCP
  socket broker for genuine cross-process/edge-cloud operation), with a
  generalized MLOps registry, a §17.2-compliant versioned API router, and
  the shadow-mode → staged-rollout → fleet-wide → automatic-rollback
  deployment gate every learned model has to clear before it can influence
  a robot. **Built and tested** — 60/60 tests pass, including real-socket
  TCP-bus tests and a live-HTTP-server test of the dashboard integration
  below. No network access was available to install `xgboost`, `torch`,
  `pydantic`, `fastapi`, `paho-mqtt`, or `grpcio` in this environment
  (confirmed as a hard proxy-level block, not a missing index) — where that
  blocked a spec-PRIMARY model, a real dependency-free implementation was
  built from scratch instead (a hand-derived, gradient-checked GRU for
  thermal forecasting; a stdlib-only TCP pub/sub broker for network
  transport) rather than left as a stub; see `ai/README.md`'s table for the
  handful of cases where the spec's own named fallback was used instead,
  and why. Nothing in this layer issues a motion command — see
  `ai/README.md`'s "governing rule" for how that's enforced structurally,
  not just stated.

All three build with a C++20 compiler and the standard library only — no
Eigen, no Boost, no YAML library, no FreeRTOS/STM32 SDK, no ROS2 SDK.
The core stack and firmware layer were built and verified with GCC 13.3.0 on
Ubuntu 24.04; the ROS2 layer needs a real ROS2 Jazzy/Humble environment to
verify.

## Build

```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build .
./arm_demo          # core stack demo
./firmware_demo     # firmware layer demo
```

For the ROS2 layer, see `ros2_ws/README.md` (requires a real ROS2 install;
`colcon build` from a workspace containing `ros2_ws/src`'s contents).

Or directly with g++ (no cmake required), from the project root:

```bash
# Core stack
g++ -std=c++20 -O2 -Iinclude src/kinematics/*.cpp src/motion/*.cpp src/hal/*.cpp \
    src/safety/*.cpp src/config/*.cpp src/main.cpp -o arm_demo
./arm_demo

# Firmware layer (needs -pthread)
g++ -std=c++20 -O2 -pthread -I. -Iinclude \
    firmware/joint_foc/joint_foc_task.cpp firmware/safety_board/safety_board_task.cpp \
    firmware/firmware_demo.cpp -o firmware_demo
./firmware_demo
```

## What `arm_demo` does

1. Prints the full robot + per-joint specification table (§1.5/§2.1/§5.6/§6.2).
2. Loads `configs/arm_variant_standard.yaml` (the §20.5 config format) and
   builds the DH kinematic chain from it.
3. Runs forward kinematics, then solves inverse kinematics for a target pose
   (closed-form geometric seed + Jacobian/damped-least-squares refinement,
   per §11.4) and verifies the round-trip.
4. Builds a synchronized 6-axis S-curve trajectory (§13.3's recommended
   default) between two joint configurations and steps the motion controller
   against six simulated joint drives.
5. Mid-move, injects a simulated contact load on the elbow joint (J3) to
   exercise the §14 torque-deviation collision-detection path, and shows the
   safety FSM (§13.5) latching **Running → Fault**.
6. Demonstrates fault-clear, hardware E-stop trigger (with STO on every
   joint, §9.5), and E-stop reset back to `PowerOn`.

## Layout and document traceability

| Path | Source doc section(s) | Contents |
|---|---|---|
| `include/core/robot_config.hpp` | §1.5, §2.1, §5.6, §6.2, §7, §14, §13.3 | Every numeric parameter as `constexpr` typed config |
| `include/core/linalg.hpp` | — | Dependency-free Vector3/Matrix3/Transform/6x6 solve |
| `kinematics/dh_kinematics.*` | §4.3, §11.4 | DH forward kinematics + geometric Jacobian |
| `kinematics/ik_solver.*` | §11.4 | Closed-form geometric seed + Jacobian DLS refinement |
| `motion/trajectory_profile.*` | §13.3, §13.4 | Trapezoidal + jerk-limited S-curve profiles |
| `motion/motion_controller.*` | §11.3 | Real-time interpolator, synchronized multi-axis moves |
| `hal/joint_interface.hpp` | §20.4 | The interface reproduced verbatim from the doc |
| `hal/simulated_joint_driver.*` | §9.3, §6.2, §6.4, §7.1 | Simulated per-joint drive + thermal/torque model |
| `hal/can_bus_simulated.hpp` | §9.7, §19.5 | In-process stand-in for the CANopen joint bus |
| `safety/safety_fsm.*` | §13.5, §14.1, §9.5 | Operational state machine + safety functions |
| `config/config_loader.*` | §11.7, §20.5 | Hand-rolled parser for the §20.5 config format |
| `configs/arm_variant_standard.yaml` | §20.5 | Reproduces the doc's sample config |

## Gaps in the source document (and how this codebase handles them)

The source PDF's representative configuration truncates two tables with
`# ... J3-J6 continued`:

- **DH parameters** (§4.3/§20.5): only J1 (`a=0, d=0.284, alpha=90°`) and J2
  (`a=0.400, d=0, alpha=0`) are given numerically. J3-J6 are filled in here
  with `PLACEHOLDER_`-commented values sized to be consistent with the
  850 mm reach and spherical-wrist requirement stated elsewhere in the doc.
- **Joint soft limits** for J3-J6 (§20.5): only J1/J2 limits are given
  numerically; J3-J6 are filled with representative values.

Both are isolated to `include/core/robot_config.hpp` and
`configs/arm_variant_standard.yaml` — correcting them there propagates
through kinematics, motion planning, and safety limit checks automatically.
A few other parameters aren't given numeric values anywhere in the source
doc (e.g. joint acceleration limits, the collision-detection torque-deviation
threshold, control-loop update rate); these are marked with inline comments
explaining the engineering assumption made.

## Out of scope (not built here)

- **PCB / electrical schematics** (§9, §pcb/) and **mechanical CAD** (§3, §cad/).
- **Real STM32/FreeRTOS build** — `firmware/` implements the FOC control loop
  and safety-board logic faithfully but runs it on host threads via a small
  shim, not a real ARM cross-compile; see `firmware/README.md`.
- **Real ROS2/colcon build** — `ros2_ws/` implements the hardware interface,
  MoveIt config, and safety/diagnostics nodes but has not been compiled or
  run (no ROS2 install in this environment); see `ros2_ws/README.md`.
- `vision/object_detection`'s `YOLOOnnxDetector` against REAL pretrained
  weights — the inference pipeline itself (preprocessing, decode, NMS) is
  real and tested; there's no network access here to export or download
  actual `.onnx` weights (see `vision/README.md`).
- Formal safety certification against ISO 10218-1/-2, ISO/TS 15066,
  IEC 60204-1, IEC 61800-5-2 (§14.3) — the safety *architecture* here follows
  those standards' structure (dual-channel STO, hardware E-stop independent
  of firmware state) but has not been certified.

## Windows compatibility

The Python layers (`ai/`, `vision/`, `dashboard/backend`'s FastAPI app and
`ai_routes.py`) were already largely cross-platform — consistent use of
`pathlib.Path` throughout, no `subprocess`/shell calls, no POSIX-only
modules. A real audit turned up and fixed two genuine gaps rather than
assuming "mostly uses pathlib" meant "fully portable":

- `common/mlops.py`'s `ModelRegistry` used `Path.read_text()`/`.write_text()`
  without an explicit encoding, which defaults to the platform's locale
  encoding — frequently a Windows codepage other than UTF-8. Fixed to pass
  `encoding="utf-8"` explicitly both ways.
- `common/persistence.py`'s SQLite store now sets `PRAGMA journal_mode=WAL`
  for file-backed databases, since Windows' default rollback-journal file
  locking is stricter about concurrent access than POSIX's.
- `common/tcp_bus.py`'s use of `SO_REUSEADDR` is documented as having
  different (more permissive) semantics on Windows than POSIX — not a bug,
  since every caller binds to an OS-assigned ephemeral port anyway, but
  worth knowing before relying on it for anything else.

The one real, code-level blocker was `dashboard/backend`'s native C++
bridge: `native_bridge/robot_bridge.h` had no `__declspec(dllexport)`
anywhere. Unlike a Linux `.so` (symbols exported by default), a Windows DLL
exports nothing without it — the library would have loaded fine via
`ctypes.CDLL` and then failed with `AttributeError` on the very first
function call. Fixed with a cross-platform `ROBOT_BRIDGE_API` export macro,
a new `build.bat` (MSVC primary, MinGW alternative documented in the same
file), and cross-platform library-filename resolution in `main.py`'s
`_load_library()` (previously hardcoded `librobot_bridge.so`
unconditionally). The Linux build was re-run and smoke-tested via a real
`ctypes` call after these changes to confirm nothing broke — `build.bat`
itself could not be: there's no MSVC or MinGW cross-compiler in this
environment to test a Windows build with. Treat `build.bat` as a careful,
reviewed first draft to verify on real Windows hardware, the same caution
this README already asks for on `ros2_ws/` and other unverified layers.

`ros2_ws/` remains genuinely out of scope for Windows — ROS2 itself has
only limited, non-primary Windows support, and this repo's own architecture
already routes around that (the FastAPI dashboard backend is the intended
non-ROS2, cross-platform control path; `simulation/mujoco/mac_sim_server.py`
documents a deliberate Mac-runs-the-simulator/Linux-VM-runs-ROS2 split for
the same reason). Extending ROS2 itself onto Windows was not attempted.
