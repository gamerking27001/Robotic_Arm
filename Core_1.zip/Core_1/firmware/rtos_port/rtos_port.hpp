// firmware/rtos_port/rtos_port.hpp
//
// §12.2: "FreeRTOS on each joint's STM32 for hard-real-time current-loop
// control." §19.1 names FreeRTOS + PlatformIO + STM32 HAL as the firmware
// technology stack.
//
// IMPORTANT — what this file actually is:
// There is no ARM cross-compiler, STM32 HAL, or FreeRTOS kernel available in
// this build environment, so this is NOT the real FreeRTOS kernel. It's a
// minimal host-side shim that mirrors the small slice of the FreeRTOS API
// surface this firmware layer needs (periodic tasks à la vTaskDelayUntil,
// binary flags à la a GPIO/semaphore, a thread-safe queue à la a CAN mailbox)
// so that:
//   (a) the task/ISR partitioning and timing model can be written and
//       validated exactly as it would be structured on real FreeRTOS, and
//   (b) porting to real FreeRTOS + STM32 HAL later is a mechanical swap of
//       this header's implementation, not a redesign of joint_foc_task.cpp /
//       safety_board_task.cpp.
// See firmware/platformio.ini for the real-hardware target scaffold this is
// standing in for.
#pragma once

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <deque>
#include <functional>
#include <mutex>
#include <optional>
#include <string>
#include <thread>

namespace firmware::rtos {

using Clock = std::chrono::steady_clock;

// Mirrors the FreeRTOS pattern of a task created with xTaskCreate() running a
// `for(;;) { ...; vTaskDelayUntil(&last_wake, period); }` loop — i.e. a
// fixed-rate periodic task, which is how both the current-loop task and the
// safety-board task are structured in the real system (§9.3: "current loop
// closed locally at >10 kHz"; §14: independent periodic safety monitoring).
class PeriodicTask {
public:
    PeriodicTask(std::string name, std::chrono::microseconds period, std::function<void()> tick_fn)
        : name_(std::move(name)), period_(period), tick_fn_(std::move(tick_fn)) {}

    ~PeriodicTask() { stop(); }

    void start() {
        running_ = true;
        thread_ = std::thread([this] { run(); });
    }

    void stop() {
        if (running_.exchange(false) && thread_.joinable()) thread_.join();
    }

    [[nodiscard]] const std::string& name() const { return name_; }
    [[nodiscard]] std::uint64_t tickCount() const { return tick_count_.load(); }
    // Largest observed gap between intended and actual wake time — a rough
    // stand-in for the jitter figure you'd pull from real hardware timers.
    [[nodiscard]] std::chrono::microseconds worstCaseJitter() const { return worst_jitter_; }

private:
    void run() {
        auto next_wake = Clock::now();
        while (running_.load()) {
            const auto actual = Clock::now();
            const auto jitter = std::chrono::duration_cast<std::chrono::microseconds>(
                actual > next_wake ? (actual - next_wake) : std::chrono::microseconds{0});
            if (jitter > worst_jitter_) worst_jitter_ = jitter;

            tick_fn_();
            ++tick_count_;

            next_wake += period_;
            std::this_thread::sleep_until(next_wake);
        }
    }

    std::string name_;
    std::chrono::microseconds period_;
    std::function<void()> tick_fn_;
    std::thread thread_;
    std::atomic<bool> running_{false};
    std::atomic<std::uint64_t> tick_count_{0};
    std::chrono::microseconds worst_jitter_{0};
};

// A hardware-line stand-in (e.g. the dual-channel E-stop loop, §9.5) — a
// plain atomic bool is a reasonable software analog of a debounced GPIO input
// latched by an ISR.
class HardwareLine {
public:
    void set(bool level) { level_.store(level); }
    [[nodiscard]] bool get() const { return level_.load(); }

private:
    std::atomic<bool> level_{false};
};

// Thread-safe bounded-ish FIFO — stands in for a CAN mailbox / message queue
// between tasks (§9.3: joint drives "receiving position/velocity/torque
// setpoints from the main controller over CAN").
template <typename T>
class Queue {
public:
    void push(const T& item) {
        std::lock_guard<std::mutex> lock(mutex_);
        queue_.push_back(item);
        cv_.notify_one();
    }

    [[nodiscard]] std::optional<T> tryPop() {
        std::lock_guard<std::mutex> lock(mutex_);
        if (queue_.empty()) return std::nullopt;
        T item = queue_.front();
        queue_.pop_front();
        return item;
    }

    [[nodiscard]] std::size_t size() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return queue_.size();
    }

private:
    mutable std::mutex mutex_;
    std::condition_variable cv_;
    std::deque<T> queue_;
};

}  // namespace firmware::rtos
