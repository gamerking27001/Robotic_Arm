// firmware/joint_foc/joint_foc_task.hpp
// §11.2: "Per-joint firmware implements the FOC current loop, local
// overcurrent/over-temperature protection, and reports state upstream over
// CAN at a fixed telemetry rate, remaining fully functional (including STO
// response) even if the host computer is disconnected."
// §9.3: "...receiving position/velocity/torque setpoints from the main
// controller over CAN. This distributes control-loop computation and
// simplifies the main controller's real-time budget to trajectory-level
// (position/velocity) updates rather than raw current-loop control" — i.e.
// the host sends position/velocity/torque *targets*; this firmware task
// closes the position -> velocity -> current cascade locally, exactly the
// way a real industrial servo drive does.
#pragma once

#include <atomic>
#include <mutex>
#include <optional>

#include "core/robot_config.hpp"
#include "firmware/common/foc_math.hpp"
#include "firmware/common/motor_hal.hpp"
#include "firmware/common/pi_controller.hpp"
#include "firmware/rtos_port/rtos_port.hpp"

namespace firmware::joint_foc {

namespace config = arm::config;

enum class ControlMode { kPosition, kVelocity, kTorque };

struct SetpointCommand {
    ControlMode mode = ControlMode::kPosition;
    double value = 0.0;  // rad, rad/s, or Nm (joint-side, post-gearbox) depending on mode
};

// Compiled-in motor/controller calibration constants — on real hardware these
// come from a motor datasheet + tuned gains stored in the §11.7 config
// system, not derived from the simulated plant (the plant only needs to
// agree closely enough for the loops to behave sensibly in simulation).
struct JointFocConfig {
    double motor_torque_constant_nm_per_a = 0.5;  // motor-side Nm/A
    control::PIGains id_gains{10.0, 1500.0};
    control::PIGains iq_gains{10.0, 1500.0};
    control::PIGains velocity_gains{0.8, 6.0};      // outer velocity loop -> motor-side torque command
    double position_kp = 40.0;                        // outer position loop (§13.2 "PID: baseline position-loop control") -> velocity command
    double current_limit_a = 20.0;
    double overcurrent_trip_a = 30.0;                 // §11.2 local overcurrent protection
    double overtemp_trip_c = config::kSafetySpec.thermal_trip_c;  // §6.4 / §11.2 local overtemperature protection

    static JointFocConfig fromJointSpec(const config::JointSpec& spec);
};

struct TelemetryReport {
    double position_rad = 0.0;      // joint-side (post-gearbox)
    double velocity_rad_s = 0.0;    // joint-side
    double torque_estimate_nm = 0.0; // joint-side
    double current_a = 0.0;
    double winding_temp_c = 0.0;
    bool sto_active = false;
    bool fault = false;
    bool overcurrent_fault = false;
    bool overtemp_fault = false;
};

class JointFocTask {
public:
    JointFocTask(config::JointId id, hal::MotorHal& motor, JointFocConfig cfg, rtos::HardwareLine& sto_line);

    // Called from the CAN-RX path (§9.3) — thread-safe, lock-free via atomics
    // on the plain-old-data command so it can be invoked from a different
    // task than the one calling tick().
    void setCommand(SetpointCommand cmd);

    // Runs one current-loop iteration; call this from a PeriodicTask at
    // >=10 kHz (§9.3). Internally sub-divides into slower velocity/position
    // cascade updates via tick counters, matching how a real drive runs
    // nested loops at different rates from a single high-rate ISR.
    void tick(double dt_s);

    [[nodiscard]] TelemetryReport telemetry() const;

private:
    void runPositionLoop();
    void runVelocityLoop();
    void runCurrentLoop(double dt_s);

    config::JointId id_;
    const config::JointSpec& spec_;
    hal::MotorHal& motor_;
    JointFocConfig cfg_;
    rtos::HardwareLine& sto_line_;  // §9.5: hardware STO input, checked independently every tick

    std::atomic<ControlMode> mode_{ControlMode::kPosition};
    std::atomic<double> setpoint_value_{0.0};

    control::PIController id_pi_;
    control::PIController iq_pi_;
    control::PIController velocity_pi_;

    double velocity_command_rad_s_ = 0.0;   // output of position loop
    double torque_command_motor_nm_ = 0.0;  // output of velocity loop, input to current loop
    std::uint32_t tick_counter_ = 0;

    mutable std::mutex telemetry_mutex_;
    TelemetryReport last_telemetry_{};
};

}  // namespace firmware::joint_foc
