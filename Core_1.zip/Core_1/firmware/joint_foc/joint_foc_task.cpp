#include "firmware/joint_foc/joint_foc_task.hpp"

#include <algorithm>
#include <cmath>

#include "core/linalg.hpp"

namespace firmware::joint_foc {

JointFocConfig JointFocConfig::fromJointSpec(const config::JointSpec& spec) {
    JointFocConfig cfg{};
    const double rated_current_estimate_a = spec.motor_power_w / config::kRobotSpec.bus_voltage_vdc;
    const double motor_side_rated_torque_nm = spec.rated_output_torque_nm / spec.gear_ratio;
    cfg.motor_torque_constant_nm_per_a = motor_side_rated_torque_nm / std::max(rated_current_estimate_a, 1e-6);
    cfg.current_limit_a = rated_current_estimate_a * 2.0;    // headroom to peak within thermal limits
    cfg.overcurrent_trip_a = rated_current_estimate_a * 4.0;  // §11.2 hardware/firmware overcurrent threshold
    cfg.overtemp_trip_c = config::kSafetySpec.thermal_trip_c;
    return cfg;
}

JointFocTask::JointFocTask(config::JointId id, hal::MotorHal& motor, JointFocConfig cfg, rtos::HardwareLine& sto_line)
    : id_(id), spec_(config::kJointSpecs[static_cast<std::size_t>(id)]), motor_(motor), cfg_(cfg),
      sto_line_(sto_line),
      id_pi_(cfg.id_gains, -motor.busVoltageVdc() * 0.5, motor.busVoltageVdc() * 0.5),
      iq_pi_(cfg.iq_gains, -motor.busVoltageVdc() * 0.5, motor.busVoltageVdc() * 0.5),
      velocity_pi_(cfg.velocity_gains, -spec_.peak_output_torque_nm, spec_.peak_output_torque_nm) {}

void JointFocTask::setCommand(SetpointCommand cmd) {
    mode_.store(cmd.mode);
    setpoint_value_.store(cmd.value);
}

void JointFocTask::runPositionLoop() {
    TelemetryReport current;
    {
        std::lock_guard<std::mutex> lock(telemetry_mutex_);
        current = last_telemetry_;
    }
    const double target = setpoint_value_.load();
    const double error = target - current.position_rad;
    const double max_speed_rad_s = arm::core::deg2rad(spec_.max_joint_speed_deg_s);
    velocity_command_rad_s_ = std::clamp(cfg_.position_kp * error, -max_speed_rad_s, max_speed_rad_s);
}

void JointFocTask::runVelocityLoop() {
    const double target_velocity = (mode_.load() == ControlMode::kVelocity) ? setpoint_value_.load()
                                                                              : velocity_command_rad_s_;
    const double current_velocity = motor_.readMechanicalVelocityRadS() / spec_.gear_ratio;  // joint-side
    const double torque_joint_nm = velocity_pi_.update(target_velocity, current_velocity, /*dt_s=*/0.001);
    const double torque_joint_clamped = std::clamp(torque_joint_nm, -spec_.peak_output_torque_nm,
                                                     spec_.peak_output_torque_nm);
    torque_command_motor_nm_ = torque_joint_clamped / spec_.gear_ratio;
}

void JointFocTask::runCurrentLoop(double dt_s) {
    const double torque_command_nm = (mode_.load() == ControlMode::kTorque)
                                          ? setpoint_value_.load() / spec_.gear_ratio  // joint Nm -> motor-side
                                          : torque_command_motor_nm_;

    double iq_ref = torque_command_nm / std::max(cfg_.motor_torque_constant_nm_per_a, 1e-9);
    iq_ref = std::clamp(iq_ref, -cfg_.current_limit_a, cfg_.current_limit_a);
    const double id_ref = 0.0;  // max-torque-per-amp for a surface-mount PMSM, §6.1

    const hal::PhaseCurrents i_abc = motor_.readPhaseCurrents();
    const double theta_e = motor_.readElectricalAngleRad();
    const foc::AlphaBeta i_ab = foc::clarke(i_abc.ia, i_abc.ib);
    const foc::DQ i_dq = foc::park(i_ab, theta_e);

    const double current_magnitude = std::hypot(i_dq.d, i_dq.q);

    // §11.2 local overcurrent/overtemperature protection — trips regardless
    // of host/CAN connectivity, independent of the outer loops above.
    const double winding_temp = motor_.readWindingTempC();
    const bool overcurrent = current_magnitude > cfg_.overcurrent_trip_a;
    const bool overtemp = winding_temp > cfg_.overtemp_trip_c;
    const bool sto_asserted = sto_line_.get();

    if (sto_asserted || overcurrent || overtemp) {
        motor_.setGateDriverEnabled(false);
        id_pi_.reset();
        iq_pi_.reset();
        velocity_pi_.reset();
        // Still advance the plant's electrical/mechanical state (with the
        // gate disabled, SimulatedMotorHal decays current toward zero rather
        // than integrating fresh voltage) — otherwise the plant's internal
        // clock never advances while faulted and a transient overcurrent/
        // overtemp trip could never self-clear.
        motor_.writePwmDuty(0.5, 0.5, 0.5);
    } else {
        motor_.setGateDriverEnabled(true);
        const double vd = id_pi_.update(id_ref, i_dq.d, dt_s);
        const double vq = iq_pi_.update(iq_ref, i_dq.q, dt_s);
        const foc::AlphaBeta v_ab = foc::inversePark({vd, vq}, theta_e);
        const foc::ThreePhase duty = foc::svpwmDuty(v_ab, motor_.busVoltageVdc());
        motor_.writePwmDuty(duty.a, duty.b, duty.c);
    }

    TelemetryReport t;
    t.position_rad = motor_.readMechanicalAngleRad() / spec_.gear_ratio;
    t.velocity_rad_s = motor_.readMechanicalVelocityRadS() / spec_.gear_ratio;
    t.torque_estimate_nm = i_dq.q * cfg_.motor_torque_constant_nm_per_a * spec_.gear_ratio;
    t.current_a = current_magnitude;
    t.winding_temp_c = winding_temp;
    t.sto_active = sto_asserted;
    t.overcurrent_fault = overcurrent;
    t.overtemp_fault = overtemp;
    t.fault = overcurrent || overtemp;

    std::lock_guard<std::mutex> lock(telemetry_mutex_);
    last_telemetry_ = t;
}

void JointFocTask::tick(double dt_s) {
    // Cascade rates: current loop every tick (>=10 kHz per §9.3); velocity
    // loop at 1/10th rate; position loop at 1/100th rate — a conventional
    // servo-drive cascade structure (fast inner loop, progressively slower
    // outer loops) implemented via simple tick-counting since this shim has
    // no separate hardware timers to trigger sub-tasks at different rates.
    ++tick_counter_;
    if (mode_.load() == ControlMode::kPosition && tick_counter_ % 100 == 0) {
        runPositionLoop();
    }
    if (mode_.load() != ControlMode::kTorque && tick_counter_ % 10 == 0) {
        runVelocityLoop();
    }
    runCurrentLoop(dt_s);
}

TelemetryReport JointFocTask::telemetry() const {
    std::lock_guard<std::mutex> lock(telemetry_mutex_);
    return last_telemetry_;
}

}  // namespace firmware::joint_foc
