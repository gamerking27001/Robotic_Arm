// firmware/firmware_demo.cpp
// Spins up six JointFocTask instances (one per joint, each on its own
// >=10 kHz PeriodicTask — §9.3) plus one independent SafetyBoardTask
// (§9.8/§14), all against SimulatedMotorHal plants, and demonstrates:
//   1. A position-mode move on the waist joint tracked by the local
//      position->velocity->current cascade.
//   2. A hardware E-stop press asserting STO on every joint — and each
//      joint's own current-loop task disabling its gate driver *on its next
//      tick*, independent of the safety board's own tick rate or any host
//      involvement (§11.2's "fully functional ... even if the host computer
//      is disconnected").
//   3. Local overtemperature protection tripping a single joint without
//      affecting the others.
#include <cstdio>
#include <thread>
#include <vector>

#include "core/robot_config.hpp"
#include "firmware/common/simulated_motor_hal.hpp"
#include "firmware/joint_foc/joint_foc_task.hpp"
#include "firmware/rtos_port/rtos_port.hpp"
#include "firmware/safety_board/safety_board_task.hpp"

using namespace firmware;
using arm::config::JointId;
using arm::config::kJointSpecs;
using arm::config::kNumJoints;

int main() {
    std::printf("=== Firmware layer demo: per-joint FOC + independent safety board ===\n\n");

    std::vector<std::unique_ptr<hal::SimulatedMotorHal>> plants;
    std::vector<std::unique_ptr<joint_foc::JointFocTask>> joints;
    std::array<rtos::HardwareLine, kNumJoints> sto_lines{};
    std::array<rtos::HardwareLine*, kNumJoints> sto_line_ptrs{};
    rtos::HardwareLine estop_line;

    for (std::size_t i = 0; i < kNumJoints; ++i) {
        const auto id = static_cast<JointId>(i);
        plants.push_back(std::make_unique<hal::SimulatedMotorHal>(kJointSpecs[i]));
        auto cfg = joint_foc::JointFocConfig::fromJointSpec(kJointSpecs[i]);
        joints.push_back(std::make_unique<joint_foc::JointFocTask>(id, *plants.back(), cfg, sto_lines[i]));
        sto_line_ptrs[i] = &sto_lines[i];
    }

    std::array<joint_foc::JointFocTask*, kNumJoints> joint_ptrs{};
    for (std::size_t i = 0; i < kNumJoints; ++i) joint_ptrs[i] = joints[i].get();

    safety_board::SafetyBoardTask safety(estop_line, sto_line_ptrs, joint_ptrs);

    // §9.3: current loop closed locally at >10 kHz -> 20 kHz tick (50us
    // period) gives comfortable margin above the stated minimum.
    std::vector<std::unique_ptr<rtos::PeriodicTask>> joint_tasks;
    for (std::size_t i = 0; i < kNumJoints; ++i) {
        joint_tasks.push_back(std::make_unique<rtos::PeriodicTask>(
            std::string("joint_foc_") + kJointSpecs[i].name.data(), std::chrono::microseconds(50),
            [&, i] { joints[i]->tick(1.0 / 20000.0); }));
    }
    // §14: safety-board monitoring runs at its own independent rate (1 kHz)
    // — deliberately decoupled from the current-loop rate above.
    rtos::PeriodicTask safety_task("safety_board", std::chrono::microseconds(1000), [&] { safety.tick(); });

    for (auto& t : joint_tasks) t->start();
    safety_task.start();

    // Command the waist joint (J1) to a position setpoint; leave the rest at
    // their zero-torque default so their loops just hold station.
    joints[0]->setCommand({joint_foc::ControlMode::kPosition, arm::core::deg2rad(30.0)});

    std::this_thread::sleep_for(std::chrono::milliseconds(300));
    {
        const auto t = joints[0]->telemetry();
        std::printf("[t=0.30s] J1 (Waist) position: %.2f deg (target 30.0 deg), current: %.2f A, temp: %.1f C\n",
                     arm::core::rad2deg(t.position_rad), t.current_a, t.winding_temp_c);
    }

    // --- Hardware E-stop press ---------------------------------------------
    std::printf("\n[event] Hardware E-stop line asserted\n");
    estop_line.set(true);
    std::this_thread::sleep_for(std::chrono::milliseconds(50));  // let both safety board and joint tasks tick
    {
        const auto status = safety.status();
        std::printf("Safety board status: estop_active=%d relay_fault_suspected=%d any_fault=%d\n",
                     status.estop_line_active, status.relay_fault_suspected, status.any_fault);
        for (std::size_t i = 0; i < kNumJoints; ++i) {
            const auto t = joints[i]->telemetry();
            std::printf("  J%zu (%-10s) sto_active(local)=%d  sto_line=%d\n", i + 1, kJointSpecs[i].name.data(),
                         t.sto_active, sto_lines[i].get());
        }
    }

    std::printf("\n[event] Hardware E-stop line released, safety board re-evaluates\n");
    estop_line.set(false);
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
    std::printf("Safety board status: estop_active=%d any_fault=%d\n\n", safety.status().estop_line_active,
                safety.status().any_fault);

    // --- Local overtemperature protection (independent per joint) ----------
    std::printf("[event] Simulating a stalled/overloaded elbow (J3) forcing winding temperature past trip point\n");
    // Force a large sustained load so the plant's I^2R heating model in
    // simulated_motor_hal.hpp drives winding temperature past the trip point.
    plants[2]->setExternalLoadTorqueNm(200.0);
    joints[2]->setCommand({joint_foc::ControlMode::kVelocity, arm::core::deg2rad(120.0)});
    std::this_thread::sleep_for(std::chrono::milliseconds(400));
    {
        const auto t = joints[2]->telemetry();
        std::printf("J3 (Elbow) after sustained overload: temp=%.1fC overtemp_fault=%d sto_active=%d\n",
                     t.winding_temp_c, t.overtemp_fault, t.sto_active);
        const auto t0 = joints[0]->telemetry();
        std::printf("J1 (Waist) unaffected: overtemp_fault=%d sto_active=%d (protection is per-joint)\n",
                     t0.overtemp_fault, t0.sto_active);
    }

    for (auto& t : joint_tasks) {
        std::printf("%-24s ticks=%-8llu worst_jitter=%lldus\n", t->name().c_str(),
                     static_cast<unsigned long long>(t->tickCount()),
                     static_cast<long long>(t->worstCaseJitter().count()));
    }

    for (auto& t : joint_tasks) t->stop();
    safety_task.stop();

    std::printf("\nFirmware demo complete.\n");
    return 0;
}
