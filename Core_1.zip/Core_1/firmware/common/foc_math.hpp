// firmware/common/foc_math.hpp
// Field-Oriented Control math for the per-joint current loop (§9.3, §6.1's
// PMSM/BLDC motor selection). Pure functions, no hardware dependency — this
// is the part of joint_foc that is identical whether it runs on an STM32 or
// on this host simulation.
#pragma once

#include <algorithm>
#include <array>
#include <cmath>

namespace firmware::foc {

constexpr double kSqrt3 = 1.7320508075688772;
constexpr double kOneOverSqrt3 = 0.5773502691896258;
constexpr double kTwoPi = 6.283185307179586;

struct AlphaBeta {
    double alpha = 0.0;
    double beta = 0.0;
};

struct DQ {
    double d = 0.0;
    double q = 0.0;
};

struct ThreePhase {
    double a = 0.0, b = 0.0, c = 0.0;
};

// Clarke transform: three-phase currents -> stationary alpha-beta frame.
// Uses the measured a/b phases (per §7.1's per-phase current sensors) and
// derives c from KCL (ia+ib+ic=0) rather than requiring a third sensor.
[[nodiscard]] inline AlphaBeta clarke(double ia, double ib) {
    return {ia, (ia + 2.0 * ib) * kOneOverSqrt3};
}

// Park transform: stationary alpha-beta -> rotating d-q frame at electrical
// angle theta_e (rad), using the absolute-encoder-derived rotor position
// (§7.1: 17-20 bit absolute encoder, motor-side of every joint).
[[nodiscard]] inline DQ park(const AlphaBeta& ab, double theta_e) {
    const double c = std::cos(theta_e), s = std::sin(theta_e);
    return {ab.alpha * c + ab.beta * s, -ab.alpha * s + ab.beta * c};
}

// Inverse Park: d-q voltage command -> stationary alpha-beta voltage command.
[[nodiscard]] inline AlphaBeta inversePark(const DQ& v_dq, double theta_e) {
    const double c = std::cos(theta_e), s = std::sin(theta_e);
    return {v_dq.d * c - v_dq.q * s, v_dq.d * s + v_dq.q * c};
}

// alpha-beta -> three-phase (inverse Clarke), used both to derive PWM duty
// cycles and by the simulated plant to reconstruct phase voltages.
[[nodiscard]] inline ThreePhase inverseClarke(const AlphaBeta& ab) {
    return {ab.alpha, -0.5 * ab.alpha + (kSqrt3 / 2.0) * ab.beta, -0.5 * ab.alpha - (kSqrt3 / 2.0) * ab.beta};
}

// Sine-triangle PWM with third-harmonic (min-max common-mode) injection —
// a standard, simple approximation of true sector-based SVPWM that extends
// linear modulation range toward the same ~15% higher DC-bus utilization
// without the sector lookup-table complexity. Returns duty cycles in [0, 1].
[[nodiscard]] inline ThreePhase svpwmDuty(const AlphaBeta& v_ab, double v_bus) {
    ThreePhase v = inverseClarke(v_ab);
    const double v_max = std::max({v.a, v.b, v.c});
    const double v_min = std::min({v.a, v.b, v.c});
    const double v_common = 0.5 * (v_max + v_min);  // common-mode (third-harmonic) injection
    v.a -= v_common;
    v.b -= v_common;
    v.c -= v_common;

    const double half_bus = std::max(v_bus * 0.5, 1e-6);
    ThreePhase duty{0.5 + v.a / (2.0 * half_bus), 0.5 + v.b / (2.0 * half_bus), 0.5 + v.c / (2.0 * half_bus)};
    duty.a = std::clamp(duty.a, 0.0, 1.0);
    duty.b = std::clamp(duty.b, 0.0, 1.0);
    duty.c = std::clamp(duty.c, 0.0, 1.0);
    return duty;
}

// Wraps an angle to (-pi, pi] — used to keep the accumulated electrical angle
// bounded across many current-loop ticks.
[[nodiscard]] inline double wrapAngle(double theta) {
    while (theta > M_PI) theta -= kTwoPi;
    while (theta <= -M_PI) theta += kTwoPi;
    return theta;
}

}  // namespace firmware::foc
