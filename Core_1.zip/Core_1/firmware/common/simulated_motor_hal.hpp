// firmware/common/simulated_motor_hal.hpp
// Host-side PMSM dq-frame electrical/mechanical plant model implementing
// MotorHal, standing in for real STM32 ADC/encoder/PWM peripherals so
// joint_foc_task can be exercised without hardware. Electrical parameters
// (resistance, inductance, pole pairs, rotor inertia) are NOT given anywhere
// in the source design document — they're illustrative values derived from
// each joint's §6.2 rated torque/power, clearly separated here so they're
// easy to replace with datasheet values for a specific motor.
#pragma once

#include <algorithm>
#include <chrono>
#include <mutex>

#include "core/robot_config.hpp"
#include "firmware/common/foc_math.hpp"
#include "firmware/common/motor_hal.hpp"

namespace firmware::hal {

struct IllustrativeElectricalParams {
    double phase_resistance_ohm;
    double phase_inductance_h;
    int pole_pairs;
    double torque_constant_nm_per_a;   // motor-side (pre-gearbox) Nm/A; also used as back-EMF constant V/(rad/s)
    double rotor_inertia_kgm2;
    double viscous_friction_nm_per_rads;

    static IllustrativeElectricalParams derive(const arm::config::JointSpec& spec) {
        IllustrativeElectricalParams p{};
        p.pole_pairs = 7;  // common for this motor class — illustrative, not in source doc
        p.phase_resistance_ohm = 8.0 / spec.motor_power_w;                 // crude inverse-power scaling
        p.phase_inductance_h = 0.5e-3;
        const double rated_current_estimate_a = spec.motor_power_w / arm::config::kRobotSpec.bus_voltage_vdc;
        const double motor_side_rated_torque_nm = spec.rated_output_torque_nm / spec.gear_ratio;
        p.torque_constant_nm_per_a = motor_side_rated_torque_nm / std::max(rated_current_estimate_a, 1e-6);
        p.rotor_inertia_kgm2 = 2e-3 * (spec.motor_power_w / 100.0);
        p.viscous_friction_nm_per_rads = 1e-4;
        return p;
    }
};

class SimulatedMotorHal final : public MotorHal {
public:
    explicit SimulatedMotorHal(const arm::config::JointSpec& spec, double bus_voltage_vdc = arm::config::kRobotSpec
                                                                                                  .bus_voltage_vdc)
        : spec_(spec), params_(IllustrativeElectricalParams::derive(spec)), bus_voltage_(bus_voltage_vdc) {
        last_update_ = std::chrono::steady_clock::now();
    }

    PhaseCurrents readPhaseCurrents() override {
        std::lock_guard<std::mutex> lock(mutex_);
        const foc::AlphaBeta i_ab = foc::inversePark({id_, iq_}, theta_e_);
        const foc::ThreePhase i_abc = foc::inverseClarke(i_ab);
        return {i_abc.a, i_abc.b};
    }

    double readElectricalAngleRad() override {
        std::lock_guard<std::mutex> lock(mutex_);
        return theta_e_;
    }

    double readMechanicalVelocityRadS() override {
        std::lock_guard<std::mutex> lock(mutex_);
        return omega_m_;
    }

    double readMechanicalAngleRad() override {
        std::lock_guard<std::mutex> lock(mutex_);
        return theta_m_;
    }

    double readWindingTempC() override {
        std::lock_guard<std::mutex> lock(mutex_);
        return winding_temp_c_;
    }

    void writePwmDuty(double duty_a, double duty_b, [[maybe_unused]] double duty_c) override {
        std::lock_guard<std::mutex> lock(mutex_);
        const auto now = std::chrono::steady_clock::now();
        const double dt = std::chrono::duration<double>(now - last_update_).count();
        last_update_ = now;
        if (dt <= 0.0 || dt > 0.01) return;  // skip degenerate/first-call steps

        if (!gate_enabled_) {
            // §9.5 STO: gate driver disabled, currents/torque decay to zero
            // regardless of commanded duty.
            id_ *= 0.5;
            iq_ *= 0.5;
            integrateMechanics(0.0, dt);
            return;
        }

        // duty -> line-to-"neutral" voltage: 0.5 duty = 0V, 1.0 = +Vbus/2.
        const double va = (duty_a - 0.5) * bus_voltage_;
        const double vb = (duty_b - 0.5) * bus_voltage_;
        const foc::AlphaBeta v_ab = foc::clarke(va, vb);
        const foc::DQ v_dq = foc::park(v_ab, theta_e_);

        const double L = params_.phase_inductance_h;
        const double R = params_.phase_resistance_ohm;
        const double we = theta_e_rate_;

        const double did_dt = (v_dq.d - R * id_ + we * L * iq_) / L;
        const double diq_dt = (v_dq.q - R * iq_ - we * L * id_ - params_.torque_constant_nm_per_a * we) / L;
        id_ += did_dt * dt;
        iq_ += diq_dt * dt;

        const double motor_torque_nm = params_.torque_constant_nm_per_a * iq_;
        integrateMechanics(motor_torque_nm, dt);

        // Coarse thermal model driven by I^2R loss.
        const double copper_loss_w = 1.5 * R * (id_ * id_ + iq_ * iq_);
        const double steady_state_c = 25.0 + copper_loss_w * 0.4;
        winding_temp_c_ += (steady_state_c - winding_temp_c_) * std::min(1.0, dt * 0.5);
    }

    void setGateDriverEnabled(bool enabled) override {
        std::lock_guard<std::mutex> lock(mutex_);
        gate_enabled_ = enabled;
    }

    [[nodiscard]] double busVoltageVdc() const override { return bus_voltage_; }

    // Test/demo hook: apply an external (gearbox-reflected) load torque, e.g.
    // to model payload weight or an injected collision — motor-side units.
    void setExternalLoadTorqueNm(double load_nm) {
        std::lock_guard<std::mutex> lock(mutex_);
        external_load_nm_ = load_nm;
    }

private:
    void integrateMechanics(double motor_torque_nm, double dt) {
        const double net_torque =
            motor_torque_nm - params_.viscous_friction_nm_per_rads * omega_m_ - external_load_nm_;
        const double alpha = net_torque / std::max(params_.rotor_inertia_kgm2, 1e-9);
        omega_m_ += alpha * dt;
        theta_m_ += omega_m_ * dt;
        theta_e_rate_ = omega_m_ * params_.pole_pairs;
        theta_e_ = foc::wrapAngle(theta_m_ * params_.pole_pairs);
    }

    const arm::config::JointSpec& spec_;
    IllustrativeElectricalParams params_;
    double bus_voltage_;

    std::mutex mutex_;
    std::chrono::steady_clock::time_point last_update_;
    bool gate_enabled_ = true;

    double id_ = 0.0, iq_ = 0.0;          // dq-frame currents (A)
    double theta_e_ = 0.0;                 // electrical angle (rad)
    double theta_e_rate_ = 0.0;            // electrical angular rate (rad/s)
    double theta_m_ = 0.0;                 // mechanical angle (rad, motor-side)
    double omega_m_ = 0.0;                 // mechanical angular rate (rad/s, motor-side)
    double winding_temp_c_ = 25.0;
    double external_load_nm_ = 0.0;
};

}  // namespace firmware::hal
