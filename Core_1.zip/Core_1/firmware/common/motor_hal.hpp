// firmware/common/motor_hal.hpp
// The hardware-abstraction seam for joint_foc: on real hardware, an
// implementation of this interface wraps STM32 HAL calls (HAL_ADC_GetValue
// for phase currents, the encoder/SPI-BiSS-C driver for §7.1's absolute
// encoder, HAL_TIM_PWM_Start / CCR register writes for PWM duty cycles).
// SimulatedMotorHal (simulated_motor_hal.hpp) implements this same interface
// against a plant model instead, so joint_foc_task.cpp is byte-for-byte the
// same code whether it's driving real silicon or the host simulation.
#pragma once

namespace firmware::hal {

struct PhaseCurrents {
    double ia = 0.0;
    double ib = 0.0;
};

class MotorHal {
public:
    virtual ~MotorHal() = default;

    // §7.1: per-phase current sensors, ±1% FS, feed the ADC.
    [[nodiscard]] virtual PhaseCurrents readPhaseCurrents() = 0;

    // §7.1: 17-20 bit absolute encoder, motor-side of every joint — returns
    // electrical angle in radians (already pole-pair-scaled from mechanical).
    [[nodiscard]] virtual double readElectricalAngleRad() = 0;

    // §7.1: motor-side mechanical velocity, from the incremental encoder /
    // derivative of the absolute encoder.
    [[nodiscard]] virtual double readMechanicalVelocityRadS() = 0;

    // §7.1: motor-side absolute mechanical angle (unwrapped, power-cycle-safe
    // per the encoder catalogue's "no homing" note), used to close the outer
    // position loop.
    [[nodiscard]] virtual double readMechanicalAngleRad() = 0;

    // §7.1: winding temperature sensor (analog/I2C).
    [[nodiscard]] virtual double readWindingTempC() = 0;

    // §9.3: writes PWM duty cycles [0,1] per phase to the timer compare
    // registers (HAL_TIM_PWM on real hardware).
    virtual void writePwmDuty(double duty_a, double duty_b, double duty_c) = 0;

    // §9.5: Safe Torque Off — on real hardware this immediately disables the
    // gate driver enable line, independent of the PWM timer state.
    virtual void setGateDriverEnabled(bool enabled) = 0;

    [[nodiscard]] virtual double busVoltageVdc() const = 0;
};

}  // namespace firmware::hal
