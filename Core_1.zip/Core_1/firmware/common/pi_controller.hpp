// firmware/common/pi_controller.hpp
// §13.2: "PID: baseline position-loop control at each joint" and §13.2
// feedforward notes. The current loop itself (this file's primary use, per
// §9.3) is conventionally PI (no derivative term, since current has no
// meaningful "jerk" term to damp) with anti-windup clamping — the outer
// position loop in motion_controller-equivalent firmware code reuses the same
// class with different gains.
#pragma once

#include <algorithm>

namespace firmware::control {

struct PIGains {
    double kp = 0.0;
    double ki = 0.0;
};

class PIController {
public:
    PIController(PIGains gains, double output_min, double output_max)
        : gains_(gains), out_min_(output_min), out_max_(output_max) {}

    // dt in seconds. Returns the saturated control output; internally applies
    // back-calculation anti-windup so the integrator doesn't run away while
    // the output is saturated (important for the torque-limited startup /
    // stall cases described implicitly by §6.4's thermal derating).
    double update(double setpoint, double measurement, double dt_s) {
        const double error = setpoint - measurement;
        const double p_term = gains_.kp * error;

        double output_unsat = p_term + integral_;
        double output = std::clamp(output_unsat, out_min_, out_max_);

        // Back-calculation anti-windup: only integrate when not saturated, or
        // when the error would pull the output back into range.
        const bool saturated_high = output_unsat > out_max_;
        const bool saturated_low = output_unsat < out_min_;
        const bool would_reduce_saturation = (saturated_high && error < 0.0) || (saturated_low && error > 0.0);
        if (!saturated_high && !saturated_low) {
            integral_ += gains_.ki * error * dt_s;
        } else if (would_reduce_saturation) {
            integral_ += gains_.ki * error * dt_s;
        }

        output_unsat = p_term + integral_;
        output = std::clamp(output_unsat, out_min_, out_max_);
        return output;
    }

    void reset() { integral_ = 0.0; }
    void setGains(PIGains g) { gains_ = g; }

private:
    PIGains gains_;
    double out_min_, out_max_;
    double integral_ = 0.0;
};

}  // namespace firmware::control
