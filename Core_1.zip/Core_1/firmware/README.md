# firmware/ — per-joint FOC + independent safety board

Implements §9.3 (per-joint FOC current loop), §11.2 (local overcurrent/
overtemperature protection, host-independent operation), §13.2 (cascaded
PID control), and §9.5/§9.8/§14 (independent safety-board firmware) from the
design baseline — as **host-buildable, host-testable C++**, not real STM32
firmware. Read this before assuming any of it runs on actual silicon.

## Build & run

From the project root:

```bash
g++ -std=c++20 -O2 -pthread -I. -Iinclude \
  firmware/joint_foc/joint_foc_task.cpp \
  firmware/safety_board/safety_board_task.cpp \
  firmware/firmware_demo.cpp \
  -o firmware_demo
./firmware_demo
```

Or via the top-level CMake build (`cmake --build .` after configuring),
which produces a `firmware_demo` target alongside `arm_demo`.

## What `firmware_demo` demonstrates

- Six `JointFocTask` instances, each on its own real OS thread ticking at
  20 kHz (`rtos::PeriodicTask`, §9.3's ">10 kHz" current loop), each closing
  a position → velocity → current cascade locally per §9.3/§13.2.
- A `SafetyBoardTask` on a separate 1 kHz thread, with **no code dependency**
  on the joint tasks' internals — it only reads a telemetry snapshot and
  writes hardware-line outputs, mirroring the doc's stated electrical/logical
  isolation (§9.8: "a firmware fault cannot defeat the safety function").
- A hardware E-stop press asserting STO on all six joints, and each joint's
  *own* current-loop task disabling its own gate driver on its own next tick
  — not routed through the safety board or any host process, matching
  §11.2's "remaining fully functional (including STO response) even if the
  host computer is disconnected."
- Local per-joint overtemperature protection: an overloaded elbow (J3) trips
  and asserts its own STO without touching the other five joints.

## What's real vs. simulated here

| Piece | Status |
|---|---|
| Task/ISR partitioning (current-loop task, safety-board task, their independence) | Faithful to §9/§11/§14's architecture |
| Clarke/Park/inverse-Park transforms, SVPWM duty calculation | Standard FOC math, correct |
| PI current/velocity loops with anti-windup, cascaded position→velocity→torque→current | Real control-theory implementation |
| STO / E-stop propagation semantics (hardware line, independent of host) | Faithful to §9.5 |
| **RTOS** (`firmware/rtos_port/rtos_port.hpp`) | **Not FreeRTOS.** A ~150-line host shim (std::thread + sleep_until) that mirrors the small slice of the FreeRTOS API this code needs, documented in the header. No ARM cross-compiler or FreeRTOS kernel was available to build against in this environment. |
| **Motor electrical parameters** (resistance, inductance, torque constant, rotor inertia) | Illustrative, derived from each joint's §6.2 rated torque/power — not from a motor datasheet. Clearly isolated in `IllustrativeElectricalParams::derive()`. |
| **HAL** (`firmware/common/motor_hal.hpp`) | A real abstract interface with a simulated (not STM32 HAL) implementation. Swapping in real ADC/timer/encoder calls means implementing this same interface — `joint_foc_task.cpp` itself would not need to change. |
| Achieved loop-rate jitter printed at the end of the demo | Reflects this **container's** thread scheduling, not a real-time guarantee — six software threads contending for CPU here is a very different environment from a dedicated STM32 core running the real current loop in an ISR. Don't read those numbers as representative of real hardware timing. |

## Porting to real hardware

1. Implement `firmware::hal::MotorHal` against real STM32 HAL calls (ADC DMA
   for phase currents, the BiSS-C/SPI absolute-encoder driver, `HAL_TIM_PWM`
   for duty cycles, a GPIO for the gate-driver enable line).
2. Replace `firmware/rtos_port/rtos_port.hpp` with real FreeRTOS
   (`xTaskCreate`, `vTaskDelayUntil`, a real `xQueueCreate`-backed queue) —
   `joint_foc_task.cpp` and `safety_board_task.cpp` don't reference the shim
   directly (only `PeriodicTask`/`HardwareLine`/`Queue`), so this is a
   contained swap.
3. Replace the illustrative electrical parameters with your motor's
   datasheet values.
4. `platformio.ini` in this directory sketches the real build target
   (STM32H7, FreeRTOS framework) per §19.1 — it is **not** buildable here
   (no ARM toolchain / STM32Cube framework available in this environment)
   but shows the intended project shape for when you build on real hardware.
