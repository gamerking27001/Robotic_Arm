// firmware/safety_board/safety_board_task.hpp
// §9.8: "a Safety Board implementing the E-stop/STO logic independently of
// the main controller's firmware, so a firmware fault cannot defeat the
// safety function."
// §9.5: dual-channel hardwired E-stop (bypasses firmware entirely, cuts motor
// bus power via a safety relay), per-joint dual-channel STO (IEC 61800-5-2),
// force-guided (mechanically-linked) relays so contact-welding failure is
// detectable (category 3 architecture, §14.3/ISO 10218-1/-2).
//
// This task deliberately has NO dependency on JointFocTask, MotionController,
// or any main-controller state — it only reads hardware-line inputs and
// per-joint telemetry snapshots, and writes hardware-line outputs (the STO
// lines each JointFocTask polls independently every current-loop tick). That
// mirrors the real electrical/logical isolation: a firmware fault in
// joint_foc cannot defeat this task, and this task's own logic never touches
// joint_foc's internal state.
#pragma once

#include <array>

#include "core/robot_config.hpp"
#include "firmware/joint_foc/joint_foc_task.hpp"
#include "firmware/rtos_port/rtos_port.hpp"

namespace firmware::safety_board {

namespace config = arm::config;

// §14.2 "Force-GuidedSafetyRelay": a real force-guided relay exposes a
// normally-closed monitor contact wired so that if the main contact welds
// shut, the monitor contact can't also read closed — a contact-welding
// failure becomes electrically detectable. This struct is the software
// model of that: `commanded_open` is what the safety board is telling the
// relay to do; `monitor_contact_confirms_open` is the independent feedback
// path. A mismatch after the settling time is a "welded contact" fault.
struct RelayState {
    bool commanded_open = false;
    bool monitor_contact_confirms_open = false;
};

struct SafetyBoardStatus {
    bool estop_line_active = false;
    bool relay_fault_suspected = false;   // §14.2 force-guided contact-welding check
    std::array<bool, config::kNumJoints> sto_asserted{};
    std::array<bool, config::kNumJoints> joint_overtemp{};
    std::array<bool, config::kNumJoints> joint_overcurrent{};
    bool any_fault = false;
};

class SafetyBoardTask {
public:
    SafetyBoardTask(rtos::HardwareLine& estop_input,
                     std::array<rtos::HardwareLine*, config::kNumJoints> sto_outputs,
                     std::array<joint_foc::JointFocTask*, config::kNumJoints> joints);

    // Runs one safety-evaluation cycle (§14: independent periodic monitoring,
    // not tied to the main controller's loop rate). Call from its own
    // PeriodicTask — see firmware_demo.cpp.
    void tick();

    [[nodiscard]] SafetyBoardStatus status() const;

private:
    rtos::HardwareLine& estop_input_;
    std::array<rtos::HardwareLine*, config::kNumJoints> sto_outputs_;
    std::array<joint_foc::JointFocTask*, config::kNumJoints> joints_;
    RelayState relay_{};
    SafetyBoardStatus last_status_{};
};

}  // namespace firmware::safety_board
