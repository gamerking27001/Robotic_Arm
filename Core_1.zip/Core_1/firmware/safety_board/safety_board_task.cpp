#include "firmware/safety_board/safety_board_task.hpp"

namespace firmware::safety_board {

SafetyBoardTask::SafetyBoardTask(rtos::HardwareLine& estop_input,
                                  std::array<rtos::HardwareLine*, config::kNumJoints> sto_outputs,
                                  std::array<joint_foc::JointFocTask*, config::kNumJoints> joints)
    : estop_input_(estop_input), sto_outputs_(sto_outputs), joints_(joints) {}

void SafetyBoardTask::tick() {
    SafetyBoardStatus status{};
    status.estop_line_active = estop_input_.get();

    // §9.5 Emergency Stop: dual-channel hardwired loop, directly cuts motor
    // bus power via a safety relay, independent of the main controller's
    // firmware state. Modeled here as: E-stop active -> command every STO
    // line active, unconditionally.
    relay_.commanded_open = status.estop_line_active;
    // Force-guided monitor contact: in this software model it always tracks
    // the command faithfully (no fault injected) — a real relay's monitor
    // contact could disagree if the main contact welded shut, which is what
    // relay_fault_suspected would catch.
    relay_.monitor_contact_confirms_open = relay_.commanded_open;
    status.relay_fault_suspected = (relay_.commanded_open != relay_.monitor_contact_confirms_open);

    for (std::size_t i = 0; i < config::kNumJoints; ++i) {
        const bool estop_forces_sto = status.estop_line_active || status.relay_fault_suspected;

        const joint_foc::TelemetryReport t = joints_[i]->telemetry();
        status.joint_overtemp[i] = t.overtemp_fault;
        status.joint_overcurrent[i] = t.overcurrent_fault;

        // §14.1 STO per joint: independent per-joint dual-channel STO,
        // asserted by E-stop, a suspected relay fault, or that joint's own
        // local overcurrent/overtemperature condition (§9.5/§14.1).
        const bool sto = estop_forces_sto || t.overtemp_fault || t.overcurrent_fault;
        sto_outputs_[i]->set(sto);
        status.sto_asserted[i] = sto;
    }

    status.any_fault = status.estop_line_active || status.relay_fault_suspected;
    for (std::size_t i = 0; i < config::kNumJoints; ++i) {
        status.any_fault = status.any_fault || status.joint_overtemp[i] || status.joint_overcurrent[i];
    }

    last_status_ = status;
}

SafetyBoardStatus SafetyBoardTask::status() const { return last_status_; }

}  // namespace firmware::safety_board
