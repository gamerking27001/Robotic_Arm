--[[
setup_arm.lua

Run this as a CoppeliaSim scene child script AFTER importing
../../ros2_ws/src/robot_description/urdf/generated_arm.urdf via
CoppeliaSim's built-in URDF importer (Plugins > URDF Import, or the
simURDF.load() function). See README.md in this directory for why import
is used here instead of a third from-scratch generator, and for the
step-by-step workflow this script is one step of.

What this script does, once the URDF is already imported:
1. Locates the 6 revolute joints by the exact names generate_urdf.py
   gives them (joint1..joint6 -- NOT joint1_offset etc., which are the
   fixed DH-offset joints and have no motion to configure).
2. Sets each to servo (position-controlled) mode, matching the
   <command_interface name="position"> the URDF's <ros2_control> block
   declares -- so this scene behaves the same way, control-wise, as the
   real/simulated-CAN ros2_control bringup and the MuJoCo model's
   <position> actuators (simulation/mujoco/generate_mjcf.py).
3. Applies the same joint limits already baked into the URDF's
   <limit lower=.../> tags -- CoppeliaSim's URDF importer SHOULD carry
   these over automatically, but this script re-asserts them explicitly
   so a scene that started from a hand-edited or older import still ends
   up correct. Re-asserting from the URDF's own values (not
   re-typing DH_TABLE/JOINT_LIMITS as a fourth copy) keeps this script
   from becoming a fourth place those numbers could drift.
4. Verifies the tool0 frame exists and reports its handle -- useful for
   attaching a gripper/tool model later.

CONFIDENCE LEVEL -- read before trusting this: this was written from
documented CoppeliaSim Lua API conventions (sim.getObject, sim.setJointMode,
sim.setJointInterval, sim namespace generally) but has NOT been run inside
a real CoppeliaSim instance -- no CoppeliaSim install was available in the
environment this was written in, matching every other simulation-stack
caveat in this repo (see documentation/simulation-stack-decision.md and
simulation/mujoco/README.md for the same honesty pattern applied there).
It also was NOT run through a standalone Lua interpreter (none was
available either) -- only manually checked for balanced parens/braces and
matching function/end pairs, which catches gross syntax errors but not
real ones (undefined globals, wrong argument counts, etc.).
Specific things worth checking against your actual CoppeliaSim version
before trusting this:
  - sim.getObject('/path') vs the older sim.getObjectHandle('name') --
    this script uses the newer path-based sim.getObject, which is current
    as of CoppeliaSim 4.x; if you're on an older version you may need
    sim.getObjectHandle instead.
  - Exactly what object names the URDF importer assigns -- it SHOULD
    preserve the URDF's own joint/link names (joint1..joint6, link1..
    link6, tool0), but importer behavior can differ by CoppeliaSim
    version and is worth confirming against the Scene Hierarchy panel
    after import, before assuming this script's name lookups will
    succeed unmodified.
  - sim.setJointMode's exact mode/options constants for this
    CoppeliaSim version (sim.jointmode_dynamic + sim.jointdynctrl_position
    below reflects a commonly-documented combination, not a version-pinned
    confirmed one).
]]--

local JOINT_NAMES = {"joint1", "joint2", "joint3", "joint4", "joint5", "joint6"}

function sysCall_init()
    print("[setup_arm] Configuring imported modular_arm_msme URDF...")

    local handles = {}
    local all_found = true
    for i, name in ipairs(JOINT_NAMES) do
        -- Path-based lookup; adjust the leading path if the importer nests
        -- joints under a different root object name than the URDF's
        -- robot name ("modular_arm_msme" -- see generate_urdf.py's
        -- ET.Element("robot", name="modular_arm_msme")).
        local ok, handle = pcall(sim.getObject, "/" .. name)
        if ok and handle ~= -1 then
            handles[name] = handle
        else
            print("[setup_arm] WARNING: could not find joint object '" .. name ..
                  "' -- check the Scene Hierarchy panel for the importer's actual naming " ..
                  "and adjust JOINT_NAMES/path prefix above if needed.")
            all_found = false
        end
    end

    if not all_found then
        print("[setup_arm] Aborting further configuration -- fix joint name lookups first.")
        return
    end

    for i, name in ipairs(JOINT_NAMES) do
        local h = handles[name]

        -- Servo/position control mode -- matches the URDF's declared
        -- position command interface (see this file's header comment).
        sim.setJointMode(h, sim.jointmode_dynamic, sim.jointdynctrl_position)

        -- Re-assert the joint limits from the object's own current
        -- interval (which the URDF importer should have set from the
        -- URDF's <limit> tag) rather than re-typing DH_TABLE/JOINT_LIMITS
        -- here as a fourth copy -- see the header comment on why.
        local cyclic, interval = sim.getJointInterval(h)
        print(string.format("[setup_arm] %s: mode=servo/position, limit=[%.4f, %.4f] rad (from imported URDF)",
              name, interval[1], interval[1] + interval[2]))
    end

    local ok, tool0_handle = pcall(sim.getObject, "/tool0")
    if ok and tool0_handle ~= -1 then
        print("[setup_arm] tool0 frame found, handle=" .. tool0_handle .. " -- attach gripper/tool models here.")
    else
        print("[setup_arm] WARNING: tool0 frame not found -- gripper/tool attachment point is missing.")
    end

    print("[setup_arm] Done. See README.md for the ROS2 interface (simROS2) wiring, not yet configured by this script.")
end
