# simulation/coppeliasim

## Approach: import the canonical URDF, don't regenerate the robot a third time

Unlike `simulation/mujoco/generate_mjcf.py`, this directory does **not**
contain a from-scratch CoppeliaSim scene generator. Instead:

1. Import `../../ros2_ws/src/robot_description/urdf/generated_arm.urdf`
   directly using CoppeliaSim's built-in URDF importer (Plugins → URDF
   Import in the CoppeliaSim UI, or the `simURDF.load()` API call).
2. Run `setup_arm.lua` (as a scene child script) to configure joint
   control modes and verify the import.

**Why import instead of a third generator:** `generate_urdf.py` and
`generate_mjcf.py` both read `DH_TABLE`/`JOINT_LIMITS` from their own
copies of the same numbers — already a flagged, real drift risk between
two files (`simulation/mujoco/README.md`'s "Known gap"). Writing a third
independent CoppeliaSim generator with a third copy of those tables would
make that risk worse, not better. Importing the URDF CoppeliaSim's own
importer already supports means CoppeliaSim's geometry is derived from
the exact same file the ROS2 stack uses — kinematic consistency by
construction, not by cross-checking three generators against each other
after the fact.

## Step-by-step workflow

1. Regenerate the URDF if it's stale: `python3
   ../../ros2_ws/src/robot_description/scripts/generate_urdf.py`
2. Open CoppeliaSim, use the URDF importer to load
   `../../ros2_ws/src/robot_description/urdf/generated_arm.urdf`.
3. Confirm in the Scene Hierarchy panel that the imported joints are
   named `joint1`–`joint6` (matching the URDF) — importer naming
   behavior can vary by CoppeliaSim version; see `setup_arm.lua`'s header
   comment if they don't match.
4. Attach `setup_arm.lua` as a scene child script and run it (or trigger
   `sysCall_init` by starting the simulation) — it sets each joint to
   servo/position control mode and confirms the `tool0` frame exists.

## The Mac-side gRPC server exists now — `coppeliasim_sim_server.py`

Closes the same gap MuJoCo's `../mujoco/mac_sim_server.py` closes, for
CoppeliaSim: an implementation of
`../../documentation/bridge_proto/sim_hardware.proto`'s
`SimulationHardwareService`. The key structural difference from the
MuJoCo version: CoppeliaSim is always a separate, already-running
application (GUI or headless) that this script connects to as an
EXTERNAL CLIENT via CoppeliaSim's ZMQ Remote API — it doesn't embed
physics directly the way MuJoCo's Python bindings let `mac_sim_server.py`
do. You start CoppeliaSim, import the URDF, run `setup_arm.lua`, and
start the simulation yourself before running this script — see the
Step-by-step workflow above.

**Compounded confidence caveat, worse than MuJoCo's:** everything
`../mujoco/README.md` says about `mac_sim_server.py` being the least
independently-checkable file in the project applies here too, plus one
more layer — CoppeliaSim's remote API has changed more across major
versions historically than MuJoCo's Python bindings have, so the exact
function signatures used here (`sim.setJointTargetPosition`,
`sim.getJointForce`, `client.setStepping`/`client.step`) are the single
most likely thing in this entire simulation stack to need correction
against your actual installed CoppeliaSim version. See the file's own
docstring for the full framing.

## Open architectural question — resolved (see the bridge architecture doc)

This directory gets CoppeliaSim's **geometry** right (imported from the
canonical URDF). How CoppeliaSim talks to ROS2 over the network was left
open here on purpose, and is now resolved in
`../../documentation/mac-ubuntu-bridge-architecture.md` §6: CoppeliaSim
(and MuJoCo) connect via a new `sim_network_hardware_interface`
`ros2_control` plugin running in the VM, proxying `read()`/`write()` over
a gRPC stream (`documentation/bridge_proto/sim_hardware.proto`) — the
same role `robot_hardware_interface` already plays against the simulated
CAN bus, just reached over the network instead of in-process. **Not yet
built** — the architecture decision is made, the plugin and the Mac-side
gRPC server it talks to are still to-do.

## Confidence level

Same honesty pattern as the rest of this project's simulation work: none
of this has been run against a real CoppeliaSim install (not available
in the environment this was written in). `setup_arm.lua`'s header
comment lists the specific API assumptions (path-based `sim.getObject`,
`sim.setJointMode` constants) most likely to need correction against
your actual CoppeliaSim version — check the Scene Hierarchy panel after
import before assuming the script's name lookups will succeed unmodified.
