#!/usr/bin/env python3
"""coppeliasim_sim_server.py

Runs ON THE MAC alongside a running CoppeliaSim instance (with the URDF
already imported and setup_arm.lua already run — see this directory's
README's "Step-by-step workflow"). Implements the same
../../documentation/bridge_proto/sim_hardware.proto SimulationHardwareService
server that simulation/mujoco/mac_sim_server.py implements for MuJoCo —
see that file's docstring for the shared design rationale
(SimulationHardwareService, the confidence-level framing, why current_a/
winding_temp_c are honestly zeroed rather than fabricated). This file
covers what's different about CoppeliaSim specifically.

KEY DIFFERENCE FROM mac_sim_server.py: MuJoCo is a physics library this
process embeds directly (mujoco.MjModel/MjData, no separate MuJoCo
process). CoppeliaSim is the opposite — it's always a separate, already-
running GUI (or headless) application, and this script is an EXTERNAL
CLIENT connecting to it over CoppeliaSim's ZMQ Remote API
(the `coppeliasim-zmqremoteapi-client` package, CoppeliaSim 4.x's
current/modern remote API — NOT the legacy b0-based remote API some
older CoppeliaSim tutorials still reference). You must start CoppeliaSim
yourself, with the scene already set up, before running this script.

Setup (on the Mac):
    pip install coppeliasim-zmqremoteapi-client grpcio grpcio-tools
    python3 -m grpc_tools.protoc \
        -I ../../documentation/bridge_proto \
        --python_out=. --grpc_python_out=. \
        ../../documentation/bridge_proto/sim_hardware.proto
    # 1. Start CoppeliaSim
    # 2. Import ../../ros2_ws/src/robot_description/urdf/generated_arm.urdf
    #    via the URDF import plugin (see README.md)
    # 3. Attach and run setup_arm.lua
    # 4. Start the simulation (Play button, or sim.startSimulation() via
    #    the API) -- this script assumes a simulation is already running,
    #    it does not start one itself, since whether to auto-start is a
    #    workflow choice worth making explicitly rather than silently
    #    doing it for you (see "What this doesn't do yet" below).
    python3 coppeliasim_sim_server.py

The generated sim_hardware_pb2*.py files are not checked into this repo
-- same reasoning as mac_sim_server.py's identical note.

CONFIDENCE LEVEL: same "least independently-checkable" caveat as
mac_sim_server.py, compounded further -- this was written against
documented ZMQ Remote API conventions (sim.getObject, sim.setJointTargetPosition,
sim.getJointPosition, sim.getJointVelocity, sim.getJointForce,
client.setStepping/client.step) but there was no CoppeliaSim install, no
network to get one or the zmqremoteapi client package, and (unlike
MuJoCo, which is at least a well-documented, stable Python API this
model has broad familiarity with) CoppeliaSim's remote API has changed
significantly across major versions historically -- treat the exact
function names/signatures below as the single most likely thing to need
correction on a real CoppeliaSim install, more so than anything else in
this project's simulation stack.
"""
import sys
import time
from concurrent import futures

import grpc

try:
    from coppeliasim_zmqremoteapi_client import RemoteAPIClient
except ImportError:
    print(
        "coppeliasim-zmqremoteapi-client not installed -- pip install coppeliasim-zmqremoteapi-client",
        file=sys.stderr,
    )
    raise

try:
    import sim_hardware_pb2
    import sim_hardware_pb2_grpc
except ImportError:
    print(
        "sim_hardware_pb2*.py not found -- generate them first (see this file's docstring's Setup section)",
        file=sys.stderr,
    )
    raise

NUM_JOINTS = 6
JOINT_NAMES = ["joint1", "joint2", "joint3", "joint4", "joint5", "joint6"]  # matches generate_urdf.py's naming
CONTROL_PERIOD_S = 0.01  # 100 Hz, matching controllers.yaml's update_rate -- see stepping note below


class SimulationHardwareServicer(sim_hardware_pb2_grpc.SimulationHardwareServiceServicer):
    def __init__(self):
        self.client = RemoteAPIClient()
        self.sim = self.client.getObject("sim")

        self.joint_handles = []
        for name in JOINT_NAMES:
            try:
                handle = self.sim.getObject("/" + name)
            except Exception as e:
                raise RuntimeError(
                    f"Could not find joint object '/{name}' in the running CoppeliaSim scene -- "
                    f"has the URDF been imported and does the importer's naming match? "
                    f"See README.md and setup_arm.lua's header comment. Original error: {e}"
                )
            self.joint_handles.append(handle)
        print(f"[coppeliasim_sim_server] Found all {NUM_JOINTS} joint objects in the running scene")

        # Stepping mode: this script explicitly advances the simulation
        # one step per control cycle (client.step()), rather than letting
        # CoppeliaSim run freely and just sampling state whenever a
        # JointCommand arrives -- keeps simulation time synchronized with
        # the 100Hz control period instead of drifting against wall-clock
        # time, the same determinism reasoning mac_sim_server.py's
        # SUBSTEPS_PER_CYCLE stepping gets from MuJoCo's mj_step() loop.
        self.client.setStepping(True)

    def StreamJoints(self, request_iterator, context):
        print("[coppeliasim_sim_server] Client connected, starting stream")
        for command in request_iterator:
            positions = list(command.position_setpoint_rad)
            if len(positions) != NUM_JOINTS:
                context.set_code(grpc.StatusCode.INVALID_ARGUMENT)
                context.set_details(f"Expected {NUM_JOINTS} position setpoints, got {len(positions)}")
                return

            for handle, pos in zip(self.joint_handles, positions):
                self.sim.setJointTargetPosition(handle, pos)

            self.client.step()  # advance CoppeliaSim by exactly one simulation step

            state = sim_hardware_pb2.JointState()
            state.cycle_sequence = command.cycle_sequence

            for handle in self.joint_handles:
                position_rad = self.sim.getJointPosition(handle)
                velocity_rad_s = self.sim.getJointVelocity(handle)
                # sim.getJointForce() returns the joint's force/torque
                # for a revolute joint in dynamic mode -- a genuinely
                # simulated quantity, same "real, not fabricated" bar
                # mac_sim_server.py's qfrc_actuator reporting holds to.
                torque_nm = self.sim.getJointForce(handle)

                diverged = position_rad != position_rad or velocity_rad_s != velocity_rad_s  # NaN check

                per_joint = state.joints.add()
                per_joint.position_rad = position_rad
                per_joint.velocity_rad_s = velocity_rad_s
                per_joint.torque_estimate_nm = torque_nm
                # current_a, winding_temp_c: honestly zeroed, same
                # reasoning as mac_sim_server.py -- CoppeliaSim's rigid-
                # body dynamics don't model motor electrical/thermal
                # behavior any more than MuJoCo's do.
                per_joint.current_a = 0.0
                per_joint.winding_temp_c = 0.0
                per_joint.sto_active = False
                per_joint.fault = diverged

            yield state

        print("[coppeliasim_sim_server] Client disconnected")


def main():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=50053)  # distinct from mac_sim_server.py's 50052 --
    # run only one of the two servers at a time against a given
    # sim_network_hardware_interface instance; the port numbers don't
    # need to differ for that reason alone, but keeping them distinct
    # avoids a confusing accidental collision if both happen to be
    # running on the same Mac during development.
    args = parser.parse_args()

    server = grpc.server(futures.ThreadPoolExecutor(max_workers=4))
    sim_hardware_pb2_grpc.add_SimulationHardwareServiceServicer_to_server(SimulationHardwareServicer(), server)
    address = f"0.0.0.0:{args.port}"
    server.add_insecure_port(address)  # see mac_sim_server.py's identical flagged TLS gap
    server.start()
    print(f"[coppeliasim_sim_server] Listening on {address}")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        server.stop(grace=2)


if __name__ == "__main__":
    main()
