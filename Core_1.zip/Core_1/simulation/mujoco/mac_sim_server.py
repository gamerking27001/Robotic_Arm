#!/usr/bin/env python3
"""mac_sim_server.py

Runs ON THE MAC (per the fixed dev environment requirement — this is not
meant to run inside the Ubuntu VM). Implements the SERVER side of
../../documentation/bridge_proto/sim_hardware.proto's
SimulationHardwareService — the counterpart to
../../ros2_ws/src/sim_network_hardware_interface's gRPC CLIENT running in
the VM. See that package's README and
../../documentation/mac-ubuntu-bridge-architecture.md §6 for the full
picture; this file is what makes "the Mac-side simulator" concrete rather
than a design placeholder.

What this does each StreamJoints cycle:
1. Receive a JointCommand (position setpoints, one per joint).
2. Write those into the MJCF's <position> actuators (generate_mjcf.py
   already sets these up with ctrlrange matching each joint's limits).
3. Step the MuJoCo simulation forward by one control period (5 physics
   substeps at the MJCF's 0.002s timestep = 0.01s = one 100Hz cycle,
   matching ros2_ws/src/robot_bringup/config/controllers.yaml's
   update_rate -- see the timestep note below).
4. Read back qpos/qvel/qfrc_actuator and send a JointState.

Setup (on the Mac):
    pip install mujoco grpcio grpcio-tools
    python3 -m grpc_tools.protoc \
        -I ../../documentation/bridge_proto \
        --python_out=. --grpc_python_out=. \
        ../../documentation/bridge_proto/sim_hardware.proto
    python3 generate_mjcf.py   # if generated_arm.xml doesn't exist yet
    python3 mac_sim_server.py

The two lines that `protoc`/`grpc_tools` generate (sim_hardware_pb2.py,
sim_hardware_pb2_grpc.py) are NOT checked into this repo -- they're
regenerable build artifacts from the one canonical .proto source, same
"don't duplicate the source of truth" reasoning as generate_mjcf.py's own
"Known gap" note about DH_TABLE. Run the protoc command above before
`import`ing this file's dependencies will resolve.

CONFIDENCE LEVEL -- read before trusting this: written against
documented mujoco (Python bindings) and grpc (Python sync bidi-streaming
server) API conventions, but NEVER RUN. No Mac, no MuJoCo install, no
grpc/grpcio-tools, and no network to install any of them were available
in the environment this was written in -- this is, honestly, the least
independently-checkable file in the whole project (everything else at
least got XML/YAML validation, balanced-brace checks, or a real g++/
python3 compile; this file got a careful read-through and nothing else).
Specific things most likely to need a fix on first real run:
  - mujoco's exact qpos/qvel/qfrc_actuator indexing for a chain of hinge
    joints each with 1 DOF -- this assumes joint i's qpos/qvel/qfrc_actuator
    index equals its position in the kinematic chain (0-indexed), which
    is the normal case for a simple serial chain of 1-DOF hinges with no
    free joints or multi-DOF joints anywhere in the tree, but worth
    confirming against `model.joint(i).qposadr` directly rather than
    assuming the naive index once this actually runs.
  - Whether grpc's synchronous Python server handles a single long-lived
    bidi-streaming RPC the way assumed here (one call, one thread, for
    the connection's lifetime) without additional server threading
    configuration (max_workers, etc.) -- the ThreadPoolExecutor sizing
    below is a reasonable-looking default, not a confirmed-correct one.
"""
import sys
import time
from concurrent import futures

import grpc
import mujoco

try:
    import sim_hardware_pb2
    import sim_hardware_pb2_grpc
except ImportError:
    print(
        "sim_hardware_pb2*.py not found -- generate them first:\n"
        "  python3 -m grpc_tools.protoc -I ../../documentation/bridge_proto "
        "--python_out=. --grpc_python_out=. ../../documentation/bridge_proto/sim_hardware.proto",
        file=sys.stderr,
    )
    raise

NUM_JOINTS = 6
CONTROL_PERIOD_S = 0.01  # 100 Hz, matching controllers.yaml's update_rate
MJCF_TIMESTEP_S = 0.002  # matches generate_mjcf.py's <option timestep="0.002">
SUBSTEPS_PER_CYCLE = round(CONTROL_PERIOD_S / MJCF_TIMESTEP_S)  # 5


class SimulationHardwareServicer(sim_hardware_pb2_grpc.SimulationHardwareServiceServicer):
    def __init__(self, mjcf_path: str):
        self.model = mujoco.MjModel.from_xml_path(mjcf_path)
        self.data = mujoco.MjData(self.model)
        print(f"[mac_sim_server] Loaded {mjcf_path}: {self.model.nbody} bodies, {self.model.njnt} joints")
        if self.model.njnt < NUM_JOINTS:
            # Fails loudly rather than silently truncating/padding -- a
            # mismatch here means the MJCF and this server disagree about
            # the robot, which should never happen given both trace back
            # to the same canonical source (generate_mjcf.py), but
            # checking explicitly is cheap and catches a stale
            # generated_arm.xml immediately instead of producing
            # confusing downstream errors.
            raise RuntimeError(
                f"Expected at least {NUM_JOINTS} joints in the MJCF, found {self.model.njnt} -- "
                f"is generated_arm.xml stale? Re-run generate_mjcf.py."
            )

    def StreamJoints(self, request_iterator, context):
        print("[mac_sim_server] Client connected, starting stream")
        for command in request_iterator:
            positions = list(command.position_setpoint_rad)
            if len(positions) != NUM_JOINTS:
                context.set_code(grpc.StatusCode.INVALID_ARGUMENT)
                context.set_details(f"Expected {NUM_JOINTS} position setpoints, got {len(positions)}")
                return

            # Write to the <position> actuators generate_mjcf.py set up
            # (ctrl indices match actuator declaration order, which
            # matches joint declaration order -- both come from the same
            # zip(DH_TABLE, JOINT_LIMITS, JOINT_NAMES) loop).
            for i, pos in enumerate(positions):
                self.data.ctrl[i] = pos

            for _ in range(SUBSTEPS_PER_CYCLE):
                mujoco.mj_step(self.model, self.data)

            state = sim_hardware_pb2.JointState()
            state.cycle_sequence = command.cycle_sequence

            diverged = False
            for i in range(NUM_JOINTS):
                joint = self.model.joint(i)
                qpos_addr = joint.qposadr[0]
                qvel_addr = joint.qveladr[0]
                position_rad = float(self.data.qpos[qpos_addr])
                velocity_rad_s = float(self.data.qvel[qvel_addr])

                # NaN/Inf check -- a diverged MuJoCo simulation (bad
                # gains, an exploding contact, etc.) produces exactly
                # this, and reporting it as a fault (rather than sending
                # garbage numbers as if they were valid telemetry) is
                # what lets sim_network_hardware_interface's safety FSM
                # actually catch it, per that package's stale/fault
                # handling design.
                if position_rad != position_rad or velocity_rad_s != velocity_rad_s:  # NaN check (x != x iff NaN)
                    diverged = True

                per_joint = state.joints.add()
                per_joint.position_rad = position_rad
                per_joint.velocity_rad_s = velocity_rad_s
                # current_a, winding_temp_c: MuJoCo doesn't simulate motor
                # electrical/thermal behavior -- honestly zero rather than
                # a fabricated plausible-looking number. A real
                # implementation wanting these would need a separate
                # electrical/thermal model layered on top, not something
                # MuJoCo's rigid-body physics gives you for free.
                per_joint.current_a = 0.0
                per_joint.winding_temp_c = 0.0
                # qfrc_actuator IS a real simulated quantity (the force/
                # torque the position actuator is applying at this DOF),
                # unlike the two placeholders above.
                per_joint.torque_estimate_nm = float(self.data.qfrc_actuator[qvel_addr])
                per_joint.sto_active = False  # no STO concept in pure MuJoCo sim -- see module docstring
                per_joint.fault = diverged

            yield state

        print("[mac_sim_server] Client disconnected")


def main():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--mjcf", default="generated_arm.xml")
    parser.add_argument("--port", type=int, default=50052)  # matches sim_network_hardware_interface's convention
    args = parser.parse_args()

    server = grpc.server(futures.ThreadPoolExecutor(max_workers=4))
    sim_hardware_pb2_grpc.add_SimulationHardwareServiceServicer_to_server(
        SimulationHardwareServicer(args.mjcf), server
    )
    address = f"0.0.0.0:{args.port}"
    server.add_insecure_port(address)  # see sim_network_hardware_interface/README.md's flagged TLS gap -- same here
    server.start()
    print(f"[mac_sim_server] Listening on {address}")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        server.stop(grace=2)


if __name__ == "__main__":
    main()
