#!/usr/bin/env python3
"""generate_mjcf.py

Generates mujoco/generated_arm.xml (MJCF) from the exact same DH-parameter
and joint-limit constants as
../../ros2_ws/src/robot_description/scripts/generate_urdf.py — which is
itself sourced from ../../configs/arm_variant_standard.yaml and
../../include/core/robot_config.hpp (design-baseline.md §4.3/§20.5).

This is the second representation generated from that one canonical
source (URDF was the first) — see documentation/simulation-stack-decision.md
for why MuJoCo exists here at all (it replaces the Gazebo integration that
was removed) and ONE CANONICAL ROBOT ties every representation in this
repo (§ "MOST IMPORTANT REQUIREMENT" of the mega-prompt this project was
scoped against) back to the same numbers. DH_TABLE/JOINT_LIMITS are now
imported from ../../tools/robot_params.py — the single shared source
generate_urdf.py, this file, and cad/freecad/generate_arm_cad.py all
import from, closing what used to be flagged here as a "Known gap"
(three separate copy-pasted copies, before this consolidation).

DH -> MJCF conversion note: this uses the exact same two-step split as
generate_urdf.py's DH->URDF conversion, because the underlying problem is
identical. Classic DH's rotation theta_i happens about z_{i-1} (the
PARENT frame's z axis, BEFORE the (a, alpha, d) offset is applied),
whereas a MuJoCo <joint> rotates about an axis defined in its OWN body's
frame, and a MuJoCo <body>'s pos/quat offset from its parent is applied
BEFORE any joint inside it -- structurally the same ordering problem
URDF has. So each DH joint becomes two nested MJCF bodies:
  1. An "axis body" at zero offset from the parent, containing the
     revolute <joint axis="0 0 1"> -- the actual DH rotation.
  2. A "link body" nested inside it, offset by pos="a 0 d" and rotated by
     axisangle="1 0 0 <alpha>" -- the DH geometric offset, applied at
     theta=0 exactly as in the URDF version's <origin xyz="a 0 d"
     rpy="alpha 0 0">.
This is not an approximation of the URDF conversion -- it is the same
proof, restated in MJCF's body-nesting model instead of URDF's
joint-and-link-list model.

Units: <compiler angle="radian"/> is set explicitly below so every
angle-bearing attribute (axisangle's angle component, joint range) takes
radians directly, matching how DH_TABLE/JOINT_LIMITS are already stored
in radians -- MuJoCo's default unit is degrees, and silently leaving
that default in place would have been a real, easy-to-miss unit bug.

Confidence level: this file was NOT validated by actually loading the
output into MuJoCo (mujoco.MjModel.from_xml_path()) -- no network access
to install the mujoco Python package in the environment this was written
in. It IS validated as well-formed XML and structurally cross-checked
(body/joint/actuator counts, numeric values) against generate_urdf.py's
output -- see simulation/mujoco/README.md for exactly what that means and
what still needs a real MuJoCo install to confirm (most likely spots for
a real error: quaternion/axisangle convention edge cases, or an actuator
gain/ctrlrange that's syntactically valid but numerically unreasonable).
"""
import math
import os
import sys
import xml.etree.ElementTree as ET
import xml.dom.minidom as minidom

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "tools"))
from robot_params import DH_TABLE, JOINT_LIMITS, JOINT_NAMES  # noqa: E402

LARGE_JOINT_EFFORT_NM = [240.0, 300.0, 120.0]  # peak torque, J1-J3 (design-baseline.md §6.2)
SMALL_JOINT_EFFORT_NM = [24.0, 24.0, 12.0]      # peak torque, J4-J6 (§6.2)

# Illustrative-only masses/radii, matching generate_urdf.py's choices
# exactly so the two models stay visually/dynamically comparable even
# though neither is derived from real CAD mass properties yet.
BASE_MASS_KG = 3.0
BASE_RADIUS_M = 0.09
LARGE_LINK_MASS_KG = 2.0
SMALL_LINK_MASS_KG = 0.6
LARGE_LINK_RADIUS_M = 0.06
SMALL_LINK_RADIUS_M = 0.035
AXIS_BODY_MASS_KG = 0.05  # negligible -- this body only carries the rotation frame, same as URDF's link{i}_axis


def deg2rad(d):
    return d * math.pi / 180.0


def sub(parent, tag, **attrs):
    return ET.SubElement(parent, tag, {k: str(v) for k, v in attrs.items()})


def solid_sphere_inertia(mass, radius):
    """Same illustrative solid-sphere approximation generate_urdf.py uses
    for <inertial> -- NOT from real CAD mass properties. See that file's
    add_inertial() for the identical formula."""
    i = (2.0 / 5.0) * mass * radius * radius
    return i, i, i  # diagonal inertia is isotropic for a solid sphere


def add_inertial(body, mass, radius):
    ixx, iyy, izz = solid_sphere_inertia(mass, radius)
    sub(body, "inertial", pos="0 0 0", mass=mass, diaginertia=f"{ixx} {iyy} {izz}")


def add_link_geom(body, length, radius):
    """A single geom serves as both visual and collision by default in
    MuJoCo (unlike URDF, which has separate <visual>/<collision> blocks
    with identical geometry in generate_urdf.py anyway) -- one <geom> here
    is the correct MJCF equivalent, not a simplification."""
    sub(
        body, "geom", type="cylinder",
        fromto=f"0 0 0 0 0 {length}",
        size=str(radius),
        rgba="0.55 0.57 0.60 1.0",
    )


def build_mjcf():
    mujoco = ET.Element("mujoco", model="modular_arm_msme")

    # Angles in radians throughout, matching DH_TABLE/JOINT_LIMITS' own
    # units -- see the module docstring's "Units" note on why this must
    # be explicit (MuJoCo's default is degrees).
    sub(mujoco, "compiler", angle="radian", autolimits="true")
    sub(mujoco, "option", timestep="0.002", gravity="0 0 -9.81")

    default = sub(mujoco, "default")
    # Joint damping/frictionloss are illustrative placeholders (small,
    # non-zero, numerically stable defaults), NOT sized from real bearing/
    # gearbox friction data -- design-baseline.md §6.3's torque
    # methodology doesn't provide these directly, so treat as
    # TO BE VALIDATED like everything else not sourced from a real
    # measurement or the design doc's own tables.
    sub(default, "joint", damping="0.5", frictionloss="0.1")

    worldbody = sub(mujoco, "worldbody")
    sub(worldbody, "light", pos="0 0 2", dir="0 0 -1", diffuse="0.8 0.8 0.8")

    base = sub(worldbody, "body", name="base_link", pos="0 0 0")
    add_link_geom(base, length=0.05, radius=BASE_RADIUS_M)
    add_inertial(base, mass=BASE_MASS_KG, radius=BASE_RADIUS_M)

    joint_names_mjcf = []
    joint_ranges = []
    parent_body = base

    for i, ((a, alpha, d), (min_deg, max_deg, max_speed), name) in enumerate(
        zip(DH_TABLE, JOINT_LIMITS, JOINT_NAMES)
    ):
        is_large = i < 3
        radius = LARGE_LINK_RADIUS_M if is_large else SMALL_LINK_RADIUS_M
        mass = LARGE_LINK_MASS_KG if is_large else SMALL_LINK_MASS_KG
        # Same illustrative-length rule as generate_urdf.py: just enough
        # that the model isn't degenerate for visualization, NOT from §3's
        # (unspecified) mechanical CAD.
        length = max(abs(a), abs(d), 0.05)

        # 1) Axis body: zero offset from parent, carries the actual DH
        #    rotation about its own z axis -- mirrors generate_urdf.py's
        #    "jointN" (revolute, origin=identity, axis=z).
        axis_body = sub(parent_body, "body", name=f"link{i+1}_axis", pos="0 0 0")
        add_inertial(axis_body, mass=AXIS_BODY_MASS_KG, radius=0.02)
        joint_name = f"joint{i+1}"
        sub(
            axis_body, "joint", name=joint_name, type="hinge", axis="0 0 1",
            range=f"{deg2rad(min_deg)} {deg2rad(max_deg)}",
        )
        joint_names_mjcf.append(joint_name)
        joint_ranges.append((deg2rad(min_deg), deg2rad(max_deg)))

        # 2) Link body: the DH geometric offset (a, alpha, d) at theta=0 --
        #    mirrors generate_urdf.py's "jointN_offset" (fixed,
        #    origin=xyz(a,0,d) rpy=(alpha,0,0)). axisangle expresses a
        #    pure local-X rotation by alpha directly, avoiding a hand-
        #    computed quaternion.
        link_body = sub(axis_body, "body", name=f"link{i+1}", pos=f"{a} 0 {d}", axisangle=f"1 0 0 {alpha}")
        add_link_geom(link_body, length=length, radius=radius)
        add_inertial(link_body, mass=mass, radius=radius)

        parent_body = link_body

    # Tool-changer flange frame, coincident with the final link (design
    # baseline §8.2) -- a zero-mass site rather than a body, since it
    # doesn't need its own inertia or joint, just a named reference frame
    # a gripper/tool model can attach to later.
    sub(parent_body, "site", name="tool0", pos="0 0 0", size="0.005")

    # Position actuators, one per joint, matching the ros2_control
    # "command_interface name=position" the URDF's <ros2_control> block
    # declares (generate_urdf.py) -- so both models expose the same
    # control modality. kp is an illustrative, numerically-stable
    # placeholder (NOT a tuned gain -- design-baseline.md §13.2 covers
    # real PID/feedforward tuning as a separate, later concern).
    actuator = sub(mujoco, "actuator")
    for i, (joint_name, (lo, hi)) in enumerate(zip(joint_names_mjcf, joint_ranges)):
        is_large = i < 3
        kp = 500.0 if is_large else 100.0  # placeholder -- larger joints get a larger illustrative gain, not a tuned one
        sub(actuator, "position", name=f"{joint_name}_pos", joint=joint_name, kp=kp, ctrlrange=f"{lo} {hi}")

    return mujoco


def main():
    import os
    model = build_mjcf()
    rough = ET.tostring(model, encoding="unicode")
    pretty = minidom.parseString(rough).toprettyxml(indent="  ")
    pretty = "\n".join(line for line in pretty.split("\n") if line.strip())
    script_dir = os.path.dirname(os.path.abspath(__file__))
    out_path = os.path.join(script_dir, "generated_arm.xml")
    with open(out_path, "w") as f:
        f.write(pretty)
    print(f"Wrote {os.path.normpath(out_path)}")


if __name__ == "__main__":
    main()
