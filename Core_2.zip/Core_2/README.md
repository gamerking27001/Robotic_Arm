# robotic_arm_core

A modern C++20 implementation of the "Modular Industrial Robotic Arm for
MSMEs" engineering baseline, built in three layers:

**Changelog note:** a review pass found and fixed a real safety-authority
bug in `ros2_ws` — the ROS2 layer's E-stop previously updated a status
topic without actually being able to stop the robot. See
`ros2_ws/README.md`'s "Safety authority fix" section before relying on
anything E-stop-related in that layer. The same pass added dashboard
authentication (previously "No auth"), Docker/systemd deployment
scaffolding, and a CI workflow that runs a real ROS2 `colcon build` against
`ros2_ws` for the first time — see `deploy/README.md`.

- **`include/`, `src/`** — the host-level **core stack**: kinematics, motion
  planning, a joint hardware-abstraction layer, and the safety state machine,
  running against a simulated CAN bus / simulated joint dynamics. Builds and
  runs (`arm_demo`) — verified.
- **`firmware/`** — the **per-joint FOC control loop + independent safety
  board firmware** (§9.3, §11.2, §14, §9.8), host-simulated on real OS
  threads at real timing rates. Builds and runs (`firmware_demo`) — verified.
  See `firmware/README.md` for its own scope notes.
- **`ros2_ws/`** — the **ROS2 integration layer** (§12, §18, §20.2): a
  `ros2_control` hardware interface wrapping the core stack, a MoveIt 2
  planning config, a URDF generated from the same config the core stack
  reads, and safety/diagnostics nodes. **Not built or run** — there's no
  ROS2 installation in this environment. See `ros2_ws/README.md` before
  trusting any of it; treat it as a careful first draft, not verified code.
- **`dashboard/`** — the **operator dashboard** (§19.4, §20.1): a FastAPI
  backend (`dashboard/backend`) that wraps the core stack via a small C ABI
  + ctypes (no ROS2 dependency), a React+TypeScript frontend
  (`dashboard/frontend`), and a second web app, `dashboard/commissioning-wizard`
  (§17.5/§20.7's deployment checklist, mostly automated against the live
  backend). All **built, run, and integration-tested** — real HTTP/WebSocket
  requests against a live server, and two real bugs (safety evaluation
  timing, STO never actually clearing) caught and fixed in the process. See
  each package's own README.
- **`mobile/ArmOperatorApp`** — a **true native Android app** (React Native),
  same operator dashboard functionality. Real scaffolding from
  `@react-native-community/cli`, real `npm install`, clean `tsc`, and 4/4
  component tests passing against `react-test-renderer` — but the actual
  Android/Gradle build could not be verified (Google's package servers and
  even `services.gradle.org` aren't reachable here). See
  `mobile/ArmOperatorApp/README.md` for exactly where verification stops.
- **`desktop/windows`** — a **native desktop app** (Electron), wrapping the
  already-tested `dashboard/frontend` bundle unmodified. The most thoroughly
  verified new piece: real Windows `.exe` and Linux binaries were actually
  packaged and (the Linux one) run and **screenshotted** rendering live
  telemetry through a real backend — two real proxy bugs found and fixed
  along the way. See `desktop/windows/README.md`.
- **`vision/`** — the **computer vision layer** (§15, marked *Optional* in
  the source doc): calibration, part localization, barcode/QR reading,
  quality inspection, and pose estimation, each with classical-CV
  implementations. **Built and tested** — 16/16 tests pass against real
  synthetic image/point data with known ground truth. Object detection is
  the one module that doesn't implement what the doc calls for (a real YOLO
  detector needs weights and a GPU this environment doesn't have) — see
  `vision/README.md` for the honest scope note.

All three build with a C++20 compiler and the standard library only — no
Eigen, no Boost, no YAML library, no FreeRTOS/STM32 SDK, no ROS2 SDK.
The core stack and firmware layer were built and verified with GCC 13.3.0 on
Ubuntu 24.04; the ROS2 layer needs a real ROS2 Jazzy/Humble environment to
verify.

## Build

```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build .
./arm_demo          # core stack demo
./firmware_demo     # firmware layer demo
```

For the ROS2 layer, see `ros2_ws/README.md` (requires a real ROS2 install;
`colcon build` from a workspace containing `ros2_ws/src`'s contents).

Or directly with g++ (no cmake required), from the project root:

```bash
# Core stack
g++ -std=c++20 -O2 -Iinclude src/kinematics/*.cpp src/motion/*.cpp src/hal/*.cpp \
    src/safety/*.cpp src/config/*.cpp src/main.cpp -o arm_demo
./arm_demo

# Firmware layer (needs -pthread)
g++ -std=c++20 -O2 -pthread -I. -Iinclude \
    firmware/joint_foc/joint_foc_task.cpp firmware/safety_board/safety_board_task.cpp \
    firmware/firmware_demo.cpp -o firmware_demo
./firmware_demo
```

## What `arm_demo` does

1. Prints the full robot + per-joint specification table (§1.5/§2.1/§5.6/§6.2).
2. Loads `configs/arm_variant_standard.yaml` (the §20.5 config format) and
   builds the DH kinematic chain from it.
3. Runs forward kinematics, then solves inverse kinematics for a target pose
   (closed-form geometric seed + Jacobian/damped-least-squares refinement,
   per §11.4) and verifies the round-trip.
4. Builds a synchronized 6-axis S-curve trajectory (§13.3's recommended
   default) between two joint configurations and steps the motion controller
   against six simulated joint drives.
5. Mid-move, injects a simulated contact load on the elbow joint (J3) to
   exercise the §14 torque-deviation collision-detection path, and shows the
   safety FSM (§13.5) latching **Running → Fault**.
6. Demonstrates fault-clear, hardware E-stop trigger (with STO on every
   joint, §9.5), and E-stop reset back to `PowerOn`.

## Layout and document traceability

| Path | Source doc section(s) | Contents |
|---|---|---|
| `include/core/robot_config.hpp` | §1.5, §2.1, §5.6, §6.2, §7, §14, §13.3 | Every numeric parameter as `constexpr` typed config |
| `include/core/linalg.hpp` | — | Dependency-free Vector3/Matrix3/Transform/6x6 solve |
| `kinematics/dh_kinematics.*` | §4.3, §11.4 | DH forward kinematics + geometric Jacobian |
| `kinematics/ik_solver.*` | §11.4 | Closed-form geometric seed + Jacobian DLS refinement |
| `motion/trajectory_profile.*` | §13.3, §13.4 | Trapezoidal + jerk-limited S-curve profiles |
| `motion/motion_controller.*` | §11.3 | Real-time interpolator, synchronized multi-axis moves |
| `hal/joint_interface.hpp` | §20.4 | The interface reproduced verbatim from the doc |
| `hal/simulated_joint_driver.*` | §9.3, §6.2, §6.4, §7.1 | Simulated per-joint drive + thermal/torque model |
| `hal/can_bus_simulated.hpp` | §9.7, §19.5 | In-process stand-in for the CANopen joint bus |
| `safety/safety_fsm.*` | §13.5, §14.1, §9.5 | Operational state machine + safety functions |
| `config/config_loader.*` | §11.7, §20.5 | Hand-rolled parser for the §20.5 config format |
| `configs/arm_variant_standard.yaml` | §20.5 | Reproduces the doc's sample config |

## Digital Twin (a different source document)

[`digital_twin/`](digital_twin/README.md) implements the Digital Twin Sync
Engine + viewport described in *Industrial Robotics Operating Platform for
MSMEs* — a separate spec document from the one this top-level README and
table track (that document's own section numbers, §1-§18, are unrelated to
the §-numbers above, which are this repo's original hardware-design spec).
It connects to this repo's `dashboard/backend` for live telemetry and calls
into `include/kinematics/dh_kinematics.*` through one new, additive native
bridge export — see its README for exactly what's implemented, what's
explicitly out of scope, and how it was verified.

## Motion Planner (same other source document)

[`motion_planner/`](motion_planner/README.md) implements that same MSME
platform spec's §7 (waypoint programming, IK/FK feasibility, collision
detection, trajectory optimization, and a token-gated deploy per §17.3).
It reuses `motion/synchronized_move.hpp` (extracted from
`MotionController::beginMove()` — same algorithm, now callable offline) and
two new native bridge exports (`robot_bridge_solve_ik`,
`robot_bridge_sample_joint_move`), and was verified with a real live run:
create → simulate → deploy against the actual `dashboard/backend`, with the
telemetry afterward confirming the simulated arm reached the exact
commanded joint angles. See its README for scope and verification detail.

## Cloud Platform (same other source document)

[`cloud_platform/`](cloud_platform/README.md) implements that same MSME
platform spec's §§13/17: the fleet database schema (Organizations, Sites,
Robots, Users, RoleAssignments, Programs, ProgramVersions, Alerts,
AlertRules) as real SQLAlchemy models running against a real PostgreSQL 16
+ PostGIS database, plus the Cloud API (versioned routes, idempotent
command dispatch, JWT-scoped RBAC matching §3.3's five roles exactly, and
the §17.2 error-code taxonomy). 63 tests pass against the live database,
not a mock. See its README for exactly what's implemented, an explicitly
documented cross-org visibility limitation the test suite itself surfaces,
and two real bugs the test suite caught and fixed along the way.

## Local Gateway (same other source document)

[`local_gateway/`](local_gateway/README.md) implements that same MSME
platform spec's §§1-4: the Local Gateway Service, with **real protocol
implementations** -- a genuine OPC UA server/client (asyncua) and a
genuine Modbus TCP server/client (pymodbus), two simulated "controller
brands" behind one `RobotAdapter` interface (the vendor-adapter pattern
§1.4/§2.7 describe), plus real MQTT (mosquitto) batched cloud sync, a real
SQLite offline-resilience buffer, and §4.2's composite health score.
48 tests pass, including live OPC UA/Modbus/MQTT round trips against real
servers and brokers, not mocks. See its README for exactly what's
implemented and what's explicitly out of scope (EtherCAT/CAN, gRPC command
dispatch). The one gap it originally flagged -- nothing consuming the
published MQTT telemetry into `cloud_platform` -- is now closed by
[`cloud_platform/ingestion_bridge/`](cloud_platform/ingestion_bridge/README.md),
a real MQTT-to-Cloud-API consumer (6/6 tests passing end to end: real
MQTT publish -> real bridge -> real Cloud API -> real PostgreSQL).

## Gaps in the source document (and how this codebase handles them)

The source PDF's representative configuration truncates two tables with
`# ... J3-J6 continued`:

- **DH parameters** (§4.3/§20.5): only J1 (`a=0, d=0.284, alpha=90°`) and J2
  (`a=0.400, d=0, alpha=0`) are given numerically. J3-J6 are filled in here
  with `PLACEHOLDER_`-commented values sized to be consistent with the
  850 mm reach and spherical-wrist requirement stated elsewhere in the doc.
- **Joint soft limits** for J3-J6 (§20.5): only J1/J2 limits are given
  numerically; J3-J6 are filled with representative values.

Both are isolated to `include/core/robot_config.hpp` and
`configs/arm_variant_standard.yaml` — correcting them there propagates
through kinematics, motion planning, and safety limit checks automatically.
A few other parameters aren't given numeric values anywhere in the source
doc (e.g. joint acceleration limits, the collision-detection torque-deviation
threshold, control-loop update rate); these are marked with inline comments
explaining the engineering assumption made.

## Out of scope (not built here)

- **PCB / electrical schematics** (§9, §pcb/) and **mechanical CAD** (§3, §cad/).
- **Real STM32/FreeRTOS build** — `firmware/` implements the FOC control loop
  and safety-board logic faithfully but runs it on host threads via a small
  shim, not a real ARM cross-compile; see `firmware/README.md`.
- **Real ROS2/colcon build** — `ros2_ws/` implements the hardware interface,
  MoveIt config, and safety/diagnostics nodes but has not been compiled or
  run (no ROS2 install in this environment); see `ros2_ws/README.md`.
- `vision/object_detection`'s real YOLO/TensorRT detector (needs pretrained
  weights + GPU not available here — see `vision/README.md`).
- Formal safety certification against ISO 10218-1/-2, ISO/TS 15066,
  IEC 60204-1, IEC 61800-5-2 (§14.3) — the safety *architecture* here follows
  those standards' structure (dual-channel STO, hardware E-stop independent
  of firmware state) but has not been certified.
