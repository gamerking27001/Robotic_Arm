# cloud_platform/api_service

The Cloud API service (FastAPI + SQLAlchemy + PostgreSQL/PostGIS). See
[`../README.md`](../README.md) for architecture, scope, and end-to-end run
instructions.

## Layout

- `app/models.py` -- ORM models (section 17.1's ERD).
- `app/db.py` -- engine/session setup, `init_db()`.
- `app/auth.py` -- password hashing, JWT issuance/verification, section 3.3's RBAC.
- `app/errors.py` -- the section 17.2 error-code taxonomy.
- `app/schemas.py` -- Pydantic request/response models.
- `app/routers/orgs.py` -- organizations, sites, users, role assignments, login.
- `app/routers/robots.py` -- registration, status, idempotent command dispatch.
- `app/routers/telemetry.py` -- ingestion + query.
- `app/routers/programs.py` -- versioned program storage.
- `app/routers/alerts.py` -- alert rules + evaluation + acknowledgment.
- `tests/` -- 63 tests, run against real Postgres (`cloud_platform_test`).

## Local dev

```bash
pip install -r requirements.txt --break-system-packages
export CLOUD_PLATFORM_DATABASE_URL=postgresql+psycopg2://postgres:postgres@localhost:5432/cloud_platform_test
export CLOUD_PLATFORM_JWT_SECRET=test-secret
python3 -m pytest tests/ -q

export CLOUD_PLATFORM_DATABASE_URL=postgresql+psycopg2://postgres:postgres@localhost:5432/cloud_platform
uvicorn app.main:app --reload --port 8300
```

Every test drops and recreates the `public` schema before running (see
`tests/conftest.py`) -- point `CLOUD_PLATFORM_DATABASE_URL` at a database
you're fine with being wiped repeatedly, never at a database with real data.
