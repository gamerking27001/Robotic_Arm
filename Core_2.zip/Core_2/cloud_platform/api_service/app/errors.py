"""app/errors.py

Section 17.2: "Explicit error taxonomy -- A small, consistent error-code
set (validation, permission, not-found, conflict, robot-unreachable,
robot-rejected) is used across all services so client applications can
build one error-handling path rather than per-endpoint special cases."

Every one of those six codes, exactly, plus the HTTP status each maps to.
No endpoint in this service raises a bare HTTPException with an ad-hoc
detail string -- they all raise one of these, so the response body shape
(`{"error_code": ..., "message": ..., "details": {...}}`) is identical
everywhere.
"""
from __future__ import annotations

from typing import Any, Optional

from fastapi import HTTPException


class ApiError(HTTPException):
    error_code: str
    status_code: int

    def __init__(self, message: str, details: Optional[dict[str, Any]] = None) -> None:
        super().__init__(status_code=self.status_code, detail={"error_code": self.error_code, "message": message, "details": details or {}})


class ValidationError(ApiError):
    error_code = "validation"
    status_code = 422


class PermissionError_(ApiError):
    """Named with a trailing underscore to avoid shadowing the builtin
    PermissionError -- the error_code itself is still exactly "permission"."""

    error_code = "permission"
    status_code = 403


class NotFoundError(ApiError):
    error_code = "not_found"
    status_code = 404


class ConflictError(ApiError):
    error_code = "conflict"
    status_code = 409


class RobotUnreachableError(ApiError):
    """The cloud API couldn't reach the robot's Local Gateway Service (or,
    in this codebase's stand-in, dashboard/backend / motion_planner --
    see routers/robots.py's dispatch endpoint) -- a network/connectivity
    failure, not a rejection by the robot's own safety logic (that's
    RobotRejectedError, below)."""

    error_code = "robot_unreachable"
    status_code = 502


class RobotRejectedError(ApiError):
    """The robot (or its gateway) was reachable but refused the command --
    e.g. the safety FSM wasn't in Idle/Running (see
    dashboard/backend/main.py's /api/moves 409 response, which this error
    wraps when the cloud API forwards a command)."""

    error_code = "robot_rejected"
    status_code = 409


class UnauthenticatedError(ApiError):
    """Not one of the six section-17.2 codes (that list is about
    request-level failures on an already-authenticated call) -- kept
    separate from PermissionError_ because "no/invalid credentials" and
    "valid credentials, insufficient permission" are different failure
    modes a client should handle differently (401 -> re-auth; 403 ->
    don't retry, ask a human)."""

    error_code = "unauthenticated"
    status_code = 401
