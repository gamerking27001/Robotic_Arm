"""app/db.py

SQLAlchemy engine/session setup. Connection string is entirely
environment-driven (CLOUD_PLATFORM_DATABASE_URL) -- no hardcoded host,
consistent with this being a cloud service meant to run against a managed
Postgres instance (section 13.1's "managed cloud services" principle,
section 18.1's data tier), not the app talking to a fixed local database.
"""
from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Iterator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from .models import Base

DEFAULT_DATABASE_URL = "postgresql+psycopg2://postgres:postgres@localhost:5432/cloud_platform"


def _database_url() -> str:
    return os.environ.get("CLOUD_PLATFORM_DATABASE_URL", DEFAULT_DATABASE_URL)


engine = create_engine(_database_url(), pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


def init_db() -> None:
    """Creates every table (and the PostGIS extension, idempotently) if it
    doesn't already exist. Uses SQLAlchemy's create_all() rather than a
    migration tool for this deliverable -- a real deployment would use
    Alembic (or equivalent) to version schema changes across environments;
    create_all() is fine for a fresh dev/test database, not for migrating
    an existing one, and that distinction matters enough to say explicitly
    rather than let create_all() quietly stand in for a migration story it
    isn't one."""
    with engine.begin() as conn:
        conn.exec_driver_sql("CREATE EXTENSION IF NOT EXISTS postgis")
    Base.metadata.create_all(bind=engine)


def get_session() -> Iterator[Session]:
    """FastAPI dependency -- yields a session, closes it after the request."""
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


@contextmanager
def session_scope() -> Iterator[Session]:
    """Non-FastAPI context-manager form, for scripts/tests."""
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
