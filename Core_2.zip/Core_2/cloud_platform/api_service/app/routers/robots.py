"""app/routers/robots.py -- Section 3.2 Fleet Management: robot registration,
status, and Section 17.2's idempotent command dispatch.
"""
from __future__ import annotations

from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends
from geoalchemy2.functions import ST_MakePoint, ST_SetSRID, ST_X, ST_Y
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..auth import TokenClaims, get_current_claims, require_permission
from ..db import get_session
from ..errors import NotFoundError, ValidationError
from ..models import CommandRequest, ProgramVersion, Robot, RobotStatus, Site
from ..schemas import DispatchProgramRequest, DispatchProgramResponse, RobotOut, RobotRegisterRequest, RobotStatusUpdate

router = APIRouter(prefix="/v1", tags=["robots"])


def _robot_out(session: Session, robot: Robot) -> RobotOut:
    lat = lon = None
    if robot.location is not None:
        lon, lat = session.execute(select(ST_X(robot.location), ST_Y(robot.location))).one()
    return RobotOut(
        id=robot.id,
        site_id=robot.site_id,
        brand=robot.brand,
        model=robot.model,
        status=robot.status.value,
        registered_at=robot.registered_at,
        latitude=lat,
        longitude=lon,
    )


def _check_robot_scope(session: Session, claims: TokenClaims, robot: Robot) -> None:
    """Every robot-scoped endpoint below is also org-scoped implicitly:
    a robot's site determines its org, and role_assignments (checked inside
    require_permission) are what actually grant access to a *specific*
    robot or site -- but at minimum, a robot with no site (unregistered
    into any org yet) or a robot whose site belongs to a different org
    than the caller's token must never be visible cross-tenant."""
    if robot.site_id is not None:
        site = session.get(Site, robot.site_id)
        if site is not None and str(site.org_id) != claims.org_id:
            raise NotFoundError("robot not found")


@router.post("/organizations/{org_id}/robots", response_model=RobotOut)
def register_robot(
    org_id: UUID,
    req: RobotRegisterRequest,
    claims: TokenClaims = Depends(get_current_claims),
    session: Session = Depends(get_session),
):
    """Section 3.2: "Onboarding wizard binds a physical robot's identity
    ... to a platform record." """
    if str(org_id) != claims.org_id:
        raise NotFoundError("organization not found")
    if req.site_id is not None:
        site = session.get(Site, req.site_id)
        if site is None or str(site.org_id) != claims.org_id:
            raise ValidationError("site_id does not belong to this organization")
    require_permission(claims, "robot:register", site_id=str(req.site_id) if req.site_id else None)

    location = None
    if req.latitude is not None and req.longitude is not None:
        location = ST_SetSRID(ST_MakePoint(req.longitude, req.latitude), 4326)

    robot = Robot(site_id=req.site_id, brand=req.brand, model=req.model, location=location, status=RobotStatus.registered)
    session.add(robot)
    session.commit()
    session.refresh(robot)
    return _robot_out(session, robot)


@router.get("/robots/{robot_id}", response_model=RobotOut)
def get_robot(robot_id: UUID, claims: TokenClaims = Depends(get_current_claims), session: Session = Depends(get_session)):
    robot = session.get(Robot, robot_id)
    if robot is None:
        raise NotFoundError("robot not found")
    _check_robot_scope(session, claims, robot)
    require_permission(claims, "dashboard:view", robot_id=str(robot_id), site_id=str(robot.site_id) if robot.site_id else None)
    return _robot_out(session, robot)


@router.get("/organizations/{org_id}/robots", response_model=list[RobotOut])
def list_robots(
    org_id: UUID,
    site_id: Optional[UUID] = None,
    claims: TokenClaims = Depends(get_current_claims),
    session: Session = Depends(get_session),
):
    """Section 13.1's Fleet Management: "Centralized robot registry,
    grouping by site/cell". Only returns robots that have a site assigned
    (a robot's org membership is derived transitively through its site --
    see models.py -- so an unassigned robot, site_id=None, can't appear in
    any org's listing; it would need to be assigned to a site first)."""
    if str(org_id) != claims.org_id:
        raise NotFoundError("organization not found")
    require_permission(claims, "dashboard:view")
    query = select(Robot).join(Site, Robot.site_id == Site.id).where(Site.org_id == org_id)
    if site_id is not None:
        query = query.where(Robot.site_id == site_id)
    robots = session.execute(query).scalars().all()
    return [_robot_out(session, r) for r in robots]


@router.patch("/robots/{robot_id}/status", response_model=RobotOut)
def update_robot_status(
    robot_id: UUID,
    req: RobotStatusUpdate,
    claims: TokenClaims = Depends(get_current_claims),
    session: Session = Depends(get_session),
):
    robot = session.get(Robot, robot_id)
    if robot is None:
        raise NotFoundError("robot not found")
    _check_robot_scope(session, claims, robot)
    require_permission(claims, "robot:status:update", robot_id=str(robot_id), site_id=str(robot.site_id) if robot.site_id else None)
    try:
        robot.status = RobotStatus(req.status)
    except ValueError as exc:
        raise ValidationError(f"unknown status: {req.status}") from exc
    session.commit()
    session.refresh(robot)
    return _robot_out(session, robot)


# --- Idempotent command dispatch (Section 17.2) -------------------------------


@router.post("/robots/{robot_id}/commands/dispatch-program", response_model=DispatchProgramResponse)
def dispatch_program(
    robot_id: UUID,
    req: DispatchProgramRequest,
    claims: TokenClaims = Depends(get_current_claims),
    session: Session = Depends(get_session),
):
    """Section 17.2: "Idempotent command endpoints -- Commands that affect
    robot state (deploy program, trigger OTA) are idempotent and carry a
    client-generated request ID, so a retried request after a network drop
    cannot double-execute a motion command."

    Implementation: `command_requests` has a UNIQUE(robot_id, request_id)
    constraint (models.py). The first POST with a given request_id
    executes the dispatch and records the result; every subsequent POST
    with that same request_id (e.g. a client retry after a dropped
    response) hits the unique constraint, and this handler returns the
    *original* recorded result instead of dispatching a second time --
    `replayed: true` tells the caller which happened.

    "Dispatch" itself is a stub in this deliverable (see
    cloud_platform/README.md's scope note): it records the command as
    accepted without forwarding to a real Local Gateway Service, since none
    exists in this codebase. What's implemented and tested is the
    idempotency guarantee itself, which is the section 17.2 requirement --
    not a specific gateway integration.
    """
    robot = session.get(Robot, robot_id)
    if robot is None:
        raise NotFoundError("robot not found")
    _check_robot_scope(session, claims, robot)
    require_permission(claims, "program:run", robot_id=str(robot_id), site_id=str(robot.site_id) if robot.site_id else None)

    version = session.get(ProgramVersion, req.program_version_id)
    if version is None:
        raise ValidationError("program_version_id does not exist")

    existing = session.execute(
        select(CommandRequest).where(CommandRequest.robot_id == robot_id, CommandRequest.request_id == req.request_id)
    ).scalar_one_or_none()
    if existing is not None:
        return DispatchProgramResponse(
            request_id=req.request_id, accepted=existing.accepted, replayed=True, result=existing.result or {}
        )

    result = {"status": "dispatched (stub)", "program_version_id": str(version.id), "waypoint_count": len(version.waypoint_data.get("waypoints", []))}
    command = CommandRequest(
        robot_id=robot_id,
        request_id=req.request_id,
        command_type="dispatch_program",
        payload={"program_version_id": str(req.program_version_id)},
        result=result,
        accepted=True,
    )
    session.add(command)
    try:
        session.commit()
    except IntegrityError:
        # Race: two concurrent requests with the same request_id both
        # passed the SELECT above before either committed. Whichever loses
        # the DB-level unique-constraint race re-reads and returns the
        # winner's result -- same replayed=True contract as the normal
        # duplicate-request path above, just reached via a different route.
        session.rollback()
        existing = session.execute(
            select(CommandRequest).where(CommandRequest.robot_id == robot_id, CommandRequest.request_id == req.request_id)
        ).scalar_one()
        return DispatchProgramResponse(
            request_id=req.request_id, accepted=existing.accepted, replayed=True, result=existing.result or {}
        )

    return DispatchProgramResponse(request_id=req.request_id, accepted=True, replayed=False, result=result)
