"""app/routers/orgs.py -- Organizations, Sites, Users, Role Assignments, Auth (login).

Section 3.2/3.3 and 12.1's account/role/auth model, plus Section 17.1's
ORGANIZATIONS/SITES/USERS/ROLE_ASSIGNMENTS tables. Bundled into one router
(rather than four) because every one of these is small and none has enough
independent complexity to earn its own file -- unlike robots/telemetry/
programs/alerts, which do.
"""
from __future__ import annotations

from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, Header
from geoalchemy2.functions import ST_MakePoint, ST_SetSRID, ST_X, ST_Y
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import auth as auth_module
from ..auth import TokenClaims, get_current_claims, require_permission
from ..db import get_session
from ..errors import ConflictError, NotFoundError, UnauthenticatedError, ValidationError
from ..models import Organization, Role, RoleAssignment, Site, User
from ..schemas import (
    LoginRequest,
    LoginResponse,
    OrganizationCreate,
    OrganizationOut,
    RoleAssignmentCreate,
    RoleAssignmentOut,
    SiteCreate,
    SiteOut,
    UserCreate,
    UserOut,
)

router = APIRouter(prefix="/v1", tags=["orgs"])


# --- Organizations ------------------------------------------------------------


@router.post("/organizations", response_model=OrganizationOut)
def create_organization(req: OrganizationCreate, session: Session = Depends(get_session)):
    """Unauthenticated by design: this is how the very first organization
    (and, immediately after, its first fleet_administrator user) comes into
    existence -- there is no existing token that could authorize it."""
    org = Organization(name=req.name, subscription_tier=req.subscription_tier)
    session.add(org)
    session.commit()
    session.refresh(org)
    return OrganizationOut.model_validate(org)


@router.get("/organizations/{org_id}", response_model=OrganizationOut)
def get_organization(org_id: UUID, claims: TokenClaims = Depends(get_current_claims), session: Session = Depends(get_session)):
    if str(org_id) != claims.org_id:
        raise NotFoundError("organization not found")  # not 403: don't reveal existence to other orgs
    org = session.get(Organization, org_id)
    if org is None:
        raise NotFoundError("organization not found")
    return OrganizationOut.model_validate(org)


# --- Sites ----------------------------------------------------------------------


@router.post("/organizations/{org_id}/sites", response_model=SiteOut)
def create_site(
    org_id: UUID, req: SiteCreate, claims: TokenClaims = Depends(get_current_claims), session: Session = Depends(get_session)
):
    if str(org_id) != claims.org_id:
        raise NotFoundError("organization not found")
    require_permission(claims, "site:create")
    address = None
    if req.latitude is not None and req.longitude is not None:
        address = ST_SetSRID(ST_MakePoint(req.longitude, req.latitude), 4326)
    site = Site(org_id=org_id, name=req.name, address=address)
    session.add(site)
    session.commit()
    session.refresh(site)
    lat = lon = None
    if site.address is not None:
        lon, lat = session.execute(select(ST_X(site.address), ST_Y(site.address))).one()
    return SiteOut(id=site.id, org_id=site.org_id, name=site.name, latitude=lat, longitude=lon)


@router.get("/sites/{site_id}", response_model=SiteOut)
def get_site(site_id: UUID, claims: TokenClaims = Depends(get_current_claims), session: Session = Depends(get_session)):
    site = session.get(Site, site_id)
    if site is None or str(site.org_id) != claims.org_id:
        raise NotFoundError("site not found")
    lat = lon = None
    if site.address is not None:
        lon, lat = session.execute(select(ST_X(site.address), ST_Y(site.address))).one()
    return SiteOut(id=site.id, org_id=site.org_id, name=site.name, latitude=lat, longitude=lon)


# --- Users / Role Assignments -------------------------------------------------


@router.post("/organizations/{org_id}/users", response_model=UserOut)
def create_user(
    org_id: UUID,
    req: UserCreate,
    session: Session = Depends(get_session),
    authorization: Optional[str] = Header(default=None),
):
    """The *first* user of a brand-new organization can be created without
    a token (there being no user yet to hold one, and no token to check).
    Every subsequent user must be created by an authenticated
    fleet_administrator of that same org -- checked manually against an
    optional Authorization header here (rather than via
    Depends(get_current_claims), which would make the header mandatory)
    since the requirement itself is conditional on whether the org already
    has users."""
    existing_count = session.query(User).filter(User.org_id == org_id).count()
    if existing_count > 0:
        if not authorization:
            raise UnauthenticatedError(
                "organization already has users -- authenticate as a fleet_administrator to add more"
            )
        claims = get_current_claims(authorization)
        if str(org_id) != claims.org_id:
            raise NotFoundError("organization not found")
        require_permission(claims, "user:create")

    user = User(org_id=org_id, email=req.email, auth_method="password", password_hash=auth_module.hash_password(req.password))
    session.add(user)
    session.flush()
    if existing_count == 0:
        # The org's first user is automatically granted fleet_administrator,
        # org-wide (robot_id=site_id=None) -- otherwise no one could ever
        # grant the first role in a new organization.
        session.add(RoleAssignment(user_id=user.id, role=Role.fleet_administrator, robot_id=None, site_id=None))
    session.commit()
    session.refresh(user)
    return UserOut.model_validate(user)


@router.post("/organizations/{org_id}/role-assignments", response_model=RoleAssignmentOut)
def create_role_assignment(
    org_id: UUID,
    req: RoleAssignmentCreate,
    claims: TokenClaims = Depends(get_current_claims),
    session: Session = Depends(get_session),
):
    if str(org_id) != claims.org_id:
        raise NotFoundError("organization not found")
    require_permission(claims, "role_assignment:create")  # only fleet_administrator has "*"
    target_user = session.get(User, req.user_id)
    if target_user is None or target_user.org_id != org_id:
        raise ValidationError("user_id does not belong to this organization")
    try:
        role = Role(req.role)
    except ValueError as exc:
        raise ValidationError(f"unknown role: {req.role}") from exc
    ra = RoleAssignment(user_id=req.user_id, role=role, robot_id=req.robot_id, site_id=req.site_id)
    session.add(ra)
    session.commit()
    session.refresh(ra)
    return RoleAssignmentOut(id=ra.id, user_id=ra.user_id, role=ra.role.value, robot_id=ra.robot_id, site_id=ra.site_id)


# --- Auth ------------------------------------------------------------------------


@router.post("/auth/login", response_model=LoginResponse)
def login(req: LoginRequest, session: Session = Depends(get_session)):
    user = session.execute(select(User).where(User.email == req.email)).scalar_one_or_none()
    if user is None or user.password_hash is None or not auth_module.verify_password(req.password, user.password_hash):
        raise UnauthenticatedError("invalid email or password")
    role_assignments = session.execute(select(RoleAssignment).where(RoleAssignment.user_id == user.id)).scalars().all()
    token = auth_module.issue_access_token(user, list(role_assignments))
    return LoginResponse(access_token=token, expires_in_s=auth_module.DEFAULT_TOKEN_TTL_S)
