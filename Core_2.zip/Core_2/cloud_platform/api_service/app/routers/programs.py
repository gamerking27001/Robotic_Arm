"""app/routers/programs.py

Section 17.1's PROGRAMS/PROGRAM_VERSIONS tables: fleet-wide, versioned
program storage -- "stores each program revision's waypoint data as jsonb,
giving version history without a separate document store."
"""
from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..auth import TokenClaims, get_current_claims, require_permission
from ..db import get_session
from ..errors import NotFoundError
from ..models import Program, ProgramVersion, Robot, Site
from ..schemas import ProgramCreate, ProgramOut, ProgramVersionCreate, ProgramVersionOut

router = APIRouter(prefix="/v1", tags=["programs"])


def _robot_scope_or_404(session: Session, claims: TokenClaims, robot_id: UUID) -> Robot:
    robot = session.get(Robot, robot_id)
    if robot is None:
        raise NotFoundError("robot not found")
    if robot.site_id is not None:
        site = session.get(Site, robot.site_id)
        if site is not None and str(site.org_id) != claims.org_id:
            raise NotFoundError("robot not found")
    return robot


@router.post("/robots/{robot_id}/programs", response_model=ProgramOut)
def create_program(
    robot_id: UUID, req: ProgramCreate, claims: TokenClaims = Depends(get_current_claims), session: Session = Depends(get_session)
):
    robot = _robot_scope_or_404(session, claims, robot_id)
    require_permission(claims, "program:create", robot_id=str(robot_id), site_id=str(robot.site_id) if robot.site_id else None)
    program = Program(robot_id=robot_id, name=req.name)
    session.add(program)
    session.commit()
    session.refresh(program)
    return ProgramOut(id=program.id, robot_id=program.robot_id, name=program.name, current_version_id=program.current_version_id)


@router.get("/robots/{robot_id}/programs", response_model=list[ProgramOut])
def list_programs(robot_id: UUID, claims: TokenClaims = Depends(get_current_claims), session: Session = Depends(get_session)):
    robot = _robot_scope_or_404(session, claims, robot_id)
    require_permission(claims, "dashboard:view", robot_id=str(robot_id), site_id=str(robot.site_id) if robot.site_id else None)
    programs = session.execute(select(Program).where(Program.robot_id == robot_id)).scalars().all()
    return [ProgramOut(id=p.id, robot_id=p.robot_id, name=p.name, current_version_id=p.current_version_id) for p in programs]


@router.post("/programs/{program_id}/versions", response_model=ProgramVersionOut)
def create_program_version(
    program_id: UUID,
    req: ProgramVersionCreate,
    claims: TokenClaims = Depends(get_current_claims),
    session: Session = Depends(get_session),
):
    program = session.get(Program, program_id)
    if program is None:
        raise NotFoundError("program not found")
    robot = _robot_scope_or_404(session, claims, program.robot_id)
    require_permission(claims, "program:edit", robot_id=str(robot.id), site_id=str(robot.site_id) if robot.site_id else None)

    next_version_number = (
        session.execute(select(func.coalesce(func.max(ProgramVersion.version_number), 0)).where(ProgramVersion.program_id == program_id)).scalar_one()
        + 1
    )
    version = ProgramVersion(program_id=program_id, version_number=next_version_number, waypoint_data=req.waypoint_data)
    session.add(version)
    session.flush()
    if req.set_as_current:
        program.current_version_id = version.id
    session.commit()
    session.refresh(version)
    return ProgramVersionOut(
        id=version.id, program_id=version.program_id, version_number=version.version_number,
        waypoint_data=version.waypoint_data, created_at=version.created_at,
    )


@router.get("/programs/{program_id}/versions", response_model=list[ProgramVersionOut])
def list_program_versions(program_id: UUID, claims: TokenClaims = Depends(get_current_claims), session: Session = Depends(get_session)):
    program = session.get(Program, program_id)
    if program is None:
        raise NotFoundError("program not found")
    robot = _robot_scope_or_404(session, claims, program.robot_id)
    require_permission(claims, "dashboard:view", robot_id=str(robot.id), site_id=str(robot.site_id) if robot.site_id else None)
    versions = session.execute(
        select(ProgramVersion).where(ProgramVersion.program_id == program_id).order_by(ProgramVersion.version_number)
    ).scalars().all()
    return [
        ProgramVersionOut(id=v.id, program_id=v.program_id, version_number=v.version_number, waypoint_data=v.waypoint_data, created_at=v.created_at)
        for v in versions
    ]
