"""app/routers/telemetry.py

Section 1.5/13.1: telemetry ingestion (stand-in for the MQTT path a real
Local Gateway Service would use -- see TelemetryIngestRequest's docstring)
and query (Section 13.1's "Remote Monitoring -- Fleet-wide live and
historical telemetry viewing").
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auth import TokenClaims, get_current_claims, require_permission
from ..db import get_session
from ..errors import NotFoundError
from ..models import Robot, Site, Telemetry
from ..schemas import TelemetryIngestRequest, TelemetryOut

router = APIRouter(prefix="/v1", tags=["telemetry"])


def _robot_scope_or_404(session: Session, claims: TokenClaims, robot_id: UUID) -> Robot:
    robot = session.get(Robot, robot_id)
    if robot is None:
        raise NotFoundError("robot not found")
    if robot.site_id is not None:
        site = session.get(Site, robot.site_id)
        if site is not None and str(site.org_id) != claims.org_id:
            raise NotFoundError("robot not found")
    return robot


@router.post("/robots/{robot_id}/telemetry", status_code=202)
def ingest_telemetry(
    robot_id: UUID,
    req: TelemetryIngestRequest,
    claims: TokenClaims = Depends(get_current_claims),
    session: Session = Depends(get_session),
):
    robot = _robot_scope_or_404(session, claims, robot_id)
    require_permission(claims, "telemetry:ingest", robot_id=str(robot_id), site_id=str(robot.site_id) if robot.site_id else None)

    now = datetime.now(timezone.utc)
    rows = [
        Telemetry(
            time=sample.time or now,
            robot_id=robot_id,
            metric_name=sample.metric_name,
            value=sample.value,
            quality_flag=sample.quality_flag,
        )
        for sample in req.samples
    ]
    session.add_all(rows)
    session.commit()
    return {"accepted": len(rows)}


@router.get("/robots/{robot_id}/telemetry", response_model=list[TelemetryOut])
def query_telemetry(
    robot_id: UUID,
    metric_name: Optional[str] = None,
    since: Optional[datetime] = None,
    until: Optional[datetime] = None,
    limit: int = 1000,
    claims: TokenClaims = Depends(get_current_claims),
    session: Session = Depends(get_session),
):
    robot = _robot_scope_or_404(session, claims, robot_id)
    require_permission(claims, "dashboard:view", robot_id=str(robot_id), site_id=str(robot.site_id) if robot.site_id else None)

    query = select(Telemetry).where(Telemetry.robot_id == robot_id)
    if metric_name is not None:
        query = query.where(Telemetry.metric_name == metric_name)
    if since is not None:
        query = query.where(Telemetry.time >= since)
    if until is not None:
        query = query.where(Telemetry.time <= until)
    query = query.order_by(Telemetry.time.desc()).limit(min(limit, 5000))

    rows = session.execute(query).scalars().all()
    return [TelemetryOut(time=r.time, robot_id=r.robot_id, metric_name=r.metric_name, value=r.value, quality_flag=r.quality_flag) for r in rows]
