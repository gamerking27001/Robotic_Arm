"""app/routers/alerts.py

Section 4.2 (health score) / Section 8's AI services describe alerts as the
output of continuous monitoring against thresholds or learned models; this
router implements the threshold half generically: Section 17.1's
ALERT_RULES table (metric_name, condition, severity) plus an /evaluate
endpoint that checks a robot's most recent telemetry against every rule and
raises an Alert for any that's violated (Section 3.4's "notification
center surfaces alarms").

/evaluate is called on demand here rather than on a schedule -- a real
deployment would run it periodically (or trigger it from the ingestion
path itself) via a scheduler/worker process, which is out of scope for
this deliverable (see cloud_platform/README.md).
"""
from __future__ import annotations

import re
from uuid import UUID

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auth import TokenClaims, get_current_claims, require_permission
from ..db import get_session
from ..errors import NotFoundError, ValidationError
from ..models import Alert, AlertRule, AlertSeverity, Robot, Site, Telemetry
from ..schemas import AlertOut, AlertRuleCreate, AlertRuleOut

router = APIRouter(prefix="/v1", tags=["alerts"])

_CONDITION_RE = re.compile(r"^\s*(>=|<=|>|<|==)\s*(-?\d+(?:\.\d+)?)\s*$")


def evaluate_condition(condition: str, value: float) -> bool:
    """Parses a tiny threshold DSL: "> 80", "<= 0.5", "== 1", etc. -- the
    ALERT_RULES.condition column is a plain string per the Section 17.1
    ERD, and this is the simplest evaluator that can actually interpret
    one; a production system would likely want a richer rule language
    (multi-metric conditions, hysteresis), out of scope here."""
    match = _CONDITION_RE.match(condition)
    if not match:
        raise ValidationError(f"unparseable alert condition: {condition!r} (expected e.g. '> 80', '<= 0.5')")
    op, threshold_s = match.group(1), match.group(2)
    threshold = float(threshold_s)
    if op == ">":
        return value > threshold
    if op == ">=":
        return value >= threshold
    if op == "<":
        return value < threshold
    if op == "<=":
        return value <= threshold
    return value == threshold


def _robot_scope_or_404(session: Session, claims: TokenClaims, robot_id: UUID) -> Robot:
    robot = session.get(Robot, robot_id)
    if robot is None:
        raise NotFoundError("robot not found")
    if robot.site_id is not None:
        site = session.get(Site, robot.site_id)
        if site is not None and str(site.org_id) != claims.org_id:
            raise NotFoundError("robot not found")
    return robot


@router.post("/alert-rules", response_model=AlertRuleOut)
def create_alert_rule(req: AlertRuleCreate, claims: TokenClaims = Depends(get_current_claims), session: Session = Depends(get_session)):
    require_permission(claims, "alert_rule:create")
    try:
        severity = AlertSeverity(req.severity)
    except ValueError as exc:
        raise ValidationError(f"unknown severity: {req.severity}") from exc
    evaluate_condition(req.condition, 0.0)  # validate the condition parses, without needing a real value yet
    rule = AlertRule(metric_name=req.metric_name, condition=req.condition, severity=severity)
    session.add(rule)
    session.commit()
    session.refresh(rule)
    return AlertRuleOut(id=rule.id, metric_name=rule.metric_name, condition=rule.condition, severity=rule.severity.value)


@router.get("/alert-rules", response_model=list[AlertRuleOut])
def list_alert_rules(claims: TokenClaims = Depends(get_current_claims), session: Session = Depends(get_session)):
    require_permission(claims, "dashboard:view")
    rules = session.execute(select(AlertRule)).scalars().all()
    return [AlertRuleOut(id=r.id, metric_name=r.metric_name, condition=r.condition, severity=r.severity.value) for r in rules]


@router.post("/robots/{robot_id}/alerts/evaluate", response_model=list[AlertOut])
def evaluate_alerts(robot_id: UUID, claims: TokenClaims = Depends(get_current_claims), session: Session = Depends(get_session)):
    robot = _robot_scope_or_404(session, claims, robot_id)
    require_permission(claims, "dashboard:view", robot_id=str(robot_id), site_id=str(robot.site_id) if robot.site_id else None)

    rules = session.execute(select(AlertRule)).scalars().all()
    newly_raised: list[Alert] = []

    for rule in rules:
        latest = session.execute(
            select(Telemetry)
            .where(Telemetry.robot_id == robot_id, Telemetry.metric_name == rule.metric_name)
            .order_by(Telemetry.time.desc())
            .limit(1)
        ).scalar_one_or_none()
        if latest is None:
            continue
        if not evaluate_condition(rule.condition, latest.value):
            continue

        # Don't raise a duplicate alert for a rule that already has an
        # unacknowledged open alert on this robot -- evaluate_alerts can be
        # called repeatedly (e.g. once per ingestion batch) without
        # flooding the alert list.
        already_open = session.execute(
            select(Alert).where(Alert.robot_id == robot_id, Alert.rule_id == rule.id, Alert.acknowledged_at.is_(None))
        ).scalar_one_or_none()
        if already_open is not None:
            continue

        alert = Alert(robot_id=robot_id, rule_id=rule.id, severity=rule.severity)
        session.add(alert)
        newly_raised.append(alert)

    session.commit()
    for a in newly_raised:
        session.refresh(a)
    return [
        AlertOut(id=a.id, robot_id=a.robot_id, rule_id=a.rule_id, severity=a.severity.value, triggered_at=a.triggered_at, acknowledged_at=a.acknowledged_at)
        for a in newly_raised
    ]


@router.get("/robots/{robot_id}/alerts", response_model=list[AlertOut])
def list_alerts(robot_id: UUID, claims: TokenClaims = Depends(get_current_claims), session: Session = Depends(get_session)):
    robot = _robot_scope_or_404(session, claims, robot_id)
    require_permission(claims, "dashboard:view", robot_id=str(robot_id), site_id=str(robot.site_id) if robot.site_id else None)
    alerts = session.execute(select(Alert).where(Alert.robot_id == robot_id).order_by(Alert.triggered_at.desc())).scalars().all()
    return [
        AlertOut(id=a.id, robot_id=a.robot_id, rule_id=a.rule_id, severity=a.severity.value, triggered_at=a.triggered_at, acknowledged_at=a.acknowledged_at)
        for a in alerts
    ]


@router.post("/alerts/{alert_id}/acknowledge", response_model=AlertOut)
def acknowledge_alert(alert_id: UUID, claims: TokenClaims = Depends(get_current_claims), session: Session = Depends(get_session)):
    from datetime import datetime, timezone

    alert = session.get(Alert, alert_id)
    if alert is None:
        raise NotFoundError("alert not found")
    robot = _robot_scope_or_404(session, claims, alert.robot_id)
    require_permission(claims, "alarm:acknowledge", robot_id=str(robot.id), site_id=str(robot.site_id) if robot.site_id else None)
    alert.acknowledged_at = datetime.now(timezone.utc)
    session.commit()
    session.refresh(alert)
    return AlertOut(id=alert.id, robot_id=alert.robot_id, rule_id=alert.rule_id, severity=alert.severity.value, triggered_at=alert.triggered_at, acknowledged_at=alert.acknowledged_at)
