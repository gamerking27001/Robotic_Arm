"""app/models.py

SQLAlchemy models for the section 17.1 database schema. Field-for-field
mapping to the source ERD (ORGANIZATIONS, SITES, ROBOTS, USERS,
ROLE_ASSIGNMENTS, PROGRAMS, PROGRAM_VERSIONS, ALERTS, ALERT_RULES) plus a
small number of documented additions where the ERD's extracted field list
is incomplete for the relationships the same section's prose describes.
Every addition is called out below rather than silently introduced -- same
convention the rest of this repo uses for gaps in its source document(s).

Documented gaps and how they're filled:

1. `robots.brand` -- the source PDF extracts this column as "hazard_brand",
   which doesn't correspond to anything section 13/17 discusses (no hazard
   classification field appears anywhere else in the spec). Read as an
   OCR/extraction artifact of "brand" (section 2's whole "brand-agnostic"
   theme, and the ERD's own `model` column right next to it), not
   implemented literally.

2. `robots.site_id` -- the ERD's relationship list includes a
   "ROBOTS located_at SITES"-shaped edge (see section 17.1's relationship
   labels: generates/located_at/stores/raises/belongs_to/belongs_to/has/
   scoped_to/has/triggered_by), but the extracted ROBOTS column list has no
   site_id foreign key. Added because "a robot located at a site" needs a
   column to express that.

3. `alerts.rule_id` -- similarly, the relationship list's "triggered_by"
   edge only makes sense as ALERTS -> ALERT_RULES, but ALERTS' extracted
   column list has no rule_id. Added (nullable -- not every alert need come
   from a static rule; section 8.10's anomaly-detection AI can raise one
   directly).

4. `users.password_hash` -- the ERD lists `auth_method` (e.g. "password",
   "sso") but no credential field. Section 12.1 requires "password + TOTP
   multi-factor authentication" to be verifiable against *something*.
   Added as nullable (SSO-authenticated users have no local password).

5. `role_assignments.site_id` -- the ERD's ROLE_ASSIGNMENTS table has only
   `robot_id`, but section 3.3 explicitly states roles are "scoped
   per-robot and per-site". Added (nullable) alongside `robot_id` (also
   nullable) so a role assignment can be robot-scoped, site-scoped, or
   org-wide (both null) -- see app/auth.py's scope-checking logic.

6. `command_requests` -- not in the ERD at all. Section 17.2 requires
   "idempotent command endpoints ... carry a client-generated request ID,
   so a retried request after a network drop cannot double-execute a
   motion command". That needs a table to remember which request IDs have
   already been handled; see app/routers/robots.py's dispatch endpoint.

TimescaleDB note: `telemetry` is designed to become a TimescaleDB
hypertable (`SELECT create_hypertable('telemetry', 'time')`, per section
2.5's decision to use TimescaleDB for cloud time-series telemetry) -- this
sandbox's package sources don't include the TimescaleDB extension (only
plain PostgreSQL 16 + PostGIS were installable here), so it's tested here
as a plain table with a btree index on (robot_id, time), which is
schema-identical to a hypertable from every ORM/query-code's point of view;
create_hypertable() is a one-line addition for a real deployment with the
extension installed, not a schema change.
"""
from __future__ import annotations

import enum
import uuid
from datetime import datetime

from geoalchemy2 import Geography
from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Index,
    String,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.sql import func


class Base(DeclarativeBase):
    pass


def _uuid_pk() -> Mapped[uuid.UUID]:
    return mapped_column(UUID(as_uuid=True), primary_key=True, server_default=func.gen_random_uuid())


class SubscriptionTier(str, enum.Enum):
    starter = "starter"
    growth = "growth"
    enterprise = "enterprise"


class Organization(Base):
    __tablename__ = "organizations"

    id: Mapped[uuid.UUID] = _uuid_pk()
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    subscription_tier: Mapped[SubscriptionTier] = mapped_column(
        Enum(SubscriptionTier, native_enum=False, length=20), nullable=False, default=SubscriptionTier.starter
    )

    sites: Mapped[list["Site"]] = relationship(back_populates="organization", cascade="all, delete-orphan")
    users: Mapped[list["User"]] = relationship(back_populates="organization", cascade="all, delete-orphan")


class Site(Base):
    __tablename__ = "sites"

    id: Mapped[uuid.UUID] = _uuid_pk()
    org_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    # Geography, not geometry (per section 2.5's decision: PostGIS geography
    # types for spatial queries like "all robots within this facility") --
    # geography does great-circle distance math, correct for real-world
    # lat/lng, unlike geometry which assumes a flat plane.
    address: Mapped[str | None] = mapped_column(Geography(geometry_type="POINT", srid=4326), nullable=True)

    organization: Mapped[Organization] = relationship(back_populates="sites")
    robots: Mapped[list["Robot"]] = relationship(back_populates="site")


class RobotStatus(str, enum.Enum):
    registered = "registered"
    online = "online"
    offline = "offline"
    fault = "fault"
    decommissioned = "decommissioned"


class Robot(Base):
    __tablename__ = "robots"

    id: Mapped[uuid.UUID] = _uuid_pk()
    site_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("sites.id", ondelete="SET NULL"), nullable=True)
    # KNOWN LIMITATION: a robot's org membership is derived entirely
    # transitively through site_id (robot -> site -> organization) -- the
    # ERD gives ROBOTS no direct org_id column, and site_id is nullable
    # (a robot can be registered before being assigned to a site, per
    # section 3.2's onboarding flow). Consequence: an unassigned robot
    # (site_id IS NULL) is not scoped to any organization and is currently
    # visible to any authenticated user of *any* org -- see
    # routers/robots.py's `_check_robot_scope()`, which only enforces
    # isolation once site_id is set, and
    # tests/test_robots.py::test_robot_from_other_org_is_not_visible,
    # which asserts this behavior explicitly rather than leaving it an
    # undocumented surprise. A real deployment should either make site_id
    # non-nullable (require a site at registration) or add a direct org_id
    # column; neither is done here since it would mean deviating further
    # from the ERD's stated ROBOTS columns than the documented gap-fills
    # above already do.
    brand: Mapped[str] = mapped_column(String(100), nullable=False)  # see module docstring, gap #1
    model: Mapped[str] = mapped_column(String(100), nullable=False)
    location: Mapped[str | None] = mapped_column(Geography(geometry_type="POINT", srid=4326), nullable=True)
    registered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    status: Mapped[RobotStatus] = mapped_column(Enum(RobotStatus, native_enum=False, length=20), nullable=False, default=RobotStatus.registered)

    site: Mapped[Site | None] = relationship(back_populates="robots")
    programs: Mapped[list["Program"]] = relationship(back_populates="robot", cascade="all, delete-orphan")
    alerts: Mapped[list["Alert"]] = relationship(back_populates="robot", cascade="all, delete-orphan")
    role_assignments: Mapped[list["RoleAssignment"]] = relationship(back_populates="robot")


class Telemetry(Base):
    """TimescaleDB-hypertable-shaped telemetry table -- see module
    docstring. One row per (robot, metric, timestamp) sample, matching
    section 4.1's per-parameter telemetry model (joint angles, current,
    torque, temperature, health score, ... each as its own
    metric_name/value pair) rather than one wide row per robot per tick --
    this is what makes the schema hypertable-friendly (append-only,
    time-ordered, no UPDATEs)."""

    __tablename__ = "telemetry"
    __table_args__ = (Index("ix_telemetry_robot_time", "robot_id", "time"),)

    # No single-column primary key: TimescaleDB hypertables require the
    # partitioning column (time) in any uniqueness constraint, and this
    # table has no natural single-column key anyway (a robot can report
    # many metrics at the same instant) -- composite PK instead.
    time: Mapped[datetime] = mapped_column(DateTime(timezone=True), primary_key=True)
    robot_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("robots.id", ondelete="CASCADE"), primary_key=True, nullable=False
    )
    metric_name: Mapped[str] = mapped_column(String(100), primary_key=True, nullable=False)
    value: Mapped[float] = mapped_column(Float, nullable=False)
    quality_flag: Mapped[str] = mapped_column(String(20), nullable=False, default="good")


class Program(Base):
    __tablename__ = "programs"

    id: Mapped[uuid.UUID] = _uuid_pk()
    robot_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("robots.id", ondelete="CASCADE"), nullable=False)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    current_version_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("program_versions.id", ondelete="SET NULL", use_alter=True, name="fk_programs_current_version_id"),
        nullable=True,
    )

    robot: Mapped[Robot] = relationship(back_populates="programs")
    versions: Mapped[list["ProgramVersion"]] = relationship(
        back_populates="program", foreign_keys="ProgramVersion.program_id", cascade="all, delete-orphan"
    )


class ProgramVersion(Base):
    __tablename__ = "program_versions"
    __table_args__ = (UniqueConstraint("program_id", "version_number", name="uq_program_version_number"),)

    id: Mapped[uuid.UUID] = _uuid_pk()
    program_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("programs.id", ondelete="CASCADE"), nullable=False)
    version_number: Mapped[int] = mapped_column(nullable=False)
    # Section 17.1: "stores each program revision's waypoint data as jsonb,
    # giving version history without a separate document store." Shape
    # matches motion_planner's Program/Waypoint model (planner/program.py)
    # closely enough to round-trip through it, but this table doesn't
    # import that module -- cloud_platform and motion_planner stay
    # independently deployable (same reasoning as digital_twin/
    # motion_planner's own service-independence notes), so the JSON shape
    # is just documented convention here, not enforced by a shared type.
    waypoint_data: Mapped[dict] = mapped_column(JSONB, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    program: Mapped[Program] = relationship(back_populates="versions", foreign_keys=[program_id])


class AlertSeverity(str, enum.Enum):
    info = "info"
    warning = "warning"
    critical = "critical"


class AlertRule(Base):
    __tablename__ = "alert_rules"

    id: Mapped[uuid.UUID] = _uuid_pk()
    metric_name: Mapped[str] = mapped_column(String(100), nullable=False)
    condition: Mapped[str] = mapped_column(String(200), nullable=False)  # e.g. "> 80", "< 0.5" -- see routers/alerts.py evaluator
    severity: Mapped[AlertSeverity] = mapped_column(Enum(AlertSeverity, native_enum=False, length=20), nullable=False)

    alerts: Mapped[list["Alert"]] = relationship(back_populates="rule")


class Alert(Base):
    __tablename__ = "alerts"

    id: Mapped[uuid.UUID] = _uuid_pk()
    robot_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("robots.id", ondelete="CASCADE"), nullable=False)
    rule_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("alert_rules.id", ondelete="SET NULL"), nullable=True
    )  # see module docstring, gap #3
    severity: Mapped[AlertSeverity] = mapped_column(Enum(AlertSeverity, native_enum=False, length=20), nullable=False)
    triggered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    acknowledged_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    robot: Mapped[Robot] = relationship(back_populates="alerts")
    rule: Mapped[AlertRule | None] = relationship(back_populates="alerts")


class User(Base):
    __tablename__ = "users"

    id: Mapped[uuid.UUID] = _uuid_pk()
    org_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False)
    email: Mapped[str] = mapped_column(String(320), nullable=False, unique=True)
    auth_method: Mapped[str] = mapped_column(String(20), nullable=False, default="password")
    password_hash: Mapped[str | None] = mapped_column(String(200), nullable=True)  # see module docstring, gap #4

    organization: Mapped[Organization] = relationship(back_populates="users")
    role_assignments: Mapped[list["RoleAssignment"]] = relationship(back_populates="user", cascade="all, delete-orphan")


class Role(str, enum.Enum):
    """Section 3.3's five roles, exactly."""

    operator = "operator"
    programmer = "programmer"
    developer_integrator = "developer_integrator"
    maintenance_technician = "maintenance_technician"
    fleet_administrator = "fleet_administrator"


class RoleAssignment(Base):
    __tablename__ = "role_assignments"

    id: Mapped[uuid.UUID] = _uuid_pk()
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    robot_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("robots.id", ondelete="CASCADE"), nullable=True)
    site_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("sites.id", ondelete="CASCADE"), nullable=True
    )  # see module docstring, gap #5
    role: Mapped[Role] = mapped_column(Enum(Role, native_enum=False, length=30), nullable=False)

    user: Mapped[User] = relationship(back_populates="role_assignments")
    robot: Mapped[Robot | None] = relationship(back_populates="role_assignments")


class CommandRequest(Base):
    """Idempotency ledger for section 17.2's "idempotent command endpoints
    ... carry a client-generated request ID" rule -- see module docstring
    gap #6 and app/routers/robots.py's dispatch endpoint."""

    __tablename__ = "command_requests"
    __table_args__ = (UniqueConstraint("robot_id", "request_id", name="uq_command_request"),)

    id: Mapped[uuid.UUID] = _uuid_pk()
    robot_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("robots.id", ondelete="CASCADE"), nullable=False)
    request_id: Mapped[str] = mapped_column(String(100), nullable=False)  # client-generated
    command_type: Mapped[str] = mapped_column(String(50), nullable=False)
    payload: Mapped[dict] = mapped_column(JSONB, nullable=False)
    result: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    accepted: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
