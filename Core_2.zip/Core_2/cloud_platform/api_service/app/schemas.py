"""app/schemas.py -- Pydantic request/response models."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Optional
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field


# --- Organizations / Sites ---------------------------------------------------


class OrganizationCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    subscription_tier: str = "starter"


class OrganizationOut(BaseModel):
    id: UUID
    name: str
    subscription_tier: str

    model_config = {"from_attributes": True}


class SiteCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    latitude: Optional[float] = None
    longitude: Optional[float] = None


class SiteOut(BaseModel):
    id: UUID
    org_id: UUID
    name: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None


# --- Users / Auth ------------------------------------------------------------


class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=200)


class UserOut(BaseModel):
    id: UUID
    org_id: UUID
    email: str
    auth_method: str

    model_config = {"from_attributes": True}


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in_s: float


class RoleAssignmentCreate(BaseModel):
    user_id: UUID
    role: str
    robot_id: Optional[UUID] = None
    site_id: Optional[UUID] = None


class RoleAssignmentOut(BaseModel):
    id: UUID
    user_id: UUID
    role: str
    robot_id: Optional[UUID] = None
    site_id: Optional[UUID] = None


# --- Robots -------------------------------------------------------------------


class RobotRegisterRequest(BaseModel):
    """Section 3.2: "Robot Registration -- Onboarding wizard binds a
    physical robot's identity (serial number, brand/model, network
    address) to a platform record." No serial-number/network-address
    field exists in the Section 17.1 ERD's ROBOTS columns, so this
    endpoint accepts exactly the ERD's fields (brand/model/site/location)
    -- not extended beyond that."""

    site_id: Optional[UUID] = None
    brand: str = Field(..., min_length=1, max_length=100)
    model: str = Field(..., min_length=1, max_length=100)
    latitude: Optional[float] = None
    longitude: Optional[float] = None


class RobotOut(BaseModel):
    id: UUID
    site_id: Optional[UUID] = None
    brand: str
    model: str
    status: str
    registered_at: datetime
    latitude: Optional[float] = None
    longitude: Optional[float] = None


class RobotStatusUpdate(BaseModel):
    status: str


# --- Telemetry ----------------------------------------------------------------


class TelemetrySampleIn(BaseModel):
    metric_name: str = Field(..., min_length=1, max_length=100)
    value: float
    quality_flag: str = "good"
    time: Optional[datetime] = None  # defaults to server now() if omitted


class TelemetryIngestRequest(BaseModel):
    """A Local Gateway Service would batch many samples per publish (see
    Section 1.5: "the local Gateway batches and forwards telemetry to the
    cloud over MQTT") -- this HTTP endpoint is this codebase's stand-in for
    that MQTT ingestion path (no message broker in this sandbox; see
    cloud_platform/README.md), accepting the same batched-samples shape a
    real MQTT consumer would hand off to the ingestion service after
    deserializing a batch."""

    samples: list[TelemetrySampleIn] = Field(..., min_length=1, max_length=1000)


class TelemetryOut(BaseModel):
    time: datetime
    robot_id: UUID
    metric_name: str
    value: float
    quality_flag: str


# --- Alerts / Alert Rules -----------------------------------------------------


class AlertRuleCreate(BaseModel):
    metric_name: str = Field(..., min_length=1, max_length=100)
    condition: str = Field(..., min_length=1, max_length=200)
    severity: str


class AlertRuleOut(BaseModel):
    id: UUID
    metric_name: str
    condition: str
    severity: str


class AlertOut(BaseModel):
    id: UUID
    robot_id: UUID
    rule_id: Optional[UUID]
    severity: str
    triggered_at: datetime
    acknowledged_at: Optional[datetime]


class AlertAcknowledgeRequest(BaseModel):
    pass


# --- Programs / Program Versions ----------------------------------------------


class ProgramCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)


class ProgramOut(BaseModel):
    id: UUID
    robot_id: UUID
    name: str
    current_version_id: Optional[UUID]


class ProgramVersionCreate(BaseModel):
    waypoint_data: dict[str, Any]
    set_as_current: bool = True


class ProgramVersionOut(BaseModel):
    id: UUID
    program_id: UUID
    version_number: int
    waypoint_data: dict[str, Any]
    created_at: datetime


# --- Idempotent command dispatch (Section 17.2) -------------------------------


class DispatchProgramRequest(BaseModel):
    request_id: str = Field(..., min_length=1, max_length=100)
    program_version_id: UUID


class DispatchProgramResponse(BaseModel):
    request_id: str
    accepted: bool
    replayed: bool  # True if this request_id had already been handled -- see routers/robots.py
    result: dict[str, Any]
