"""app/auth.py

Section 12.1: "Cloud accounts use password + TOTP multi-factor
authentication ... session and API authorization uses JWT tokens scoped to
the role-based permission model defined in Section 3.3."

Section 17.2: "Least-privilege scoping -- Every API token is scoped to a
role and a robot/site set (Section 3.3, Section 12.4) at the token level,
not just enforced in application logic, so a compromised token has bounded
blast radius."

That "at the token level" requirement is the reason the JWT's payload
embeds the user's role assignments as they existed *at issuance time*
(`scopes`, below) rather than the token being a bare user-id reference that
every endpoint re-resolves against the current role_assignments table: a
stolen token is bounded by what it was issued for, and (deliberately) an
admin revoking/changing someone's roles doesn't retroactively narrow
already-issued tokens before they expire -- consistent with a short
DEFAULT_TOKEN_TTL and matches how most bearer-token systems actually work.

TOTP itself (the second factor) is out of scope for this deliverable -- see
cloud_platform/README.md's scope note; password verification and JWT
issuance/scoping are implemented and tested.
"""
from __future__ import annotations

import os
import time
import uuid
from dataclasses import dataclass
from typing import Optional

from fastapi import Header
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from .errors import PermissionError_, UnauthenticatedError
from .models import Role, RoleAssignment, User

_pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

JWT_ALGORITHM = "HS256"
DEFAULT_TOKEN_TTL_S = 3600.0


def _jwt_secret() -> str:
    secret = os.environ.get("CLOUD_PLATFORM_JWT_SECRET")
    if not secret:
        raise RuntimeError("CLOUD_PLATFORM_JWT_SECRET must be set")
    return secret


def hash_password(plain: str) -> str:
    return _pwd_context.hash(plain)


def verify_password(plain: str, hashed: str) -> bool:
    return _pwd_context.verify(plain, hashed)


@dataclass(frozen=True)
class ScopeClaim:
    role: Role
    robot_id: Optional[str]  # str(uuid), or None for site-wide/org-wide
    site_id: Optional[str]


@dataclass(frozen=True)
class TokenClaims:
    user_id: str
    org_id: str
    scopes: tuple[ScopeClaim, ...]
    issued_at: float
    expires_at: float


def issue_access_token(user: User, role_assignments: list[RoleAssignment], ttl_s: float = DEFAULT_TOKEN_TTL_S) -> str:
    now = time.time()
    payload = {
        "sub": str(user.id),
        "org_id": str(user.org_id),
        "scopes": [
            {
                "role": ra.role.value if isinstance(ra.role, Role) else ra.role,
                "robot_id": str(ra.robot_id) if ra.robot_id else None,
                "site_id": str(ra.site_id) if ra.site_id else None,
            }
            for ra in role_assignments
        ],
        "iat": now,
        "exp": now + ttl_s,
        "jti": uuid.uuid4().hex,  # unique per token; not tracked for revocation here, but present for that future extension
    }
    return jwt.encode(payload, _jwt_secret(), algorithm=JWT_ALGORITHM)


def decode_access_token(token: str) -> TokenClaims:
    try:
        payload = jwt.decode(token, _jwt_secret(), algorithms=[JWT_ALGORITHM])
    except JWTError as exc:
        raise UnauthenticatedError("invalid or expired token") from exc

    scopes = tuple(
        ScopeClaim(role=Role(s["role"]), robot_id=s.get("robot_id"), site_id=s.get("site_id"))
        for s in payload.get("scopes", [])
    )
    return TokenClaims(
        user_id=payload["sub"],
        org_id=payload["org_id"],
        scopes=scopes,
        issued_at=payload["iat"],
        expires_at=payload["exp"],
    )


def get_current_claims(authorization: Optional[str] = Header(default=None)) -> TokenClaims:
    """FastAPI dependency. Expects `Authorization: Bearer <token>`."""
    if not authorization or not authorization.lower().startswith("bearer "):
        raise UnauthenticatedError("missing Authorization: Bearer <token> header")
    token = authorization.split(" ", 1)[1].strip()
    return decode_access_token(token)


# --- Section 3.3's permission matrix ----------------------------------------

# Each role's allowed actions, exactly matching Section 3.3's table.
# "*" means every action defined anywhere in this map.
_ROLE_PERMISSIONS: dict[Role, set[str]] = {
    Role.operator: {
        "program:run",
        "dashboard:view",
        "alarm:acknowledge",
    },
    Role.programmer: {
        "program:run",
        "dashboard:view",
        "alarm:acknowledge",
        "program:create",
        "program:edit",
        "simulation:run",
    },
    Role.developer_integrator: {
        "program:run",
        "dashboard:view",
        "alarm:acknowledge",
        "program:create",
        "program:edit",
        "simulation:run",
        "lowlevel:control",
        "calibration:perform",
        "firmware:update",
    },
    Role.maintenance_technician: {
        "diagnostics:view",
        "telemetry:history:view",
        "alarm:acknowledge",
    },
    Role.fleet_administrator: {"*"},
}


def role_has_permission(role: Role, action: str) -> bool:
    allowed = _ROLE_PERMISSIONS.get(role, set())
    return "*" in allowed or action in allowed


def require_permission(claims: TokenClaims, action: str, *, robot_id: Optional[str] = None, site_id: Optional[str] = None) -> None:
    """Raises PermissionError_ unless at least one of the token's scopes
    both (a) grants `action` for its role and (b) matches the target
    resource: a scope with robot_id=None and site_id=None is org-wide, one
    with only site_id set covers every robot at that site, one with
    robot_id set covers exactly that robot -- matching Section 3.3's
    "scoped per-robot and per-site" wording literally, not just per-robot."""
    for scope in claims.scopes:
        if not role_has_permission(scope.role, action):
            continue
        if scope.robot_id is None and scope.site_id is None:
            return  # org-wide grant for this role
        if robot_id is not None and scope.robot_id == robot_id:
            return
        if site_id is not None and scope.site_id == site_id:
            return
        if robot_id is None and site_id is None:
            # Action isn't robot/site-specific (e.g. "create an
            # organization-level resource") -- any matching-role scope,
            # regardless of its own robot/site restriction, satisfies a
            # request that itself names no specific robot/site.
            return
    raise PermissionError_(f"role/scope does not grant '{action}' for the requested resource")
