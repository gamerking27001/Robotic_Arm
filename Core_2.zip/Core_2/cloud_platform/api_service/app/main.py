"""app/main.py

Cloud Platform API (platform spec Section 13, Section 17). See
../../README.md for architecture, scope, and run instructions.

Run:
    export CLOUD_PLATFORM_DATABASE_URL=postgresql+psycopg2://postgres:postgres@localhost:5432/cloud_platform
    export CLOUD_PLATFORM_JWT_SECRET=...
    uvicorn app.main:app --port 8300
"""
from __future__ import annotations

import logging
import os

from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .db import init_db
from .errors import ApiError
from .routers import alerts, orgs, programs, robots, telemetry

logging.basicConfig(
    level=os.environ.get("CLOUD_PLATFORM_LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
logger = logging.getLogger("cloud_platform.api")

@asynccontextmanager
async def lifespan(app: FastAPI):
    if os.environ.get("CLOUD_PLATFORM_SKIP_INIT_DB") != "1":
        init_db()
    yield


app = FastAPI(title="Cloud Platform API", version="0.1.0", lifespan=lifespan)

_cors_origins = [o.strip() for o in os.environ.get("CLOUD_PLATFORM_CORS_ORIGINS", "").split(",") if o.strip()]
if _cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PATCH", "DELETE"],
        allow_headers=["Authorization", "Content-Type"],
    )


@app.exception_handler(ApiError)
async def api_error_handler(request: Request, exc: ApiError) -> JSONResponse:
    # ApiError.detail is already {"error_code", "message", "details"}
    # (see errors.py) -- this handler exists only so the response body is
    # exactly that shape and nothing else (FastAPI's default HTTPException
    # handler wraps `detail` in {"detail": ...}, which would nest it one
    # level deeper than the Section 17.2 error taxonomy calls for).
    return JSONResponse(status_code=exc.status_code, content=exc.detail)


@app.get("/healthz")
def healthz():
    return {"status": "ok"}


app.include_router(orgs.router)
app.include_router(robots.router)
app.include_router(telemetry.router)
app.include_router(programs.router)
app.include_router(alerts.router)
