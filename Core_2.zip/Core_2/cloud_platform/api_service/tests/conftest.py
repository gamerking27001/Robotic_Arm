"""tests/conftest.py

Runs against a real PostgreSQL + PostGIS database (CLOUD_PLATFORM_DATABASE_URL,
defaulting to a local `cloud_platform_test` database -- see ../README.md for
setup) -- not SQLite or a mock. Each test gets a clean schema: rather than
per-test transactions/rollback (which doesn't compose well with the app's
own session-per-request commits), every test drops and recreates the public
schema, which is fast enough for this table count and keeps tests fully
isolated from each other and from the dev database (`cloud_platform`).
"""
import os

os.environ.setdefault("CLOUD_PLATFORM_JWT_SECRET", "test-jwt-secret")
os.environ.setdefault(
    "CLOUD_PLATFORM_DATABASE_URL",
    "postgresql+psycopg2://postgres:postgres@localhost:5432/cloud_platform_test",
)

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text

from app.db import engine, init_db
from app.main import app


@pytest.fixture(autouse=True)
def clean_schema():
    with engine.begin() as conn:
        conn.execute(text("DROP SCHEMA public CASCADE"))
        conn.execute(text("CREATE SCHEMA public"))
    init_db()
    yield


@pytest.fixture()
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture()
def org_and_admin(client: TestClient):
    """Creates an organization and its (auto-admin) first user, logs in,
    and returns (client, org_id, headers) -- the setup nearly every
    endpoint test needs, so it isn't repeated in every test function."""
    org = client.post("/v1/organizations", json={"name": "Test Org"}).json()
    client.post(
        f"/v1/organizations/{org['id']}/users", json={"email": "admin@test.com", "password": "supersecret123"}
    )
    login = client.post("/v1/auth/login", json={"email": "admin@test.com", "password": "supersecret123"})
    token = login.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    return client, org["id"], headers


@pytest.fixture()
def registered_robot(org_and_admin):
    client, org_id, headers = org_and_admin
    resp = client.post(f"/v1/organizations/{org_id}/robots", json={"brand": "GenericArm", "model": "GA-6DOF-v1"}, headers=headers)
    return client, org_id, headers, resp.json()["id"]
