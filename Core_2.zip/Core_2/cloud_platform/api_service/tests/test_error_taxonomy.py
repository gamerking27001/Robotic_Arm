"""Section 17.2: "A small, consistent error-code set (validation,
permission, not-found, conflict, robot-unreachable, robot-rejected) is used
across all services" -- checks the response *shape* is identical regardless
of which endpoint/error fired, and that each code the API actually surfaces
maps to its documented HTTP status."""


def _assert_shape(resp, error_code, status_code):
    assert resp.status_code == status_code
    body = resp.json()
    assert body["error_code"] == error_code
    assert "message" in body and isinstance(body["message"], str)
    assert "details" in body and isinstance(body["details"], dict)


def test_validation_error_shape(org_and_admin):
    client, org_id, headers = org_and_admin
    resp = client.post("/v1/alert-rules", json={"metric_name": "x", "condition": "garbage", "severity": "warning"}, headers=headers)
    _assert_shape(resp, "validation", 422)


def test_not_found_error_shape(org_and_admin):
    client, org_id, headers = org_and_admin
    resp = client.get("/v1/robots/00000000-0000-0000-0000-000000000000", headers=headers)
    _assert_shape(resp, "not_found", 404)


def test_unauthenticated_error_shape(client):
    resp = client.get("/v1/robots/00000000-0000-0000-0000-000000000000")
    _assert_shape(resp, "unauthenticated", 401)


def test_permission_error_shape(org_and_admin):
    """A non-admin role (operator) attempting an admin-only action
    (creating a role assignment) should get a 403 'permission' error, not
    a 401 (the credentials themselves are valid -- the role just doesn't
    grant this action)."""
    client, org_id, headers = org_and_admin

    # Create a second user and grant them only 'operator', scoped to a
    # specific (nonexistent, doesn't matter for this check) robot id.
    client.post(f"/v1/organizations/{org_id}/users", json={"email": "op@test.com", "password": "password123"}, headers=headers)
    op_login = client.post("/v1/auth/login", json={"email": "op@test.com", "password": "password123"})
    # The second user has *no* role assignments yet (create_user doesn't
    # grant one automatically past the first user) -- any permission check
    # should fail closed.
    op_headers = {"Authorization": f"Bearer {op_login.json()['access_token']}"}

    resp = client.post(
        f"/v1/organizations/{org_id}/role-assignments",
        json={"user_id": "11111111-1111-1111-1111-111111111111", "role": "operator"},
        headers=op_headers,
    )
    _assert_shape(resp, "permission", 403)
