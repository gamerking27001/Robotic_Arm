def test_ingest_and_query_telemetry(registered_robot):
    client, org_id, headers, robot_id = registered_robot
    resp = client.post(
        f"/v1/robots/{robot_id}/telemetry",
        json={"samples": [{"metric_name": "j1_torque_nm", "value": 12.5}, {"metric_name": "health_score", "value": 88.0}]},
        headers=headers,
    )
    assert resp.status_code == 202
    assert resp.json() == {"accepted": 2}

    resp = client.get(f"/v1/robots/{robot_id}/telemetry", headers=headers)
    assert resp.status_code == 200
    assert len(resp.json()) == 2


def test_query_filters_by_metric_name(registered_robot):
    client, org_id, headers, robot_id = registered_robot
    client.post(
        f"/v1/robots/{robot_id}/telemetry",
        json={"samples": [{"metric_name": "j1_torque_nm", "value": 1.0}, {"metric_name": "health_score", "value": 2.0}]},
        headers=headers,
    )
    resp = client.get(f"/v1/robots/{robot_id}/telemetry", params={"metric_name": "health_score"}, headers=headers)
    body = resp.json()
    assert len(body) == 1
    assert body[0]["metric_name"] == "health_score"


def test_ingest_rejects_empty_batch(registered_robot):
    client, org_id, headers, robot_id = registered_robot
    resp = client.post(f"/v1/robots/{robot_id}/telemetry", json={"samples": []}, headers=headers)
    assert resp.status_code == 422


def test_ingest_to_unknown_robot_404s(org_and_admin):
    client, org_id, headers = org_and_admin
    resp = client.post(
        "/v1/robots/00000000-0000-0000-0000-000000000000/telemetry",
        json={"samples": [{"metric_name": "x", "value": 1.0}]},
        headers=headers,
    )
    assert resp.status_code == 404
