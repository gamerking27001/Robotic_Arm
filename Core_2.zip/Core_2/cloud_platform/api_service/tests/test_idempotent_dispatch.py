"""Section 17.2: "Idempotent command endpoints -- Commands that affect
robot state (deploy program, trigger OTA) are idempotent and carry a
client-generated request ID, so a retried request after a network drop
cannot double-execute a motion command." """


def _program_version(client, robot_id, headers):
    program = client.post(f"/v1/robots/{robot_id}/programs", json={"name": "p"}, headers=headers).json()
    return client.post(f"/v1/programs/{program['id']}/versions", json={"waypoint_data": {"waypoints": []}}, headers=headers).json()


def test_first_dispatch_is_not_replayed(registered_robot):
    client, org_id, headers, robot_id = registered_robot
    version = _program_version(client, robot_id, headers)
    resp = client.post(
        f"/v1/robots/{robot_id}/commands/dispatch-program",
        json={"request_id": "req-abc", "program_version_id": version["id"]},
        headers=headers,
    )
    assert resp.status_code == 200
    assert resp.json()["replayed"] is False
    assert resp.json()["accepted"] is True


def test_retried_dispatch_with_same_request_id_is_replayed_not_reexecuted(registered_robot):
    client, org_id, headers, robot_id = registered_robot
    version = _program_version(client, robot_id, headers)
    body = {"request_id": "req-same", "program_version_id": version["id"]}

    first = client.post(f"/v1/robots/{robot_id}/commands/dispatch-program", json=body, headers=headers)
    second = client.post(f"/v1/robots/{robot_id}/commands/dispatch-program", json=body, headers=headers)

    assert first.json()["replayed"] is False
    assert second.json()["replayed"] is True
    # The replayed response is *exactly* the original result, not a fresh one.
    assert first.json()["result"] == second.json()["result"]


def test_different_request_ids_both_execute(registered_robot):
    client, org_id, headers, robot_id = registered_robot
    version = _program_version(client, robot_id, headers)
    r1 = client.post(
        f"/v1/robots/{robot_id}/commands/dispatch-program", json={"request_id": "req-1", "program_version_id": version["id"]}, headers=headers
    )
    r2 = client.post(
        f"/v1/robots/{robot_id}/commands/dispatch-program", json={"request_id": "req-2", "program_version_id": version["id"]}, headers=headers
    )
    assert r1.json()["replayed"] is False
    assert r2.json()["replayed"] is False


def test_same_request_id_different_robots_both_execute(org_and_admin):
    """The idempotency key is (robot_id, request_id), not request_id alone
    -- see models.py's UniqueConstraint -- so a client is free to reuse
    request IDs across different robots without them colliding."""
    client, org_id, headers = org_and_admin
    robot_a = client.post(f"/v1/organizations/{org_id}/robots", json={"brand": "X", "model": "Y"}, headers=headers).json()["id"]
    robot_b = client.post(f"/v1/organizations/{org_id}/robots", json={"brand": "X", "model": "Y"}, headers=headers).json()["id"]
    version_a = _program_version(client, robot_a, headers)
    version_b = _program_version(client, robot_b, headers)

    r1 = client.post(f"/v1/robots/{robot_a}/commands/dispatch-program", json={"request_id": "shared-id", "program_version_id": version_a["id"]}, headers=headers)
    r2 = client.post(f"/v1/robots/{robot_b}/commands/dispatch-program", json={"request_id": "shared-id", "program_version_id": version_b["id"]}, headers=headers)
    assert r1.json()["replayed"] is False
    assert r2.json()["replayed"] is False


def test_dispatch_with_unknown_program_version_rejected(registered_robot):
    client, org_id, headers, robot_id = registered_robot
    resp = client.post(
        f"/v1/robots/{robot_id}/commands/dispatch-program",
        json={"request_id": "req-x", "program_version_id": "00000000-0000-0000-0000-000000000000"},
        headers=headers,
    )
    assert resp.status_code == 422
    assert resp.json()["error_code"] == "validation"
