import pytest

from app.auth import (
    ScopeClaim,
    TokenClaims,
    decode_access_token,
    hash_password,
    issue_access_token,
    require_permission,
    role_has_permission,
    verify_password,
)
from app.errors import PermissionError_, UnauthenticatedError
from app.models import Role, RoleAssignment, User


def _fake_user(org_id="11111111-1111-1111-1111-111111111111"):
    u = User(email="x@test.com", org_id=org_id, auth_method="password")
    u.id = "22222222-2222-2222-2222-222222222222"
    return u


def test_password_hash_round_trip():
    hashed = hash_password("correct horse battery staple")
    assert verify_password("correct horse battery staple", hashed)
    assert not verify_password("wrong password", hashed)


def test_issue_and_decode_token_round_trip():
    user = _fake_user()
    ra = RoleAssignment(user_id=user.id, role=Role.operator, robot_id=None, site_id=None)
    token = issue_access_token(user, [ra], ttl_s=60)
    claims = decode_access_token(token)
    assert claims.user_id == str(user.id)
    assert claims.org_id == str(user.org_id)
    assert len(claims.scopes) == 1
    assert claims.scopes[0].role == Role.operator


def test_expired_token_rejected():
    """python-jose's exp check (_validate_exp) truncates both the token's
    exp claim and "now" to whole seconds via utctimetuple() -- there's no
    sub-second resolution, so a token that expired less than ~1 second ago
    can appear not-yet-expired depending on second-boundary timing. Using a
    clearly-in-the-past ttl_s (instead of a tiny positive ttl + a short
    sleep, which is exactly what hit that granularity limit here) makes
    this deterministic and avoids a real sleep."""
    user = _fake_user()
    token = issue_access_token(user, [], ttl_s=-5.0)
    with pytest.raises(UnauthenticatedError):
        decode_access_token(token)


def test_malformed_token_rejected():
    with pytest.raises(UnauthenticatedError):
        decode_access_token("not-a-real-jwt")


@pytest.mark.parametrize(
    "role,action,expected",
    [
        (Role.operator, "program:run", True),
        (Role.operator, "program:create", False),
        (Role.programmer, "program:create", True),
        (Role.programmer, "lowlevel:control", False),
        (Role.developer_integrator, "lowlevel:control", True),
        (Role.maintenance_technician, "diagnostics:view", True),
        (Role.maintenance_technician, "program:create", False),
        (Role.fleet_administrator, "anything:at:all", True),
    ],
)
def test_role_permission_matrix_matches_section_3_3(role, action, expected):
    assert role_has_permission(role, action) is expected


def test_require_permission_org_wide_scope_grants_any_robot():
    claims = TokenClaims(
        user_id="u", org_id="o", scopes=(ScopeClaim(role=Role.fleet_administrator, robot_id=None, site_id=None),),
        issued_at=0, expires_at=1e18,
    )
    require_permission(claims, "robot:register", robot_id="any-robot-id")  # should not raise


def test_require_permission_robot_scoped_rejects_different_robot():
    claims = TokenClaims(
        user_id="u", org_id="o", scopes=(ScopeClaim(role=Role.programmer, robot_id="robot-a", site_id=None),),
        issued_at=0, expires_at=1e18,
    )
    require_permission(claims, "program:create", robot_id="robot-a")  # should not raise
    with pytest.raises(PermissionError_):
        require_permission(claims, "program:create", robot_id="robot-b")


def test_require_permission_site_scoped_covers_any_robot_at_site():
    claims = TokenClaims(
        user_id="u", org_id="o", scopes=(ScopeClaim(role=Role.operator, robot_id=None, site_id="site-a"),),
        issued_at=0, expires_at=1e18,
    )
    require_permission(claims, "program:run", robot_id="robot-x", site_id="site-a")  # should not raise
    with pytest.raises(PermissionError_):
        require_permission(claims, "program:run", robot_id="robot-y", site_id="site-b")


def test_require_permission_wrong_role_for_action_rejected_even_with_matching_scope():
    claims = TokenClaims(
        user_id="u", org_id="o", scopes=(ScopeClaim(role=Role.operator, robot_id="robot-a", site_id=None),),
        issued_at=0, expires_at=1e18,
    )
    with pytest.raises(PermissionError_):
        require_permission(claims, "program:create", robot_id="robot-a")  # operator can't create programs
