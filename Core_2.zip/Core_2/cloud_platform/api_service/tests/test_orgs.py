import pytest


def test_create_organization_unauthenticated_succeeds(client):
    resp = client.post("/v1/organizations", json={"name": "Acme"})
    assert resp.status_code == 200
    assert resp.json()["subscription_tier"] == "starter"


def test_first_user_becomes_fleet_administrator_automatically(client):
    org = client.post("/v1/organizations", json={"name": "Acme"}).json()
    client.post(f"/v1/organizations/{org['id']}/users", json={"email": "a@acme.com", "password": "password123"})
    login = client.post("/v1/auth/login", json={"email": "a@acme.com", "password": "password123"})
    assert login.status_code == 200
    token = login.json()["access_token"]

    # Prove admin power: create a second user, which requires fleet_administrator.
    resp = client.post(
        f"/v1/organizations/{org['id']}/users",
        json={"email": "b@acme.com", "password": "password456"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 200


def test_second_user_without_auth_is_rejected(client):
    org = client.post("/v1/organizations", json={"name": "Acme"}).json()
    client.post(f"/v1/organizations/{org['id']}/users", json={"email": "a@acme.com", "password": "password123"})
    resp = client.post(f"/v1/organizations/{org['id']}/users", json={"email": "b@acme.com", "password": "password456"})
    assert resp.status_code == 401
    assert resp.json()["error_code"] == "unauthenticated"


def test_login_wrong_password_rejected(org_and_admin):
    client, org_id, headers = org_and_admin
    resp = client.post("/v1/auth/login", json={"email": "admin@test.com", "password": "wrong-password"})
    assert resp.status_code == 401


def test_login_unknown_email_rejected(client):
    resp = client.post("/v1/auth/login", json={"email": "nobody@test.com", "password": "whatever123"})
    assert resp.status_code == 401


def test_create_site_with_coordinates(org_and_admin):
    client, org_id, headers = org_and_admin
    resp = client.post(f"/v1/organizations/{org_id}/sites", json={"name": "Plant 1", "latitude": 28.6139, "longitude": 77.2090}, headers=headers)
    assert resp.status_code == 200
    body = resp.json()
    assert body["latitude"] == pytest.approx(28.6139, abs=1e-4)
    assert body["longitude"] == pytest.approx(77.2090, abs=1e-4)


def test_cross_org_organization_access_returns_404_not_403(client):
    """Section 17.2-style least-privilege posture: an org that another
    tenant's token doesn't grant access to should look like it doesn't
    exist, not leak its existence via a 403."""
    org_a = client.post("/v1/organizations", json={"name": "Org A"}).json()
    client.post(f"/v1/organizations/{org_a['id']}/users", json={"email": "a@a.com", "password": "password123"})
    token_a = client.post("/v1/auth/login", json={"email": "a@a.com", "password": "password123"}).json()["access_token"]

    org_b = client.post("/v1/organizations", json={"name": "Org B"}).json()

    resp = client.get(f"/v1/organizations/{org_b['id']}", headers={"Authorization": f"Bearer {token_a}"})
    assert resp.status_code == 404
