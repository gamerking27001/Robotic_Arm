import pytest

from app.errors import ValidationError
from app.routers.alerts import evaluate_condition


@pytest.mark.parametrize(
    "condition,value,expected",
    [
        ("> 80", 90.0, True),
        ("> 80", 80.0, False),
        (">= 80", 80.0, True),
        ("< 0.5", 0.4, True),
        ("<= 0.5", 0.5, True),
        ("== 1", 1.0, True),
        ("== 1", 1.1, False),
    ],
)
def test_evaluate_condition(condition, value, expected):
    assert evaluate_condition(condition, value) is expected


def test_evaluate_condition_unparseable_raises():
    with pytest.raises(ValidationError):
        evaluate_condition("not a condition", 1.0)


def test_alert_rule_creation_validates_condition_syntax(org_and_admin):
    client, org_id, headers = org_and_admin
    resp = client.post("/v1/alert-rules", json={"metric_name": "x", "condition": "garbage", "severity": "warning"}, headers=headers)
    assert resp.status_code == 422
    assert resp.json()["error_code"] == "validation"


def test_evaluate_raises_alert_when_condition_met(registered_robot):
    client, org_id, headers, robot_id = registered_robot
    client.post("/v1/alert-rules", json={"metric_name": "health_score", "condition": "< 50", "severity": "critical"}, headers=headers)
    client.post(f"/v1/robots/{robot_id}/telemetry", json={"samples": [{"metric_name": "health_score", "value": 20.0}]}, headers=headers)

    resp = client.post(f"/v1/robots/{robot_id}/alerts/evaluate", headers=headers)
    assert resp.status_code == 200
    alerts = resp.json()
    assert len(alerts) == 1
    assert alerts[0]["severity"] == "critical"


def test_evaluate_does_not_raise_when_condition_not_met(registered_robot):
    client, org_id, headers, robot_id = registered_robot
    client.post("/v1/alert-rules", json={"metric_name": "health_score", "condition": "< 50", "severity": "critical"}, headers=headers)
    client.post(f"/v1/robots/{robot_id}/telemetry", json={"samples": [{"metric_name": "health_score", "value": 90.0}]}, headers=headers)

    resp = client.post(f"/v1/robots/{robot_id}/alerts/evaluate", headers=headers)
    assert resp.json() == []


def test_evaluate_does_not_duplicate_open_alerts(registered_robot):
    client, org_id, headers, robot_id = registered_robot
    client.post("/v1/alert-rules", json={"metric_name": "health_score", "condition": "< 50", "severity": "critical"}, headers=headers)
    client.post(f"/v1/robots/{robot_id}/telemetry", json={"samples": [{"metric_name": "health_score", "value": 20.0}]}, headers=headers)

    first = client.post(f"/v1/robots/{robot_id}/alerts/evaluate", headers=headers).json()
    second = client.post(f"/v1/robots/{robot_id}/alerts/evaluate", headers=headers).json()
    assert len(first) == 1
    assert len(second) == 0  # already-open alert for this rule -- not duplicated

    all_alerts = client.get(f"/v1/robots/{robot_id}/alerts", headers=headers).json()
    assert len(all_alerts) == 1


def test_acknowledging_lets_a_new_alert_be_raised_again(registered_robot):
    client, org_id, headers, robot_id = registered_robot
    client.post("/v1/alert-rules", json={"metric_name": "health_score", "condition": "< 50", "severity": "critical"}, headers=headers)
    client.post(f"/v1/robots/{robot_id}/telemetry", json={"samples": [{"metric_name": "health_score", "value": 20.0}]}, headers=headers)

    first = client.post(f"/v1/robots/{robot_id}/alerts/evaluate", headers=headers).json()
    client.post(f"/v1/alerts/{first[0]['id']}/acknowledge", headers=headers)

    client.post(f"/v1/robots/{robot_id}/telemetry", json={"samples": [{"metric_name": "health_score", "value": 19.0}]}, headers=headers)
    second = client.post(f"/v1/robots/{robot_id}/alerts/evaluate", headers=headers).json()
    assert len(second) == 1

    all_alerts = client.get(f"/v1/robots/{robot_id}/alerts", headers=headers).json()
    assert len(all_alerts) == 2
