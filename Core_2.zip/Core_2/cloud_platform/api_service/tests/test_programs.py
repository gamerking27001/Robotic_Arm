def test_create_program_and_first_version(registered_robot):
    client, org_id, headers, robot_id = registered_robot
    program = client.post(f"/v1/robots/{robot_id}/programs", json={"name": "pick-place"}, headers=headers).json()
    assert program["current_version_id"] is None

    version = client.post(
        f"/v1/programs/{program['id']}/versions",
        json={"waypoint_data": {"waypoints": [{"label": "home"}]}},
        headers=headers,
    ).json()
    assert version["version_number"] == 1

    program_after = client.get(f"/v1/robots/{robot_id}/programs", headers=headers).json()[0]
    assert program_after["current_version_id"] == version["id"]


def test_version_numbers_increment(registered_robot):
    client, org_id, headers, robot_id = registered_robot
    program = client.post(f"/v1/robots/{robot_id}/programs", json={"name": "p"}, headers=headers).json()
    v1 = client.post(f"/v1/programs/{program['id']}/versions", json={"waypoint_data": {"a": 1}}, headers=headers).json()
    v2 = client.post(f"/v1/programs/{program['id']}/versions", json={"waypoint_data": {"a": 2}}, headers=headers).json()
    assert v1["version_number"] == 1
    assert v2["version_number"] == 2

    versions = client.get(f"/v1/programs/{program['id']}/versions", headers=headers).json()
    assert [v["version_number"] for v in versions] == [1, 2]


def test_set_as_current_false_does_not_advance_current_version(registered_robot):
    client, org_id, headers, robot_id = registered_robot
    program = client.post(f"/v1/robots/{robot_id}/programs", json={"name": "p"}, headers=headers).json()
    v1 = client.post(f"/v1/programs/{program['id']}/versions", json={"waypoint_data": {"a": 1}}, headers=headers).json()
    client.post(f"/v1/programs/{program['id']}/versions", json={"waypoint_data": {"a": 2}, "set_as_current": False}, headers=headers)

    program_after = client.get(f"/v1/robots/{robot_id}/programs", headers=headers).json()[0]
    assert program_after["current_version_id"] == v1["id"]


def test_program_for_unknown_robot_404s(org_and_admin):
    client, org_id, headers = org_and_admin
    resp = client.post("/v1/robots/00000000-0000-0000-0000-000000000000/programs", json={"name": "x"}, headers=headers)
    assert resp.status_code == 404
