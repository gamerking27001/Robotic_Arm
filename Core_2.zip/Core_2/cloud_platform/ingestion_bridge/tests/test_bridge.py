"""End-to-end tests: a real running cloud_platform server (uvicorn, on the
same event loop -- see local_gateway/gateway_service/tests/test_api.py for
why TestClient's separate thread-portal doesn't mix well with a bridge
that also needs to run its own background tasks on that loop), a real
mosquitto broker (already running in this sandbox), and the real
MqttIngestionBridge / CloudApiClient -- not mocked.
"""
from __future__ import annotations

import asyncio
import itertools
import json
import time

import httpx
import paho.mqtt.client as mqtt
import pytest
import uvicorn

from bridge import CloudApiClient, CloudApiAuthError, MqttIngestionBridge

pytestmark = pytest.mark.asyncio

_http_port_counter = itertools.count(8580)

MQTT_HOST = "localhost"
MQTT_PORT = 1883


@pytest.fixture()
async def cloud_api_server():
    import app.main as app_main

    port = next(_http_port_counter)
    config = uvicorn.Config(app_main.app, host="127.0.0.1", port=port, log_level="warning")
    server = uvicorn.Server(config)
    task = asyncio.create_task(server.serve())
    while not server.started:
        await asyncio.sleep(0.05)

    base_url = f"http://127.0.0.1:{port}"
    async with httpx.AsyncClient(base_url=base_url, timeout=10.0) as client:
        org = (await client.post("/v1/organizations", json={"name": "Bridge Test Org"})).json()
        await client.post(
            f"/v1/organizations/{org['id']}/users",
            json={"email": "bridge-svc@test.com", "password": "bridgepassword123"},
        )
        login = await client.post("/v1/auth/login", json={"email": "bridge-svc@test.com", "password": "bridgepassword123"})
        token = login.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        robot = (
            await client.post(f"/v1/organizations/{org['id']}/robots", json={"brand": "GenericArm", "model": "GA-6DOF-v1"}, headers=headers)
        ).json()

    yield {"base_url": base_url, "robot_id": robot["id"]}

    server.should_exit = True
    await task


def _publish_raw(topic: str, payload: bytes | str) -> None:
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    client.connect(MQTT_HOST, MQTT_PORT, keepalive=10)
    client.loop_start()
    client.publish(topic, payload, qos=1).wait_for_publish(timeout=5.0)
    client.loop_stop()
    client.disconnect()


def _publish_telemetry_batch(robot_id: str, samples: list[dict]) -> None:
    payload = json.dumps({"robot_id": robot_id, "samples": samples})
    _publish_raw(f"robots/{robot_id}/telemetry", payload)


async def test_bridge_forwards_real_mqtt_message_into_cloud_platform(cloud_api_server):
    base_url, robot_id = cloud_api_server["base_url"], cloud_api_server["robot_id"]

    api_client = CloudApiClient(base_url, "bridge-svc@test.com", "bridgepassword123")
    bridge = MqttIngestionBridge(MQTT_HOST, MQTT_PORT, api_client)
    await bridge.start()
    await asyncio.sleep(0.3)  # let the MQTT subscription actually establish

    _publish_telemetry_batch(robot_id, [{"metric_name": "j1_position_deg", "value": 12.5}, {"metric_name": "health_score", "value": 91.0}])

    deadline = time.monotonic() + 5.0
    while bridge.stats.forwarded == 0 and time.monotonic() < deadline:
        await asyncio.sleep(0.1)

    assert bridge.stats.forwarded == 1
    assert bridge.stats.failed == 0

    async with httpx.AsyncClient(base_url=base_url) as client:
        login = await client.post("/v1/auth/login", json={"email": "bridge-svc@test.com", "password": "bridgepassword123"})
        headers = {"Authorization": f"Bearer {login.json()['access_token']}"}
        resp = await client.get(f"/v1/robots/{robot_id}/telemetry", headers=headers)
        rows = resp.json()
        metric_names = {r["metric_name"] for r in rows}
        assert {"j1_position_deg", "health_score"}.issubset(metric_names)

    await bridge.stop()


async def test_bridge_handles_multiple_batches(cloud_api_server):
    base_url, robot_id = cloud_api_server["base_url"], cloud_api_server["robot_id"]

    api_client = CloudApiClient(base_url, "bridge-svc@test.com", "bridgepassword123")
    bridge = MqttIngestionBridge(MQTT_HOST, MQTT_PORT, api_client)
    await bridge.start()
    await asyncio.sleep(0.3)

    for i in range(3):
        _publish_telemetry_batch(robot_id, [{"metric_name": "j1_position_deg", "value": float(i)}])

    deadline = time.monotonic() + 5.0
    while bridge.stats.forwarded < 3 and time.monotonic() < deadline:
        await asyncio.sleep(0.1)

    assert bridge.stats.forwarded == 3
    await bridge.stop()


async def test_bridge_discards_malformed_message_without_crashing(cloud_api_server):
    base_url, robot_id = cloud_api_server["base_url"], cloud_api_server["robot_id"]

    api_client = CloudApiClient(base_url, "bridge-svc@test.com", "bridgepassword123")
    bridge = MqttIngestionBridge(MQTT_HOST, MQTT_PORT, api_client)
    await bridge.start()
    await asyncio.sleep(0.3)

    _publish_raw(f"robots/{robot_id}/telemetry", b"not valid json at all")
    _publish_raw(f"robots/{robot_id}/telemetry", json.dumps({"robot_id": robot_id}))  # missing "samples"

    deadline = time.monotonic() + 3.0
    while bridge.stats.malformed < 2 and time.monotonic() < deadline:
        await asyncio.sleep(0.1)

    assert bridge.stats.malformed == 2
    assert bridge.stats.forwarded == 0

    # And the bridge is still alive/working afterward -- a malformed
    # message must not kill the consumer loop.
    _publish_telemetry_batch(robot_id, [{"metric_name": "still_works", "value": 1.0}])
    deadline = time.monotonic() + 5.0
    while bridge.stats.forwarded == 0 and time.monotonic() < deadline:
        await asyncio.sleep(0.1)
    assert bridge.stats.forwarded == 1

    await bridge.stop()


async def test_bridge_reports_failure_for_unknown_robot(cloud_api_server):
    """A message addressed to a robot_id that doesn't exist in
    cloud_platform should be counted as failed (cloud_platform returns 404
    -- see routers/telemetry.py), not silently dropped or crash the loop."""
    base_url, _ = cloud_api_server["base_url"], cloud_api_server["robot_id"]

    api_client = CloudApiClient(base_url, "bridge-svc@test.com", "bridgepassword123")
    bridge = MqttIngestionBridge(MQTT_HOST, MQTT_PORT, api_client)
    await bridge.start()
    await asyncio.sleep(0.3)

    _publish_telemetry_batch("00000000-0000-0000-0000-000000000000", [{"metric_name": "x", "value": 1.0}])

    deadline = time.monotonic() + 5.0
    while bridge.stats.failed == 0 and time.monotonic() < deadline:
        await asyncio.sleep(0.1)

    assert bridge.stats.failed == 1
    await bridge.stop()


async def test_cloud_api_client_wrong_credentials_raises_auth_error(cloud_api_server):
    base_url = cloud_api_server["base_url"]
    api_client = CloudApiClient(base_url, "bridge-svc@test.com", "wrong-password")
    with pytest.raises(CloudApiAuthError):
        await api_client.ingest_batch("00000000-0000-0000-0000-000000000000", [{"metric_name": "x", "value": 1.0}])
    await api_client.aclose()


async def test_cloud_api_client_reuses_token_without_relogging_in(cloud_api_server):
    """Two consecutive ingest_batch calls within the token TTL should only
    trigger one /v1/auth/login -- confirmed indirectly: the first call sets
    _expires_at, the second call must not change it (a re-login would issue
    a fresh token with a new expiry)."""
    base_url, robot_id = cloud_api_server["base_url"], cloud_api_server["robot_id"]
    api_client = CloudApiClient(base_url, "bridge-svc@test.com", "bridgepassword123")

    ok1 = await api_client.ingest_batch(robot_id, [{"metric_name": "m", "value": 1.0}])
    expires_at_1 = api_client._expires_at
    ok2 = await api_client.ingest_batch(robot_id, [{"metric_name": "m", "value": 2.0}])
    expires_at_2 = api_client._expires_at

    assert ok1 and ok2
    assert expires_at_1 == expires_at_2
    await api_client.aclose()
