"""tests/conftest.py

Adds ../../api_service to sys.path (so tests can start the real
cloud_platform FastAPI app) and sets the env vars it needs at import time.
Mirrors cloud_platform/api_service/tests/conftest.py's DB settings --
uses the same `cloud_platform_test` database, cleaned per test.
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_API_SERVICE_DIR = os.path.abspath(os.path.join(_HERE, "..", "..", "api_service"))
if _API_SERVICE_DIR not in sys.path:
    sys.path.insert(0, _API_SERVICE_DIR)

os.environ.setdefault("CLOUD_PLATFORM_JWT_SECRET", "test-jwt-secret")
os.environ.setdefault(
    "CLOUD_PLATFORM_DATABASE_URL",
    "postgresql+psycopg2://postgres:postgres@localhost:5432/cloud_platform_test",
)

import pytest
from sqlalchemy import text

from app.db import engine, init_db


@pytest.fixture(autouse=True)
def clean_schema():
    with engine.begin() as conn:
        conn.execute(text("DROP SCHEMA public CASCADE"))
        conn.execute(text("CREATE SCHEMA public"))
    init_db()
    yield
