"""cloud_platform/ingestion_bridge/bridge.py

The "IngestionServicePods" piece of section 18.1's cloud deployment
diagram: "Ingestion-tier pods (MQTT broker, telemetry ingestion service)
are the highest-throughput, most horizontally-scalable component." Closes
the one gap local_gateway/README.md flagged explicitly: local_gateway
publishes real, batched telemetry to a real MQTT broker
(`robots/{robot_id}/telemetry`, see gateway/mqtt_publisher.py), but nothing
in this repo was consuming it and forwarding it into cloud_platform's
database -- until this module.

Two pieces:
- `CloudApiClient`: a small async client for cloud_platform's own
  `/v1/auth/login` + `/v1/robots/{id}/telemetry` endpoints -- logs in with
  a service-account email/password (section 12.1's own auth model; not a
  separate API-key mechanism) and re-authenticates before the JWT expires.
- `MqttIngestionBridge`: subscribes to `robots/+/telemetry` (every robot,
  via MQTT's `+` single-level wildcard), and forwards each batch it
  receives to the Cloud API via that client.

paho-mqtt's callbacks run on its own background thread (see
gateway/mqtt_publisher.py's docstring for the same note) -- messages are
handed to the asyncio event loop via `call_soon_threadsafe` onto a queue,
and a single async consumer task drains that queue and does the actual
HTTP forwarding, so the MQTT thread itself never blocks on network I/O.

Note on robot_id: cloud_platform's ROBOTS.id is a UUID (section 17.1's
ERD); the MQTT payload's `robot_id` field is whatever string
local_gateway was configured with (LOCAL_GATEWAY_ROBOT_ID). For a message
to land in the right robot's telemetry history, that configured string
must equal a real robot's UUID as registered in cloud_platform -- this
bridge does not create robots or attempt fuzzy matching, it only forwards.
See README.md's end-to-end run instructions for the concrete steps that
keeps consistent.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Optional

import httpx
import paho.mqtt.client as mqtt

logger = logging.getLogger("cloud_platform.ingestion_bridge")

DEFAULT_TOPIC_PATTERN = "robots/+/telemetry"
TOKEN_REFRESH_MARGIN_S = 60.0


class CloudApiAuthError(RuntimeError):
    pass


class CloudApiClient:
    def __init__(self, base_url: str, email: str, password: str, http_client: Optional[httpx.AsyncClient] = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.email = email
        self.password = password
        self._client = http_client or httpx.AsyncClient(base_url=self.base_url, timeout=10.0)
        self._owns_client = http_client is None
        self._token: Optional[str] = None
        self._expires_at: float = 0.0

    async def _login(self) -> None:
        resp = await self._client.post("/v1/auth/login", json={"email": self.email, "password": self.password})
        if resp.status_code != 200:
            raise CloudApiAuthError(f"login failed ({resp.status_code}): {resp.text}")
        body = resp.json()
        self._token = body["access_token"]
        self._expires_at = time.time() + body["expires_in_s"]
        logger.info("Ingestion bridge authenticated to Cloud API as %s", self.email)

    async def _ensure_token(self) -> str:
        if self._token is None or time.time() > self._expires_at - TOKEN_REFRESH_MARGIN_S:
            await self._login()
        assert self._token is not None
        return self._token

    async def ingest_batch(self, robot_id: str, samples: list[dict[str, Any]]) -> bool:
        """Returns True if cloud_platform accepted the batch (HTTP 202).
        Retries once after a forced re-login on a 401 (covers the case
        where the token was valid by our clock but got rejected anyway --
        e.g. server restarted with a new JWT secret)."""
        token = await self._ensure_token()
        payload = {
            "samples": [
                {
                    "metric_name": s["metric_name"],
                    "value": s["value"],
                    "quality_flag": s.get("quality_flag", "good"),
                }
                for s in samples
            ]
        }
        resp = await self._client.post(
            f"/v1/robots/{robot_id}/telemetry", json=payload, headers={"Authorization": f"Bearer {token}"}
        )
        if resp.status_code == 401:
            self._token = None
            token = await self._ensure_token()
            resp = await self._client.post(
                f"/v1/robots/{robot_id}/telemetry", json=payload, headers={"Authorization": f"Bearer {token}"}
            )
        if resp.status_code != 202:
            logger.warning("Cloud API rejected telemetry batch for robot=%s: %s %s", robot_id, resp.status_code, resp.text)
            return False
        return True

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()


@dataclass
class BridgeStats:
    received: int = 0
    forwarded: int = 0
    failed: int = 0
    malformed: int = 0


class MqttIngestionBridge:
    def __init__(
        self,
        mqtt_host: str,
        mqtt_port: int,
        api_client: CloudApiClient,
        topic_pattern: str = DEFAULT_TOPIC_PATTERN,
        client_id: str = "cloud-platform-ingestion-bridge",
    ) -> None:
        self.mqtt_host = mqtt_host
        self.mqtt_port = mqtt_port
        self.api_client = api_client
        self.topic_pattern = topic_pattern
        self.stats = BridgeStats()

        self._queue: asyncio.Queue = asyncio.Queue()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=client_id)
        self._client.on_message = self._on_message
        self._client.on_connect = self._on_connect
        self._consumer_task: Optional[asyncio.Task] = None
        self._connected = False

    def _on_connect(self, client, userdata, flags, reason_code, properties=None) -> None:
        client.subscribe(self.topic_pattern, qos=1)
        logger.info("Ingestion bridge subscribed to %s", self.topic_pattern)

    def _on_message(self, client, userdata, msg) -> None:
        # Runs on paho-mqtt's own thread -- hand off to the event loop
        # rather than doing anything (including logging.warning at scale)
        # that could contend with the network thread.
        if self._loop is not None:
            self._loop.call_soon_threadsafe(self._queue.put_nowait, msg.payload)

    async def start(self) -> None:
        self._loop = asyncio.get_event_loop()
        self._client.connect(self.mqtt_host, self.mqtt_port, keepalive=30)
        self._client.loop_start()
        self._connected = True
        self._consumer_task = asyncio.create_task(self._consume_loop(), name="ingestion-bridge-consumer")

    async def _consume_loop(self) -> None:
        while True:
            raw = await self._queue.get()
            self.stats.received += 1
            try:
                payload = json.loads(raw)
                robot_id = payload["robot_id"]
                samples = payload["samples"]
                if not isinstance(samples, list) or not samples:
                    raise ValueError("samples must be a non-empty list")
            except (json.JSONDecodeError, KeyError, ValueError) as exc:
                self.stats.malformed += 1
                logger.warning("Discarding malformed telemetry message: %s", exc)
                continue

            ok = await self.api_client.ingest_batch(robot_id, samples)
            if ok:
                self.stats.forwarded += 1
            else:
                self.stats.failed += 1

    async def stop(self) -> None:
        if self._consumer_task is not None:
            self._consumer_task.cancel()
            try:
                await self._consumer_task
            except asyncio.CancelledError:
                pass
        if self._connected:
            self._client.loop_stop()
            self._client.disconnect()
            self._connected = False
        await self.api_client.aclose()
