"""cloud_platform/ingestion_bridge/main.py

Standalone runner. See README.md for the full end-to-end setup (a robot
must already be registered in cloud_platform, and LOCAL_GATEWAY_ROBOT_ID
must match that robot's UUID for messages to land against it).

Run:
    export INGESTION_BRIDGE_CLOUD_API_URL=http://localhost:8300
    export INGESTION_BRIDGE_SERVICE_EMAIL=ingestion-bridge@acme.example
    export INGESTION_BRIDGE_SERVICE_PASSWORD=...
    export INGESTION_BRIDGE_MQTT_HOST=localhost
    python3 main.py
"""
from __future__ import annotations

import asyncio
import logging
import os

from bridge import CloudApiClient, MqttIngestionBridge

logger = logging.getLogger("cloud_platform.ingestion_bridge.main")


async def main() -> None:
    logging.basicConfig(level=os.environ.get("INGESTION_BRIDGE_LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s [%(name)s] %(message)s")

    cloud_api_url = os.environ["INGESTION_BRIDGE_CLOUD_API_URL"]
    service_email = os.environ["INGESTION_BRIDGE_SERVICE_EMAIL"]
    service_password = os.environ["INGESTION_BRIDGE_SERVICE_PASSWORD"]
    mqtt_host = os.environ.get("INGESTION_BRIDGE_MQTT_HOST", "localhost")
    mqtt_port = int(os.environ.get("INGESTION_BRIDGE_MQTT_PORT", "1883"))

    api_client = CloudApiClient(cloud_api_url, service_email, service_password)
    bridge = MqttIngestionBridge(mqtt_host, mqtt_port, api_client)
    await bridge.start()
    logger.info("Ingestion bridge running: mqtt=%s:%d cloud_api=%s", mqtt_host, mqtt_port, cloud_api_url)
    try:
        while True:
            await asyncio.sleep(60)
            logger.info(
                "stats: received=%d forwarded=%d failed=%d malformed=%d",
                bridge.stats.received, bridge.stats.forwarded, bridge.stats.failed, bridge.stats.malformed,
            )
    finally:
        await bridge.stop()


if __name__ == "__main__":
    asyncio.run(main())
