# cloud_platform/ingestion_bridge

Closes the one gap `local_gateway/README.md` flagged explicitly: the
Local Gateway Service publishes real, batched telemetry to a real MQTT
broker (`robots/{robot_id}/telemetry`), but nothing was consuming it and
writing it into `cloud_platform`'s database. This is that consumer --
section 18.1's "IngestionServicePods" from the cloud deployment diagram.

```
MQTT broker (robots/+/telemetry)
        |
        v
MqttIngestionBridge  --(HTTP, JWT auth via a service-account login)-->  cloud_platform Cloud API
   (bridge.py)                                                          (POST /v1/robots/{id}/telemetry)
```

## What this is (and isn't)

- Subscribes to every robot's telemetry topic at once (`robots/+/telemetry`,
  MQTT's single-level wildcard) and forwards each batch to
  `cloud_platform`'s existing ingestion endpoint.
- Authenticates as a real cloud_platform user (a "service account" --
  section 12.1's own password + JWT auth model, not a separate API-key
  mechanism invented for this one piece) and re-authenticates before the
  token expires.
- Malformed MQTT payloads are discarded (counted, logged) without killing
  the consumer loop; a rejected batch (e.g. addressed to a robot_id that
  doesn't exist) is counted as failed, not silently dropped.

Explicitly **not** built here:
- **Robot-ID reconciliation** -- the MQTT payload's `robot_id` field must
  already equal a real robot's UUID in cloud_platform (i.e.
  `LOCAL_GATEWAY_ROBOT_ID` needs to be set to that UUID, not an arbitrary
  string like `"demo-robot"`) for a message to land anywhere. This bridge
  doesn't register robots or fuzzy-match names to IDs.
- **At-least-once delivery guarantees beyond what MQTT QoS 1 already
  gives** -- if the bridge process itself crashes between receiving a
  message and successfully forwarding it, that message is lost (no local
  buffer/replay on this side -- that resilience already lives on the
  *publishing* side, in `local_gateway`'s SQLite buffer, which only marks a
  batch synced after a confirmed MQTT publish, not after this bridge
  confirms cloud delivery).
- **Horizontal scaling** -- section 18.1 describes ingestion-tier pods as
  independently, horizontally scalable; this is one process, one MQTT
  client, no partitioning/load-balancing across multiple bridge instances.

## Running it end to end

```bash
# 1. Cloud API running, with an org/user/robot already registered --
#    see cloud_platform/README.md. Note the robot's UUID.

# 2. A service-account user in that org (any existing user works, e.g.
#    the org's first/admin user) -- note its email/password.

# 3. This bridge
cd robotic_arm_core/cloud_platform/ingestion_bridge
pip install -r requirements.txt --break-system-packages
export INGESTION_BRIDGE_CLOUD_API_URL=http://localhost:8300
export INGESTION_BRIDGE_SERVICE_EMAIL=admin@acme.example
export INGESTION_BRIDGE_SERVICE_PASSWORD=...
export INGESTION_BRIDGE_MQTT_HOST=localhost
python3 main.py

# 4. Local Gateway, configured to publish under that same robot UUID
cd ../../local_gateway/gateway_service
export LOCAL_GATEWAY_ROBOT_ID=<the robot UUID from step 1>
export LOCAL_GATEWAY_MQTT_HOST=localhost
# ... (rest of local_gateway/README.md's setup)
```

Telemetry now flows: simulated controller (OPC UA/Modbus) -> Local
Gateway -> MQTT -> this bridge -> Cloud API -> PostgreSQL, and is queryable
via `GET /v1/robots/{id}/telemetry`.

## What's actually verified

**6/6 tests pass**, against a real running cloud_platform server (uvicorn),
a real PostgreSQL database, and the real mosquitto broker already used
elsewhere in this repo -- not mocks:
- A message published over real MQTT lands in cloud_platform's database,
  confirmed by reading it back via the Cloud API.
- Multiple sequential batches are all forwarded correctly.
- A malformed message (invalid JSON, missing `samples`) is discarded
  without crashing the consumer loop, and the bridge keeps working on the
  next valid message.
- A batch addressed to a nonexistent robot is counted as a failure (the
  Cloud API's real 404 response), not silently dropped.
- Wrong service-account credentials raise `CloudApiAuthError`.
- The JWT is reused across calls within its TTL rather than re-logging in
  on every single batch (confirmed by checking the token's expiry
  timestamp doesn't change between two calls).
