# Cloud Platform (platform spec sections 13, 17)

Implements the Cloud API and database schema from *Industrial Robotics
Operating Platform for MSMEs*, section 13 (fleet management, remote
monitoring, alerts) and section 17 (the database ERD, API design
principles: versioned routes, idempotent commands, least-privilege
token scoping, and an explicit error-code taxonomy).

```
cloud_platform/
  api_service/
    app/
      models.py     SQLAlchemy ORM -- the section 17.1 ERD, field for field
                     (every deviation from the literal extracted ERD is
                     documented in this file's own docstring)
      db.py          Engine/session setup (Postgres + PostGIS)
      auth.py         JWT issuance/verification, section 3.3's RBAC matrix
      errors.py       The section 17.2 error-code taxonomy
      schemas.py      Pydantic request/response models
      routers/        orgs, robots, telemetry, programs, alerts
    tests/            63 tests, run against a real PostgreSQL + PostGIS database
```

## What this is (and isn't)

Built to sections 13/17's spec:
- §17.1: the full ERD -- Organizations, Sites, Robots, Users,
  RoleAssignments, Programs, ProgramVersions, Alerts, AlertRules -- as real
  SQLAlchemy models running against real PostgreSQL 16 + PostGIS (installed
  and tested in this sandbox, not simulated).
- §17.2: versioned routes (`/v1/...`), an idempotent command-dispatch
  endpoint (client-generated `request_id`, verified to not double-execute
  on retry), least-privilege token scoping (a JWT's `scopes` claim, not
  just application-logic checks -- see auth.py), and the exact six-code
  error taxonomy (validation/permission/not_found/conflict/
  robot_unreachable/robot_rejected), enforced as one consistent response
  shape across every endpoint.
- §3.2/3.3: robot registration, and all five roles (Operator, Programmer,
  Developer/Integrator, Maintenance Technician, Fleet Administrator) with
  section 3.3's exact permission table, scoped per-robot and per-site.
- §12.1: password-based authentication + JWT session tokens. §4.2/§8's
  threshold-based alerting, generically (any `metric_name`/`condition`,
  not hardcoded to health score specifically).

Explicitly **not** built here:
- **TimescaleDB** -- this sandbox's package sources don't include the
  TimescaleDB extension (only plain PostgreSQL 16 + PostGIS were
  installable; see the "what was actually installed" section below). The
  `telemetry` table is schema-compatible with a hypertable
  (`SELECT create_hypertable('telemetry', 'time')` is the one-line addition
  a real deployment with the extension would make) but runs here as a
  plain indexed table.
- **MQTT ingestion** -- §1.5 describes the Local Gateway batching telemetry
  to the cloud over MQTT; no message broker exists in this sandbox either.
  `POST /v1/robots/{id}/telemetry` is the HTTP stand-in an MQTT consumer
  would call after deserializing a batch -- see
  `TelemetryIngestRequest`'s docstring in schemas.py. **Update:** this gap
  is now closed -- see [`ingestion_bridge/`](ingestion_bridge/README.md),
  a real MQTT-to-Cloud-API consumer, built after `local_gateway/` started
  publishing real telemetry over a real MQTT broker.
- **TOTP (the second auth factor)** -- §12.1 specifies password + TOTP;
  only password auth + JWT session tokens are implemented.
- **A real Local Gateway Service behind command dispatch** -- the
  `/commands/dispatch-program` endpoint's idempotency guarantee (the
  actual §17.2 requirement) is fully implemented and tested; the dispatch
  itself is a recorded stub, since no Local Gateway Service exists in this
  codebase to forward to (see robots.py's dispatch endpoint docstring --
  motion_planner's `deploy_client.py` is the piece of this repo that
  *does* really talk to a robot, for the different, single-robot,
  synchronous case that module handles).
- **Alembic migrations** -- schema is created with SQLAlchemy's
  `create_all()`, fine for a fresh database, not a migration story for an
  existing one. See db.py's `init_db()` docstring.
- **A scheduler for alert evaluation** -- `/robots/{id}/alerts/evaluate` is
  called on demand (and by the test suite) rather than on a recurring
  schedule; see routers/alerts.py's module docstring.

## Known limitation worth flagging explicitly

A robot's organization membership is derived *transitively* through its
site (`robot.site_id -> site.org_id`) because the §17.1 ERD gives `ROBOTS`
no direct `org_id` column, and `site_id` is nullable (a robot can be
registered before being assigned to a site, per §3.2's onboarding flow).
**Consequence**: an unassigned robot (`site_id IS NULL`) isn't scoped to
any organization and is currently visible to any authenticated user of
*any* org. This is asserted explicitly, not just left as a bug, in
`tests/test_robots.py::test_robot_from_other_org_is_not_visible` and
documented on the `Robot.site_id` column in `models.py`. A real deployment
should make `site_id` non-nullable at registration or add a direct
`org_id` column.

## What was actually installed and run in this sandbox

- PostgreSQL 16 (`apt-get install postgresql`)
- PostGIS 3.4 (`apt-get install postgresql-16-postgis-3`) -- confirmed with
  `SELECT postgis_version()`; `sites.address` and `robots.location` are
  real `geography(Point, 4326)` columns, round-tripped through
  GeoAlchemy2/Shapely in the test suite, not stubbed.
- TimescaleDB was attempted (`apt-get install timescaledb-2-postgresql-16`)
  and confirmed **unavailable** in this sandbox's package sources (its own
  APT repo isn't in the allowed egress list) -- see the scope note above.

## Running it end to end

```bash
# 1. PostgreSQL + PostGIS (adjust for your environment; this sandbox used apt)
sudo apt-get install postgresql postgresql-16-postgis-3
sudo -u postgres psql -c "ALTER USER postgres PASSWORD 'postgres';"
sudo -u postgres createdb cloud_platform
sudo -u postgres createdb cloud_platform_test
sudo -u postgres psql -d cloud_platform -c "CREATE EXTENSION postgis;"
sudo -u postgres psql -d cloud_platform_test -c "CREATE EXTENSION postgis;"

# 2. Cloud API
cd robotic_arm_core/cloud_platform/api_service
pip install -r requirements.txt --break-system-packages
export CLOUD_PLATFORM_DATABASE_URL=postgresql+psycopg2://postgres:postgres@localhost:5432/cloud_platform
export CLOUD_PLATFORM_JWT_SECRET=change-me
uvicorn app.main:app --port 8300
# (separate terminal) tests, against cloud_platform_test:
python3 -m pytest tests/ -q   # 63 tests

# 3. Try it
curl -X POST localhost:8300/v1/organizations -d '{"name": "Acme MSME"}' -H 'Content-Type: application/json'
# -> {"id": "<org_id>", ...}
curl -X POST localhost:8300/v1/organizations/<org_id>/users \
  -d '{"email": "admin@acme.com", "password": "supersecret123"}' -H 'Content-Type: application/json'
curl -X POST localhost:8300/v1/auth/login \
  -d '{"email": "admin@acme.com", "password": "supersecret123"}' -H 'Content-Type: application/json'
# -> {"access_token": "<jwt>", ...}
curl -X POST localhost:8300/v1/organizations/<org_id>/robots \
  -H 'Authorization: Bearer <jwt>' -H 'Content-Type: application/json' \
  -d '{"brand": "GenericArm", "model": "GA-6DOF-v1"}'
```

## What's actually verified

**63/63 tests pass, against a real running PostgreSQL 16 + PostGIS
database** (not SQLite, not mocked) -- covering:
- Auth: password hashing/verification, JWT issue/decode/expiry, section
  3.3's full permission matrix parametrized across all five roles, and
  scope-checking (org-wide / site-wide / robot-specific grants, including
  the negative cases).
- Multi-tenancy: cross-org access returns 404 (not 403, to avoid leaking
  existence), the first user of a new org auto-becomes fleet_administrator,
  every subsequent user requires an authenticated admin to create.
- Robots: registration (with and without a site), status updates,
  site-scoped listing, and the documented cross-org isolation limitation
  above.
- Telemetry: batch ingestion, metric-name filtering, empty-batch
  rejection.
- Programs: versioning (auto-incrementing version numbers), `current_version_id`
  advancement (and non-advancement when `set_as_current=False`).
- Alerts: the condition-string evaluator (`> 80`, `<= 0.5`, etc.),
  duplicate-open-alert suppression, and re-triggering after acknowledgment.
- **Idempotent dispatch**: first request executes, an identical retry
  (same `robot_id` + `request_id`) returns the *original* result rather
  than re-executing, different `request_id`s (or the same `request_id` on
  a different robot) both execute independently.
- The error taxonomy's response shape (`{"error_code", "message",
  "details"}`) verified identical across validation/not_found/
  unauthenticated/permission failures.
- A real PostGIS geography round trip: creating a site with lat/lng,
  reading it back via `ST_X`/`ST_Y`, confirmed exact.

Two real bugs were caught and fixed while building this, not shipped
silently:
1. Enum-typed columns (`RobotStatus`, `AlertSeverity`, etc.) were
   originally backed by plain `String` columns -- fine for the object just
   constructed in Python, but SQLAlchemy doesn't auto-coerce a plain string
   back into the enum type on a DB round-trip, so `.value` on a re-fetched
   row crashed. Fixed by using SQLAlchemy's native `Enum` type. See
   `models.py`.
2. `create_user`'s "requires an authenticated admin after the first user"
   rule was written but never actually reachable -- the original code
   unconditionally rejected any request once an org had users, regardless
   of whether valid admin credentials were supplied. Caught while writing
   `tests/test_orgs.py::test_first_user_becomes_fleet_administrator_automatically`,
   fixed in `routers/orgs.py`.
