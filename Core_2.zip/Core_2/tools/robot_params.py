"""robot_params.py

Single source of truth for the DH parameters, joint limits, and joint
names that ros2_ws/src/robot_description/scripts/generate_urdf.py,
simulation/mujoco/generate_mjcf.py, and cad/freecad/generate_arm_cad.py
all need — previously three separate copy-pasted copies of the same
numbers, flagged as a growing risk in each of those files' own README
("Known gap" in simulation/mujoco/README.md and cad/freecad/README.md).
This consolidation is that fix: one module, three importers, zero copies
left to drift against each other.

Traces back to documentation/design-baseline.md §20.5's config snippet
and (for J1/J2, the only non-placeholder values) §4.3 — see
include/core/robot_config.hpp for the C++ side of this same data
(motor/gearbox/torque values, which robot_config.hpp already gets right
independently — this module is specifically the DH/joint-limit half that
each Python generator needed its own copy of before this refactor).

J3–J6 DH parameters and joint limits are still PLACEHOLDER — the source
document truncates at exactly this point (see design-baseline.md's
cross-validation note) and no other section supplies these numbers.
Every representation generated from this module (URDF, MJCF, CoppeliaSim-
via-URDF-import, this CAD skeleton) inherits that same placeholder
geometry for J3-J6 — updating it here, in one place, is what propagates
the real values to all four once they're known, instead of requiring
four separate edits.
"""

# (a_m, alpha_rad, d_m) -- classic DH parameters, one tuple per joint.
DH_TABLE = [
    (0.000, 1.5707963268, 0.284),   # J1 -- verbatim from source doc §20.5
    (0.400, 0.0, 0.000),             # J2 -- verbatim from source doc §20.5
    (0.350, 1.5707963268, 0.000),   # J3 -- PLACEHOLDER (source truncated), see robot_config.hpp
    (0.000, -1.5707963268, 0.350),  # J4 -- PLACEHOLDER
    (0.000, 1.5707963268, 0.000),   # J5 -- PLACEHOLDER
    (0.000, 0.0, 0.100),             # J6 -- PLACEHOLDER
]

# (min_deg, max_deg, max_speed_deg_s)
JOINT_LIMITS = [
    (-170, 170, 180),  # J1 -- verbatim from source doc
    (-95, 95, 180),      # J2 -- verbatim from source doc
    (-175, 175, 180),    # J3 -- PLACEHOLDER
    (-185, 185, 300),    # J4 -- PLACEHOLDER
    (-120, 120, 300),    # J5 -- PLACEHOLDER
    (-360, 360, 300),    # J6 -- PLACEHOLDER
]

# Descriptive names (used by generate_mjcf.py/generate_arm_cad.py for
# body/object naming) -- distinct from the ROS2-facing "joint1".."joint6"
# names generate_urdf.py emits, which are matched exactly by
# ros2_ws/src/sim_network_hardware_interface's JOINT_NAMES and
# simulation/coppeliasim/coppeliasim_sim_server.py's JOINT_NAMES (those
# two stay as their own local lists deliberately -- they're ROS2
# interface names other running processes match by string, not
# DH-parameter data, so consolidating them here would conflate two
# different kinds of "joint name").
JOINT_NAMES = ["waist", "shoulder", "elbow", "wrist_roll", "wrist_pitch", "flange_roll"]

NUM_JOINTS = len(DH_TABLE)
assert NUM_JOINTS == len(JOINT_LIMITS) == len(JOINT_NAMES) == 6
