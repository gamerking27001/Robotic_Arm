# digital_twin/viewport

The "DigitalTwinViewport" (platform spec section 5.5): React + TypeScript +
three.js client for `../sync_engine`. See [`../README.md`](../README.md)
for architecture, scope, and end-to-end run instructions.

## Layout

- `src/api.ts` — REST client + `/ws/twin` subscription (mirrors `dashboard/frontend/src/api.ts`'s conventions).
- `src/hooks/useTwinSocket.ts` — WS subscription + client-side interpolation buffer (smooths network-delivery jitter on top of the server's own 60Hz stream).
- `src/three/RobotTwinScene.ts` — the actual three.js scene: procedural robot geometry, environment objects, render loop.
- `src/components/Viewport.tsx` — mounts the scene.
- `src/components/CalibrationPanel.tsx` — section 5.6 touch-off calibration UI.
- `src/components/FrameTree.tsx` — live frame-hierarchy debug table.

## Local dev

```bash
npm install
npm run dev     # http://localhost:5174, proxies /api and /ws to :8100 (see vite.config.ts)
npm run build   # tsc project build + production bundle
npm run lint    # oxlint
```

Requires `../sync_engine`'s API running on `:8100` (see its README) and a
viewer/operator API key entered via the "Set key" field in the header
(stored in `sessionStorage`).
