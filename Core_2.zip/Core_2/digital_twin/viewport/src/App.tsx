import { useState } from 'react';
import './App.css';
import { getApiKey, setApiKey } from './api';
import { CalibrationPanel } from './components/CalibrationPanel';
import { FrameTree } from './components/FrameTree';
import { Viewport } from './components/Viewport';
import { useTwinSocket } from './hooks/useTwinSocket';

function App() {
  const { connected, stale, renderHz, buffer } = useTwinSocket();
  const [apiKeyInput, setApiKeyInput] = useState(getApiKey() ?? '');

  return (
    <div className="app">
      <header className="app-header">
        <h1>Digital Twin Viewport</h1>
        <div className="status-badges">
          <span className={`badge ${connected ? 'badge-ok' : 'badge-error'}`}>
            {connected ? 'connected' : 'disconnected'}
          </span>
          <span className={`badge ${stale ? 'badge-warn' : 'badge-ok'}`}>{stale ? 'stale telemetry' : 'live'}</span>
          {renderHz && <span className="badge">{renderHz.toFixed(0)} Hz</span>}
        </div>
        <div className="api-key-field">
          <input
            type="password"
            placeholder="X-API-Key"
            value={apiKeyInput}
            onChange={(e) => setApiKeyInput(e.target.value)}
          />
          <button
            onClick={() => {
              setApiKey(apiKeyInput);
              window.location.reload();
            }}
          >
            Set key
          </button>
        </div>
      </header>

      <main className="app-body">
        <Viewport buffer={buffer} />
        <aside className="app-sidebar">
          <FrameTree snapshot={buffer.latestSnapshot()} />
          <CalibrationPanel />
        </aside>
      </main>
    </div>
  );
}

export default App;
