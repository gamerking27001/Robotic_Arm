// src/components/Viewport.tsx
import { useEffect, useRef, useState } from 'react';
import { fetchScene, UnauthorizedError } from '../api';
import type { TwinBufferHandle } from '../hooks/useTwinSocket';
import { RobotTwinScene } from '../three/RobotTwinScene';

interface ViewportProps {
  buffer: TwinBufferHandle;
}

export function Viewport({ buffer }: ViewportProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const twinScene = new RobotTwinScene(container);
    let cancelled = false;

    fetchScene()
      .then((scene) => {
        if (cancelled) return;
        twinScene.loadScene(scene);
        twinScene.startRenderLoop((now) => buffer.sample(now));
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        setError(err instanceof UnauthorizedError ? 'Unauthorized -- check the API key in Settings.' : String(err));
      });

    return () => {
      cancelled = true;
      twinScene.dispose();
    };
    // `buffer` comes from useTwinSocket()'s useRef() and keeps the same
    // identity for the component's lifetime, so listing it here doesn't
    // cause extra re-runs -- this effect mounts the scene / starts the
    // render loop once and cleans up once, on unmount.
  }, [buffer]);

  return (
    <div className="viewport">
      <div ref={containerRef} className="viewport-canvas" />
      {error && <div className="viewport-error">{error}</div>}
    </div>
  );
}
