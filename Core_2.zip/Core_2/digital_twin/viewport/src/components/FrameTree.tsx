// src/components/FrameTree.tsx
// Displays the resolved world-transform of every frame in the section 5.6
// hierarchy, refreshed from the live /ws/twin stream (via useTwinSocket) --
// mainly a debugging/verification aid: lets you see the calibration
// offset's effect on robot_base and everything under it without needing
// the 3D view.
import type { TransformJson, TwinSnapshot } from '../api';

const DISPLAY_ORDER = ['world', 'cell', 'robot_base', 'link1', 'link2', 'link3', 'link4', 'link5', 'link6', 'tool', 'workpiece'];

function fmt(t: TransformJson): string {
  const [x, y, z] = t.position;
  return `p=(${x.toFixed(3)}, ${y.toFixed(3)}, ${z.toFixed(3)})`;
}

interface FrameTreeProps {
  snapshot: TwinSnapshot | null;
}

export function FrameTree({ snapshot }: FrameTreeProps) {
  return (
    <div className="panel frame-tree">
      <h2>Frame hierarchy</h2>
      {!snapshot && <p className="panel-hint">Waiting for the first snapshot...</p>}
      {snapshot && (
        <table>
          <tbody>
            {DISPLAY_ORDER.filter((name) => snapshot.frames[name]).map((name) => (
              <tr key={name}>
                <td className="frame-name">{name}</td>
                <td>{fmt(snapshot.frames[name])}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
