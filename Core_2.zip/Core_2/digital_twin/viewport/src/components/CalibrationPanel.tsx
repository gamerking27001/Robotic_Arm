// src/components/CalibrationPanel.tsx
//
// UI for the section 5.6 guided touch-off calibration workflow: the
// operator jogs the physical robot's TCP to a known reference point (in
// this codebase, that's a manual step outside this app -- there's no
// jog/teach-pendant UI here, see digital_twin/README.md), enters that
// point's known nominal cell-frame coordinate, and hits Capture. The
// engine pairs it with the *current* live TCP position server-side (see
// sync_engine/twin/sync_service.py::capture_calibration_point) -- this
// panel never sends a "measured" coordinate itself.
import { useEffect, useState } from 'react';
import {
  deleteCalibration,
  deleteCalibrationPoints,
  fetchCalibration,
  postComputeCalibration,
  postTouchOff,
  UnauthorizedError,
  type CalibrationStatus,
} from '../api';

export function CalibrationPanel() {
  const [status, setStatus] = useState<CalibrationStatus | null>(null);
  const [label, setLabel] = useState('');
  const [x, setX] = useState('0');
  const [y, setY] = useState('0');
  const [z, setZ] = useState('0');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const refresh = () => {
    fetchCalibration()
      .then(setStatus)
      .catch((err: unknown) => setMessage(err instanceof UnauthorizedError ? 'Unauthorized' : String(err)));
  };

  useEffect(() => {
    refresh();
  }, []);

  const runAction = async (action: () => Promise<unknown>, successMessage: string) => {
    setBusy(true);
    setMessage(null);
    try {
      await action();
      setMessage(successMessage);
      refresh();
    } catch (err: unknown) {
      setMessage(err instanceof UnauthorizedError ? 'Unauthorized' : String(err));
    } finally {
      setBusy(false);
    }
  };

  const capture = () => {
    const nominal: [number, number, number] = [Number(x), Number(y), Number(z)];
    if (!label.trim() || nominal.some((v) => Number.isNaN(v))) {
      setMessage('Enter a label and three numeric coordinates.');
      return;
    }
    void runAction(() => postTouchOff(label.trim(), nominal), `Captured "${label.trim()}".`);
    setLabel('');
  };

  const compute = () => void runAction(() => postComputeCalibration(), 'Calibration computed and applied.');
  const clearPoints = () => void runAction(() => deleteCalibrationPoints(), 'Captured points cleared.');
  const reset = () => void runAction(() => deleteCalibration(), 'Calibration offset reset to identity.');

  const lastResult = status?.last_result ?? null;

  return (
    <div className="panel calibration-panel">
      <h2>Calibration (§5.6)</h2>
      <p className="panel-hint">
        Jog the physical TCP to a known reference point, enter its nominal cell-frame coordinate below, then
        Capture. Repeat for at least 3 non-collinear points, then Compute.
      </p>

      <div className="calibration-form">
        <input placeholder="label" value={label} onChange={(e) => setLabel(e.target.value)} />
        <input placeholder="x (m)" value={x} onChange={(e) => setX(e.target.value)} />
        <input placeholder="y (m)" value={y} onChange={(e) => setY(e.target.value)} />
        <input placeholder="z (m)" value={z} onChange={(e) => setZ(e.target.value)} />
        <button disabled={busy} onClick={capture}>
          Capture
        </button>
      </div>

      <table className="calibration-points">
        <thead>
          <tr>
            <th>Label</th>
            <th>Nominal (cell)</th>
            <th>Measured (base)</th>
          </tr>
        </thead>
        <tbody>
          {status?.points.map((p) => (
            <tr key={p.label}>
              <td>{p.label}</td>
              <td>{p.nominal_cell_xyz.map((v) => v.toFixed(3)).join(', ')}</td>
              <td>{p.measured_base_xyz.map((v) => v.toFixed(3)).join(', ')}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="calibration-actions">
        <button disabled={busy || (status?.points.length ?? 0) < 3} onClick={compute}>
          Compute + apply
        </button>
        <button disabled={busy || !status?.points.length} onClick={clearPoints}>
          Clear points
        </button>
        <button disabled={busy} onClick={reset}>
          Reset offset
        </button>
      </div>

      {lastResult && (
        <div className={`calibration-result ${lastResult.meets_sub_mm_target ? 'ok' : 'warn'}`}>
          RMS fit error: {lastResult.rms_error_mm.toFixed(3)} mm (max {lastResult.max_error_mm.toFixed(3)} mm) across{' '}
          {lastResult.num_points} points --{' '}
          {lastResult.meets_sub_mm_target ? 'meets sub-mm target' : 'above sub-mm target, re-check touch-off points'}
        </div>
      )}

      {message && <div className="calibration-message">{message}</div>}
    </div>
  );
}
