// src/three/RobotTwinScene.ts
//
// The "DigitalTwinViewport" (platform spec section 5.5). Builds procedural
// robot geometry (no CAD meshes exist for this design -- see
// digital_twin/README.md and sync_engine/twin/scene.py) from the /api/scene
// descriptor, and updates it every animation frame from the interpolated
// frame-graph snapshot the useTwinSocket hook produces.
//
// Deliberately plain three.js, not react-three-fiber: this repo's frontend
// stack (dashboard/frontend) is plain React + fetch/WebSocket with no
// rendering-framework dependency, and pulling in a second, heavier
// abstraction for one viewport isn't warranted -- a render loop owned by
// this class, driven by requestAnimationFrame, is a small enough surface to
// just write directly.
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import type { EnvironmentObject, RobotGeometry, SceneResponse, TransformJson } from '../api';

const LINK_COLOR = 0x64748b;
const LINK_HIGHLIGHT_COLOR = 0x38bdf8;
const AXIS_LENGTH_M = 0.06;

function applyTransform(obj: THREE.Object3D, t: TransformJson): void {
  obj.position.set(t.position[0], t.position[1], t.position[2]);
  // TransformJson quaternion is (w, x, y, z); THREE.Quaternion's
  // constructor/`.set()` takes (x, y, z, w) -- order matters, this is the
  // one place server (Python, w-first) and client (three.js, w-last)
  // conventions actually meet, so it's called out explicitly rather than
  // left as a bare `.set(...)` a reader would have to double back on.
  const [qw, qx, qy, qz] = t.quaternion;
  obj.quaternion.set(qx, qy, qz, qw);
}

export class RobotTwinScene {
  private readonly renderer: THREE.WebGLRenderer;
  private readonly scene: THREE.Scene;
  private readonly camera: THREE.PerspectiveCamera;
  private readonly controls: OrbitControls;
  private readonly container: HTMLElement;
  private readonly resizeObserver: ResizeObserver;

  // One small "frame marker" (sphere + axes) per frame name the server
  // reports (world, cell, robot_base, link1..6, tool, workpiece) -- these
  // are what update() actually repositions each tick.
  private readonly frameMarkers = new Map<string, THREE.Group>();
  // Cylinders spanning consecutive frame origins (robot_base->link1,
  // link1->link2, ...) -- recomputed each tick from the two endpoint
  // positions, since scale/orientation both change as the arm moves.
  private segments: { fromFrame: string; toFrame: string; mesh: THREE.Mesh }[] = [];

  private animationHandle: number | null = null;
  private disposed = false;

  constructor(container: HTMLElement) {
    this.container = container;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0f172a);

    const { clientWidth, clientHeight } = container;
    this.camera = new THREE.PerspectiveCamera(45, clientWidth / Math.max(1, clientHeight), 0.01, 50);
    this.camera.position.set(1.6, -1.6, 1.2);
    this.camera.up.set(0, 0, 1); // Z-up, matching the robot base frame convention used throughout the C++ core / DH table.

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(clientWidth, clientHeight);
    container.appendChild(this.renderer.domElement);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.target.set(0.5, 0, 0.1);
    this.controls.enableDamping = true;

    this.scene.add(new THREE.GridHelper(3, 30, 0x334155, 0x1e293b).rotateX(Math.PI / 2));
    this.scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    const key = new THREE.DirectionalLight(0xffffff, 0.8);
    key.position.set(2, -2, 3);
    this.scene.add(key);

    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(container);
  }

  loadScene(scene: SceneResponse): void {
    this.buildRobotGeometry(scene.robot);
    this.buildEnvironment(scene.environment.objects);
  }

  private buildRobotGeometry(robot: RobotGeometry): void {
    const frameChain = ['robot_base', ...robot.segments.map((s) => s.to_frame)];
    for (const name of new Set(['world', 'cell', ...frameChain, 'tool', 'workpiece'])) {
      this.ensureFrameMarker(name, name === 'tool' || name === 'workpiece');
    }

    for (const seg of robot.segments) {
      const geometry = new THREE.CylinderGeometry(seg.radius_m, seg.radius_m, 1, 16);
      geometry.translate(0, 0.5, 0); // origin at the base of the cylinder, not its center, so scale-to-length works from `fromFrame`'s origin.
      geometry.rotateX(Math.PI / 2); // three's cylinder is Y-axis-aligned by default; segments are built along local Z below.
      const material = new THREE.MeshStandardMaterial({ color: LINK_COLOR, metalness: 0.3, roughness: 0.6 });
      const mesh = new THREE.Mesh(geometry, material);
      this.scene.add(mesh);
      this.segments.push({ fromFrame: seg.from_frame, toFrame: seg.to_frame, mesh });
    }
  }

  private ensureFrameMarker(name: string, small: boolean): THREE.Group {
    const existing = this.frameMarkers.get(name);
    if (existing) return existing;

    const group = new THREE.Group();
    const sphere = new THREE.Mesh(
      new THREE.SphereGeometry(small ? 0.012 : 0.02, 12, 12),
      new THREE.MeshStandardMaterial({ color: LINK_HIGHLIGHT_COLOR }),
    );
    group.add(sphere);
    group.add(new THREE.AxesHelper(AXIS_LENGTH_M));
    this.scene.add(group);
    this.frameMarkers.set(name, group);
    return group;
  }

  private buildEnvironment(objects: EnvironmentObject[]): void {
    for (const obj of objects) {
      const geometry = new THREE.BoxGeometry(obj.size[0], obj.size[1], obj.size[2]);
      const material = obj.wireframe
        ? new THREE.MeshBasicMaterial({ color: obj.color, wireframe: true })
        : new THREE.MeshStandardMaterial({ color: obj.color, roughness: 0.9 });
      const mesh = new THREE.Mesh(geometry, material);
      applyTransform(mesh, { position: obj.position, quaternion: obj.quaternion });
      mesh.name = obj.id;
      this.scene.add(mesh);
    }
  }

  /** Called once per animation frame with the (already client-side
   * interpolated -- see useTwinSocket.ts) world-transform for every frame
   * name the server reports. */
  update(frames: Record<string, TransformJson>): void {
    for (const [name, marker] of this.frameMarkers) {
      const t = frames[name];
      if (t) applyTransform(marker, t);
    }
    for (const seg of this.segments) {
      const a = frames[seg.fromFrame];
      const b = frames[seg.toFrame];
      if (!a || !b) continue;
      const pA = new THREE.Vector3(a.position[0], a.position[1], a.position[2]);
      const pB = new THREE.Vector3(b.position[0], b.position[1], b.position[2]);
      const length = pA.distanceTo(pB);
      seg.mesh.position.copy(pA);
      if (length > 1e-6) {
        seg.mesh.lookAt(pB);
        // Cylinder geometry was built base-at-origin, extending along its
        // local +Z after the rotateX(PI/2) above; lookAt() points -Z at the
        // target by three's convention, so rotate 180deg about the local Y
        // axis to flip it to point +Z at pB instead of away from it.
        seg.mesh.rotateY(Math.PI);
        seg.mesh.scale.set(1, 1, length);
      }
    }
  }

  startRenderLoop(sample: (nowMs: number) => Record<string, TransformJson> | null): void {
    const loop = () => {
      if (this.disposed) return;
      const frames = sample(performance.now());
      if (frames) this.update(frames);
      this.controls.update();
      this.renderer.render(this.scene, this.camera);
      this.animationHandle = requestAnimationFrame(loop);
    };
    this.animationHandle = requestAnimationFrame(loop);
  }

  private handleResize(): void {
    const { clientWidth, clientHeight } = this.container;
    if (clientWidth === 0 || clientHeight === 0) return;
    this.camera.aspect = clientWidth / clientHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(clientWidth, clientHeight);
  }

  dispose(): void {
    this.disposed = true;
    if (this.animationHandle !== null) cancelAnimationFrame(this.animationHandle);
    this.resizeObserver.disconnect();
    this.controls.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
