// src/hooks/useTwinSocket.ts
//
// The server (digital_twin/sync_engine) already decouples render rate from
// telemetry rate and pushes a smooth, interpolated snapshot at a fixed rate
// (default 60 Hz -- see sync_engine's interpolation.py, section 5.4 of the
// platform spec). But WebSocket *delivery* timing on top of that isn't
// perfectly regular (event-loop scheduling, network jitter), so rendering
// directly on "whatever snapshot arrived most recently" can still visibly
// stutter. This hook keeps the last two arrivals and interpolates between
// them by wall-clock time inside the render loop (see
// three/RobotTwinScene.ts), the same technique real-time multiplayer
// clients use to smooth over irregular network delivery of a
// server-authoritative state stream.
import { useEffect, useRef, useState } from 'react';
import { subscribeTwin, type TransformJson, type TwinSnapshot } from '../api';

interface Arrival {
  snapshot: TwinSnapshot;
  receivedAtMs: number;
}

export interface TwinBufferHandle {
  /** Interpolated per-frame-name transforms for wall-clock time `nowMs`
   * (compatible with `performance.now()`), or null before the first
   * snapshot has arrived. */
  sample(nowMs: number): Record<string, TransformJson> | null;
  latestSnapshot(): TwinSnapshot | null;
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v));
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

/** Shortest-path quaternion slerp, (w, x, y, z) convention -- matches the
 * server's TransformJson.quaternion layout exactly (see twin/transform.py's
 * to_dict()). Falls back to normalized lerp when the two orientations are
 * nearly identical, where slerp's sin(theta)-denominator formula becomes
 * numerically unstable. */
function slerpQuat(
  a: [number, number, number, number],
  b: [number, number, number, number],
  t: number,
): [number, number, number, number] {
  let [aw, ax, ay, az] = a;
  const [bw, bx, by, bz] = b;
  let dot = aw * bw + ax * bx + ay * by + az * bz;
  if (dot < 0) {
    aw = -aw;
    ax = -ax;
    ay = -ay;
    az = -az;
    dot = -dot;
  }
  if (dot > 0.9995) {
    const w = lerp(aw, bw, t);
    const x = lerp(ax, bx, t);
    const y = lerp(ay, by, t);
    const z = lerp(az, bz, t);
    const n = Math.hypot(w, x, y, z) || 1;
    return [w / n, x / n, y / n, z / n];
  }
  const theta0 = Math.acos(clamp(dot, -1, 1));
  const theta = theta0 * t;
  const sinTheta0 = Math.sin(theta0);
  const s0 = Math.sin(theta0 - theta) / sinTheta0;
  const s1 = Math.sin(theta) / sinTheta0;
  return [aw * s0 + bw * s1, ax * s0 + bx * s1, ay * s0 + by * s1, az * s0 + bz * s1];
}

class TwinBuffer implements TwinBufferHandle {
  private prev: Arrival | null = null;
  private curr: Arrival | null = null;

  push(snapshot: TwinSnapshot): void {
    this.prev = this.curr;
    this.curr = { snapshot, receivedAtMs: performance.now() };
  }

  latestSnapshot(): TwinSnapshot | null {
    return this.curr?.snapshot ?? null;
  }

  sample(nowMs: number): Record<string, TransformJson> | null {
    if (!this.curr) return null;
    if (!this.prev) return this.curr.snapshot.frames;

    const arrivalGap = this.curr.receivedAtMs - this.prev.receivedAtMs;
    if (arrivalGap <= 1) return this.curr.snapshot.frames;

    // Normalized time where 0 = prev's arrival, 1 = curr's arrival. Beyond
    // 1 is short extrapolation past the newest snapshot (covers the gap
    // while waiting for the next WS message); capped at 1.3 (30% of one
    // inter-arrival gap) for position, and never extrapolated for rotation
    // (t_rot below is clamped to 1) -- overshooting a rotation looks far
    // worse than briefly under/over-shooting a position by a few mm.
    const tPos = clamp(1 + (nowMs - this.curr.receivedAtMs) / arrivalGap, 0, 1.3);
    const tRot = clamp(tPos, 0, 1);

    const prevFrames = this.prev.snapshot.frames;
    const currFrames = this.curr.snapshot.frames;
    const out: Record<string, TransformJson> = {};
    for (const name of Object.keys(currFrames)) {
      const a = prevFrames[name];
      const b = currFrames[name];
      if (!a) {
        out[name] = b;
        continue;
      }
      out[name] = {
        position: [
          lerp(a.position[0], b.position[0], tPos),
          lerp(a.position[1], b.position[1], tPos),
          lerp(a.position[2], b.position[2], tPos),
        ],
        quaternion: slerpQuat(a.quaternion, b.quaternion, tRot),
      };
    }
    return out;
  }
}

export interface UseTwinSocketResult {
  connected: boolean;
  stale: boolean;
  renderHz: number | null;
  jointAnglesRad: number[] | null;
  buffer: TwinBufferHandle;
}

export function useTwinSocket(): UseTwinSocketResult {
  const bufferRef = useRef(new TwinBuffer());
  const [connected, setConnected] = useState(false);
  const [stale, setStale] = useState(true);
  const [renderHz, setRenderHz] = useState<number | null>(null);
  const [jointAnglesRad, setJointAnglesRad] = useState<number[] | null>(null);

  useEffect(() => {
    const unsubscribe = subscribeTwin(
      (snapshot) => {
        bufferRef.current.push(snapshot);
        setStale(snapshot.stale);
        setRenderHz(snapshot.render_hz);
        setJointAnglesRad(snapshot.joint_angles_rad);
      },
      (isConnected) => setConnected(isConnected),
    );
    return unsubscribe;
  }, []);

  return { connected, stale, renderHz, jointAnglesRad, buffer: bufferRef.current };
}
