// src/api.ts
// Types mirror digital_twin/sync_engine/api.py's Pydantic models and JSON
// shapes exactly. Client pattern (sessionStorage API key, UnauthorizedError,
// WS-with-reconnect) mirrors dashboard/frontend/src/api.ts deliberately —
// same problem, same solution, not reinvented.

export interface TransformJson {
  position: [number, number, number];
  quaternion: [number, number, number, number]; // w, x, y, z
}

export interface DhRow {
  a_m: number;
  alpha_rad: number;
  d_m: number;
}

export interface LinkSegment {
  name: string;
  from_frame: string;
  to_frame: string;
  radius_m: number;
}

export interface RobotGeometry {
  joint_names: string[];
  num_joints: number;
  dh_table: DhRow[];
  segments: LinkSegment[];
  note: string;
}

export interface EnvironmentObject {
  id: string;
  type: 'box';
  position: [number, number, number];
  quaternion: [number, number, number, number];
  size: [number, number, number];
  color: string;
  label: string;
  wireframe?: boolean;
}

export interface EnvironmentScene {
  note?: string;
  frame?: string;
  objects: EnvironmentObject[];
}

export interface SceneResponse {
  robot: RobotGeometry;
  environment: EnvironmentScene;
}

export interface TwinSnapshot {
  frames: Record<string, TransformJson>;
  joint_angles_rad: number[];
  stale: boolean;
  extrapolated: boolean;
  age_s: number | null;
  server_time: number;
  render_hz: number;
}

export interface CalibrationPointOut {
  label: string;
  nominal_cell_xyz: [number, number, number];
  measured_base_xyz: [number, number, number];
}

export interface CalibrationResultOut {
  transform: TransformJson;
  rms_error_mm: number;
  max_error_mm: number;
  num_points: number;
  meets_sub_mm_target: boolean;
}

export interface CalibrationStatus {
  points: CalibrationPointOut[];
  last_result: CalibrationResultOut | null;
  current_offset: TransformJson;
}

const API_BASE = '/api';
const API_KEY_STORAGE_KEY = 'digital_twin_api_key';

export function setApiKey(key: string): void {
  sessionStorage.setItem(API_KEY_STORAGE_KEY, key);
}

export function getApiKey(): string | null {
  return sessionStorage.getItem(API_KEY_STORAGE_KEY);
}

export function clearApiKey(): void {
  sessionStorage.removeItem(API_KEY_STORAGE_KEY);
}

export class UnauthorizedError extends Error {
  constructor() {
    super('Unauthorized -- missing or invalid API key');
    this.name = 'UnauthorizedError';
  }
}

function authHeaders(): HeadersInit {
  const key = getApiKey();
  return key ? { 'X-API-Key': key } : {};
}

async function jsonOrThrow<T>(res: Response): Promise<T> {
  if (res.status === 401) throw new UnauthorizedError();
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`${res.status} ${res.statusText}: ${body}`);
  }
  return res.json() as Promise<T>;
}

export async function fetchScene(): Promise<SceneResponse> {
  return jsonOrThrow(await fetch(`${API_BASE}/scene`, { headers: authHeaders() }));
}

export async function fetchFrames(): Promise<TwinSnapshot> {
  return jsonOrThrow(await fetch(`${API_BASE}/frames`, { headers: authHeaders() }));
}

export async function fetchCalibration(): Promise<CalibrationStatus> {
  return jsonOrThrow(await fetch(`${API_BASE}/calibration`, { headers: authHeaders() }));
}

export async function postTouchOff(
  label: string,
  nominalCellXyz: [number, number, number],
): Promise<CalibrationPointOut> {
  const res = await fetch(`${API_BASE}/calibration/touch-off`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({ label, nominal_cell_xyz: nominalCellXyz }),
  });
  return jsonOrThrow(res);
}

export async function postComputeCalibration(): Promise<CalibrationResultOut> {
  const res = await fetch(`${API_BASE}/calibration/compute`, {
    method: 'POST',
    headers: authHeaders(),
  });
  return jsonOrThrow(res);
}

export async function deleteCalibrationPoints(): Promise<void> {
  await fetch(`${API_BASE}/calibration/points`, { method: 'DELETE', headers: authHeaders() });
}

export async function deleteCalibration(): Promise<void> {
  await fetch(`${API_BASE}/calibration`, { method: 'DELETE', headers: authHeaders() });
}

/** Opens /ws/twin. Fires ~`render_hz` times/sec (default 60) with a fresh
 * TwinSnapshot. Auth via ?api_key= query param, same reasoning as
 * dashboard/frontend: browsers can't set custom headers on a WS handshake. */
export function subscribeTwin(
  onMessage: (msg: TwinSnapshot) => void,
  onStatusChange?: (connected: boolean) => void,
): () => void {
  const proto = window.location.protocol === 'https:' ? 'wss' : 'ws';
  const key = getApiKey();
  const query = key ? `?api_key=${encodeURIComponent(key)}` : '';
  const url = `${proto}://${window.location.host}/ws/twin${query}`;
  let socket: WebSocket | null = null;
  let closed = false;
  let retryTimer: ReturnType<typeof setTimeout> | null = null;

  const connect = () => {
    if (closed) return;
    socket = new WebSocket(url);
    socket.onopen = () => onStatusChange?.(true);
    socket.onmessage = (event) => {
      try {
        onMessage(JSON.parse(event.data) as TwinSnapshot);
      } catch {
        // ignore malformed frames
      }
    };
    socket.onclose = () => {
      onStatusChange?.(false);
      if (!closed) retryTimer = setTimeout(connect, 1000);
    };
    socket.onerror = () => socket?.close();
  };
  connect();

  return () => {
    closed = true;
    if (retryTimer) clearTimeout(retryTimer);
    socket?.close();
  };
}
