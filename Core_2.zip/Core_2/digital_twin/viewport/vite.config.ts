import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Proxies /api and /ws to the Digital Twin Sync Engine (digital_twin/sync_engine,
// default port 8100) during `npm run dev`, mirroring dashboard/frontend's
// vite.config.ts pattern for its own (different) backend on :8000.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5174,
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8100',
        changeOrigin: true,
      },
      '/ws': {
        target: 'ws://127.0.0.1:8100',
        ws: true,
      },
    },
  },
})
