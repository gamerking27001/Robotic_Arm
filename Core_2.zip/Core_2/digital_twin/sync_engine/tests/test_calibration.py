import math

import numpy as np
import pytest

from twin.calibration import (
    CalibrationError,
    CalibrationPoint,
    MIN_CALIBRATION_POINTS,
    SUB_MM_FIT_THRESHOLD_MM,
    compute_calibration,
)


def _rotation_z(rad):
    c, s = math.cos(rad), math.sin(rad)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def _make_points(R, t, nominal_pts, noise_mm=0.0, seed=0):
    """Builds CalibrationPoints where measured_base = R^-1 (nominal - t)
    i.e. consistent with nominal = R @ measured + t (the direction
    compute_calibration solves for: T_cell_robot_base maps base->cell)."""
    rng = np.random.default_rng(seed)
    points = []
    Rinv = R.T
    for i, nominal in enumerate(nominal_pts):
        nominal = np.array(nominal, dtype=np.float64)
        measured = Rinv @ (nominal - t)
        if noise_mm > 0.0:
            measured = measured + rng.normal(scale=noise_mm / 1000.0, size=3)
        points.append(
            CalibrationPoint(label=f"p{i}", nominal_cell_xyz=tuple(nominal), measured_base_xyz=tuple(measured))
        )
    return points


def test_recovers_known_pure_translation():
    R = np.eye(3)
    t = np.array([0.5, -0.2, 0.1])
    nominal_pts = [(0.0, 0.0, 0.0), (1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)]
    points = _make_points(R, t, nominal_pts)

    result = compute_calibration(points)

    assert np.allclose(result.transform.R, R, atol=1e-6)
    assert np.allclose(result.transform.p, t, atol=1e-6)
    assert result.rms_error_mm < 1e-6
    assert result.meets_sub_mm_target is True


def test_recovers_known_rotation_and_translation():
    R = _rotation_z(math.radians(37.0))
    t = np.array([0.2, 0.1, 0.0])
    nominal_pts = [(0.65, 0.0, 0.375), (1.15, 0.0, 0.375), (0.65, 1.2, 0.375), (0.9, 0.6, 0.0)]
    points = _make_points(R, t, nominal_pts)

    result = compute_calibration(points)

    assert np.allclose(result.transform.R, R, atol=1e-6)
    assert np.allclose(result.transform.p, t, atol=1e-6)
    assert result.rms_error_mm < 1e-6


def test_residual_error_reported_with_noise():
    R = _rotation_z(math.radians(10.0))
    t = np.array([0.0, 0.0, 0.0])
    nominal_pts = [(0.5, 0.0, 0.3), (1.0, 0.0, 0.3), (0.5, 1.0, 0.3), (0.8, 0.5, 0.0)]
    points = _make_points(R, t, nominal_pts, noise_mm=0.3, seed=42)

    result = compute_calibration(points)

    # With 0.3mm of injected per-point noise, the RMS fit residual should be
    # small but not exactly zero, and should stay in a sane ballpark (not
    # orders of magnitude off, which would indicate a units/convention bug).
    assert 0.0 < result.rms_error_mm < 2.0


def test_too_few_points_raises():
    points = _make_points(np.eye(3), np.zeros(3), [(0, 0, 0), (1, 0, 0)])
    assert len(points) < MIN_CALIBRATION_POINTS
    with pytest.raises(CalibrationError):
        compute_calibration(points)


def test_collinear_points_raise_degenerate_error():
    # All points on the line x=0..2, y=0, z=0 -- cannot determine rotation
    # about that axis.
    nominal_pts = [(0.0, 0.0, 0.0), (1.0, 0.0, 0.0), (2.0, 0.0, 0.0)]
    points = _make_points(np.eye(3), np.zeros(3), nominal_pts)
    with pytest.raises(CalibrationError):
        compute_calibration(points)


def test_meets_sub_mm_target_threshold_is_the_documented_constant():
    assert SUB_MM_FIT_THRESHOLD_MM == 0.5
