import math

import numpy as np
import pytest

from twin.kinematics_bridge import KinematicsBridge

bridge = KinematicsBridge()
requires_native_bridge = pytest.mark.skipif(
    not bridge.is_available(),
    reason="native_bridge/librobot_bridge.so not built -- run (cd dashboard/backend && ./build.sh) first",
)


@requires_native_bridge
def test_home_pose_matches_known_arm_demo_output():
    """arm_demo (src/main.cpp) prints, at the all-zero joint configuration:
        Home pose (FK): p=(0.7500, 0.0000, -0.1660) m
    This is the same DHKinematicChain, called through the new
    robot_bridge_compute_link_frames export instead of directly -- if this
    doesn't match, the ctypes marshalling (not the kinematics itself,
    already covered by the C++ side) is broken."""
    frames = bridge.compute_link_frames([0.0] * 6)
    tcp = frames[-1]
    assert tcp.p == pytest.approx([0.75, 0.0, -0.166], abs=1e-4)


@requires_native_bridge
def test_returns_six_link_transforms():
    frames = bridge.compute_link_frames([0.0] * 6)
    assert len(frames) == 6


@requires_native_bridge
def test_wrong_length_input_raises():
    with pytest.raises(ValueError):
        bridge.compute_link_frames([0.0] * 5)


@requires_native_bridge
def test_nonzero_joint_angles_change_tcp_position():
    home = bridge.compute_link_frames([0.0] * 6)[-1]
    rotated_waist = bridge.compute_link_frames([math.radians(90.0), 0, 0, 0, 0, 0])[-1]
    # Rotating J1 (waist) by 90deg should swing the TCP's X/Y position, not
    # leave it where it was.
    assert not np.allclose(home.p, rotated_waist.p, atol=1e-6)
    # Z height is unaffected by a pure waist rotation (J1 axis is Z).
    assert home.p[2] == pytest.approx(rotated_waist.p[2], abs=1e-9)


def test_unavailable_bridge_raises_clear_error(tmp_path):
    from twin.kinematics_bridge import KinematicsBridgeUnavailable

    missing = KinematicsBridge(library_path=str(tmp_path / "does_not_exist.so"))
    assert missing.is_available() is False
    with pytest.raises(KinematicsBridgeUnavailable):
        missing.compute_link_frames([0.0] * 6)
