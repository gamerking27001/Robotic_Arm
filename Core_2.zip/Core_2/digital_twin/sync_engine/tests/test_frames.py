import numpy as np
import pytest

from twin.frames import FrameGraph, FrameGraphError, LINK_NAMES
from twin.transform import Transform


def test_default_graph_has_expected_frames():
    g = FrameGraph()
    names = set(g.names())
    assert {"world", "cell", "robot_base", "tool", "workpiece"}.issubset(names)
    assert set(LINK_NAMES).issubset(names)


def test_identity_graph_resolves_to_identity_everywhere():
    g = FrameGraph()
    for name in g.names():
        t = g.world_transform(name)
        assert np.allclose(t.R, np.eye(3))
        assert np.allclose(t.p, np.zeros(3))


def test_calibration_offset_propagates_to_links_and_tool():
    g = FrameGraph()
    offset = Transform.from_translation(1.0, 2.0, 0.0)
    g.set_calibration_offset(offset)

    assert np.allclose(g.world_transform("robot_base").p, [1.0, 2.0, 0.0])
    # link1 has identity local transform by default, so its world pose
    # should equal the calibration offset directly.
    assert np.allclose(g.world_transform("link1").p, [1.0, 2.0, 0.0])
    # tool is parented under link6, also identity locally by default.
    assert np.allclose(g.world_transform("tool").p, [1.0, 2.0, 0.0])
    # workpiece is parented under cell, NOT robot_base -- must be unaffected
    # by a robot_base calibration offset.
    assert np.allclose(g.world_transform("workpiece").p, [0.0, 0.0, 0.0])


def test_update_link_frames_sets_all_six_links():
    g = FrameGraph()
    poses = [Transform.from_translation(float(i), 0.0, 0.0) for i in range(6)]
    g.update_link_frames(poses)
    for i, name in enumerate(LINK_NAMES):
        assert np.allclose(g.world_transform(name).p, [float(i), 0.0, 0.0])


def test_update_link_frames_wrong_count_raises():
    g = FrameGraph()
    with pytest.raises(FrameGraphError):
        g.update_link_frames([Transform.identity()] * 5)


def test_tool_offset_composes_after_link6():
    g = FrameGraph()
    g.update_link_frames([Transform.identity()] * 5 + [Transform.from_translation(0.75, 0.0, -0.166)])
    g.set_tool_offset(Transform.from_translation(0.0, 0.0, 0.1))  # 10cm gripper offset along Z
    tool_pose = g.world_transform("tool")
    assert np.allclose(tool_pose.p, [0.75, 0.0, -0.066])  # -0.166 + 0.1


def test_unknown_frame_raises():
    g = FrameGraph()
    with pytest.raises(FrameGraphError):
        g.world_transform("nonexistent")
    with pytest.raises(FrameGraphError):
        g.set_local_transform("nonexistent", Transform.identity())


def test_snapshot_covers_every_frame():
    g = FrameGraph()
    snap = g.snapshot()
    assert set(snap.keys()) == set(g.names())
    for entry in snap.values():
        assert "position" in entry and "quaternion" in entry
