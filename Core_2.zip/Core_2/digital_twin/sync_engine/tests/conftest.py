"""tests/conftest.py

Sets the Digital Twin API's required environment variables before any test
module imports `api` (api.py fails fast at import time if these aren't set
— see its module docstring — so this has to happen before collection, not
inside a fixture)."""
import os

os.environ.setdefault("DIGITAL_TWIN_VIEWER_API_KEY", "test-viewer-key")
os.environ.setdefault("DIGITAL_TWIN_OPERATOR_API_KEY", "test-operator-key")
os.environ.setdefault("DIGITAL_TWIN_TELEMETRY_SOURCE", "synthetic")
os.environ.setdefault("DIGITAL_TWIN_RENDER_HZ", "60")
