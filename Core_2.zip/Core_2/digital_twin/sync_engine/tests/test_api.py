import time

import pytest
from fastapi.testclient import TestClient

from api import app

VIEWER_HEADERS = {"X-API-Key": "test-viewer-key"}
OPERATOR_HEADERS = {"X-API-Key": "test-operator-key"}


def test_healthz_unauthenticated():
    with TestClient(app) as client:
        resp = client.get("/healthz")
        assert resp.status_code == 200
        assert resp.json() == {"status": "ok"}


def test_scene_requires_auth():
    with TestClient(app) as client:
        resp = client.get("/api/scene")
        assert resp.status_code == 401


def test_scene_returns_robot_and_environment():
    with TestClient(app) as client:
        resp = client.get("/api/scene", headers=VIEWER_HEADERS)
        assert resp.status_code == 200
        body = resp.json()
        assert body["robot"]["num_joints"] == 6
        assert len(body["robot"]["segments"]) == 6
        assert "environment" in body
        assert len(body["environment"]["objects"]) > 0


def test_frames_snapshot_has_all_expected_frames():
    with TestClient(app) as client:
        # Give the render loop at least one tick.
        time.sleep(0.1)
        resp = client.get("/api/frames", headers=VIEWER_HEADERS)
        assert resp.status_code == 200
        body = resp.json()
        expected = {"world", "cell", "robot_base", "link1", "link2", "link3", "link4", "link5", "link6", "tool",
                    "workpiece"}
        assert expected.issubset(set(body["frames"].keys()))
        assert "joint_angles_rad" in body
        assert len(body["joint_angles_rad"]) == 6


def test_operator_endpoints_reject_viewer_key():
    with TestClient(app) as client:
        resp = client.post(
            "/api/calibration/touch-off",
            headers=VIEWER_HEADERS,
            json={"label": "p1", "nominal_cell_xyz": [0.0, 0.0, 0.0]},
        )
        assert resp.status_code == 401


def test_touch_off_capture_and_status_roundtrip():
    with TestClient(app) as client:
        time.sleep(0.05)
        resp = client.post(
            "/api/calibration/touch-off",
            headers=OPERATOR_HEADERS,
            json={"label": "corner_1", "nominal_cell_xyz": [0.65, 0.0, 0.375]},
        )
        assert resp.status_code == 200
        body = resp.json()
        assert body["label"] == "corner_1"
        assert len(body["measured_base_xyz"]) == 3

        status = client.get("/api/calibration", headers=VIEWER_HEADERS).json()
        assert len(status["points"]) == 1
        assert status["points"][0]["label"] == "corner_1"


def test_compute_calibration_with_too_few_points_returns_422():
    with TestClient(app) as client:
        client.delete("/api/calibration/points", headers=OPERATOR_HEADERS)
        client.post(
            "/api/calibration/touch-off",
            headers=OPERATOR_HEADERS,
            json={"label": "only_one", "nominal_cell_xyz": [0.1, 0.2, 0.3]},
        )
        resp = client.post("/api/calibration/compute", headers=OPERATOR_HEADERS)
        assert resp.status_code == 422


def test_reset_calibration_restores_identity_offset():
    with TestClient(app) as client:
        resp = client.delete("/api/calibration", headers=OPERATOR_HEADERS)
        assert resp.status_code == 200
        status = client.get("/api/calibration", headers=VIEWER_HEADERS).json()
        assert status["current_offset"]["position"] == pytest.approx([0.0, 0.0, 0.0])
        assert status["current_offset"]["quaternion"] == pytest.approx([1.0, 0.0, 0.0, 0.0])


def test_ws_twin_streams_snapshots():
    with TestClient(app) as client:
        with client.websocket_connect(f"/ws/twin?api_key=test-viewer-key") as ws:
            msg = ws.receive_json()
            assert "frames" in msg
            assert "joint_angles_rad" in msg
            assert set(["world", "robot_base", "tool"]).issubset(set(msg["frames"].keys()))


def test_ws_twin_rejects_bad_key():
    with TestClient(app) as client:
        with pytest.raises(Exception):
            with client.websocket_connect("/ws/twin?api_key=wrong-key") as ws:
                ws.receive_json()
