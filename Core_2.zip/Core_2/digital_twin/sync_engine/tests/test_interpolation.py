import pytest

from twin.interpolation import JointStateInterpolator


def _q6(v):
    return tuple([v] * 6)


def test_no_data_is_stale():
    interp = JointStateInterpolator()
    result = interp.sample_at(t_query=100.0)
    assert result.stale is True
    assert result.q == _q6(0.0)


def test_single_sample_holds_value():
    interp = JointStateInterpolator()
    interp.push_sample(10.0, _q6(0.5))
    result = interp.sample_at(t_query=10.0)
    assert result.q == pytest.approx(_q6(0.5))
    assert result.stale is False


def test_linear_interpolation_between_two_samples():
    interp = JointStateInterpolator()
    interp.push_sample(0.0, _q6(0.0))
    interp.push_sample(1.0, _q6(1.0))
    result = interp.sample_at(t_query=0.25)
    assert result.q == pytest.approx(_q6(0.25), abs=1e-9)
    assert result.extrapolated is False
    assert result.stale is False


def test_interpolation_at_exact_sample_times():
    interp = JointStateInterpolator()
    interp.push_sample(0.0, _q6(0.0))
    interp.push_sample(1.0, _q6(2.0))
    assert interp.sample_at(t_query=0.0).q == pytest.approx(_q6(0.0))
    assert interp.sample_at(t_query=1.0).q == pytest.approx(_q6(2.0))


def test_query_before_first_sample_holds_earliest():
    interp = JointStateInterpolator()
    interp.push_sample(5.0, _q6(3.0))
    result = interp.sample_at(t_query=1.0)
    assert result.q == pytest.approx(_q6(3.0))
    assert result.stale is False


def test_extrapolation_within_bound_uses_constant_velocity():
    interp = JointStateInterpolator(max_extrapolation_s=0.15, staleness_timeout_s=1.0)
    interp.push_sample(0.0, _q6(0.0))
    interp.push_sample(0.1, _q6(0.1))  # velocity = 1.0 rad/s
    result = interp.sample_at(t_query=0.15)  # 0.05s past newest, within max_extrapolation_s
    assert result.extrapolated is True
    assert result.q == pytest.approx(_q6(0.15), abs=1e-9)
    assert result.stale is False


def test_extrapolation_beyond_bound_holds_last_value():
    interp = JointStateInterpolator(max_extrapolation_s=0.05, staleness_timeout_s=1.0)
    interp.push_sample(0.0, _q6(0.0))
    interp.push_sample(0.1, _q6(1.0))
    result = interp.sample_at(t_query=0.5)  # well past max_extrapolation_s
    assert result.q == pytest.approx(_q6(1.0))  # held at last known, not coasting to 5.0
    assert result.extrapolated is True


def test_staleness_flag_after_timeout():
    interp = JointStateInterpolator(staleness_timeout_s=0.2, max_extrapolation_s=0.05)
    interp.push_sample(0.0, _q6(0.0))
    result = interp.sample_at(t_query=1.0)
    assert result.stale is True


def test_out_of_order_sample_is_dropped():
    interp = JointStateInterpolator()
    interp.push_sample(1.0, _q6(1.0))
    interp.push_sample(0.5, _q6(99.0))  # older than the last pushed sample -> dropped
    result = interp.sample_at(t_query=1.0)
    assert result.q == pytest.approx(_q6(1.0))


def test_decouples_low_rate_input_from_high_rate_output():
    """Directly demonstrates section 5.4: feed samples at a low, uneven
    rate (simulating a 10-50 Hz telemetry feed) and query at a much higher,
    perfectly regular rate (60 fps) -- every query should get a valid,
    smoothly-varying result, not just whatever the last raw sample was."""
    interp = JointStateInterpolator(buffer_size=16)
    # 10 Hz input over 1 second: samples at t=0.0, 0.1, ..., 0.9
    for i in range(10):
        t = i * 0.1
        interp.push_sample(t, _q6(t))  # value == time, so interpolated value should == query time

    outputs = []
    for i in range(60):  # 60 Hz output over the same 1 second window
        t_query = i / 60.0
        if t_query > 0.9:
            break
        result = interp.sample_at(t_query=t_query)
        outputs.append(result.q[0])
        assert result.q[0] == pytest.approx(t_query, abs=1e-9)

    # Output is monotonically non-decreasing (smooth), not stair-stepping.
    assert all(b >= a for a, b in zip(outputs, outputs[1:]))
    assert len(outputs) > 10  # genuinely produced more samples than the input had


def test_rejects_wrong_length_joint_vector():
    interp = JointStateInterpolator(num_joints=6)
    with pytest.raises(ValueError):
        interp.push_sample(0.0, (1.0, 2.0, 3.0))
