import math

import numpy as np
import pytest

from twin.transform import Transform


def test_identity_round_trip():
    t = Transform.identity()
    px, py, pz, qw, qx, qy, qz = t.to_quaternion()
    assert (px, py, pz) == (0.0, 0.0, 0.0)
    assert qw == pytest.approx(1.0)
    assert qx == pytest.approx(0.0)
    assert qy == pytest.approx(0.0)
    assert qz == pytest.approx(0.0)


def test_quaternion_round_trip_general_rotation():
    R = _rotation_z(math.radians(30)) @ _rotation_y(math.radians(45)) @ _rotation_x(math.radians(60))
    t = Transform.from_rotation_translation(R, np.array([1.0, -2.0, 0.5]))
    px, py, pz, qw, qx, qy, qz = t.to_quaternion()
    back = Transform.from_quaternion(px, py, pz, qw, qx, qy, qz)
    assert np.allclose(back.R, R, atol=1e-9)
    assert np.allclose(back.p, [1.0, -2.0, 0.5], atol=1e-9)


def test_180_degree_rotation_branches():
    # Exercises the branches of the Shepperd's-method conversion that the
    # naive single-formula approach gets wrong (trace ~= -1).
    for R in (_rotation_x(math.pi), _rotation_y(math.pi), _rotation_z(math.pi)):
        t = Transform.from_rotation_translation(R, np.zeros(3))
        px, py, pz, qw, qx, qy, qz = t.to_quaternion()
        back = Transform.from_quaternion(px, py, pz, qw, qx, qy, qz)
        assert np.allclose(back.R, R, atol=1e-8)


def test_composition_matches_matrix_composition():
    R1, p1 = _rotation_z(math.radians(20)), np.array([1.0, 0.0, 0.0])
    R2, p2 = _rotation_x(math.radians(40)), np.array([0.0, 0.5, 0.0])
    t1 = Transform.from_rotation_translation(R1, p1)
    t2 = Transform.from_rotation_translation(R2, p2)
    composed = t1 @ t2
    assert np.allclose(composed.R, R1 @ R2)
    assert np.allclose(composed.p, R1 @ p2 + p1)


def test_inverse_undoes_transform():
    R = _rotation_y(math.radians(73))
    t = Transform.from_rotation_translation(R, np.array([0.3, -0.1, 0.9]))
    identity = t @ t.inverse()
    assert np.allclose(identity.R, np.eye(3), atol=1e-9)
    assert np.allclose(identity.p, np.zeros(3), atol=1e-9)


def test_apply_matches_manual_matrix_multiply():
    R = _rotation_z(math.radians(90))
    t = Transform.from_rotation_translation(R, np.array([1.0, 0.0, 0.0]))
    v = np.array([1.0, 0.0, 0.0])
    result = t.apply(v)
    # rotate (1,0,0) by 90deg about Z -> (0,1,0), then translate by (1,0,0)
    assert np.allclose(result, [1.0, 1.0, 0.0], atol=1e-9)


def test_matches_cpp_home_pose():
    """Cross-check against the known values printed by the C++ core's
    arm_demo / the robot_bridge_compute_link_frames probe at the all-zero
    ("home") joint configuration:
        link6 (TCP): p=(0.7500, 0.0000, -0.1660), q=(-0,1,0,0)
    (see digital_twin/sync_engine/README.md for how this was captured).
    This doesn't re-derive FK in Python (that's the C++ core's job) — it
    only checks Transform.from_quaternion() reconstructs the same rotation
    matrix the C++ side's toQuaternion() would have produced for that
    matrix, i.e. that the two implementations use the same convention.
    """
    t = Transform.from_quaternion(0.75, 0.0, -0.166, 0.0, 1.0, 0.0, 0.0)
    # q=(w=0,x=1,y=0,z=0) is a 180 deg rotation about X.
    expected_R = _rotation_x(math.pi)
    assert np.allclose(t.R, expected_R, atol=1e-6)
    assert np.allclose(t.p, [0.75, 0.0, -0.166])


def _rotation_x(rad):
    c, s = math.cos(rad), math.sin(rad)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])


def _rotation_y(rad):
    c, s = math.cos(rad), math.sin(rad)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])


def _rotation_z(rad):
    c, s = math.cos(rad), math.sin(rad)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
