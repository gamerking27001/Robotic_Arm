"""digital_twin/sync_engine/api.py

FastAPI service for the Digital Twin Sync Engine (platform spec section 5;
section 1.2's core-module table). Consumed by digital_twin/viewport (the
"DigitalTwinViewport", section 5.5) and, in principle, any other client that
wants the resolved frame graph (a desktop app's 3D panel, a debug CLI, etc).

Run (after building the native bridge — see README.md):
    pip install -r requirements.txt
    export DIGITAL_TWIN_VIEWER_API_KEY=...
    export DIGITAL_TWIN_OPERATOR_API_KEY=...
    uvicorn api:app --reload --port 8100

Authentication follows the same pattern as dashboard/backend/main.py
deliberately — two keys (viewer read-only, operator read/write), no default
key, DIGITAL_TWIN_ALLOW_INSECURE=1 for local dev only. This is a *separate*
service with its own keys, not sharing the dashboard's — a compromised twin
viewer key shouldn't be equivalent to a compromised robot-motion-command key.
"""
from __future__ import annotations

import logging
import os
import secrets
from contextlib import asynccontextmanager
from typing import List, Optional, Tuple

from fastapi import Depends, FastAPI, HTTPException, Security, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import APIKeyHeader
from pydantic import BaseModel, Field

from twin.calibration import CalibrationError
from twin.kinematics_bridge import KinematicsBridge
from twin.scene import scene_descriptor
from twin.sync_service import DigitalTwinSyncEngine
from twin.telemetry_source import SyntheticTelemetrySource, WebSocketTelemetrySource

logging.basicConfig(
    level=os.environ.get("DIGITAL_TWIN_LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
logger = logging.getLogger("digital_twin.api")

# --- Authentication (mirrors dashboard/backend/main.py) --------------------

_VIEWER_KEY = os.environ.get("DIGITAL_TWIN_VIEWER_API_KEY")
_OPERATOR_KEY = os.environ.get("DIGITAL_TWIN_OPERATOR_API_KEY")
_INSECURE = os.environ.get("DIGITAL_TWIN_ALLOW_INSECURE") == "1"

if not _INSECURE and (not _VIEWER_KEY or not _OPERATOR_KEY):
    raise RuntimeError(
        "DIGITAL_TWIN_VIEWER_API_KEY and DIGITAL_TWIN_OPERATOR_API_KEY must both be set "
        "(the calibration endpoints write to the twin's coordinate frames — no default key "
        "is provided). For local development only, set DIGITAL_TWIN_ALLOW_INSECURE=1 instead."
    )
if _INSECURE:
    logger.warning(
        "DIGITAL_TWIN_ALLOW_INSECURE=1 — authentication is DISABLED. "
        "This must never be set in a real deployment."
    )

_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


def _check_key(provided: Optional[str], required: str) -> bool:
    if provided is None:
        return False
    return secrets.compare_digest(provided, required)


def require_viewer(api_key: Optional[str] = Security(_api_key_header)) -> None:
    if _INSECURE:
        return
    if _check_key(api_key, _OPERATOR_KEY) or _check_key(api_key, _VIEWER_KEY):
        return
    raise HTTPException(status_code=401, detail="Invalid or missing API key")


def require_operator(api_key: Optional[str] = Security(_api_key_header)) -> None:
    if _INSECURE:
        return
    if _check_key(api_key, _OPERATOR_KEY):
        return
    raise HTTPException(status_code=401, detail="Invalid or missing operator API key")


async def require_viewer_ws(websocket: WebSocket) -> bool:
    if _INSECURE:
        return True
    provided = websocket.query_params.get("api_key")
    if _check_key(provided, _OPERATOR_KEY) or _check_key(provided, _VIEWER_KEY):
        return True
    await websocket.close(code=4401)
    return False


# --- Telemetry source selection --------------------------------------------


def _build_telemetry_source():
    kind = os.environ.get("DIGITAL_TWIN_TELEMETRY_SOURCE", "synthetic").lower()
    if kind == "synthetic":
        logger.info("Using SyntheticTelemetrySource (no live dashboard connection)")
        return SyntheticTelemetrySource()
    if kind == "websocket":
        url = os.environ.get("DIGITAL_TWIN_DASHBOARD_WS_URL", "ws://localhost:8000/ws/telemetry")
        api_key = os.environ.get("DIGITAL_TWIN_DASHBOARD_API_KEY")
        logger.info("Using WebSocketTelemetrySource: %s", url)
        return WebSocketTelemetrySource(url=url, api_key=api_key)
    raise RuntimeError(f"Unknown DIGITAL_TWIN_TELEMETRY_SOURCE={kind!r} (expected 'synthetic' or 'websocket')")


_engine: Optional[DigitalTwinSyncEngine] = None


def get_engine() -> DigitalTwinSyncEngine:
    assert _engine is not None, "engine not initialized (app not started via lifespan?)"
    return _engine


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _engine
    render_hz = float(os.environ.get("DIGITAL_TWIN_RENDER_HZ", "60"))
    _engine = DigitalTwinSyncEngine(
        telemetry_source=_build_telemetry_source(),
        kinematics=KinematicsBridge(),
        render_hz=render_hz,
    )
    await _engine.start()
    logger.info("Digital Twin Sync Engine started (render_hz=%.1f)", render_hz)
    try:
        yield
    finally:
        await _engine.stop()


app = FastAPI(
    title="Digital Twin Sync Engine",
    version="0.1.0",
    lifespan=lifespan,
    docs_url=None if os.environ.get("DIGITAL_TWIN_DISABLE_DOCS") == "1" else "/docs",
    redoc_url=None if os.environ.get("DIGITAL_TWIN_DISABLE_DOCS") == "1" else "/redoc",
)

_cors_origins = [o.strip() for o in os.environ.get("DIGITAL_TWIN_CORS_ORIGINS", "").split(",") if o.strip()]
if _cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "DELETE"],
        allow_headers=["X-API-Key", "Content-Type"],
    )


# --- Request/response models -------------------------------------------------


class TouchOffRequest(BaseModel):
    label: str = Field(..., min_length=1, max_length=64)
    nominal_cell_xyz: Tuple[float, float, float]


class CalibrationPointOut(BaseModel):
    label: str
    nominal_cell_xyz: Tuple[float, float, float]
    measured_base_xyz: Tuple[float, float, float]


class CalibrationResultOut(BaseModel):
    transform: dict
    rms_error_mm: float
    max_error_mm: float
    num_points: int
    meets_sub_mm_target: bool


class CalibrationStatusOut(BaseModel):
    points: List[CalibrationPointOut]
    last_result: Optional[CalibrationResultOut]
    current_offset: dict


# --- Endpoints ----------------------------------------------------------------


@app.get("/healthz")
def healthz():
    return {"status": "ok"}


@app.get("/api/scene", dependencies=[Depends(require_viewer)])
def get_scene():
    """§5.5 — static robot geometry descriptor + manually-authored
    environment; fetched once by the viewport, not part of the live stream."""
    return scene_descriptor()


@app.get("/api/frames", dependencies=[Depends(require_viewer)])
def get_frames(engine: DigitalTwinSyncEngine = Depends(get_engine)):
    """Debug/desktop-panel endpoint: the same frame-graph snapshot the
    WebSocket stream pushes, available as a plain poll for tooling that
    doesn't want a persistent connection."""
    return engine.latest_snapshot()


@app.get("/api/calibration", response_model=CalibrationStatusOut, dependencies=[Depends(require_viewer)])
def get_calibration(engine: DigitalTwinSyncEngine = Depends(get_engine)):
    points = engine.calibration_points()
    last = engine.last_calibration_result()
    return CalibrationStatusOut(
        points=[
            CalibrationPointOut(
                label=p.label, nominal_cell_xyz=p.nominal_cell_xyz, measured_base_xyz=p.measured_base_xyz
            )
            for p in points
        ],
        last_result=(
            CalibrationResultOut(
                transform=last.transform.to_dict(),
                rms_error_mm=last.rms_error_mm,
                max_error_mm=last.max_error_mm,
                num_points=last.num_points,
                meets_sub_mm_target=last.meets_sub_mm_target,
            )
            if last
            else None
        ),
        current_offset=engine.frames.world_transform("robot_base").to_dict(),
    )


@app.post("/api/calibration/touch-off", response_model=CalibrationPointOut, dependencies=[Depends(require_operator)])
def post_touch_off(req: TouchOffRequest, engine: DigitalTwinSyncEngine = Depends(get_engine)):
    """§5.6 guided calibration — operator has just jogged the physical TCP
    to a known reference point; this captures it. See
    twin/calibration.py's module docstring for why the measured side is
    never client-supplied."""
    point = engine.capture_calibration_point(req.label, req.nominal_cell_xyz)
    logger.info("Calibration touch-off captured: %s", point)
    return CalibrationPointOut(
        label=point.label, nominal_cell_xyz=point.nominal_cell_xyz, measured_base_xyz=point.measured_base_xyz
    )


@app.post("/api/calibration/compute", response_model=CalibrationResultOut, dependencies=[Depends(require_operator)])
def post_compute_calibration(engine: DigitalTwinSyncEngine = Depends(get_engine)):
    try:
        result = engine.compute_and_apply_calibration()
    except CalibrationError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    logger.info(
        "Calibration computed and applied: rms=%.3fmm max=%.3fmm meets_target=%s",
        result.rms_error_mm, result.max_error_mm, result.meets_sub_mm_target,
    )
    return CalibrationResultOut(
        transform=result.transform.to_dict(),
        rms_error_mm=result.rms_error_mm,
        max_error_mm=result.max_error_mm,
        num_points=result.num_points,
        meets_sub_mm_target=result.meets_sub_mm_target,
    )


@app.delete("/api/calibration/points", dependencies=[Depends(require_operator)])
def delete_calibration_points(engine: DigitalTwinSyncEngine = Depends(get_engine)):
    engine.clear_calibration_points()
    return {"accepted": True}


@app.delete("/api/calibration", dependencies=[Depends(require_operator)])
def delete_calibration(engine: DigitalTwinSyncEngine = Depends(get_engine)):
    """Resets the *applied* cell->robot_base offset to identity (leaves any
    captured-but-not-yet-computed touch-off points alone; use
    DELETE /api/calibration/points to clear those separately)."""
    engine.reset_calibration()
    return {"accepted": True}


@app.websocket("/ws/twin")
async def ws_twin(websocket: WebSocket, engine: DigitalTwinSyncEngine = Depends(get_engine)):
    """§5.3/§5.4 — streams the render-rate (default 60 Hz) frame-graph
    snapshot to the viewport. Auth via ?api_key=..., same reasoning as
    dashboard/backend/main.py (browsers can't set custom WS headers)."""
    await websocket.accept()
    if not await require_viewer_ws(websocket):
        return
    queue = engine.subscribe()
    try:
        while True:
            snapshot = await queue.get()
            await websocket.send_json(snapshot)
    except WebSocketDisconnect:
        pass
    finally:
        engine.unsubscribe(queue)
