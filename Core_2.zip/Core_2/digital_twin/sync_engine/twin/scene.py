"""twin/scene.py

Platform spec, section 5.5:

    "Robot visualization uses vendor-supplied or platform-authored
    mesh/URDF-equivalent models; the environment (fixtures, conveyors,
    safety fencing) is captured via the 3D Mapping module (section 6) or
    authored manually in the desktop application's scene editor."

No CAD/mesh assets exist in this repo (see README.md "Out of scope: ...
mechanical CAD") and section 6's 3D Mapping module is not built here
either, so this module supplies the two things section 5.5 says are
acceptable substitutes:

1. Procedural robot geometry — cylinder segments between consecutive link
   origins, radius derived from each joint's rated torque (a coarser joint
   needs a physically larger housing; this is a visualization heuristic, not
   an engineering/structural claim). Sized from
   `tools/robot_params.py` / `include/core/robot_config.hpp` — the repo's
   existing single source of truth for DH parameters — not a fourth copy of
   those numbers.
2. A manually-authored static environment (configs/environment_scene.json)
   — the "authored manually in the desktop application's scene editor" path
   from the same sentence, in lieu of building a scene editor UI, which is
   out of scope for this piece.

The frontend (digital_twin/viewport) turns these descriptors into actual
Three.js geometry; this module only decides *what* to draw, not how to draw
it, keeping the render-technology choice out of the sync engine.
"""
from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass
from typing import Dict, List

# Reuse the repo's existing single source of truth for DH parameters rather
# than re-copying them a fourth time (robot_config.hpp is the first copy,
# tools/robot_params.py the second/Python one, per that file's own
# docstring).
_HERE = os.path.dirname(os.path.abspath(__file__))
_REPO_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)
from tools.robot_params import DH_TABLE, JOINT_NAMES, NUM_JOINTS  # noqa: E402

_DEFAULT_ENVIRONMENT_SCENE = os.path.join(os.path.dirname(_HERE), "configs", "environment_scene.json")

# Coarse per-joint housing radius (meters) for procedural visualization only
# — roughly ranked large-module (J1-J3) vs small-module (J4-J6) per
# robot_config.hpp's `is_large_module` split, not derived from any stated
# structural dimension (none is given in the source spec).
_LARGE_JOINT_RADIUS_M = 0.06
_SMALL_JOINT_RADIUS_M = 0.035
_LARGE_JOINTS = {0, 1, 2}  # J1, J2, J3


@dataclass(frozen=True)
class LinkSegment:
    name: str
    from_frame: str  # frame name whose origin is the segment start
    to_frame: str  # frame name whose origin is the segment end
    radius_m: float


def robot_link_segments() -> List[LinkSegment]:
    """One cylinder per consecutive pair of frame origins:
    robot_base->link1, link1->link2, ..., link5->link6. Radii from the
    large/small module split above."""
    frame_chain = ["robot_base"] + [f"link{i}" for i in range(1, NUM_JOINTS + 1)]
    segments: List[LinkSegment] = []
    for i in range(NUM_JOINTS):
        radius = _LARGE_JOINT_RADIUS_M if i in _LARGE_JOINTS else _SMALL_JOINT_RADIUS_M
        segments.append(
            LinkSegment(
                name=f"{JOINT_NAMES[i]}_link",
                from_frame=frame_chain[i],
                to_frame=frame_chain[i + 1],
                radius_m=radius,
            )
        )
    return segments


def robot_geometry_descriptor() -> Dict:
    return {
        "joint_names": JOINT_NAMES,
        "num_joints": NUM_JOINTS,
        "dh_table": [{"a_m": a, "alpha_rad": alpha, "d_m": d} for (a, alpha, d) in DH_TABLE],
        "segments": [
            {"name": s.name, "from_frame": s.from_frame, "to_frame": s.to_frame, "radius_m": s.radius_m}
            for s in robot_link_segments()
        ],
        "note": (
            "Procedural geometry (cylinder segments between link frame "
            "origins) — no CAD mesh exists for this design; see "
            "digital_twin/README.md."
        ),
    }


def load_environment_scene(path: str | None = None) -> Dict:
    scene_path = path or _DEFAULT_ENVIRONMENT_SCENE
    if not os.path.exists(scene_path):
        return {"objects": [], "note": f"no environment scene file at {scene_path}"}
    with open(scene_path, "r", encoding="utf-8") as f:
        return json.load(f)


def scene_descriptor(environment_scene_path: str | None = None) -> Dict:
    return {
        "robot": robot_geometry_descriptor(),
        "environment": load_environment_scene(environment_scene_path),
    }
