"""twin/transform.py

Rigid-body transform primitive for the Digital Twin Sync Engine's frame
graph (PDF spec section reference: "Industrial Robotics Operating Platform
for MSMEs", section 5.6 — "world -> cell -> robot base -> joint chain ->
tool -> workpiece").

Internally represented as a 3x3 rotation matrix + 3-vector translation —
exactly mirroring `core::Transform` in the C++ core
(include/core/linalg.hpp) — with quaternion conversion only at the API
boundary (construction from / serialization to the native bridge's
LinkPoseC and the JSON the frontend consumes), for two reasons:

1. Composing many transforms as matrices avoids the well-known "quaternion
   multiplication order" bug class; matrix multiplication has one
   unambiguous convention.
2. It lets `test_transform.py` cross-check numeric output directly against
   the C++ `test_quaternion.cpp` / the `robot_bridge_compute_link_frames`
   probe (see digital_twin/sync_engine/README.md), so the Python and C++
   sides are verified to agree on the same convention rather than assumed
   to.

Convention: Transform T_a_b maps a point/frame expressed in frame b into
frame a's coordinates: p_a = T_a_b.apply(p_b). Composition
T_a_c = T_a_b @ T_b_c (same convention as core::Transform::operator*).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

_IDENTITY_R = np.eye(3, dtype=np.float64)
_ZERO_P = np.zeros(3, dtype=np.float64)


@dataclass(frozen=True)
class Transform:
    R: np.ndarray  # (3,3) rotation matrix
    p: np.ndarray  # (3,) translation, meters

    def __post_init__(self) -> None:
        if self.R.shape != (3, 3):
            raise ValueError(f"Transform.R must be 3x3, got {self.R.shape}")
        if self.p.shape != (3,):
            raise ValueError(f"Transform.p must be shape (3,), got {self.p.shape}")

    # --- Construction ---------------------------------------------------

    @staticmethod
    def identity() -> "Transform":
        return Transform(R=_IDENTITY_R.copy(), p=_ZERO_P.copy())

    @staticmethod
    def from_translation(x: float, y: float, z: float) -> "Transform":
        return Transform(R=_IDENTITY_R.copy(), p=np.array([x, y, z], dtype=np.float64))

    @staticmethod
    def from_quaternion(px: float, py: float, pz: float, qw: float, qx: float, qy: float, qz: float) -> "Transform":
        """Inverse of `to_quaternion()`. Mirrors core::Matrix3::fromQuaternion
        exactly (same formula) so a pose round-tripped through the native
        bridge's LinkPoseC (which is quaternion-based) reconstructs the
        identical rotation matrix the C++ side computed."""
        n = (qw * qw + qx * qx + qy * qy + qz * qz) ** 0.5
        if n < 1e-12:
            qw, qx, qy, qz = 1.0, 0.0, 0.0, 0.0
        else:
            qw, qx, qy, qz = qw / n, qx / n, qy / n, qz / n
        ww, xx, yy, zz = qw * qw, qx * qx, qy * qy, qz * qz
        wx, wy, wz = qw * qx, qw * qy, qw * qz
        xy, xz, yz = qx * qy, qx * qz, qy * qz
        R = np.array(
            [
                [ww + xx - yy - zz, 2 * (xy - wz), 2 * (xz + wy)],
                [2 * (xy + wz), ww - xx + yy - zz, 2 * (yz - wx)],
                [2 * (xz - wy), 2 * (yz + wx), ww - xx - yy + zz],
            ],
            dtype=np.float64,
        )
        return Transform(R=R, p=np.array([px, py, pz], dtype=np.float64))

    @staticmethod
    def from_rotation_translation(R: np.ndarray, p: np.ndarray) -> "Transform":
        return Transform(R=np.asarray(R, dtype=np.float64), p=np.asarray(p, dtype=np.float64))

    # --- Conversion -------------------------------------------------------

    def to_quaternion(self) -> tuple[float, float, float, float, float, float, float]:
        """Returns (px, py, pz, qw, qx, qy, qz). Trace-based (Shepperd's
        method) conversion — identical branching/formula to
        core::Matrix3::toQuaternion() in include/core/linalg.hpp, so the two
        implementations are numerically interchangeable (see
        test_transform.py::test_matches_cpp_home_pose)."""
        m = self.R
        trace = m[0, 0] + m[1, 1] + m[2, 2]
        if trace > 0.0:
            s = (trace + 1.0) ** 0.5 * 2.0
            qw = 0.25 * s
            qx = (m[2, 1] - m[1, 2]) / s
            qy = (m[0, 2] - m[2, 0]) / s
            qz = (m[1, 0] - m[0, 1]) / s
        elif m[0, 0] > m[1, 1] and m[0, 0] > m[2, 2]:
            s = (1.0 + m[0, 0] - m[1, 1] - m[2, 2]) ** 0.5 * 2.0
            qw = (m[2, 1] - m[1, 2]) / s
            qx = 0.25 * s
            qy = (m[0, 1] + m[1, 0]) / s
            qz = (m[0, 2] + m[2, 0]) / s
        elif m[1, 1] > m[2, 2]:
            s = (1.0 + m[1, 1] - m[0, 0] - m[2, 2]) ** 0.5 * 2.0
            qw = (m[0, 2] - m[2, 0]) / s
            qx = (m[0, 1] + m[1, 0]) / s
            qy = 0.25 * s
            qz = (m[1, 2] + m[2, 1]) / s
        else:
            s = (1.0 + m[2, 2] - m[0, 0] - m[1, 1]) ** 0.5 * 2.0
            qw = (m[1, 0] - m[0, 1]) / s
            qx = (m[0, 2] + m[2, 0]) / s
            qy = (m[1, 2] + m[2, 1]) / s
            qz = 0.25 * s
        n = (qw * qw + qx * qx + qy * qy + qz * qz) ** 0.5
        if n < 1e-12:
            qw, qx, qy, qz = 1.0, 0.0, 0.0, 0.0
        else:
            qw, qx, qy, qz = qw / n, qx / n, qy / n, qz / n
        return (float(self.p[0]), float(self.p[1]), float(self.p[2]), float(qw), float(qx), float(qy), float(qz))

    def to_dict(self) -> dict:
        px, py, pz, qw, qx, qy, qz = self.to_quaternion()
        return {"position": [px, py, pz], "quaternion": [qw, qx, qy, qz]}

    # --- Algebra ------------------------------------------------------------

    def __matmul__(self, other: "Transform") -> "Transform":
        """T_a_c = T_a_b @ T_b_c."""
        if not isinstance(other, Transform):
            return NotImplemented
        return Transform(R=self.R @ other.R, p=self.R @ other.p + self.p)

    def apply(self, v: np.ndarray) -> np.ndarray:
        return self.R @ np.asarray(v, dtype=np.float64) + self.p

    def inverse(self) -> "Transform":
        Rt = self.R.T
        return Transform(R=Rt, p=-(Rt @ self.p))
