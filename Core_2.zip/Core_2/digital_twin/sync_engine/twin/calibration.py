"""twin/calibration.py

Platform spec, section 5.6:

    "a guided calibration workflow (touch-off points, or vision-assisted
    calibration where a camera is available) to align the digital twin's
    coordinate frames with the physical cell to sub-millimeter-class
    accuracy for pick-place-class tasks."

This implements the touch-off half of that (vision-assisted calibration
needs the 3D Mapping / camera pipeline, section 6, which is out of scope
here — see digital_twin/README.md).

Workflow: an operator jogs the physical robot's TCP to each of several
known reference points in the cell (e.g. dowel pins or fixture corners with
surveyed/CAD-nominal coordinates), and at each one calls the "capture"
endpoint. The engine pairs the operator-entered nominal cell-frame
coordinate with the *current* TCP position it independently computes from
live joint telemetry (base-frame FK) — the operator never supplies the
measured/base-frame side of the pair, which is what keeps this an actual
physical-to-digital alignment rather than something that trivially
"calibrates" to whatever the client claims.

Math: Kabsch algorithm (SVD-based least-squares rigid transform) — the
standard, numerically well-behaved solution to "find the rotation +
translation that best maps one point set onto another", used here to solve
for T_cell_robot_base from >= 3 point correspondences.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

import numpy as np

from .transform import Transform

MIN_CALIBRATION_POINTS = 3

# "Sub-millimeter-class accuracy" (section 5.6) isn't given a numeric
# tolerance in the source spec, so this is an explicit, documented
# engineering choice (same PLACEHOLDER-style honesty as
# include/core/robot_config.hpp's DH-table gaps) rather than a number
# quietly invented and left unexplained.
SUB_MM_FIT_THRESHOLD_MM = 0.5

# Below this, the smallest singular value of the point-spread covariance is
# considered numerically degenerate: the touch-off points are (near)
# collinear and cannot uniquely determine a 3D rotation (infinitely many
# rotations about the collinear axis fit equally well). Value is relative to
# the largest singular value, not an absolute distance, so it scales with
# how far apart the touch-off points actually are.
_DEGENERACY_RATIO = 1e-6


class CalibrationError(Exception):
    pass


@dataclass(frozen=True)
class CalibrationPoint:
    label: str
    nominal_cell_xyz: Tuple[float, float, float]  # design/survey truth, in the cell frame, meters
    measured_base_xyz: Tuple[float, float, float]  # captured TCP position, robot base frame, meters


@dataclass(frozen=True)
class CalibrationResult:
    transform: Transform  # T_cell_robot_base
    rms_error_mm: float
    max_error_mm: float
    num_points: int
    meets_sub_mm_target: bool


def compute_calibration(points: List[CalibrationPoint]) -> CalibrationResult:
    if len(points) < MIN_CALIBRATION_POINTS:
        raise CalibrationError(
            f"need at least {MIN_CALIBRATION_POINTS} touch-off points, got {len(points)}"
        )

    src = np.array([p.measured_base_xyz for p in points], dtype=np.float64)  # base frame
    dst = np.array([p.nominal_cell_xyz for p in points], dtype=np.float64)  # cell frame

    centroid_src = src.mean(axis=0)
    centroid_dst = dst.mean(axis=0)
    src_c = src - centroid_src
    dst_c = dst - centroid_dst

    H = src_c.T @ dst_c  # 3x3
    U, S, Vt = np.linalg.svd(H)

    if S[-1] < _DEGENERACY_RATIO * max(S[0], 1e-12):
        raise CalibrationError(
            "touch-off points are (near-)collinear — cannot uniquely determine a 3D rotation. "
            "Use points that span an area, not a line."
        )

    d = np.sign(np.linalg.det(Vt.T @ U.T))
    if d == 0:
        d = 1.0
    correction = np.diag([1.0, 1.0, d])
    R = Vt.T @ correction @ U.T
    t = centroid_dst - R @ centroid_src

    fitted = (R @ src.T).T + t
    residuals_mm = np.linalg.norm(fitted - dst, axis=1) * 1000.0
    rms_mm = float(np.sqrt(np.mean(residuals_mm**2)))
    max_mm = float(np.max(residuals_mm))

    return CalibrationResult(
        transform=Transform.from_rotation_translation(R, t),
        rms_error_mm=rms_mm,
        max_error_mm=max_mm,
        num_points=len(points),
        meets_sub_mm_target=rms_mm <= SUB_MM_FIT_THRESHOLD_MM,
    )
