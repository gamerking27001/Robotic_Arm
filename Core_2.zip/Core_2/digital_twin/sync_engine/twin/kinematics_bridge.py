"""twin/kinematics_bridge.py

Thin ctypes wrapper around `robot_bridge_compute_link_frames()`
(dashboard/backend/native_bridge/robot_bridge.h) — the same already-verified
DH forward-kinematics chain the core C++ stack and arm_demo use
(arm::kinematics::DHKinematicChain), not a reimplementation.

Deliberately reuses dashboard/backend's compiled
`native_bridge/librobot_bridge.so` rather than building a separate copy: one
compiled kinematics implementation for the whole repo, one place to rebuild
after a DH-table change (configs/... -> include/core/robot_config.hpp).
Build it first with `dashboard/backend/build.sh` — see this package's
README.md.
"""
from __future__ import annotations

import ctypes
import os
from typing import List, Sequence

from .transform import Transform

NUM_JOINTS = 6


class LinkPoseC(ctypes.Structure):
    _fields_ = [
        ("px", ctypes.c_double),
        ("py", ctypes.c_double),
        ("pz", ctypes.c_double),
        ("qw", ctypes.c_double),
        ("qx", ctypes.c_double),
        ("qy", ctypes.c_double),
        ("qz", ctypes.c_double),
    ]


class KinematicsBridgeUnavailable(RuntimeError):
    pass


def _default_library_path() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    # digital_twin/sync_engine/twin/ -> ../../../dashboard/backend/native_bridge
    repo_root = os.path.abspath(os.path.join(here, "..", "..", ".."))
    return os.path.join(repo_root, "dashboard", "backend", "native_bridge", "librobot_bridge.so")


class KinematicsBridge:
    """Loads the shared library lazily (not at import time) so importing
    this module — e.g. from tests that only exercise the pure-Python pieces
    (interpolation, calibration, frames) — never requires the native bridge
    to be built."""

    def __init__(self, library_path: str | None = None) -> None:
        self._path = library_path or _default_library_path()
        self._lib: ctypes.CDLL | None = None

    def _ensure_loaded(self) -> ctypes.CDLL:
        if self._lib is not None:
            return self._lib
        if not os.path.exists(self._path):
            raise KinematicsBridgeUnavailable(
                f"{self._path} not found. Build it with: "
                f"(cd dashboard/backend && ./build.sh)"
            )
        lib = ctypes.CDLL(self._path)
        lib.robot_bridge_compute_link_frames.argtypes = [
            ctypes.POINTER(ctypes.c_double),
            ctypes.POINTER(LinkPoseC),
        ]
        lib.robot_bridge_compute_link_frames.restype = None
        self._lib = lib
        return lib

    def compute_link_frames(self, q_rad: Sequence[float]) -> List[Transform]:
        """q_rad: 6 joint angles (radians, J1..J6). Returns 6 Transforms,
        each T_base_link(i+1) — link_frames[5] is the TCP/flange pose."""
        if len(q_rad) != NUM_JOINTS:
            raise ValueError(f"expected {NUM_JOINTS} joint angles, got {len(q_rad)}")
        lib = self._ensure_loaded()
        q_arr = (ctypes.c_double * NUM_JOINTS)(*[float(v) for v in q_rad])
        out_arr = (LinkPoseC * NUM_JOINTS)()
        lib.robot_bridge_compute_link_frames(q_arr, out_arr)
        return [
            Transform.from_quaternion(p.px, p.py, p.pz, p.qw, p.qx, p.qy, p.qz) for p in out_arr
        ]

    def is_available(self) -> bool:
        return os.path.exists(self._path)
