"""twin/telemetry_source.py

Where the Digital Twin Sync Engine gets "LiveJointTelemetry" from (platform
spec section 5.3's data-flow diagram). The interpolator (interpolation.py)
doesn't care which of these is used — that's the point of the abstraction:
it decouples the render loop from the ingestion mechanism as cleanly as it
decouples render rate from telemetry rate.

Two implementations:

- WebSocketTelemetrySource: connects to the existing, already-authenticated
  robotic_arm_core dashboard backend's `/ws/telemetry` endpoint
  (dashboard/backend/main.py) as the real telemetry feed. Note this stream
  is pushed at ~10 Hz (dashboard/backend/main.py's `ws_telemetry` sleeps
  0.1s between frames) — deliberately *below* even the low end of the
  50-250 Hz range section 5.4 describes for raw controller telemetry, which
  makes it a good real demonstration of why the interpolator exists: the
  twin still needs to render at 60 fps from this.

- SyntheticTelemetrySource: generates smooth joint motion locally, no
  network dependency — used by the test suite and by `api.py` when no live
  dashboard is configured (DIGITAL_TWIN_TELEMETRY_SOURCE=synthetic), e.g.
  for a standalone demo of the Digital Twin viewport.
"""
from __future__ import annotations

import abc
import asyncio
import json
import logging
import math
import time
from typing import AsyncIterator, Optional, Tuple

logger = logging.getLogger("digital_twin.telemetry_source")

NUM_JOINTS = 6
Sample = Tuple[float, Tuple[float, ...]]  # (monotonic timestamp, radians x6)


class TelemetrySource(abc.ABC):
    @abc.abstractmethod
    async def samples(self) -> AsyncIterator[Sample]:
        """Async-generator: yields (t, q_rad) forever until cancelled."""
        if False:  # pragma: no cover - makes this an async generator to subclasses' type checkers
            yield  # type: ignore[misc]


class SyntheticTelemetrySource(TelemetrySource):
    """Sinusoidal joint motion, deterministic given a seed phase — enough to
    exercise the whole pipeline (interpolation -> FK -> frame graph -> WS
    broadcast) without a live robot_bridge session or network connection."""

    def __init__(self, hz: float = 20.0, amplitude_deg: float = 15.0, period_s: float = 6.0) -> None:
        self.hz = hz
        self.amplitude_rad = math.radians(amplitude_deg)
        self.period_s = period_s

    async def samples(self) -> AsyncIterator[Sample]:
        dt = 1.0 / self.hz
        t0 = time.monotonic()
        # Distinct phase offset per joint so the synthetic motion is visibly
        # a 6-DOF arm moving, not all joints in lockstep.
        phase = [i * math.pi / 6.0 for i in range(NUM_JOINTS)]
        while True:
            now = time.monotonic()
            elapsed = now - t0
            omega = 2.0 * math.pi / self.period_s
            q = tuple(self.amplitude_rad * math.sin(omega * elapsed + phase[i]) for i in range(NUM_JOINTS))
            yield (now, q)
            await asyncio.sleep(dt)


class WebSocketTelemetrySource(TelemetrySource):
    """Connects to the dashboard backend's authenticated /ws/telemetry
    endpoint and re-derives radians from the `position_deg` field it
    publishes (see dashboard/backend/main.py's JointTelemetryOut)."""

    def __init__(self, url: str, api_key: Optional[str] = None, reconnect_delay_s: float = 2.0) -> None:
        self.url = url
        self.api_key = api_key
        self.reconnect_delay_s = reconnect_delay_s

    async def samples(self) -> AsyncIterator[Sample]:
        # Imported lazily so `websockets` is only a hard dependency for
        # deployments that actually use this source (SyntheticTelemetrySource
        # and every test that doesn't need a live dashboard work without it
        # being installed).
        import websockets

        full_url = self.url
        if self.api_key:
            sep = "&" if "?" in full_url else "?"
            full_url = f"{full_url}{sep}api_key={self.api_key}"

        while True:
            try:
                async with websockets.connect(full_url, ping_interval=10, ping_timeout=10) as ws:
                    logger.info("WebSocketTelemetrySource connected: %s", self.url)
                    async for raw in ws:
                        try:
                            payload = json.loads(raw)
                            joints = payload["telemetry"]["joints"]
                            q_rad = tuple(math.radians(j["position_deg"]) for j in joints)
                        except (KeyError, ValueError, TypeError) as exc:
                            logger.warning("Skipping malformed telemetry frame: %s", exc)
                            continue
                        yield (time.monotonic(), q_rad)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - deliberately broad: any connection failure should retry, not crash the sync engine
                logger.warning("WebSocketTelemetrySource disconnected (%s) — reconnecting in %.1fs", exc, self.reconnect_delay_s)
                await asyncio.sleep(self.reconnect_delay_s)
