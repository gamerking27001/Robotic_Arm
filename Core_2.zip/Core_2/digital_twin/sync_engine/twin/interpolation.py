"""twin/interpolation.py

Platform spec, section 5.4 ("Real-Time Synchronization"):

    "The twin update rate is decoupled from the raw telemetry rate: joint
    state is interpolated between telemetry samples so the 3D view renders
    smoothly (target 60 fps) even when the underlying robot reports state
    at a lower fixed rate (typically 50-250 Hz depending on controller)."

This module is that decoupling. It does not know or care where samples come
from (see telemetry_source.py) or what consumes its output (sync_service.py
calls sample_at() on its own fixed-rate render clock, independent of
whatever rate push_sample() is being called at).

Interpolation is linear per joint angle, not slerp/quaternion-based — each
of the 6 values is a scalar revolute-joint angle (radians), not a 3D
orientation, so linear interpolation of the angle is both correct and
exactly what the forward-kinematics step downstream expects as input.
"""
from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass
from typing import Deque, Optional, Sequence, Tuple

NUM_JOINTS = 6


@dataclass(frozen=True)
class JointSample:
    t: float  # seconds, monotonic clock (time.monotonic())
    q: Tuple[float, ...]  # radians, length NUM_JOINTS


@dataclass(frozen=True)
class InterpolationResult:
    q: Tuple[float, ...]
    age_s: float  # time.monotonic() - (timestamp of the freshest sample actually used)
    extrapolated: bool  # True if t_query fell after the newest buffered sample
    stale: bool  # True if no fresh-enough sample exists at all (see staleness_timeout_s)


class JointStateInterpolator:
    def __init__(
        self,
        num_joints: int = NUM_JOINTS,
        buffer_size: int = 8,
        staleness_timeout_s: float = 0.5,
        max_extrapolation_s: float = 0.15,
    ) -> None:
        """
        staleness_timeout_s: if the newest sample is older than this, output
            is flagged `stale` (operator-visible "twin may not reflect
            reality" signal — analogous in spirit to section 8.8's Digital
            Twin Intelligence AI deviation check, but here it's simply "we
            stopped receiving telemetry", not a physical/twin mismatch).
        max_extrapolation_s: constant-velocity extrapolation is only trusted
            this far past the newest sample; beyond that the last known
            position is held rather than extrapolated further (a stalled
            feed shouldn't make the twin keep "coasting" indefinitely on a
            velocity estimate that's increasingly unlikely to still be
            valid).
        """
        if num_joints < 1:
            raise ValueError("num_joints must be >= 1")
        self.num_joints = num_joints
        self.staleness_timeout_s = staleness_timeout_s
        self.max_extrapolation_s = max_extrapolation_s
        self._buf: Deque[JointSample] = deque(maxlen=buffer_size)

    def push_sample(self, t: float, q: Sequence[float]) -> None:
        if len(q) != self.num_joints:
            raise ValueError(f"expected {self.num_joints} joint values, got {len(q)}")
        if self._buf and t <= self._buf[-1].t:
            # Out-of-order or duplicate-timestamp sample (can happen with a
            # jittery network telemetry source) — dropped rather than
            # inserted out of order, since sample_at() assumes the buffer is
            # time-sorted ascending.
            return
        self._buf.append(JointSample(t=t, q=tuple(float(v) for v in q)))

    def has_data(self) -> bool:
        return len(self._buf) > 0

    def sample_at(self, t_query: Optional[float] = None) -> InterpolationResult:
        if t_query is None:
            t_query = time.monotonic()

        if not self._buf:
            return InterpolationResult(q=tuple(0.0 for _ in range(self.num_joints)), age_s=float("inf"),
                                        extrapolated=False, stale=True)

        newest = self._buf[-1]
        oldest = self._buf[0]

        if t_query <= oldest.t:
            # Querying at/before the earliest buffered sample — normal right
            # at startup, before two samples have arrived to interpolate
            # between. Hold the earliest known state; not "stale" in the
            # telemetry-stopped sense, just not interpolatable yet.
            return InterpolationResult(q=oldest.q, age_s=0.0, extrapolated=False, stale=False)

        if t_query >= newest.t:
            age = t_query - newest.t
            stale = age > self.staleness_timeout_s
            if len(self._buf) >= 2 and age <= self.max_extrapolation_s:
                prev = self._buf[-2]
                dt_hist = newest.t - prev.t
                if dt_hist > 1e-9:
                    velocity = tuple((newest.q[i] - prev.q[i]) / dt_hist for i in range(self.num_joints))
                    q = tuple(newest.q[i] + velocity[i] * age for i in range(self.num_joints))
                    return InterpolationResult(q=q, age_s=age, extrapolated=True, stale=stale)
            # No velocity estimate available, or the query is far enough
            # past the newest sample that we no longer trust a linear
            # extrapolation — hold last known position instead of coasting.
            return InterpolationResult(q=newest.q, age_s=age, extrapolated=age > 0.0, stale=stale)

        # t_query falls strictly between two buffered samples: find the
        # bracketing pair and interpolate. Buffer is small (<= buffer_size,
        # default 8) so a linear scan is simpler and fast enough versus
        # bisect — this runs once per output tick, at most ~250 Hz.
        for i in range(len(self._buf) - 1):
            a, b = self._buf[i], self._buf[i + 1]
            if a.t <= t_query <= b.t:
                span = b.t - a.t
                frac = 0.0 if span <= 1e-9 else (t_query - a.t) / span
                q = tuple(a.q[j] + (b.q[j] - a.q[j]) * frac for j in range(self.num_joints))
                return InterpolationResult(q=q, age_s=0.0, extrapolated=False, stale=False)

        # Unreachable given the bounds checks above; fail safe rather than
        # raise mid-render-loop.
        return InterpolationResult(q=newest.q, age_s=t_query - newest.t, extrapolated=True, stale=False)
