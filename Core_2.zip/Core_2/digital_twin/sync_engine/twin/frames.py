"""twin/frames.py

The standard frame hierarchy from the platform spec, section 5.6:

    world -> cell -> robot_base -> link1 -> link2 -> ... -> link6 -> tool
                  \\-> workpiece

Notes on the chain structure:
- link1..link6 are parented directly under robot_base (not chained to each
  other) because arm::kinematics::DHKinematicChain::computeLinkFrames()
  already returns every link's pose in the *base* frame (see
  dh_kinematics.cpp / robot_bridge_compute_link_frames) — re-deriving each
  link's pose relative to the previous link would just undo that and redo
  it, for no benefit, since nothing here needs the intermediate per-joint
  relative transforms (the Motion Planner/Jacobian code that does need them
  lives in the C++ core and already has them).
- "cell -> robot_base" is exactly the calibration offset from section 5.6's
  guided calibration workflow (see calibration.py) — this is the one
  transform in the graph that changes as a result of calibration, not
  telemetry.
- "tool" is a static offset off link6 (flange -> TCP/tool-tip), configured
  per end-effector, not computed from telemetry.
- "workpiece" is a static, manually-authored placement in the cell frame
  (section 5.5: "environment ... authored manually in the desktop
  application's scene editor" — no 3D Mapping module, section 6, exists in
  this codebase yet).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .transform import Transform

LINK_NAMES: List[str] = [f"link{i}" for i in range(1, 7)]


class FrameGraphError(Exception):
    pass


@dataclass
class FrameNode:
    name: str
    parent: Optional[str]
    local_transform: Transform  # T_parent_this


@dataclass
class FrameGraph:
    """A small named scene graph. Not a general-purpose library — scoped
    exactly to the fixed hierarchy this platform needs (section 5.6), which
    keeps `world_transform()` a simple parent-walk rather than needing cycle
    detection / arbitrary topology handling a general graph would."""

    _nodes: Dict[str, FrameNode] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self._nodes:
            return  # already populated (e.g. via a test fixture)
        self.add_frame("world", parent=None, local=Transform.identity())
        self.add_frame("cell", parent="world", local=Transform.identity())
        self.add_frame("robot_base", parent="cell", local=Transform.identity())
        for name in LINK_NAMES:
            self.add_frame(name, parent="robot_base", local=Transform.identity())
        self.add_frame("tool", parent="link6", local=Transform.identity())
        self.add_frame("workpiece", parent="cell", local=Transform.identity())

    # --- Mutation -------------------------------------------------------

    def add_frame(self, name: str, parent: Optional[str], local: Transform) -> None:
        if parent is not None and parent not in self._nodes:
            raise FrameGraphError(f"parent frame '{parent}' does not exist (add it first)")
        self._nodes[name] = FrameNode(name=name, parent=parent, local_transform=local)

    def set_local_transform(self, name: str, local: Transform) -> None:
        if name not in self._nodes:
            raise FrameGraphError(f"unknown frame '{name}'")
        self._nodes[name].local_transform = local

    def set_calibration_offset(self, offset: Transform) -> None:
        """Applies the section 5.6 guided-calibration result: the
        cell -> robot_base transform. See calibration.py."""
        self.set_local_transform("robot_base", offset)

    def update_link_frames(self, link_poses_base_frame: List[Transform]) -> None:
        """`link_poses_base_frame[i]` = T_base_link(i+1), exactly the layout
        `robot_bridge_compute_link_frames()` returns (see
        kinematics_bridge.py) — called once per Digital Twin output tick
        (target 60 Hz, section 5.4) with the interpolated joint state's FK
        result."""
        if len(link_poses_base_frame) != len(LINK_NAMES):
            raise FrameGraphError(f"expected {len(LINK_NAMES)} link poses, got {len(link_poses_base_frame)}")
        for name, t in zip(LINK_NAMES, link_poses_base_frame):
            self.set_local_transform(name, t)

    def set_tool_offset(self, offset: Transform) -> None:
        self.set_local_transform("tool", offset)

    def set_workpiece_pose(self, pose_in_cell: Transform) -> None:
        self.set_local_transform("workpiece", pose_in_cell)

    # --- Query ------------------------------------------------------------

    def world_transform(self, name: str) -> Transform:
        node = self._nodes.get(name)
        if node is None:
            raise FrameGraphError(f"unknown frame '{name}'")
        if node.parent is None:
            return node.local_transform
        return self.world_transform(node.parent) @ node.local_transform

    def names(self) -> List[str]:
        return list(self._nodes.keys())

    def parent_of(self, name: str) -> Optional[str]:
        return self._nodes[name].parent

    def snapshot(self) -> Dict[str, dict]:
        """World-frame pose of every node, for the /api/frames debug
        endpoint and the /ws/twin stream."""
        return {name: self.world_transform(name).to_dict() for name in self._nodes}
