"""twin/sync_service.py

Ties together every other module in this package into the "Digital Twin
Sync Engine" module the platform spec describes (section 1.2's core-module
table; the data flow in section 5.3):

    LiveJointTelemetry -> ForwardKinematicsSolver -> 3D pose per link
                                                          |
                    RenderLoop (Simulation Engine / viewport, 60 fps target)

Two independently-running loops, exactly implementing section 5.4's
decoupling:

- `_ingest_loop`: consumes a TelemetrySource at whatever rate it delivers
  samples, pushing each into the JointStateInterpolator. No fixed rate of
  its own — driven entirely by the source.
- `_render_loop`: runs on its own fixed-rate clock (`render_hz`, default
  60), independent of the ingest rate. Each tick: ask the interpolator for
  the joint state *right now*, run FK, update the frame graph, and publish a
  snapshot to every subscribed WebSocket client (digital_twin/viewport).
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Dict, List, Optional, Set

from .calibration import CalibrationPoint, CalibrationResult, compute_calibration
from .frames import FrameGraph
from .interpolation import JointStateInterpolator
from .kinematics_bridge import KinematicsBridge, KinematicsBridgeUnavailable
from .telemetry_source import TelemetrySource
from .transform import Transform

logger = logging.getLogger("digital_twin.sync_service")

DEFAULT_RENDER_HZ = 60.0


class DigitalTwinSyncEngine:
    def __init__(
        self,
        telemetry_source: TelemetrySource,
        kinematics: Optional[KinematicsBridge] = None,
        render_hz: float = DEFAULT_RENDER_HZ,
    ) -> None:
        self.telemetry_source = telemetry_source
        self.kinematics = kinematics or KinematicsBridge()
        self.render_hz = render_hz

        self.interpolator = JointStateInterpolator()
        self.frames = FrameGraph()

        self._subscribers: Set[asyncio.Queue] = set()
        self._latest_snapshot: Dict = {"frames": {}, "stale": True, "extrapolated": False, "age_s": None}
        self._calibration_points: List[CalibrationPoint] = []
        self._last_calibration_result: Optional[CalibrationResult] = None

        self._tasks: List[asyncio.Task] = []
        self._kinematics_warned = False

    # --- Lifecycle --------------------------------------------------------

    async def start(self) -> None:
        self._tasks = [
            asyncio.create_task(self._ingest_loop(), name="twin-ingest"),
            asyncio.create_task(self._render_loop(), name="twin-render"),
        ]

    async def stop(self) -> None:
        for t in self._tasks:
            t.cancel()
        for t in self._tasks:
            try:
                await t
            except asyncio.CancelledError:
                pass
        self._tasks = []

    # --- Ingest -------------------------------------------------------------

    async def _ingest_loop(self) -> None:
        async for t, q_rad in self.telemetry_source.samples():
            self.interpolator.push_sample(t, q_rad)

    # --- Render / publish ---------------------------------------------------

    async def _render_loop(self) -> None:
        period = 1.0 / self.render_hz
        while True:
            tick_start = time.monotonic()
            self._render_tick()
            elapsed = time.monotonic() - tick_start
            await asyncio.sleep(max(0.0, period - elapsed))

    def _render_tick(self) -> None:
        result = self.interpolator.sample_at()

        link_poses: Optional[List[Transform]] = None
        if not result.stale or self.interpolator.has_data():
            try:
                link_poses = self.kinematics.compute_link_frames(result.q)
            except KinematicsBridgeUnavailable as exc:
                if not self._kinematics_warned:
                    logger.warning("Kinematics bridge unavailable, twin will not update link poses: %s", exc)
                    self._kinematics_warned = True

        if link_poses is not None:
            self.frames.update_link_frames(link_poses)

        snapshot = {
            "frames": self.frames.snapshot(),
            "joint_angles_rad": list(result.q),
            "stale": result.stale,
            "extrapolated": result.extrapolated,
            "age_s": result.age_s,
            "server_time": time.time(),
            "render_hz": self.render_hz,
        }
        self._latest_snapshot = snapshot
        self._publish(snapshot)

    def _publish(self, snapshot: Dict) -> None:
        dead: List[asyncio.Queue] = []
        for q in self._subscribers:
            try:
                q.put_nowait(snapshot)
            except asyncio.QueueFull:
                # Slow consumer — drop this tick for them rather than block
                # the whole render loop on one lagging client.
                try:
                    q.get_nowait()
                    q.put_nowait(snapshot)
                except (asyncio.QueueEmpty, asyncio.QueueFull):
                    dead.append(q)
        for q in dead:
            self._subscribers.discard(q)

    # --- Subscription (used by the /ws/twin endpoint) ------------------

    def subscribe(self) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=2)
        self._subscribers.add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        self._subscribers.discard(q)

    def latest_snapshot(self) -> Dict:
        return self._latest_snapshot

    # --- Calibration (section 5.6) -----------------------------------------

    def capture_calibration_point(self, label: str, nominal_cell_xyz: tuple) -> CalibrationPoint:
        """Pairs the operator-supplied nominal (cell-frame) coordinate with
        the *current* measured TCP position in the base frame — the operator
        never supplies the measured side directly (see calibration.py's
        module docstring for why)."""
        result = self.interpolator.sample_at()
        link_poses = self.kinematics.compute_link_frames(result.q)
        tcp = link_poses[-1]  # link6 == TCP/flange
        point = CalibrationPoint(
            label=label,
            nominal_cell_xyz=tuple(float(v) for v in nominal_cell_xyz),
            measured_base_xyz=(float(tcp.p[0]), float(tcp.p[1]), float(tcp.p[2])),
        )
        self._calibration_points.append(point)
        return point

    def calibration_points(self) -> List[CalibrationPoint]:
        return list(self._calibration_points)

    def clear_calibration_points(self) -> None:
        self._calibration_points = []

    def compute_and_apply_calibration(self) -> CalibrationResult:
        result = compute_calibration(self._calibration_points)
        self.frames.set_calibration_offset(result.transform)
        self._last_calibration_result = result
        return result

    def reset_calibration(self) -> None:
        self.frames.set_calibration_offset(Transform.identity())
        self._last_calibration_result = None

    def last_calibration_result(self) -> Optional[CalibrationResult]:
        return self._last_calibration_result
