# digital_twin/sync_engine

The Digital Twin Sync Engine service (FastAPI). See
[`../README.md`](../README.md) for architecture, scope, and end-to-end run
instructions.

## Layout

- `api.py` — FastAPI app: auth, REST endpoints, `/ws/twin`.
- `twin/transform.py` — rigid transform (matrix-based; quaternion at the API boundary).
- `twin/frames.py` — the section 5.6 frame hierarchy.
- `twin/interpolation.py` — section 5.4 render/telemetry rate decoupling.
- `twin/calibration.py` — section 5.6 Kabsch touch-off calibration.
- `twin/kinematics_bridge.py` — ctypes bridge to the native FK export.
- `twin/telemetry_source.py` — synthetic + live-WebSocket telemetry sources.
- `twin/scene.py` — procedural robot geometry + environment scene loading.
- `twin/sync_service.py` — orchestrates the above into the running engine.
- `configs/environment_scene.json` — manually-authored static environment (section 5.5).
- `tests/` — pytest suite (47 tests; run with `python3 -m pytest tests/ -q`).

## Local dev

```bash
pip install -r requirements.txt --break-system-packages   # or use a venv
python3 -m pytest tests/ -q

export DIGITAL_TWIN_ALLOW_INSECURE=1   # dev only -- see api.py's module docstring
uvicorn api:app --reload --port 8100
```

`tests/test_kinematics_bridge.py` auto-skips if
`dashboard/backend/native_bridge/librobot_bridge.so` hasn't been built yet
(`cd ../../dashboard/backend && ./build.sh`); every other test file has no
native dependency.
