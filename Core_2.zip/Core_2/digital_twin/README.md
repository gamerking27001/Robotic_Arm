# Digital Twin (platform spec section 5)

Implements the "Digital Twin Sync Engine" core module from *Industrial
Robotics Operating Platform for MSMEs* (section 1.2's module table; section
5 in full), scoped to work against the one robot this repo actually has:
[`robotic_arm_core`](../README.md), the hardware-facing arm this platform
spec's software layer would eventually sit in front of for many robots and
brands.

```
digital_twin/
  sync_engine/    Python/FastAPI service -- the actual "Digital Twin Sync
                  Engine" module: telemetry ingestion, render-rate
                  decoupling (section 5.4), forward kinematics, the frame
                  hierarchy (section 5.6), touch-off calibration.
  viewport/       React + TypeScript + three.js "DigitalTwinViewport"
                  (section 5.5) -- the 3D client that renders what the
                  sync engine publishes.
```

## What this is (and isn't)

Built to section 5's spec:
- §5.3/§5.4: live joint telemetry -> forward kinematics -> 3D pose per
  link, with the render rate (60 fps target) explicitly decoupled from
  telemetry rate.
- §5.5: robot visualization + a manually-authored environment (no CAD
  meshes, no 3D Mapping module -- see below).
- §5.6: the `world -> cell -> robot_base -> link1..6 -> tool` /
  `-> workpiece` frame hierarchy, and guided touch-off calibration.

Explicitly **not** built here (out of scope for this piece, not silently
assumed):
- **Section 6 (3D Mapping / LiDAR)** — the environment model is manually
  authored (`sync_engine/configs/environment_scene.json`), exactly the
  fallback section 5.5 names ("...or authored manually in the desktop
  application's scene editor"). No LiDAR/depth-camera pipeline exists in
  this repo.
- **CAD/mesh assets** — `robotic_arm_core`'s own README already scopes
  mechanical CAD out (see its "Out of scope" section); this module's robot
  visualization is therefore procedural geometry (cylinder segments between
  DH-derived link-frame origins — see `sync_engine/twin/scene.py`), not
  vendor mesh files.
- **Vision-assisted calibration** — section 5.6 offers touch-off *or*
  vision-assisted; only touch-off is implemented (vision-assisted needs the
  camera/3D-mapping pipeline above).
- **A desktop scene editor UI** — the environment is a hand-edited JSON
  file, not an in-app editor.
- **Multi-robot / multi-brand support** — sections 1-2's broader platform
  vision (many robots, many vendors, a Local Gateway Service in front of
  each) isn't built; this connects to exactly one `robotic_arm_core`-style
  arm.

## How the pieces connect

```
robotic_arm_core/dashboard/backend  --(WS /ws/telemetry, ~10Hz)-->  digital_twin/sync_engine
                                                                          |
                                     (ctypes -> new robot_bridge_compute_link_frames export)
                                                                          |
                                                                  arm::kinematics::DHKinematicChain
                                                                     (include/kinematics/, unchanged)

digital_twin/sync_engine  --(WS /ws/twin, 60Hz interpolated)-->  digital_twin/viewport
```

The sync engine doesn't reimplement forward kinematics — it calls into the
same `DHKinematicChain` the C++ core and `arm_demo` already use, through
one new, minimal, stateless export added to
`dashboard/backend/native_bridge/robot_bridge.{h,cpp}`
(`robot_bridge_compute_link_frames`). See that file's comments and
`tests/core/test_quaternion.cpp` for how the new C++ additions
(`core::Quaternion`, `Matrix3::toQuaternion()`/`fromQuaternion()`) were
verified, and `sync_engine/tests/test_kinematics_bridge.py` for the
Python-side cross-check against `arm_demo`'s own printed home-pose output.

## Running it end to end

```bash
# 1. Build the native bridge (also used by dashboard/backend itself)
cd robotic_arm_core/dashboard/backend && ./build.sh && cd -

# 2. Digital Twin Sync Engine
cd robotic_arm_core/digital_twin/sync_engine
pip install -r requirements.txt --break-system-packages
export DIGITAL_TWIN_VIEWER_API_KEY=change-me-viewer
export DIGITAL_TWIN_OPERATOR_API_KEY=change-me-operator
export DIGITAL_TWIN_TELEMETRY_SOURCE=synthetic   # or "websocket" against a running dashboard backend
uvicorn api:app --port 8100
# (separate terminal) run the test suite:
python3 -m pytest tests/ -q

# 3. Viewport
cd robotic_arm_core/digital_twin/viewport
npm install
npm run dev   # proxies /api and /ws to localhost:8100 (see vite.config.ts)
# open the printed localhost URL, paste the viewer/operator key into
# "Set key" in the header (stored in sessionStorage, same pattern as
# dashboard/frontend)
```

To drive the twin from the real arm instead of synthetic motion:
`DIGITAL_TWIN_TELEMETRY_SOURCE=websocket`,
`DIGITAL_TWIN_DASHBOARD_WS_URL=ws://<dashboard-host>:8000/ws/telemetry`,
`DIGITAL_TWIN_DASHBOARD_API_KEY=<dashboard's own viewer key>` — see
`sync_engine/twin/telemetry_source.py`.

## What's actually verified

- C++: `tests/core/test_quaternion.cpp` passes (`g++ ... && ./test_quaternion`);
  `robot_bridge_compute_link_frames` cross-checked by hand against
  `arm_demo`'s printed home pose (identical to 4 decimal places).
- Python: **47/47** tests pass (`sync_engine/tests/`, `pytest -q`) —
  transform algebra (cross-validated against the C++ convention),
  interpolation/rate-decoupling, Kabsch calibration (recovers known
  rotation+translation exactly on synthetic data; rejects <3 points and
  collinear point sets), the frame graph, the ctypes kinematics bridge
  against the real compiled `.so`, and the FastAPI service end to end
  (auth, scene, frames, calibration workflow, `/ws/twin`).
- TypeScript: `npm run build` (tsc project build + vite production build)
  succeeds clean; `npx oxlint src` reports 0 warnings/errors.
- Not verified: rendering correctness in an actual browser/GPU (this
  environment can build but not visually render WebGL) — the geometry
  math (segment placement/orientation) is documented inline in
  `RobotTwinScene.ts` but hasn't been eyeballed against a real render.
