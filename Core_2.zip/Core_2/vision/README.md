# vision/

§15 (Computer Vision, marked **Optional** in the source doc) + §19.6's
technology stack (OpenCV core; YOLO/TensorRT for object detection). §18's
repository structure places this at the top level: "vision/ # Vision
pipeline: detection, pose estimation, calibration."

## This layer is built and tested — 16/16 tests pass on real synthetic data

```bash
pip install -r requirements.txt
python3 -m pytest tests/ -v
```

Every module has a dedicated test that generates real synthetic image/point
data with a **known ground truth** and checks the module actually recovers
it — not just "does it run without crashing":

| Module | What the test verifies |
|---|---|
| `calibration/` | Chessboard corner detection + `cv2.calibrateCamera` converges on synthetic warped views |
| `part_localization/` | Recovers a known centroid/angle from a synthetic rotated part; pixel→world homography round-trips exactly |
| `barcode_reading/` | Decodes real QR codes (generated via the `qrcode` package) with known payloads, including multiple codes in one image |
| `object_detection/` | The classical color-blob fallback correctly finds and classifies two differently-colored synthetic objects |
| `quality_inspection/` | An identical image passes; a synthetic defect (added blob) fails; mismatched image shapes raise |
| `pose_estimation/` | PCA-recovered surface normal matches a known tilt angle to <0.1°; a non-planar point cloud is correctly flagged as low-planarity |

One test needed fixing during development: the calibration test's initial
reprojection-error threshold assumed near-photographic synthetic views, but
a 2D perspective warp of a flat texture isn't a true pinhole-camera
projection — see the comment in `tests/test_camera_calibration.py` for why
the threshold was loosened rather than treating it as a code bug.

## Module-by-module honesty notes

- **`object_detection/`** is the one module that does NOT implement what
  §15.1/§19.6 actually call for (a YOLO-class detector, TensorRT-accelerated
  on Jetson). Real pretrained weights and a GPU aren't available here, and
  downloading third-party model weights speculatively isn't something to do
  without being asked. What's provided instead is the `ObjectDetector`
  interface a real YOLO wrapper would implement, plus a classical
  color-thresholding fallback that's genuinely useful for small, fixed-SKU
  deployments but does not generalize the way a trained model does — see
  that module's docstring for the full scope note.
- **`pose_estimation/`** implements the point-cloud/PCA half of §15.1's Pose
  Estimation cell; the "learned pose networks" alternative it also lists
  isn't implemented, for the same reason as object detection.
- Every other module (calibration, part localization, barcode reading,
  quality inspection) implements real, working classical CV matching what
  §15.1 specifies for that capability — no placeholders.

## Relationship to ros2_ws

§20.2 lists `vision_pipeline/` as a ROS2 package ("Detection/pose-estimation
nodes"). `ros2_ws/src/vision_pipeline/` wraps these modules as a `vision_node`
subscribing to a camera image topic and publishing `robot_msgs` detection
messages — see `ros2_ws/README.md`'s package table for details. That ROS2
wrapper carries the same "not compiled/tested against a real ROS2 install"
caveat as the rest of `ros2_ws` (no ROS2 available in this environment), but
the vision *logic* it calls into is this package's own independently-tested
code — I verified the exact import/path-resolution logic `vision_node.py`
uses to reach these modules actually works, outside of ROS2, before treating
that wrapper as done.

Camera calibration (`calibration/`) is intentionally NOT wrapped as a
continuously-running node — it's a one-time offline routine in real
deployments, not a per-frame operation — so `vision_node` doesn't call into
it; run `camera_calibration.py` separately and feed its resulting homography
into `vision_node`'s `part_localization.homography` parameter.
