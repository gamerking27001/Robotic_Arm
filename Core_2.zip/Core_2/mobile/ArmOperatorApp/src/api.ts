// src/api.ts
// Same request shapes as dashboard/frontend/src/api.ts, adapted for a native
// app: no same-origin relative URLs (mobile talks to an explicit host), and
// no browser WebSocket-through-Vite-proxy — this polls REST endpoints
// instead of using /ws/telemetry, which is a deliberate simplification (see
// README's "What's simplified vs. dashboard/frontend" section).

export interface RobotSpec {
  payload_nominal_kg: number;
  payload_peak_kg: number;
  reach_mm: number;
  repeatability_mm: number;
  max_tcp_speed_mps: number;
  bus_voltage_vdc: number;
  rated_power_w_peak: number;
}

export interface JointSpec {
  name: string;
  soft_limit_min_deg: number;
  soft_limit_max_deg: number;
}

export interface ConfigResponse {
  robot: RobotSpec;
  joints: JointSpec[];
}

export interface JointTelemetry {
  joint_name: string;
  position_deg: number;
  velocity_deg_s: number;
  current_a: number;
  torque_estimate_nm: number;
  winding_temp_c: number;
  sto_active: boolean;
  fault: boolean;
}

export interface Telemetry {
  joints: JointTelemetry[];
  move_active: boolean;
  elapsed_move_time_s: number;
}

export interface SafetyStatus {
  state: string;
  estop_pressed: boolean;
  sto_required: boolean;
  collision_suspected: boolean;
  overcurrent: boolean;
  overtemperature: boolean;
  soft_limit_violation: boolean;
  hard_limit_violation: boolean;
  any_fault: boolean;
}

async function jsonOrThrow<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`${res.status} ${res.statusText}: ${body}`);
  }
  return res.json() as Promise<T>;
}

export class ArmApiClient {
  constructor(private baseUrl: string) {}

  setBaseUrl(url: string) {
    this.baseUrl = url;
  }

  async fetchConfig(): Promise<ConfigResponse> {
    return jsonOrThrow(await fetch(`${this.baseUrl}/api/config`));
  }

  async fetchTelemetry(): Promise<Telemetry> {
    return jsonOrThrow(await fetch(`${this.baseUrl}/api/telemetry`));
  }

  async fetchSafety(): Promise<SafetyStatus> {
    return jsonOrThrow(await fetch(`${this.baseUrl}/api/safety`));
  }

  async postMove(targetDeg: number[], useSCurve = true): Promise<{ accepted: boolean }> {
    const res = await fetch(`${this.baseUrl}/api/moves`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ target_deg: targetDeg, use_s_curve: useSCurve }),
    });
    if (res.status === 409) return { accepted: false };
    return jsonOrThrow(res);
  }

  async postEstopTrigger(reason: string): Promise<{ accepted: boolean }> {
    const res = await fetch(`${this.baseUrl}/api/estop/trigger`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reason }),
    });
    return jsonOrThrow(res);
  }

  async postEstopReset(operatorId: string): Promise<{ accepted: boolean }> {
    const res = await fetch(`${this.baseUrl}/api/estop/reset`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ operator_id: operatorId }),
    });
    return jsonOrThrow(res);
  }
}

// Android emulator's alias for the host machine's localhost. Real device on
// the same network would use the machine's LAN IP instead — editable in-app
// via the Settings field (see App.tsx).
export const DEFAULT_BASE_URL = 'http://10.0.2.2:8000';
