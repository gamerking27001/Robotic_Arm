"""vision_pipeline/vision_node.py

§12.3/§20.2 "vision_node": subscribes to a camera image topic and runs the
enabled subset of the ../../../vision modules (calibration is deliberately
NOT wrapped here — it's a one-time offline routine, not a continuous
per-frame operation; see vision/README.md and the calibration section
below), publishing results as robot_msgs messages.

IMPORTANT: the vision LOGIC this node calls into is independently tested —
see vision/tests/ (16/16 passing against real synthetic data). What is NOT
verified here, for the same reason as the rest of ros2_ws, is this file's
ROS2 plumbing itself (cv_bridge conversion, topic/parameter wiring) — there's
no ROS2 install in this environment to run it against. See ros2_ws/README.md.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

from robot_msgs.msg import (
    PartDetection as PartDetectionMsg,
    PartDetectionArray,
    BarcodeReading as BarcodeReadingMsg,
    BarcodeReadingArray,
    ObjectDetection as ObjectDetectionMsg,
    ObjectDetectionArray,
    QualityInspectionResult,
)
from geometry_msgs.msg import Point


def _add_vision_modules_to_path() -> Path:
    """Monorepo-relative-path pattern (same rationale as
    robot_hardware_interface's CMakeLists.txt): this file lives at
    ros2_ws/src/vision_pipeline/vision_pipeline/vision_node.py, five levels
    below the repo root, where the standalone `vision/` package lives.
    Works correctly with `colcon build --symlink-install` (this file stays a
    symlink into the source tree, so the relative path is stable); a
    non-symlink install would need `vision/` packaged and installed
    separately instead — see vision/README.md's note on this being a
    small, mechanical follow-up.
    """
    repo_root = Path(__file__).resolve().parents[4]
    vision_root = repo_root / "vision"
    for sub in ("part_localization", "barcode_reading", "object_detection", "quality_inspection"):
        p = vision_root / sub
        if str(p) not in sys.path:
            sys.path.insert(0, str(p))
    return vision_root


_VISION_ROOT = _add_vision_modules_to_path()

from part_localization import locate_parts, locate_parts_in_world  # noqa: E402
from barcode_reader import read_qr_codes  # noqa: E402
from object_detector import ColorBlobDetector, ColorClass  # noqa: E402
from quality_inspection import inspect_against_golden  # noqa: E402


class VisionNode(Node):
    def __init__(self):
        super().__init__("vision_node")
        self.bridge = CvBridge()

        # §15.1's capability toggles — a real deployment enables the subset
        # relevant to its task (e.g. barcode reading for kitting stations,
        # part localization for pick-place).
        self.declare_parameter("enable_part_localization", True)
        self.declare_parameter("enable_barcode_reading", True)
        self.declare_parameter("enable_object_detection", False)
        self.declare_parameter("enable_quality_inspection", False)
        self.declare_parameter("part_localization.threshold", 127)
        self.declare_parameter("part_localization.min_area_px", 200.0)
        self.declare_parameter("part_localization.invert", False)
        # Flattened row-major 3x3 pixel->world homography; identity by
        # default (i.e. world_xy_m == pixel coordinates) until a real
        # calibration is loaded — see the calibration note below.
        self.declare_parameter("part_localization.homography", [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0])
        self.declare_parameter("quality_inspection.golden_image_path", "")
        self.declare_parameter("quality_inspection.pass_score_max", 0.01)

        self.object_detector = ColorBlobDetector(
            classes=[
                # Placeholder classes — a real deployment would configure
                # these per-SKU via ROS2 parameters or a config file rather
                # than hardcoding them; see object_detector.py's scope note
                # on this being a classical fallback, not a trained model.
                ColorClass(name="red_part", hsv_lower=(0, 150, 100), hsv_upper=(10, 255, 255)),
                ColorClass(name="blue_part", hsv_lower=(110, 150, 100), hsv_upper=(130, 255, 255)),
            ]
        )

        golden_path = self.get_parameter("quality_inspection.golden_image_path").value
        self._golden_image = None
        if golden_path:
            import cv2

            self._golden_image = cv2.imread(golden_path)
            if self._golden_image is None:
                self.get_logger().warn(f"Could not load golden reference image at '{golden_path}'")

        self.part_pub = self.create_publisher(PartDetectionArray, "vision/part_detections", 10)
        self.barcode_pub = self.create_publisher(BarcodeReadingArray, "vision/barcode_readings", 10)
        self.object_pub = self.create_publisher(ObjectDetectionArray, "vision/object_detections", 10)
        self.quality_pub = self.create_publisher(QualityInspectionResult, "vision/quality_result", 10)

        self.image_sub = self.create_subscription(Image, "image_raw", self.on_image, 10)

        self.get_logger().info(f"vision_node started (vision modules loaded from {_VISION_ROOT})")

    def on_image(self, msg: Image) -> None:
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        except Exception as e:  # cv_bridge raises its own exception type; broad catch is intentional here
            self.get_logger().error(f"cv_bridge conversion failed: {e}")
            return

        if self.get_parameter("enable_part_localization").value:
            self._publish_part_detections(frame, msg)
        if self.get_parameter("enable_barcode_reading").value:
            self._publish_barcode_readings(frame, msg)
        if self.get_parameter("enable_object_detection").value:
            self._publish_object_detections(frame, msg)
        if self.get_parameter("enable_quality_inspection").value and self._golden_image is not None:
            self._publish_quality_result(frame, msg)

    def _publish_part_detections(self, frame: np.ndarray, source_msg: Image) -> None:
        h_flat = self.get_parameter("part_localization.homography").value
        homography = np.array(h_flat, dtype=np.float64).reshape(3, 3)
        detections = locate_parts_in_world(
            frame,
            homography,
            threshold=int(self.get_parameter("part_localization.threshold").value),
            min_area_px=float(self.get_parameter("part_localization.min_area_px").value),
            invert=bool(self.get_parameter("part_localization.invert").value),
        )
        out = PartDetectionArray()
        out.header = source_msg.header
        for d in detections:
            m = PartDetectionMsg()
            m.centroid_x_px, m.centroid_y_px = d.centroid_px
            m.angle_deg = d.angle_deg
            m.area_px = d.area_px
            m.has_world_pose = d.world_xy_m is not None
            if d.world_xy_m is not None:
                m.world_x_m, m.world_y_m = d.world_xy_m
            out.parts.append(m)
        self.part_pub.publish(out)

    def _publish_barcode_readings(self, frame: np.ndarray, source_msg: Image) -> None:
        readings = read_qr_codes(frame)
        out = BarcodeReadingArray()
        out.header = source_msg.header
        for r in readings:
            m = BarcodeReadingMsg()
            m.data = r.data
            m.corners_px = [Point(x=float(p[0]), y=float(p[1]), z=0.0) for p in r.corners_px]
            out.codes.append(m)
        self.barcode_pub.publish(out)

    def _publish_object_detections(self, frame: np.ndarray, source_msg: Image) -> None:
        detections = self.object_detector.detect(frame)
        out = ObjectDetectionArray()
        out.header = source_msg.header
        for d in detections:
            m = ObjectDetectionMsg()
            m.class_name = d.class_name
            m.confidence = d.confidence
            m.bbox_x_px, m.bbox_y_px, m.bbox_w_px, m.bbox_h_px = d.bbox_px
            out.objects.append(m)
        self.object_pub.publish(out)

    def _publish_quality_result(self, frame: np.ndarray, source_msg: Image) -> None:
        try:
            result = inspect_against_golden(
                frame,
                self._golden_image,
                pass_score_max=float(self.get_parameter("quality_inspection.pass_score_max").value),
            )
        except ValueError as e:
            self.get_logger().warn(f"Quality inspection skipped: {e}")
            return
        out = QualityInspectionResult()
        out.header = source_msg.header
        out.anomaly_score = result.anomaly_score
        out.passed = result.passed
        self.quality_pub.publish(out)


def main(args=None):
    rclpy.init(args=args)
    node = VisionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
