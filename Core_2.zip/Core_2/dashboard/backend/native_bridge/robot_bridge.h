// dashboard/backend/native_bridge/robot_bridge.h
// Plain C ABI wrapping the already-verified core C++ stack
// (../../../include, ../../../src) for consumption from Python via ctypes —
// no pybind11/Boost.Python dependency, just a small extern "C" surface and
// POD structs with fixed layout.
//
// §20.1: "dashboard/backend FastAPI service exposing robot state,
// diagnostics, and configuration endpoints." This header is the seam between
// that FastAPI service and the core stack: main.py loads the compiled
// .so via ctypes and calls straight into arm::hal::SimulatedJointDriver /
// arm::motion::MotionController / arm::safety::SafetyFsm.
#ifndef ROBOT_BRIDGE_H_
#define ROBOT_BRIDGE_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    double payload_nominal_kg;
    double payload_peak_kg;
    double reach_mm;
    double repeatability_mm;
    double pose_accuracy_mm;
    double max_tcp_speed_mps;
    double rated_power_w_peak;
    double bus_voltage_vdc;
    double weight_kg;
    double controller_weight_kg;
    double ambient_temp_min_c;
    double ambient_temp_max_c;
    double acoustic_noise_dba;
} RobotSpecC;

typedef struct {
    char name[32];
    double gear_ratio;
    double rated_torque_nm;
    double peak_torque_nm;
    double rated_rpm;
    double motor_power_w;
    int encoder_bits;
    double soft_limit_min_deg;
    double soft_limit_max_deg;
    double max_speed_deg_s;
} JointSpecC;

typedef struct {
    double position_rad;
    double velocity_rad_s;
    double current_a;
    double torque_estimate_nm;
    double winding_temp_c;
    int sto_active;   // 0/1
    int fault;         // 0/1
} JointTelemetryC;

typedef struct {
    char state[16];             // "PowerOn"/"Homing"/"Idle"/"Running"/"Paused"/"Fault"/"EStop"
    int estop_pressed;
    int sto_required;
    int collision_suspected;
    int overcurrent;
    int overtemperature;
    int soft_limit_violation;
    int hard_limit_violation;
    int any_fault;
} SafetyStatusC;

// Pose of one link's frame, expressed in the robot base frame — position in
// meters + orientation as a unit quaternion (w,x,y,z). Used by the Digital
// Twin Sync Engine (§5) to place link meshes in the 3D viewport; quaternions
// rather than 3x3 matrices because that's what renderer/scene-graph APIs
// (Three.js, etc.) consume directly.
typedef struct {
    double px, py, pz;
    double qw, qx, qy, qz;
} LinkPoseC;

typedef void* RobotBridgeHandle;

// Lifecycle. create() boots the safety FSM through PowerOn->Homing->Idle
// automatically (§13.5) and constructs six simulated joints + a
// MotionController, mirroring src/main.cpp's setup.
RobotBridgeHandle robot_bridge_create(void);
void robot_bridge_destroy(RobotBridgeHandle handle);

// Static configuration (doesn't need a handle — it's compiled-in config).
void robot_bridge_get_robot_spec(RobotSpecC* out);
int robot_bridge_get_joint_spec(int joint_index, JointSpecC* out);  // returns 1 on success, 0 if index out of range

// Live state.
int robot_bridge_get_joint_telemetry(RobotBridgeHandle handle, int joint_index, JointTelemetryC* out);
void robot_bridge_get_safety_status(RobotBridgeHandle handle, SafetyStatusC* out);
int robot_bridge_is_move_active(RobotBridgeHandle handle);
double robot_bridge_elapsed_move_time(RobotBridgeHandle handle);

// Control.
// target_deg6 must point to 6 doubles (joint angles in degrees, J1..J6).
// Returns 1 if the move was accepted and started, 0 otherwise (e.g. IK/limit
// rejection is not checked here — this is a joint-space move, §13.1).
int robot_bridge_begin_move(RobotBridgeHandle handle, const double* target_deg6, int use_s_curve);

// Advances the simulated plant + motion controller + safety evaluation by
// dt_s seconds — call this from a fixed-rate loop (the Python side runs this
// in a background thread, see main.py).
void robot_bridge_tick(RobotBridgeHandle handle, double dt_s);

int robot_bridge_trigger_estop(RobotBridgeHandle handle);
int robot_bridge_reset_estop(RobotBridgeHandle handle);

// Test/demo hook mirroring src/main.cpp's collision-injection demo (§14).
int robot_bridge_inject_load(RobotBridgeHandle handle, int joint_index, double load_nm);

// Pure forward kinematics: computes base->link_i pose for every link
// (i=1..6, link 6 == TCP/flange) from a joint-angle vector in radians.
// Deterministic function of the compiled-in DH table (arm::config::kDHTable)
// and q — takes no handle because it does not read or mutate any robot
// state, so callers (e.g. the Digital Twin Sync Engine, running as a
// separate process/service) can compute link poses for any joint-angle
// vector — live-telemetry-derived, interpolated, or a simulated preview —
// without needing a live robot_bridge session.
// q_rad6 must point to 6 doubles (J1..J6, radians); out6 must point to 6
// LinkPoseC slots (out6[0] = base->link1 ... out6[5] = base->TCP).
void robot_bridge_compute_link_frames(const double* q_rad6, LinkPoseC* out6);

// Inverse kinematics: solves for a joint-angle vector reaching `target`
// (position + orientation, base frame) starting from `seed_q_rad6` (used as
// the Jacobian-refinement starting point if the closed-form analytical
// stage can't produce a seed — see kinematics/ik_solver.hpp). Returns 1 and
// fills out_q_rad6 on success, 0 (out_q_rad6 left unmodified) if no
// solution was found within tolerance — the Motion Planner's "IK/FK
// Feasibility Check" step (platform spec §7.2) reads this return value
// directly as its pass/fail signal.
int robot_bridge_solve_ik(const LinkPoseC* target, const double* seed_q_rad6, double* out_q_rad6);

// Samples a synchronized 6-axis point-to-point move (see
// motion/synchronized_move.hpp — the same algorithm the live
// MotionController uses) at time `t_s`, without touching any hardware
// interface. Returns the move's total duration in seconds (0 if start ==
// target and there's nothing to do); `t_s` is clamped to [0, duration]
// internally, so sampling at t_s=0 gives `q_start_rad6` and t_s >= duration
// gives `q_target_rad6`. out_q_rad6/out_qdot_rad_s6 must each point to 6
// doubles. This is the Motion Planner's "Trajectory Optimization" /
// "Full Cycle Simulation" step (§7.4/§7.5): call once to get the duration,
// then sample densely across [0, duration] to walk the planned path.
//
// Rebuilds the trajectory profiles from scratch on every call rather than
// caching them keyed by (start, target, use_s_curve) — deliberately, to
// keep this function stateless like robot_bridge_compute_link_frames (see
// that function's comment): profile construction is closed-form segment
// math, not iterative, so the cost is small relative to what calls it (an
// offline planner sampling on the order of hundreds of points per planned
// move, not a real-time control loop).
double robot_bridge_sample_joint_move(const double* q_start_rad6, const double* q_target_rad6, int use_s_curve,
                                       double t_s, double* out_q_rad6, double* out_qdot_rad_s6);

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_BRIDGE_H_
