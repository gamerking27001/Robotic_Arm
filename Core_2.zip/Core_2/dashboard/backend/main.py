"""dashboard/backend/main.py

§19.4/§20.1: "dashboard/backend FastAPI service exposing robot state,
diagnostics, and configuration endpoints." Backed by native_bridge/
(a thin C ABI over the already-verified core C++ stack), loaded via ctypes —
no ROS2 dependency, so this layer is fully testable in any environment with a
C++ compiler and Python.

Run:
    ./build.sh                 # compiles native_bridge/librobot_bridge.so
    pip install -r requirements.txt
    export DASHBOARD_VIEWER_API_KEY=...   # see "Authentication" below
    export DASHBOARD_OPERATOR_API_KEY=...
    uvicorn main:app --reload

Authentication (added — this was previously flagged as a real gap: "No
auth" in the original README, unacceptable for anything beyond a local
demo since /api/estop/reset and /api/moves can command real robot motion):

Two API keys, both required to be set via environment variables — there is
no baked-in default key, deliberately: a hardcoded default is itself a
well-known vulnerability class ("the default password"), and failing
closed (refusing to start) is safer than failing open (starting unsecured)
for anything that can move a robot.

- DASHBOARD_VIEWER_API_KEY — read-only access (GET endpoints, websocket).
- DASHBOARD_OPERATOR_API_KEY — read/write access (POST endpoints too);
  implies viewer access as well.

Send the key as an `X-API-Key` header on HTTP requests, or as an
`api_key` query parameter for the websocket (browsers can't set custom
headers on a WebSocket handshake, so a query param is the conventional
workaround — logged access at the reverse-proxy/load-balancer level should
be configured to redact this parameter; see DEPLOYMENT.md).

For local development only, set DASHBOARD_ALLOW_INSECURE=1 to skip auth
entirely — this prints a loud warning on every request and must never be
set in a real deployment. There is no other bypass.
"""
import asyncio
import ctypes
import logging
import math
import os
import secrets
import threading
import time
from typing import List, Optional

from fastapi import Depends, FastAPI, HTTPException, Security, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import APIKeyHeader
from pydantic import BaseModel, Field

logging.basicConfig(
    level=os.environ.get("DASHBOARD_LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
logger = logging.getLogger("dashboard.backend")

NUM_JOINTS = 6
TICK_HZ = 200.0
TICK_DT = 1.0 / TICK_HZ

# --- Authentication ----------------------------------------------------------

_VIEWER_KEY = os.environ.get("DASHBOARD_VIEWER_API_KEY")
_OPERATOR_KEY = os.environ.get("DASHBOARD_OPERATOR_API_KEY")
_INSECURE = os.environ.get("DASHBOARD_ALLOW_INSECURE") == "1"

if not _INSECURE and (not _VIEWER_KEY or not _OPERATOR_KEY):
    raise RuntimeError(
        "DASHBOARD_VIEWER_API_KEY and DASHBOARD_OPERATOR_API_KEY must both be set "
        "(this service can command real robot motion — no default key is provided). "
        "For local development only, set DASHBOARD_ALLOW_INSECURE=1 instead."
    )
if _INSECURE:
    logger.warning(
        "DASHBOARD_ALLOW_INSECURE=1 — authentication is DISABLED. "
        "This must never be set in a real deployment."
    )

_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


def _check_key(provided: Optional[str], required: str) -> bool:
    if provided is None:
        return False
    return secrets.compare_digest(provided, required)


def require_viewer(api_key: Optional[str] = Security(_api_key_header)) -> None:
    if _INSECURE:
        return
    if _check_key(api_key, _OPERATOR_KEY) or _check_key(api_key, _VIEWER_KEY):
        return
    raise HTTPException(status_code=401, detail="Invalid or missing API key")


def require_operator(api_key: Optional[str] = Security(_api_key_header)) -> None:
    if _INSECURE:
        return
    if _check_key(api_key, _OPERATOR_KEY):
        return
    raise HTTPException(status_code=401, detail="Invalid or missing operator API key")


async def require_viewer_ws(websocket: WebSocket) -> bool:
    if _INSECURE:
        return True
    provided = websocket.query_params.get("api_key")
    if _check_key(provided, _OPERATOR_KEY) or _check_key(provided, _VIEWER_KEY):
        return True
    await websocket.close(code=4401)  # non-standard close code in the 4000-4999 (app-defined) range
    return False


# --- ctypes bindings, mirroring native_bridge/robot_bridge.h exactly -------


class RobotSpecC(ctypes.Structure):
    _fields_ = [
        ("payload_nominal_kg", ctypes.c_double),
        ("payload_peak_kg", ctypes.c_double),
        ("reach_mm", ctypes.c_double),
        ("repeatability_mm", ctypes.c_double),
        ("pose_accuracy_mm", ctypes.c_double),
        ("max_tcp_speed_mps", ctypes.c_double),
        ("rated_power_w_peak", ctypes.c_double),
        ("bus_voltage_vdc", ctypes.c_double),
        ("weight_kg", ctypes.c_double),
        ("controller_weight_kg", ctypes.c_double),
        ("ambient_temp_min_c", ctypes.c_double),
        ("ambient_temp_max_c", ctypes.c_double),
        ("acoustic_noise_dba", ctypes.c_double),
    ]


class JointSpecC(ctypes.Structure):
    _fields_ = [
        ("name", ctypes.c_char * 32),
        ("gear_ratio", ctypes.c_double),
        ("rated_torque_nm", ctypes.c_double),
        ("peak_torque_nm", ctypes.c_double),
        ("rated_rpm", ctypes.c_double),
        ("motor_power_w", ctypes.c_double),
        ("encoder_bits", ctypes.c_int),
        ("soft_limit_min_deg", ctypes.c_double),
        ("soft_limit_max_deg", ctypes.c_double),
        ("max_speed_deg_s", ctypes.c_double),
    ]


class JointTelemetryC(ctypes.Structure):
    _fields_ = [
        ("position_rad", ctypes.c_double),
        ("velocity_rad_s", ctypes.c_double),
        ("current_a", ctypes.c_double),
        ("torque_estimate_nm", ctypes.c_double),
        ("winding_temp_c", ctypes.c_double),
        ("sto_active", ctypes.c_int),
        ("fault", ctypes.c_int),
    ]


class SafetyStatusC(ctypes.Structure):
    _fields_ = [
        ("state", ctypes.c_char * 16),
        ("estop_pressed", ctypes.c_int),
        ("sto_required", ctypes.c_int),
        ("collision_suspected", ctypes.c_int),
        ("overcurrent", ctypes.c_int),
        ("overtemperature", ctypes.c_int),
        ("soft_limit_violation", ctypes.c_int),
        ("hard_limit_violation", ctypes.c_int),
        ("any_fault", ctypes.c_int),
    ]


def _load_library() -> ctypes.CDLL:
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, "native_bridge", "librobot_bridge.so")
    if not os.path.exists(path):
        raise RuntimeError(
            f"{path} not found — run ./build.sh first to compile the native bridge."
        )
    lib = ctypes.CDLL(path)
    lib.robot_bridge_create.restype = ctypes.c_void_p
    lib.robot_bridge_destroy.argtypes = [ctypes.c_void_p]
    lib.robot_bridge_get_robot_spec.argtypes = [ctypes.POINTER(RobotSpecC)]
    lib.robot_bridge_get_joint_spec.argtypes = [ctypes.c_int, ctypes.POINTER(JointSpecC)]
    lib.robot_bridge_get_joint_spec.restype = ctypes.c_int
    lib.robot_bridge_get_joint_telemetry.argtypes = [
        ctypes.c_void_p,
        ctypes.c_int,
        ctypes.POINTER(JointTelemetryC),
    ]
    lib.robot_bridge_get_joint_telemetry.restype = ctypes.c_int
    lib.robot_bridge_get_safety_status.argtypes = [ctypes.c_void_p, ctypes.POINTER(SafetyStatusC)]
    lib.robot_bridge_is_move_active.argtypes = [ctypes.c_void_p]
    lib.robot_bridge_is_move_active.restype = ctypes.c_int
    lib.robot_bridge_elapsed_move_time.argtypes = [ctypes.c_void_p]
    lib.robot_bridge_elapsed_move_time.restype = ctypes.c_double
    lib.robot_bridge_begin_move.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_double), ctypes.c_int]
    lib.robot_bridge_begin_move.restype = ctypes.c_int
    lib.robot_bridge_tick.argtypes = [ctypes.c_void_p, ctypes.c_double]
    lib.robot_bridge_trigger_estop.argtypes = [ctypes.c_void_p]
    lib.robot_bridge_trigger_estop.restype = ctypes.c_int
    lib.robot_bridge_reset_estop.argtypes = [ctypes.c_void_p]
    lib.robot_bridge_reset_estop.restype = ctypes.c_int
    lib.robot_bridge_inject_load.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_double]
    lib.robot_bridge_inject_load.restype = ctypes.c_int
    return lib


_lib = _load_library()
_handle = _lib.robot_bridge_create()

JOINT_NAMES = ["waist", "shoulder", "elbow", "wrist_roll", "wrist_pitch", "flange_roll"]


class TickerThread(threading.Thread):
    """Advances the simulated plant at a fixed rate — the Python-side
    analog of §11.3's real-time interpolation loop, driving the same
    MotionController the core stack's arm_demo drives."""

    def __init__(self):
        super().__init__(daemon=True)
        self._stop = threading.Event()

    def run(self):
        while not self._stop.is_set():
            _lib.robot_bridge_tick(_handle, TICK_DT)
            time.sleep(TICK_DT)

    def stop(self):
        self._stop.set()


_ticker = TickerThread()

app = FastAPI(
    title="Modular Arm Dashboard Backend",
    version="0.2.0",
    # DASHBOARD_DISABLE_DOCS=1 turns off the interactive /docs and /redoc
    # UIs -- they don't leak secrets (every real call still needs an API
    # key) but do reveal the full API surface to anyone who can reach the
    # port, which some deployments would rather not expose. Left enabled
    # by default since it's genuinely useful for integration/ops work
    # behind a properly firewalled deployment.
    docs_url=None if os.environ.get("DASHBOARD_DISABLE_DOCS") == "1" else "/docs",
    redoc_url=None if os.environ.get("DASHBOARD_DISABLE_DOCS") == "1" else "/redoc",
)

# CORS: restrictive by default (no origins allowed) — set
# DASHBOARD_CORS_ORIGINS to a comma-separated list (e.g. the frontend dev
# server's origin) to allow browser-based cross-origin access. Empty/unset
# means same-origin only, which is the safe default for a service that can
# command robot motion.
_cors_origins = [o.strip() for o in os.environ.get("DASHBOARD_CORS_ORIGINS", "").split(",") if o.strip()]
if _cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST"],
        allow_headers=["X-API-Key", "Content-Type"],
    )


@app.on_event("startup")
def _on_startup():
    _ticker.start()


@app.on_event("shutdown")
def _on_shutdown():
    _ticker.stop()
    _lib.robot_bridge_destroy(_handle)


# --- Response models --------------------------------------------------------


class RobotSpecOut(BaseModel):
    payload_nominal_kg: float
    payload_peak_kg: float
    reach_mm: float
    repeatability_mm: float
    pose_accuracy_mm: float
    max_tcp_speed_mps: float
    rated_power_w_peak: float
    bus_voltage_vdc: float
    weight_kg: float
    controller_weight_kg: float
    ambient_temp_min_c: float
    ambient_temp_max_c: float
    acoustic_noise_dba: float


class JointSpecOut(BaseModel):
    name: str
    gear_ratio: float
    rated_torque_nm: float
    peak_torque_nm: float
    rated_rpm: float
    motor_power_w: float
    encoder_bits: int
    soft_limit_min_deg: float
    soft_limit_max_deg: float
    max_speed_deg_s: float


class ConfigOut(BaseModel):
    robot: RobotSpecOut
    joints: List[JointSpecOut]


class JointTelemetryOut(BaseModel):
    joint_name: str
    position_deg: float
    velocity_deg_s: float
    current_a: float
    torque_estimate_nm: float
    winding_temp_c: float
    sto_active: bool
    fault: bool


class TelemetryOut(BaseModel):
    joints: List[JointTelemetryOut]
    move_active: bool
    elapsed_move_time_s: float


class SafetyStatusOut(BaseModel):
    state: str
    estop_pressed: bool
    sto_required: bool
    collision_suspected: bool
    overcurrent: bool
    overtemperature: bool
    soft_limit_violation: bool
    hard_limit_violation: bool
    any_fault: bool


class MoveRequest(BaseModel):
    target_deg: List[float] = Field(..., min_length=NUM_JOINTS, max_length=NUM_JOINTS)
    use_s_curve: bool = True


class EstopTriggerRequest(BaseModel):
    reason: str = "operator request"


class EstopResetRequest(BaseModel):
    operator_id: str = "unknown"


class LoadInjectRequest(BaseModel):
    load_nm: float


# --- Helpers -----------------------------------------------------------------


def _read_telemetry() -> TelemetryOut:
    joints = []
    for i in range(NUM_JOINTS):
        t = JointTelemetryC()
        _lib.robot_bridge_get_joint_telemetry(_handle, i, ctypes.byref(t))
        joints.append(
            JointTelemetryOut(
                joint_name=JOINT_NAMES[i],
                position_deg=math.degrees(t.position_rad),
                velocity_deg_s=math.degrees(t.velocity_rad_s),
                current_a=t.current_a,
                torque_estimate_nm=t.torque_estimate_nm,
                winding_temp_c=t.winding_temp_c,
                sto_active=bool(t.sto_active),
                fault=bool(t.fault),
            )
        )
    return TelemetryOut(
        joints=joints,
        move_active=bool(_lib.robot_bridge_is_move_active(_handle)),
        elapsed_move_time_s=_lib.robot_bridge_elapsed_move_time(_handle),
    )


def _read_safety() -> SafetyStatusOut:
    s = SafetyStatusC()
    _lib.robot_bridge_get_safety_status(_handle, ctypes.byref(s))
    return SafetyStatusOut(
        state=s.state.decode("utf-8"),
        estop_pressed=bool(s.estop_pressed),
        sto_required=bool(s.sto_required),
        collision_suspected=bool(s.collision_suspected),
        overcurrent=bool(s.overcurrent),
        overtemperature=bool(s.overtemperature),
        soft_limit_violation=bool(s.soft_limit_violation),
        hard_limit_violation=bool(s.hard_limit_violation),
        any_fault=bool(s.any_fault),
    )


# --- Endpoints ---------------------------------------------------------------


@app.get("/healthz")
def healthz():
    """Unauthenticated liveness endpoint for container/orchestrator health
    checks -- deliberately separate from /docs (which can be disabled via
    DASHBOARD_DISABLE_DOCS) and returns nothing beyond "the process is up
    and the native bridge handle exists", not any robot state."""
    return {"status": "ok"}


@app.get("/api/config", response_model=ConfigOut, dependencies=[Depends(require_viewer)])
def get_config():
    """§1.5/§2.1/§6.2 — full robot + per-joint specification, straight from
    the compiled-in config the core stack itself reads."""
    spec = RobotSpecC()
    _lib.robot_bridge_get_robot_spec(ctypes.byref(spec))
    robot = RobotSpecOut(**{f: getattr(spec, f) for f, _ in RobotSpecC._fields_})

    joints = []
    for i in range(NUM_JOINTS):
        j = JointSpecC()
        if not _lib.robot_bridge_get_joint_spec(i, ctypes.byref(j)):
            continue
        joints.append(
            JointSpecOut(
                name=j.name.decode("utf-8"),
                gear_ratio=j.gear_ratio,
                rated_torque_nm=j.rated_torque_nm,
                peak_torque_nm=j.peak_torque_nm,
                rated_rpm=j.rated_rpm,
                motor_power_w=j.motor_power_w,
                encoder_bits=j.encoder_bits,
                soft_limit_min_deg=j.soft_limit_min_deg,
                soft_limit_max_deg=j.soft_limit_max_deg,
                max_speed_deg_s=j.max_speed_deg_s,
            )
        )
    return ConfigOut(robot=robot, joints=joints)


@app.get("/api/telemetry", response_model=TelemetryOut, dependencies=[Depends(require_viewer)])
def get_telemetry():
    """§7.1/§11.7 — live per-joint telemetry, sampled from the ticking
    simulated plant."""
    return _read_telemetry()


@app.get("/api/safety", response_model=SafetyStatusOut, dependencies=[Depends(require_viewer)])
def get_safety():
    """§13.5/§14.1 — current safety FSM state + aggregated safety-function
    checks across all six joints."""
    return _read_safety()


@app.post("/api/moves", dependencies=[Depends(require_operator)])
def post_move(req: MoveRequest):
    """§13.1/§13.3 — starts a synchronized joint-space move using the
    S-curve-by-default trajectory profile, exactly as arm_demo does."""
    targets = (ctypes.c_double * NUM_JOINTS)(*req.target_deg)
    started = _lib.robot_bridge_begin_move(_handle, targets, 1 if req.use_s_curve else 0)
    logger.info("Move requested: target_deg=%s s_curve=%s accepted=%s", req.target_deg, req.use_s_curve, started)
    if not started:
        raise HTTPException(status_code=409, detail="Move rejected — safety FSM is not in Idle/Running")
    return {"accepted": True}


@app.post("/api/estop/trigger", dependencies=[Depends(require_operator)])
def post_estop_trigger(req: EstopTriggerRequest):
    """§14.1 — software-callable E-stop (the hardware-wired dual-channel loop
    described in §9.5 always takes priority in a real deployment and doesn't
    go through this endpoint)."""
    accepted = bool(_lib.robot_bridge_trigger_estop(_handle))
    logger.warning("E-stop triggered via dashboard: reason=%r accepted=%s", req.reason, accepted)
    return {"accepted": accepted, "reason": req.reason}


@app.post("/api/estop/reset", dependencies=[Depends(require_operator)])
def post_estop_reset(req: EstopResetRequest):
    """§13.5 estop_reset -> PowerOn (then auto re-homes to Idle here, mirroring
    safety_monitor_node's boot sequence)."""
    accepted = bool(_lib.robot_bridge_reset_estop(_handle))
    logger.info("E-stop reset via dashboard: operator_id=%r accepted=%s", req.operator_id, accepted)
    return {"accepted": accepted, "operator_id": req.operator_id}


@app.post("/api/joints/{joint_index}/load", dependencies=[Depends(require_operator)])
def post_inject_load(joint_index: int, req: LoadInjectRequest):
    """Test/demo hook mirroring src/main.cpp's collision-injection demo —
    NOT part of the source design doc's public API, useful for exercising the
    §14 torque-deviation collision detector from the dashboard."""
    if not (0 <= joint_index < NUM_JOINTS):
        raise HTTPException(status_code=404, detail="joint_index out of range")
    _lib.robot_bridge_inject_load(_handle, joint_index, req.load_nm)
    return {"accepted": True}


@app.websocket("/ws/telemetry")
async def ws_telemetry(websocket: WebSocket):
    """Streams telemetry + safety status at ~10 Hz for the dashboard frontend
    (§dashboard/frontend) to render live without polling. Auth via
    ?api_key=... query param — see module docstring."""
    await websocket.accept()
    if not await require_viewer_ws(websocket):
        return
    try:
        while True:
            payload = {
                "telemetry": _read_telemetry().model_dump(),
                "safety": _read_safety().model_dump(),
            }
            await websocket.send_json(payload)
            await asyncio.sleep(0.1)
    except WebSocketDisconnect:
        pass
