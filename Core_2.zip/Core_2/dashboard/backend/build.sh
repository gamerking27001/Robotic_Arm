#!/usr/bin/env bash
# dashboard/backend/build.sh
# Compiles native_bridge/librobot_bridge.so directly against the core stack
# sources (../../../include, ../../../src) — same monorepo-relative-path
# pattern used by ros2_ws's CMakeLists.txt files.
set -euo pipefail
cd "$(dirname "$0")"

CORE_ROOT="../.."

g++ -std=c++20 -O2 -Wall -Wextra -fPIC -shared \
  -I "${CORE_ROOT}/include" \
  native_bridge/robot_bridge.cpp \
  "${CORE_ROOT}/src/kinematics/dh_kinematics.cpp" \
  "${CORE_ROOT}/src/kinematics/ik_solver.cpp" \
  "${CORE_ROOT}/src/motion/trajectory_profile.cpp" \
  "${CORE_ROOT}/src/motion/synchronized_move.cpp" \
  "${CORE_ROOT}/src/motion/motion_controller.cpp" \
  "${CORE_ROOT}/src/hal/simulated_joint_driver.cpp" \
  "${CORE_ROOT}/src/safety/safety_fsm.cpp" \
  -o native_bridge/librobot_bridge.so

echo "Built native_bridge/librobot_bridge.so"
