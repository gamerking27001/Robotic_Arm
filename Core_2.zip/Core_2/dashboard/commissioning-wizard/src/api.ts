// src/api.ts — talks to the same dashboard/backend used by dashboard/frontend.
// No new backend endpoints were needed for this wizard; every check below is
// built from the existing REST API.

export interface JointSpec {
  name: string;
  soft_limit_min_deg: number;
  soft_limit_max_deg: number;
}

export interface ConfigResponse {
  robot: Record<string, number>;
  joints: JointSpec[];
}

export interface JointTelemetry {
  joint_name: string;
  position_deg: number;
  velocity_deg_s: number;
  sto_active: boolean;
  fault: boolean;
}

export interface Telemetry {
  joints: JointTelemetry[];
  move_active: boolean;
  elapsed_move_time_s: number;
}

export interface SafetyStatus {
  state: string;
  estop_pressed: boolean;
  sto_required: boolean;
  collision_suspected: boolean;
  overcurrent: boolean;
  overtemperature: boolean;
  soft_limit_violation: boolean;
  hard_limit_violation: boolean;
  any_fault: boolean;
}

const API_BASE = '/api';

async function jsonOrThrow<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`${res.status} ${res.statusText}: ${body}`);
  }
  return res.json() as Promise<T>;
}

export async function fetchConfig(): Promise<ConfigResponse> {
  return jsonOrThrow(await fetch(`${API_BASE}/config`));
}

export async function fetchTelemetry(): Promise<Telemetry> {
  return jsonOrThrow(await fetch(`${API_BASE}/telemetry`));
}

export async function fetchSafety(): Promise<SafetyStatus> {
  return jsonOrThrow(await fetch(`${API_BASE}/safety`));
}

export async function postMove(targetDeg: number[], useSCurve = true): Promise<{ accepted: boolean }> {
  const res = await fetch(`${API_BASE}/moves`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ target_deg: targetDeg, use_s_curve: useSCurve }),
  });
  if (res.status === 409) return { accepted: false };
  return jsonOrThrow(res);
}

export async function postEstopTrigger(reason: string): Promise<{ accepted: boolean }> {
  const res = await fetch(`${API_BASE}/estop/trigger`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reason }),
  });
  return jsonOrThrow(res);
}

export async function postEstopReset(operatorId: string): Promise<{ accepted: boolean }> {
  const res = await fetch(`${API_BASE}/estop/reset`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ operator_id: operatorId }),
  });
  return jsonOrThrow(res);
}

/** Polls `check` every `intervalMs` until it returns true or `timeoutMs` elapses. */
export async function pollUntil(
  check: () => Promise<boolean>,
  timeoutMs: number,
  intervalMs = 150,
): Promise<boolean> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (await check()) return true;
    await new Promise((r) => setTimeout(r, intervalMs));
  }
  return false;
}

export async function waitForMoveToFinish(timeoutMs = 5000): Promise<boolean> {
  return pollUntil(async () => !(await fetchTelemetry()).move_active, timeoutMs);
}
