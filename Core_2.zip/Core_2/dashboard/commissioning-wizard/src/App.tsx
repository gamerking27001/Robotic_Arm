import { useState } from 'react';
import './App.css';
import { CHECKLIST, type StepResult, type StepStatus } from './checklist';

interface StepState {
  status: StepStatus;
  details: string;
  log: string[];
}

function initialStepStates(): Record<string, StepState> {
  const out: Record<string, StepState> = {};
  for (const step of CHECKLIST) out[step.id] = { status: 'pending', details: '', log: [] };
  return out;
}

function statusBadge(status: StepStatus): string {
  switch (status) {
    case 'pass':
      return 'badge badge-pass';
    case 'fail':
      return 'badge badge-fail';
    case 'manual':
      return 'badge badge-manual';
    case 'running':
      return 'badge badge-running';
    default:
      return 'badge badge-pending';
  }
}

export default function App() {
  const [states, setStates] = useState<Record<string, StepState>>(initialStepStates());
  const [runningAll, setRunningAll] = useState(false);
  const [technicianId, setTechnicianId] = useState('');
  const [signOffDate, setSignOffDate] = useState(() => new Date().toISOString().slice(0, 10));

  async function runStep(id: string) {
    const step = CHECKLIST.find((s) => s.id === id)!;
    setStates((prev) => ({ ...prev, [id]: { status: 'running', details: '', log: [] } }));
    const log: string[] = [];
    try {
      const result: StepResult = await step.run((line) => {
        log.push(line);
        setStates((prev) => ({ ...prev, [id]: { ...prev[id], log: [...log] } }));
      });
      setStates((prev) => ({ ...prev, [id]: { status: result.status, details: result.details, log } }));
      return result.status;
    } catch (e) {
      const details = String(e);
      setStates((prev) => ({ ...prev, [id]: { status: 'fail', details, log } }));
      return 'fail';
    }
  }

  async function runAll() {
    setRunningAll(true);
    for (const step of CHECKLIST) {
      const status = await runStep(step.id);
      if (status === 'fail') break; // stop the sequence on the first real failure
    }
    setRunningAll(false);
  }

  function downloadReport() {
    const report = {
      robot_variant: 'standard_5kg_850mm',
      generated_by: 'dashboard/commissioning-wizard',
      steps: CHECKLIST.map((step) => ({
        id: step.id,
        title: step.title,
        automatable: step.automatable,
        status: states[step.id].status,
        details: states[step.id].details,
      })),
      sign_off: { technician_id: technicianId, date: signOffDate },
    };
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `commissioning_report_${signOffDate}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  const allDone = CHECKLIST.every((s) => states[s.id].status !== 'pending' && states[s.id].status !== 'running');
  const anyFailed = CHECKLIST.some((s) => states[s.id].status === 'fail');
  const canSignOff = allDone && !anyFailed && technicianId.trim().length > 0;

  return (
    <div className="wizard">
      <header className="topbar">
        <h1>Commissioning Wizard</h1>
        <p className="subtitle">§17.5 Deployment Workflow / §20.7 commissioning_checklist.yaml</p>
      </header>

      <div className="run-all-row">
        <button className="btn-primary" onClick={runAll} disabled={runningAll}>
          {runningAll ? 'Running...' : 'Run All Steps'}
        </button>
      </div>

      <ol className="steps">
        {CHECKLIST.map((step) => {
          const state = states[step.id];
          return (
            <li key={step.id} className="step">
              <div className="step-header">
                <span className={statusBadge(state.status)}>{state.status}</span>
                <strong>{step.title}</strong>
                {!step.automatable && <span className="manual-tag">manual</span>}
                <button className="btn-secondary btn-small" onClick={() => runStep(step.id)} disabled={runningAll}>
                  Run
                </button>
              </div>
              <p className="step-description">{step.description}</p>
              {state.details && <p className="step-details">{state.details}</p>}
              {state.log.length > 0 && (
                <pre className="step-log">{state.log.join('\n')}</pre>
              )}
            </li>
          );
        })}
      </ol>

      <section className="sign-off">
        <h2>Sign-Off</h2>
        <label>
          Technician ID
          <input value={technicianId} onChange={(e) => setTechnicianId(e.target.value)} placeholder="required" />
        </label>
        <label>
          Date
          <input type="date" value={signOffDate} onChange={(e) => setSignOffDate(e.target.value)} />
        </label>
        <button className="btn-primary" onClick={downloadReport} disabled={!canSignOff}>
          Download Commissioning Report
        </button>
        {!allDone && <p className="sign-off-hint">Run every step before signing off.</p>}
        {anyFailed && <p className="sign-off-hint sign-off-hint-fail">Resolve failing steps before signing off.</p>}
      </section>
    </div>
  );
}
