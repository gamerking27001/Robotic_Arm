// tests/core/test_quaternion.cpp
// Standalone, dependency-free test for core::Matrix3::toQuaternion() /
// fromQuaternion() — added alongside the Digital Twin Sync Engine, which
// hands link orientations to the renderer as quaternions. Follows the same
// assert()-based, no-framework convention as the rest of this repo (see
// src/main.cpp) rather than pulling in gtest for one new file.
#include <cassert>
#include <cmath>
#include <cstdio>

#include "core/linalg.hpp"

using arm::core::Matrix3;
using arm::core::Quaternion;
using arm::core::Vector3;
using arm::core::deg2rad;

namespace {

bool near(double a, double b, double eps = 1e-9) { return std::fabs(a - b) < eps; }

bool matricesClose(const Matrix3& a, const Matrix3& b, double eps = 1e-9) {
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            if (!near(a.m[i][j], b.m[i][j], eps)) return false;
    return true;
}

// Round-trips rotationX/Y/Z and a couple of composed rotations through
// matrix -> quaternion -> matrix and checks we get the original matrix back,
// across the branches toQuaternion() switches on (trace>0, and each of the
// three "largest diagonal element" cases) so all four code paths are hit.
void testRoundTrip(const char* label, const Matrix3& r) {
    const Quaternion q = r.toQuaternion();
    // Unit quaternion.
    assert(near(q.norm(), 1.0, 1e-9));
    const Matrix3 back = Matrix3::fromQuaternion(q);
    if (!matricesClose(r, back, 1e-8)) {
        std::fprintf(stderr, "FAIL round-trip: %s\n", label);
        assert(false);
    }
}

void testIdentity() {
    const Quaternion q = Matrix3::identity().toQuaternion();
    assert(near(q.w, 1.0) && near(q.x, 0.0) && near(q.y, 0.0) && near(q.z, 0.0));
}

void test180DegreeRotations() {
    // These are exactly the cases that break the naive single-branch
    // (trace = -1 near 180deg about X/Y/Z) — the reason toQuaternion()
    // branches on the largest diagonal term instead of always using the
    // trace>0 formula.
    testRoundTrip("180deg about X", Matrix3::rotationX(deg2rad(180.0)));
    testRoundTrip("180deg about Y", Matrix3::rotationY(deg2rad(180.0)));
    testRoundTrip("180deg about Z", Matrix3::rotationZ(deg2rad(180.0)));
}

void testGeneralRotations() {
    testRoundTrip("30/45/60 composed", Matrix3::rotationZ(deg2rad(30.0)) * Matrix3::rotationY(deg2rad(45.0)) *
                                            Matrix3::rotationX(deg2rad(60.0)));
    testRoundTrip("-170deg about X (near J1 soft limit)", Matrix3::rotationX(deg2rad(-170.0)));
    testRoundTrip("small angle 0.001deg about Z", Matrix3::rotationZ(deg2rad(0.001)));
}

// Sanity check against a hand-computable case: 90deg about Z should rotate
// +X to +Y, and the quaternion should match the known closed-form
// (cos45, 0, 0, sin45).
void testKnownQuaternion90DegZ() {
    const Quaternion q = Matrix3::rotationZ(deg2rad(90.0)).toQuaternion();
    const double expected = std::sqrt(2.0) / 2.0;
    assert(near(q.w, expected, 1e-9));
    assert(near(q.x, 0.0, 1e-9));
    assert(near(q.y, 0.0, 1e-9));
    assert(near(q.z, expected, 1e-9));

    const Vector3 rotated = Matrix3::rotationZ(deg2rad(90.0)) * Vector3{1, 0, 0};
    assert(near(rotated.x, 0.0, 1e-9) && near(rotated.y, 1.0, 1e-9) && near(rotated.z, 0.0, 1e-9));
}

}  // namespace

int main() {
    testIdentity();
    test180DegreeRotations();
    testGeneralRotations();
    testKnownQuaternion90DegZ();
    std::printf("test_quaternion: all assertions passed\n");
    return 0;
}
