// tests/core/test_ik_and_trajectory.cpp
// Tests the two algorithms newly exposed through robot_bridge for the
// Motion Planner service (platform spec §7): IKSolver::solve() (already
// existed, exercised here via a full FK->IK->FK round trip) and
// buildSynchronizedProfiles() (motion/synchronized_move.*, extracted from
// MotionController::beginMove() — see that header's comments). ABI
// marshalling correctness for the ctypes bridge itself is covered
// separately by digital_twin/sync_engine/tests/test_kinematics_bridge.py
// and motion_planner's equivalent; this test is about the underlying
// algorithms, same convention as test_quaternion.cpp.
#include <cassert>
#include <cmath>
#include <cstdio>

#include "kinematics/dh_kinematics.hpp"
#include "kinematics/ik_solver.hpp"
#include "motion/synchronized_move.hpp"

using arm::core::Transform;
using arm::kinematics::DHKinematicChain;
using arm::kinematics::IKSolver;
using arm::kinematics::JointAngles;

namespace {

bool near(double a, double b, double eps) { return std::fabs(a - b) < eps; }

void testIkFkRoundTrip() {
    const DHKinematicChain chain{};
    const IKSolver solver{chain};

    // A handful of representative joint configurations, including some
    // away from the home pose and near (but not at) common singularities.
    const JointAngles configs[] = {
        {0.3, -0.4, 0.5, 0.1, -0.2, 0.15},
        {0.0, 0.0, 0.0, 0.0, 0.0, 0.0},
        {-1.2, 0.6, -0.3, 0.9, 0.4, -0.7},
        {2.5, -1.0, 1.1, -0.2, 0.6, 0.0},
    };

    for (const auto& q_known : configs) {
        const Transform target = chain.computeLinkFrames(q_known).frames.back();

        const JointAngles zero_seed{};
        const auto solved = solver.solve(target, zero_seed);
        assert(solved.has_value());

        const Transform recovered = chain.computeLinkFrames(*solved).frames.back();
        if (!near(target.p.x, recovered.p.x, 1e-4) || !near(target.p.y, recovered.p.y, 1e-4) ||
            !near(target.p.z, recovered.p.z, 1e-4)) {
            std::fprintf(stderr, "FAIL IK/FK round trip: target p=(%.4f,%.4f,%.4f) recovered=(%.4f,%.4f,%.4f)\n",
                         target.p.x, target.p.y, target.p.z, recovered.p.x, recovered.p.y, recovered.p.z);
            assert(false);
        }
    }
}

void testIkRejectsUnreachableTarget() {
    const DHKinematicChain chain{};
    const IKSolver solver{chain};
    // Far outside the ~850mm-class reach this arm is sized for (§1.7 of the
    // arm's own spec doc) — should fail rather than silently return a
    // bogus solution.
    Transform unreachable = Transform::identity();
    unreachable.p = {100.0, 100.0, 100.0};
    const JointAngles zero_seed{};
    const auto solved = solver.solve(unreachable, zero_seed);
    assert(!solved.has_value());
}

void testSynchronizedMoveEndpoints() {
    JointAngles start{0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    JointAngles target{0.5, 0.3, -0.2, 0.1, 0.4, -0.6};

    for (bool use_s_curve : {true, false}) {
        arm::motion::SynchronizedMove move = arm::motion::buildSynchronizedProfiles(start, target, use_s_curve);
        assert(move.duration_s > 0.0);

        for (std::size_t i = 0; i < arm::config::kNumJoints; ++i) {
            const auto s0 = move.profiles[i]->sample(0.0);
            const auto s1 = move.profiles[i]->sample(move.duration_s);
            assert(near(s0.position, start[i], 1e-9));
            assert(near(s1.position, target[i], 1e-6));
            // At the very start/end of a point-to-point move every joint
            // should be momentarily at rest.
            assert(near(s0.velocity, 0.0, 1e-6));
            assert(near(s1.velocity, 0.0, 1e-6));
        }

        // All 6 joints must share the exact same duration (that's the
        // "synchronized" in synchronized move) even though they travel
        // different distances.
        for (std::size_t i = 0; i < arm::config::kNumJoints; ++i) {
            assert(near(move.profiles[i]->duration(), move.duration_s, 1e-9));
        }
    }
}

void testSynchronizedMoveZeroDisplacementJointDoesNotBreak() {
    // J3 doesn't move in this test move while the others do -- the
    // near-zero-travel degenerate-limits guard in buildSynchronizedProfiles
    // exists specifically for this case (see that function's comments).
    JointAngles start{0.0, 0.0, 0.2, 0.0, 0.0, 0.0};
    JointAngles target{0.5, 0.3, 0.2, 0.1, 0.4, -0.6};
    arm::motion::SynchronizedMove move = arm::motion::buildSynchronizedProfiles(start, target, true);
    assert(move.duration_s > 0.0);
    const auto s_end = move.profiles[2]->sample(move.duration_s);
    assert(near(s_end.position, 0.2, 1e-6));
}

}  // namespace

int main() {
    testIkFkRoundTrip();
    testIkRejectsUnreachableTarget();
    testSynchronizedMoveEndpoints();
    testSynchronizedMoveZeroDisplacementJointDoesNotBreak();
    std::printf("test_ik_and_trajectory: all assertions passed\n");
    return 0;
}
