#include "motion/motion_controller.hpp"

#include <algorithm>
#include <cmath>

#include "core/linalg.hpp"
#include "motion/synchronized_move.hpp"

namespace arm::motion {

MotionController::MotionController(std::array<hal::JointInterface*, config::kNumJoints> joints,
                                    double control_loop_hz)
    : joints_(joints), dt_s_(1.0 / control_loop_hz) {}

void MotionController::beginMove(const JointSpaceMove& move) {
    // §13.4 pipeline: TaskCommand -> TrajectoryProfileGenerator. The actual
    // synchronized-multi-axis time-scaling algorithm now lives in
    // buildSynchronizedProfiles() (motion/synchronized_move.*) — factored
    // out so the offline Motion Planner (digital_twin/../motion_planner,
    // platform-spec §7.4) can reuse the exact same algorithm without a
    // hal::JointInterface array attached. See that header's comments.
    SynchronizedMove sync = buildSynchronizedProfiles(move.start, move.target, move.use_s_curve);
    profiles_ = std::move(sync.profiles);
    move_duration_s_ = sync.duration_s;
    elapsed_s_ = 0.0;
    move_active_ = true;
}

bool MotionController::tick() {
    if (!move_active_) return false;

    for (std::size_t i = 0; i < config::kNumJoints; ++i) {
        const KinematicSample sample = profiles_[i]->sample(elapsed_s_);
        joints_[i]->setPositionSetpoint(sample.position);
    }

    elapsed_s_ += dt_s_;
    if (elapsed_s_ >= move_duration_s_) {
        move_active_ = false;
        return false;
    }
    return true;
}

}  // namespace arm::motion
