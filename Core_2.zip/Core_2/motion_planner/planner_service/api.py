"""motion_planner/planner_service/api.py

FastAPI service for the Motion Planner (platform spec §7; §17.3's
token-gated deploy rule). Implements the full §7.2 workflow as three
endpoints: create a program, simulate it (feasibility + collision +
trajectory, §7.2-§7.5), then deploy it (only accepted with a valid,
unexpired token bound to that exact program content — see
planner/deployment_token.py).

Run (after building the native bridge — see ../README.md):
    pip install -r requirements.txt
    export MOTION_PLANNER_VIEWER_API_KEY=...
    export MOTION_PLANNER_OPERATOR_API_KEY=...
    export MOTION_PLANNER_TOKEN_SECRET=...
    uvicorn api:app --port 8200
"""
from __future__ import annotations

import logging
import os
import secrets
from typing import Dict, List, Literal, Optional, Tuple

from fastapi import Depends, FastAPI, HTTPException, Security
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import APIKeyHeader
from pydantic import BaseModel, Field, model_validator

from planner import collision
from planner.deploy_client import DashboardDeployClient
from planner.deployment_token import TokenInvalid, verify_token
from planner.kinematics_bridge import KinematicsBridge
from planner.program import CartesianTarget, JointTarget, Program, Waypoint
from planner.simulation import DEFAULT_SAMPLE_HZ, SimulationResult, simulate_program

logging.basicConfig(
    level=os.environ.get("MOTION_PLANNER_LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
logger = logging.getLogger("motion_planner.api")

# --- Authentication (same pattern as digital_twin/sync_engine/api.py) ------

_VIEWER_KEY = os.environ.get("MOTION_PLANNER_VIEWER_API_KEY")
_OPERATOR_KEY = os.environ.get("MOTION_PLANNER_OPERATOR_API_KEY")
_TOKEN_SECRET = os.environ.get("MOTION_PLANNER_TOKEN_SECRET")
_INSECURE = os.environ.get("MOTION_PLANNER_ALLOW_INSECURE") == "1"

if not _INSECURE and (not _VIEWER_KEY or not _OPERATOR_KEY or not _TOKEN_SECRET):
    raise RuntimeError(
        "MOTION_PLANNER_VIEWER_API_KEY, MOTION_PLANNER_OPERATOR_API_KEY, and "
        "MOTION_PLANNER_TOKEN_SECRET must all be set (the deploy endpoint signs/verifies "
        "simulation-pass tokens with the secret — no default is provided). For local "
        "development only, set MOTION_PLANNER_ALLOW_INSECURE=1 instead."
    )
if _INSECURE:
    logger.warning("MOTION_PLANNER_ALLOW_INSECURE=1 — authentication is DISABLED. Never set this in a real deployment.")
    _TOKEN_SECRET = _TOKEN_SECRET or "insecure-dev-secret"

_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


def _check_key(provided: Optional[str], required: str) -> bool:
    return provided is not None and secrets.compare_digest(provided, required)


def require_viewer(api_key: Optional[str] = Security(_api_key_header)) -> None:
    if _INSECURE or _check_key(api_key, _OPERATOR_KEY) or _check_key(api_key, _VIEWER_KEY):
        return
    raise HTTPException(status_code=401, detail="Invalid or missing API key")


def require_operator(api_key: Optional[str] = Security(_api_key_header)) -> None:
    if _INSECURE or _check_key(api_key, _OPERATOR_KEY):
        return
    raise HTTPException(status_code=401, detail="Invalid or missing operator API key")


# --- Backing services --------------------------------------------------------

_kinematics = KinematicsBridge()
_programs: Dict[str, Program] = {}

app = FastAPI(title="Motion Planner", version="0.1.0")

_cors_origins = [o.strip() for o in os.environ.get("MOTION_PLANNER_CORS_ORIGINS", "").split(",") if o.strip()]
if _cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST"],
        allow_headers=["X-API-Key", "Content-Type"],
    )


# --- Request/response models -------------------------------------------------


class WaypointIn(BaseModel):
    label: str = Field(..., min_length=1, max_length=64)
    interpolation: Literal["joint", "linear"] = "joint"
    use_s_curve: bool = True
    joint_q_rad: Optional[Tuple[float, float, float, float, float, float]] = None
    cartesian_position: Optional[Tuple[float, float, float]] = None
    cartesian_quaternion: Optional[Tuple[float, float, float, float]] = None

    @model_validator(mode="after")
    def _exactly_one_target(self) -> "WaypointIn":
        has_joint = self.joint_q_rad is not None
        has_cartesian = self.cartesian_position is not None or self.cartesian_quaternion is not None
        if has_joint == has_cartesian:  # both set or neither set
            raise ValueError("waypoint must set exactly one of joint_q_rad or (cartesian_position + cartesian_quaternion)")
        if has_cartesian and (self.cartesian_position is None or self.cartesian_quaternion is None):
            raise ValueError("cartesian waypoints need both cartesian_position and cartesian_quaternion")
        return self


class CreateProgramRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=128)
    waypoints: List[WaypointIn] = Field(..., min_length=1)


class ProgramOut(BaseModel):
    id: str
    name: str
    waypoint_labels: List[str]


class SimulateRequest(BaseModel):
    start_q_rad: Optional[Tuple[float, float, float, float, float, float]] = None
    sample_hz: float = DEFAULT_SAMPLE_HZ


class DeployRequest(BaseModel):
    token: str
    dashboard_url: str
    dashboard_api_key: str


def _to_waypoint(w: WaypointIn) -> Waypoint:
    if w.joint_q_rad is not None:
        target = JointTarget(tuple(w.joint_q_rad))
    else:
        target = CartesianTarget(tuple(w.cartesian_position), tuple(w.cartesian_quaternion))
    return Waypoint(label=w.label, target=target, interpolation=w.interpolation, use_s_curve=w.use_s_curve)


def _get_program(program_id: str) -> Program:
    program = _programs.get(program_id)
    if program is None:
        raise HTTPException(status_code=404, detail=f"unknown program id: {program_id}")
    return program


# --- Endpoints ----------------------------------------------------------------


@app.get("/healthz")
def healthz():
    return {"status": "ok"}


@app.post("/api/programs", response_model=ProgramOut, dependencies=[Depends(require_operator)])
def create_program(req: CreateProgramRequest):
    program = Program(name=req.name, waypoints=[_to_waypoint(w) for w in req.waypoints])
    _programs[program.id] = program
    logger.info("Program created: id=%s name=%s waypoints=%d", program.id, program.name, len(program.waypoints))
    return ProgramOut(id=program.id, name=program.name, waypoint_labels=[w.label for w in program.waypoints])


@app.get("/api/programs/{program_id}", response_model=ProgramOut, dependencies=[Depends(require_viewer)])
def get_program(program_id: str):
    program = _get_program(program_id)
    return ProgramOut(id=program.id, name=program.name, waypoint_labels=[w.label for w in program.waypoints])


@app.post("/api/programs/{program_id}/simulate", dependencies=[Depends(require_operator)])
def simulate(program_id: str, req: SimulateRequest):
    program = _get_program(program_id)
    if not _kinematics.is_available():
        raise HTTPException(status_code=503, detail="native kinematics bridge not built -- see ../README.md")

    start_q = req.start_q_rad or (0.0,) * 6
    environment = collision.load_environment()
    result: SimulationResult = simulate_program(
        program,
        _kinematics,
        environment,
        start_q_rad=start_q,
        sample_hz=req.sample_hz,
        token_secret=_TOKEN_SECRET.encode("utf-8"),
    )
    logger.info(
        "Simulated program %s: passed=%s cycle_time=%.3fs collisions=%d limit_violations=%d",
        program_id, result.passed, result.total_cycle_time_s, len(result.collisions), len(result.joint_limit_violations),
    )
    return result


@app.post("/api/programs/{program_id}/deploy", dependencies=[Depends(require_operator)])
def deploy(program_id: str, req: DeployRequest):
    program = _get_program(program_id)
    try:
        verify_token(req.token, program, _TOKEN_SECRET.encode("utf-8"))
    except TokenInvalid as exc:
        raise HTTPException(status_code=422, detail=f"deployment token rejected: {exc}") from exc

    if any(wp.resolved_q_rad is None for wp in program.waypoints):
        raise HTTPException(
            status_code=422,
            detail="program has a waypoint with no resolved joint solution -- re-run /simulate",
        )

    client = DashboardDeployClient(base_url=req.dashboard_url, api_key=req.dashboard_api_key)
    result = client.deploy(program)
    logger.info("Deployed program %s: all_completed=%s", program_id, result.all_completed)
    if not result.all_completed:
        raise HTTPException(status_code=502, detail=result.__dict__)
    return result
