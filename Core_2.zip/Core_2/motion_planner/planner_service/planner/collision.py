"""planner/collision.py

Platform spec §7.5: "Collision checking runs continuously during
simulation (robot-to-robot, robot-to-environment, robot-to-fixture) using
the same convex-hull collision model approach as the motion planner."

Implements robot-to-environment / robot-to-fixture checking (the only kind
possible here — this codebase has one arm, so there is no second robot to
check against, and self-collision isn't attempted either: see
motion_planner/README.md's scope note). "Convex-hull collision model" is
approximated here as capsules (line segment + radius) for each robot link
— reusing the exact same segment geometry digital_twin/sync_engine/twin/
scene.py already defines for visualization (one geometry description, two
consumers: rendering there, collision here) — against oriented boxes for
environment/fixture objects (matching the box primitives
digital_twin/sync_engine/configs/environment_scene.json already uses).

Collision test: capsule-vs-box distance, computed by sampling points along
the capsule's segment and taking the minimum point-to-box distance across
samples, minus the capsule radius. This is a deliberate approximation of
the exact continuous capsule-vs-OBB minimum-distance calculation — exact to
within the sampling resolution (see `DEFAULT_SAMPLES_PER_SEGMENT`), not
exact in the continuous-geometry sense — chosen because it's simple enough
to get right and test with confidence, which matters more for a first
collision-checking pass than exactness beyond what §7.5 asks for. Documented
as an approximation rather than silently presented as exact, same honesty
convention the rest of this repo uses for its other placeholder/derived
values.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence, Tuple

import numpy as np

from . import _paths  # noqa: F401
from .transform import Transform

from twin.scene import robot_link_segments  # noqa: E402 -- see _paths.py

DEFAULT_SAMPLES_PER_SEGMENT = 20
DEFAULT_CLEARANCE_MARGIN_M = 0.0  # touching counts as collision; set >0 for a safety margin


@dataclass(frozen=True)
class EnvironmentObject:
    id: str
    label: str
    position: Tuple[float, float, float]
    quaternion: Tuple[float, float, float, float]  # w, x, y, z
    half_extents: Tuple[float, float, float]  # size / 2


@dataclass(frozen=True)
class CollisionEvent:
    segment_name: str
    object_id: str
    clearance_m: float  # negative = penetration depth; this event only exists when clearance <= margin


def point_to_obb_distance(point: np.ndarray, box: EnvironmentObject) -> float:
    """Distance from `point` to the surface of an oriented box (0 if the
    point is inside)."""
    R = Transform.from_quaternion(0, 0, 0, *box.quaternion).R
    local = R.T @ (point - np.array(box.position))
    half = np.array(box.half_extents)
    clamped = np.clip(local, -half, half)
    return float(np.linalg.norm(local - clamped))


def capsule_clearance(
    seg_a: np.ndarray, seg_b: np.ndarray, radius: float, box: EnvironmentObject, samples: int = DEFAULT_SAMPLES_PER_SEGMENT
) -> float:
    """Approximate minimum clearance (surface-to-surface distance, negative
    if overlapping) between a capsule (segment seg_a->seg_b, given radius)
    and an oriented box, by sampling points along the segment. `samples`
    trades accuracy for speed -- see module docstring."""
    if samples < 2:
        raise ValueError("samples must be >= 2 to cover both endpoints")
    ts = np.linspace(0.0, 1.0, samples)
    min_point_distance = min(point_to_obb_distance(seg_a + t * (seg_b - seg_a), box) for t in ts)
    return min_point_distance - radius


def link_segment_endpoints(link_poses_base_frame: Sequence[Transform]) -> List[np.ndarray]:
    """[robot_base origin, link1 origin, ..., link6 origin] -- consecutive
    pairs are exactly the segments robot_link_segments() describes (same
    from_frame/to_frame order: robot_base->link1, link1->link2, ...)."""
    if len(link_poses_base_frame) != 6:
        raise ValueError(f"expected 6 link poses, got {len(link_poses_base_frame)}")
    return [np.zeros(3)] + [t.p for t in link_poses_base_frame]


def check_pose_collisions(
    link_poses_base_frame: Sequence[Transform],
    environment: Sequence[EnvironmentObject],
    margin_m: float = DEFAULT_CLEARANCE_MARGIN_M,
    samples_per_segment: int = DEFAULT_SAMPLES_PER_SEGMENT,
) -> List[CollisionEvent]:
    """Checks every robot link segment, at one instant (one joint-angle
    vector's FK result), against every environment object. Returns every
    (segment, object) pair whose clearance is at or below `margin_m` --
    normally empty for a clear pose."""
    endpoints = link_segment_endpoints(link_poses_base_frame)
    segments = robot_link_segments()
    events: List[CollisionEvent] = []
    for i, seg in enumerate(segments):
        seg_a, seg_b = endpoints[i], endpoints[i + 1]
        for obj in environment:
            clearance = capsule_clearance(seg_a, seg_b, seg.radius_m, obj, samples=samples_per_segment)
            if clearance <= margin_m:
                events.append(CollisionEvent(segment_name=seg.name, object_id=obj.id, clearance_m=clearance))
    return events


def load_environment(cell_to_base: Transform | None = None, path: str | None = None) -> List[EnvironmentObject]:
    """Loads digital_twin/sync_engine/configs/environment_scene.json (the
    single authored copy of the environment -- not a second copy
    maintained here) and expresses every object's pose in the robot base
    frame via `cell_to_base` (defaults to identity: "cell frame == base
    frame", i.e. no calibration offset applied). In a full deployment this
    transform would come from the Digital Twin's current calibration result
    (digital_twin/sync_engine/twin/frames.py's `robot_base` node) -- not
    wired up automatically here to keep the two services independently
    callable/testable; a caller integrating both passes it through
    explicitly."""
    from twin.scene import load_environment_scene  # noqa: E402 -- see _paths.py

    cell_to_base = cell_to_base or Transform.identity()
    scene = load_environment_scene(path)
    objects: List[EnvironmentObject] = []
    for obj in scene.get("objects", []):
        pos = tuple(obj["position"])
        quat = tuple(obj["quaternion"])
        pose_in_base = cell_to_base @ Transform.from_quaternion(*pos, *quat)
        px, py, pz, qw, qx, qy, qz = pose_in_base.to_quaternion()
        size = obj["size"]
        objects.append(
            EnvironmentObject(
                id=obj["id"],
                label=obj.get("label", obj["id"]),
                position=(px, py, pz),
                quaternion=(qw, qx, qy, qz),
                half_extents=(size[0] / 2.0, size[1] / 2.0, size[2] / 2.0),
            )
        )
    return objects
