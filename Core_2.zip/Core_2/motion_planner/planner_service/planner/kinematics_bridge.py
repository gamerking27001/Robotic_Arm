"""planner/kinematics_bridge.py

ctypes wrapper for the three stateless native_bridge exports the Motion
Planner needs (dashboard/backend/native_bridge/robot_bridge.h):

- robot_bridge_compute_link_frames — forward kinematics (reused from
  digital_twin's addition; see that module's docstring for why FK is
  stateless/handle-free).
- robot_bridge_solve_ik — inverse kinematics (platform spec §7.2's
  "IK/FK Feasibility Check" step; §7.3).
- robot_bridge_sample_joint_move — synchronized multi-axis trajectory
  sampling (§7.4's "Trajectory Optimization" / §7.5's "Full Cycle
  Simulation" steps), built on the exact same synchronized-move algorithm
  MotionController uses live (motion/synchronized_move.hpp).

This is its own small ctypes binding rather than importing
digital_twin/sync_engine/twin/kinematics_bridge.py — see planner/_paths.py's
docstring for why (service independence; only the pure-math Transform
primitive is shared, not the native binding, which is service-specific
because each service calls a different subset of the exported functions).
"""
from __future__ import annotations

import ctypes
import os
from typing import List, Sequence, Tuple

from .transform import Transform

NUM_JOINTS = 6


class LinkPoseC(ctypes.Structure):
    _fields_ = [
        ("px", ctypes.c_double),
        ("py", ctypes.c_double),
        ("pz", ctypes.c_double),
        ("qw", ctypes.c_double),
        ("qx", ctypes.c_double),
        ("qy", ctypes.c_double),
        ("qz", ctypes.c_double),
    ]


class KinematicsBridgeUnavailable(RuntimeError):
    pass


def _default_library_path() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    # motion_planner/planner_service/planner/ -> ../../../dashboard/backend/native_bridge
    repo_root = os.path.abspath(os.path.join(here, "..", "..", ".."))
    return os.path.join(repo_root, "dashboard", "backend", "native_bridge", "librobot_bridge.so")


class KinematicsBridge:
    def __init__(self, library_path: str | None = None) -> None:
        self._path = library_path or _default_library_path()
        self._lib: ctypes.CDLL | None = None

    def is_available(self) -> bool:
        return os.path.exists(self._path)

    def _ensure_loaded(self) -> ctypes.CDLL:
        if self._lib is not None:
            return self._lib
        if not os.path.exists(self._path):
            raise KinematicsBridgeUnavailable(
                f"{self._path} not found. Build it with: (cd dashboard/backend && ./build.sh)"
            )
        lib = ctypes.CDLL(self._path)

        lib.robot_bridge_compute_link_frames.argtypes = [
            ctypes.POINTER(ctypes.c_double),
            ctypes.POINTER(LinkPoseC),
        ]
        lib.robot_bridge_compute_link_frames.restype = None

        lib.robot_bridge_solve_ik.argtypes = [
            ctypes.POINTER(LinkPoseC),
            ctypes.POINTER(ctypes.c_double),
            ctypes.POINTER(ctypes.c_double),
        ]
        lib.robot_bridge_solve_ik.restype = ctypes.c_int

        lib.robot_bridge_sample_joint_move.argtypes = [
            ctypes.POINTER(ctypes.c_double),
            ctypes.POINTER(ctypes.c_double),
            ctypes.c_int,
            ctypes.c_double,
            ctypes.POINTER(ctypes.c_double),
            ctypes.POINTER(ctypes.c_double),
        ]
        lib.robot_bridge_sample_joint_move.restype = ctypes.c_double

        self._lib = lib
        return lib

    def compute_link_frames(self, q_rad: Sequence[float]) -> List[Transform]:
        if len(q_rad) != NUM_JOINTS:
            raise ValueError(f"expected {NUM_JOINTS} joint angles, got {len(q_rad)}")
        lib = self._ensure_loaded()
        q_arr = (ctypes.c_double * NUM_JOINTS)(*[float(v) for v in q_rad])
        out_arr = (LinkPoseC * NUM_JOINTS)()
        lib.robot_bridge_compute_link_frames(q_arr, out_arr)
        return [Transform.from_quaternion(p.px, p.py, p.pz, p.qw, p.qx, p.qy, p.qz) for p in out_arr]

    def solve_ik(self, target: Transform, seed_q_rad: Sequence[float]) -> Tuple[float, ...] | None:
        """Returns the solved joint-angle vector (radians), or None if no
        solution was found within tolerance (§7.2's IK/FK feasibility gate
        reads this None/not-None directly)."""
        if len(seed_q_rad) != NUM_JOINTS:
            raise ValueError(f"expected {NUM_JOINTS} seed joint angles, got {len(seed_q_rad)}")
        lib = self._ensure_loaded()
        px, py, pz, qw, qx, qy, qz = target.to_quaternion()
        target_c = LinkPoseC(px=px, py=py, pz=pz, qw=qw, qx=qx, qy=qy, qz=qz)
        seed_arr = (ctypes.c_double * NUM_JOINTS)(*[float(v) for v in seed_q_rad])
        out_arr = (ctypes.c_double * NUM_JOINTS)()
        ok = lib.robot_bridge_solve_ik(ctypes.byref(target_c), seed_arr, out_arr)
        if not ok:
            return None
        return tuple(out_arr)

    def sample_joint_move(
        self, q_start_rad: Sequence[float], q_target_rad: Sequence[float], use_s_curve: bool, t_s: float
    ) -> Tuple[float, Tuple[float, ...], Tuple[float, ...]]:
        """Returns (duration_s, q_rad, qdot_rad_s) for the synchronized move
        from q_start_rad to q_target_rad, sampled at t_s (clamped to
        [0, duration_s] by the native side). Call once with any t_s to learn
        duration_s, then sample as densely as needed across [0, duration_s]
        for a full-cycle simulation (§7.5)."""
        if len(q_start_rad) != NUM_JOINTS or len(q_target_rad) != NUM_JOINTS:
            raise ValueError(f"expected {NUM_JOINTS}-length joint vectors")
        lib = self._ensure_loaded()
        start_arr = (ctypes.c_double * NUM_JOINTS)(*[float(v) for v in q_start_rad])
        target_arr = (ctypes.c_double * NUM_JOINTS)(*[float(v) for v in q_target_rad])
        out_q = (ctypes.c_double * NUM_JOINTS)()
        out_qdot = (ctypes.c_double * NUM_JOINTS)()
        duration = lib.robot_bridge_sample_joint_move(
            start_arr, target_arr, 1 if use_s_curve else 0, float(t_s), out_q, out_qdot
        )
        return duration, tuple(out_q), tuple(out_qdot)
