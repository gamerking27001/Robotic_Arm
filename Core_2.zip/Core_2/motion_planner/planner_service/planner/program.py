"""planner/program.py

§7.1: "Waypoint/Path Editing — Direct manipulation of waypoints and
interpolation type (joint/linear/circular) in 3D." This module is that
data model: a Program is an ordered list of Waypoints, each either a
joint-space target (angles given directly) or a Cartesian target (position
+ orientation, resolved to joint angles by IK during the feasibility-check
step — see simulation.py). Circular interpolation isn't implemented (see
motion_planner/README.md's scope note) — only the joint/linear split
§7.1 lists.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import List, Literal, Optional, Tuple

NUM_JOINTS = 6


@dataclass(frozen=True)
class JointTarget:
    q_rad: Tuple[float, ...]

    def __post_init__(self) -> None:
        if len(self.q_rad) != NUM_JOINTS:
            raise ValueError(f"JointTarget needs {NUM_JOINTS} joint angles, got {len(self.q_rad)}")


@dataclass(frozen=True)
class CartesianTarget:
    """Position (meters) + orientation quaternion (w,x,y,z), in the robot
    base frame — resolved to joint angles by IK during feasibility
    checking, chained from the previous waypoint's solved angles as the IK
    seed (§7.3's "seed_angles" parameter)."""

    position: Tuple[float, float, float]
    quaternion: Tuple[float, float, float, float]


@dataclass
class Waypoint:
    label: str
    target: JointTarget | CartesianTarget
    interpolation: Literal["joint", "linear"] = "joint"
    use_s_curve: bool = True
    # Filled in by the feasibility-check step (simulation.py), not supplied
    # by the caller — the resolved joint-angle vector this waypoint will
    # actually be commanded to, whether it started as a JointTarget (copied
    # straight through) or a CartesianTarget (IK-solved).
    resolved_q_rad: Optional[Tuple[float, ...]] = None


@dataclass
class Program:
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    name: str = "untitled"
    waypoints: List[Waypoint] = field(default_factory=list)
    created_at: float = field(default_factory=time.monotonic)

    def add_joint_waypoint(
        self, label: str, q_rad: Tuple[float, ...], use_s_curve: bool = True
    ) -> Waypoint:
        wp = Waypoint(label=label, target=JointTarget(q_rad), use_s_curve=use_s_curve)
        self.waypoints.append(wp)
        return wp

    def add_cartesian_waypoint(
        self,
        label: str,
        position: Tuple[float, float, float],
        quaternion: Tuple[float, float, float, float],
        use_s_curve: bool = True,
    ) -> Waypoint:
        wp = Waypoint(label=label, target=CartesianTarget(position, quaternion), use_s_curve=use_s_curve)
        self.waypoints.append(wp)
        return wp
