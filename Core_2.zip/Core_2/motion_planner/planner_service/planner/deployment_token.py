"""planner/deployment_token.py

Platform spec §17.3: "the Gateway's deploy endpoint only accepts a program
payload that carries a passing simulation result token" — enforcing §7.5's
rule structurally ("a program only becomes eligible for one-click
deployment to the physical robot after passing a full simulated cycle with
zero flagged collisions and all joint limits respected") rather than by
convention/trust.

Token = HMAC-SHA256(secret, program_hash || expiry) — binds the token to
*exactly* this program's content (via its hash) and to an expiry, so:
- editing a waypoint after simulating invalidates the token (the hash
  changes, so `verify_token` fails even though the token string itself is
  still "valid" cryptographically) -- exactly closing the gap that a
  freeform "any successful simulation counts" gate would leave open.
- an old token can't be replayed indefinitely (default TTL, see
  DEFAULT_TOKEN_TTL_S).
"""
from __future__ import annotations

import hashlib
import hmac
import json
import time
from dataclasses import dataclass

from .program import CartesianTarget, JointTarget, Program

DEFAULT_TOKEN_TTL_S = 300.0


def program_content_hash(program: Program) -> str:
    """Deterministic hash of exactly the fields that affect what the robot
    will actually be commanded to do -- not `id`/`name`/`created_at`, so
    renaming a program (say) doesn't spuriously invalidate its token, but
    changing a single waypoint's target, interpolation, or use_s_curve
    flag, or reordering/adding/removing waypoints, does."""
    canonical = []
    for wp in program.waypoints:
        if isinstance(wp.target, JointTarget):
            target_repr = {"kind": "joint", "q_rad": list(wp.target.q_rad)}
        elif isinstance(wp.target, CartesianTarget):
            target_repr = {
                "kind": "cartesian",
                "position": list(wp.target.position),
                "quaternion": list(wp.target.quaternion),
            }
        else:  # pragma: no cover - exhaustive by construction
            raise TypeError(f"unknown waypoint target type: {type(wp.target)!r}")
        canonical.append(
            {
                "label": wp.label,
                "target": target_repr,
                "interpolation": wp.interpolation,
                "use_s_curve": wp.use_s_curve,
            }
        )
    blob = json.dumps(canonical, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


@dataclass(frozen=True)
class DeploymentToken:
    program_hash: str
    issued_at: float
    expires_at: float
    signature: str

    def encode(self) -> str:
        return f"{self.program_hash}|{self.issued_at:.6f}|{self.expires_at:.6f}|{self.signature}"

    @staticmethod
    def decode(raw: str) -> "DeploymentToken":
        # "|" is not a valid RFC 4648 base16/hex character and %.6f never
        # produces one, so it's an unambiguous separator for these three
        # fields -- unlike "." (used earlier), which collides with the "."
        # every %.6f-formatted float already contains, silently breaking
        # decode() (caught by test_deployment_token.py's round-trip test).
        parts = raw.split("|")
        if len(parts) != 4:
            raise ValueError("malformed token")
        program_hash, issued_at, expires_at, signature = parts
        return DeploymentToken(
            program_hash=program_hash, issued_at=float(issued_at), expires_at=float(expires_at), signature=signature
        )


def _sign(secret: bytes, program_hash: str, issued_at: float, expires_at: float) -> str:
    message = f"{program_hash}.{issued_at:.6f}.{expires_at:.6f}".encode("utf-8")
    return hmac.new(secret, message, hashlib.sha256).hexdigest()


def issue_token(program: Program, secret: bytes, ttl_s: float = DEFAULT_TOKEN_TTL_S) -> str:
    program_hash = program_content_hash(program)
    issued_at = time.time()
    expires_at = issued_at + ttl_s
    signature = _sign(secret, program_hash, issued_at, expires_at)
    return DeploymentToken(program_hash, issued_at, expires_at, signature).encode()


class TokenInvalid(Exception):
    pass


def verify_token(raw_token: str, program: Program, secret: bytes) -> None:
    """Raises TokenInvalid with a specific reason on any failure; returns
    None (silently) on success -- callers that want a boolean can wrap this
    in a try/except, but the deploy endpoint wants the specific reason to
    log/return to the operator."""
    try:
        token = DeploymentToken.decode(raw_token)
    except ValueError as exc:
        raise TokenInvalid("malformed token") from exc

    expected_signature = _sign(secret, token.program_hash, token.issued_at, token.expires_at)
    if not hmac.compare_digest(expected_signature, token.signature):
        raise TokenInvalid("signature mismatch (token forged or secret rotated)")

    if time.time() > token.expires_at:
        raise TokenInvalid("token expired -- re-run the simulation")

    current_hash = program_content_hash(program)
    if not hmac.compare_digest(current_hash, token.program_hash):
        raise TokenInvalid("program has changed since it was simulated -- re-run the simulation")
