"""Motion Planner service — platform spec section 7. See ../README.md."""
from . import _paths  # noqa: F401 -- import for its sys.path side effect, before any sibling module needs it
