"""planner/simulation.py

Implements the §7.2 programming workflow's simulation half end to end:

    AddWaypoints -> IK/FK Feasibility Check -> Collision Detection in
    Simulation -> Trajectory Optimization -> Full Cycle Simulation
    -> [Pass] -> DeployToPhysicalRobot

("Trajectory Optimization" here is the existing S-curve time-parameterization
§7.4 already specifies and motion/synchronized_move.hpp already implements
-- there's no separate optimization pass beyond what buildSynchronizedProfiles
already does; see that header's comments for why the "optimization" is the
scaled S-curve construction itself, not a second pass on top of it.)

A program only gets a deployment token (deployment_token.py) if every
waypoint resolved, no joint soft-limit was exceeded at any sampled instant,
and no collision was flagged at any sampled instant across every planned
move -- §7.5's rule, enforced here rather than merely described.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

from . import _paths  # noqa: F401
from .collision import EnvironmentObject, check_pose_collisions
from .deployment_token import DEFAULT_TOKEN_TTL_S, issue_token
from .kinematics_bridge import KinematicsBridge
from .program import CartesianTarget, JointTarget, Program, Waypoint
from .transform import Transform

from tools.robot_params import JOINT_LIMITS, JOINT_NAMES, NUM_JOINTS  # noqa: E402 -- see _paths.py

DEFAULT_SAMPLE_HZ = 100.0


@dataclass(frozen=True)
class FeasibilityEntry:
    label: str
    ok: bool
    q_rad: Optional[Tuple[float, ...]]
    reason: Optional[str] = None


@dataclass(frozen=True)
class JointLimitViolation:
    move_index: int
    t_s: float
    joint_name: str
    angle_deg: float
    limit_min_deg: float
    limit_max_deg: float


@dataclass(frozen=True)
class SimCollisionEvent:
    move_index: int
    t_s: float
    segment_name: str
    object_id: str
    clearance_m: float


@dataclass
class SimulationResult:
    program_id: str
    passed: bool
    total_cycle_time_s: float
    move_durations_s: List[float] = field(default_factory=list)
    feasibility: List[FeasibilityEntry] = field(default_factory=list)
    collisions: List[SimCollisionEvent] = field(default_factory=list)
    joint_limit_violations: List[JointLimitViolation] = field(default_factory=list)
    deployment_token: Optional[str] = None


def _check_feasibility(
    waypoints: Sequence[Waypoint], kinematics: KinematicsBridge, start_q_rad: Tuple[float, ...]
) -> List[FeasibilityEntry]:
    entries: List[FeasibilityEntry] = []
    prev_q = start_q_rad
    for wp in waypoints:
        if isinstance(wp.target, JointTarget):
            wp.resolved_q_rad = wp.target.q_rad
            entries.append(FeasibilityEntry(label=wp.label, ok=True, q_rad=wp.target.q_rad))
            prev_q = wp.target.q_rad
        elif isinstance(wp.target, CartesianTarget):
            target_transform = Transform.from_quaternion(*wp.target.position, *wp.target.quaternion)
            solved = kinematics.solve_ik(target_transform, prev_q)
            if solved is None:
                wp.resolved_q_rad = None
                entries.append(
                    FeasibilityEntry(label=wp.label, ok=False, q_rad=None, reason="IK: no solution within tolerance")
                )
                # Feasibility checking continues for later waypoints (seeded
                # from the last *feasible* joint state) so one bad waypoint
                # doesn't hide problems with the rest of the program.
            else:
                wp.resolved_q_rad = solved
                entries.append(FeasibilityEntry(label=wp.label, ok=True, q_rad=solved))
                prev_q = solved
        else:  # pragma: no cover - exhaustive by construction
            raise TypeError(f"unknown waypoint target type: {type(wp.target)!r}")
    return entries


def simulate_program(
    program: Program,
    kinematics: KinematicsBridge,
    environment: Sequence[EnvironmentObject],
    start_q_rad: Tuple[float, ...] = (0.0,) * NUM_JOINTS,
    sample_hz: float = DEFAULT_SAMPLE_HZ,
    token_secret: bytes = b"",
    token_ttl_s: float = DEFAULT_TOKEN_TTL_S,
) -> SimulationResult:
    if not program.waypoints:
        return SimulationResult(program_id=program.id, passed=False, total_cycle_time_s=0.0)

    feasibility = _check_feasibility(program.waypoints, kinematics, start_q_rad)
    all_feasible = all(f.ok for f in feasibility)

    move_durations: List[float] = []
    collisions: List[SimCollisionEvent] = []
    joint_limit_violations: List[JointLimitViolation] = []

    prev_q = start_q_rad
    for move_index, wp in enumerate(program.waypoints):
        if wp.resolved_q_rad is None:
            # Can't simulate a move into an infeasible waypoint; record no
            # duration for it and don't advance prev_q, so any *later*
            # feasible waypoint is still checked from the last known-good
            # state rather than cascading failures.
            move_durations.append(0.0)
            continue

        this_q = wp.resolved_q_rad
        duration, _, _ = kinematics.sample_joint_move(prev_q, this_q, wp.use_s_curve, 0.0)
        move_durations.append(duration)

        n_samples = max(1, int(math.ceil(duration * sample_hz)))
        for k in range(n_samples + 1):
            t = duration * k / n_samples if n_samples > 0 else 0.0
            _, q, _qdot = kinematics.sample_joint_move(prev_q, this_q, wp.use_s_curve, t)

            for i in range(NUM_JOINTS):
                angle_deg = math.degrees(q[i])
                limit_min, limit_max, _max_speed = JOINT_LIMITS[i]
                if not (limit_min <= angle_deg <= limit_max):
                    joint_limit_violations.append(
                        JointLimitViolation(
                            move_index=move_index,
                            t_s=t,
                            joint_name=JOINT_NAMES[i],
                            angle_deg=angle_deg,
                            limit_min_deg=limit_min,
                            limit_max_deg=limit_max,
                        )
                    )

            link_poses = kinematics.compute_link_frames(q)
            for event in check_pose_collisions(link_poses, environment):
                collisions.append(
                    SimCollisionEvent(
                        move_index=move_index,
                        t_s=t,
                        segment_name=event.segment_name,
                        object_id=event.object_id,
                        clearance_m=event.clearance_m,
                    )
                )

        prev_q = this_q

    passed = all_feasible and not collisions and not joint_limit_violations
    token = issue_token(program, token_secret, token_ttl_s) if passed else None

    return SimulationResult(
        program_id=program.id,
        passed=passed,
        total_cycle_time_s=sum(move_durations),
        move_durations_s=move_durations,
        feasibility=feasibility,
        collisions=collisions,
        joint_limit_violations=joint_limit_violations,
        deployment_token=token,
    )
