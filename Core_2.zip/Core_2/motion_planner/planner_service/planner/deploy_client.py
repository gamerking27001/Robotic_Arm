"""planner/deploy_client.py

The "DeployToPhysicalRobot" step of §7.2's workflow — the only part of the
Motion Planner that actually talks to a live robot, and only reachable
after a program has a valid, unexpired deployment token bound to its exact
current content (see deployment_token.py / api.py's `/deploy` endpoint,
which checks the token *before* this module is ever called).

Sequences each waypoint as one `POST /api/moves` call to the existing
robotic_arm_core dashboard backend (dashboard/backend/main.py), waiting for
`move_active` to clear (polling `GET /api/telemetry`) before sending the
next one -- there is no queued-multi-move endpoint on that backend, so this
is what "deploy a program" reduces to against it. This is a genuinely
different failure mode than a Local Gateway Service's queued dispatch would
have (§1.2's core-module table) -- documented as a known limitation in
motion_planner/README.md, not hidden.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import List, Optional

import httpx

from .program import Program


@dataclass
class WaypointDeployResult:
    label: str
    accepted: bool
    completed: bool
    error: Optional[str] = None


@dataclass
class DeployResult:
    program_id: str
    waypoints: List[WaypointDeployResult]

    @property
    def all_completed(self) -> bool:
        return all(w.completed for w in self.waypoints)


class DashboardDeployClient:
    def __init__(self, base_url: str, api_key: str, poll_interval_s: float = 0.1, move_timeout_s: float = 30.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.poll_interval_s = poll_interval_s
        self.move_timeout_s = move_timeout_s

    def deploy(self, program: Program) -> DeployResult:
        """Precondition: every waypoint.resolved_q_rad is set (i.e. the
        program has already passed simulate_program() and its token has
        been verified by the caller -- this function does not re-check
        feasibility, collisions, or the token; api.py's /deploy endpoint is
        responsible for that ordering)."""
        results: List[WaypointDeployResult] = []
        with httpx.Client(base_url=self.base_url, headers={"X-API-Key": self.api_key}, timeout=10.0) as client:
            for wp in program.waypoints:
                if wp.resolved_q_rad is None:
                    results.append(WaypointDeployResult(label=wp.label, accepted=False, completed=False,
                                                          error="waypoint has no resolved joint solution"))
                    break  # don't attempt later waypoints out of order relative to a skipped one

                target_deg = [math.degrees(v) for v in wp.resolved_q_rad]
                try:
                    resp = client.post("/api/moves", json={"target_deg": target_deg, "use_s_curve": wp.use_s_curve})
                except httpx.HTTPError as exc:
                    results.append(WaypointDeployResult(label=wp.label, accepted=False, completed=False, error=str(exc)))
                    break

                if resp.status_code != 200:
                    results.append(
                        WaypointDeployResult(label=wp.label, accepted=False, completed=False, error=resp.text)
                    )
                    break

                completed = self._wait_for_move_completion(client)
                results.append(WaypointDeployResult(label=wp.label, accepted=True, completed=completed,
                                                      error=None if completed else "timed out waiting for move to complete"))
                if not completed:
                    break

        return DeployResult(program_id=program.id, waypoints=results)

    def _wait_for_move_completion(self, client: httpx.Client) -> bool:
        deadline = time.monotonic() + self.move_timeout_s
        while time.monotonic() < deadline:
            resp = client.get("/api/telemetry")
            if resp.status_code == 200 and not resp.json().get("move_active", True):
                return True
            time.sleep(self.poll_interval_s)
        return False
