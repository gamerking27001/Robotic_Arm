"""planner/_paths.py

Adds the two other locations this package deliberately reuses code from,
instead of copying it a second/third time:

- repo root, for `tools.robot_params` (DH table + joint limits — the
  existing single source of truth digital_twin/sync_engine/twin/scene.py
  already reuses the same way, see that file's docstring).
- digital_twin/sync_engine, for `twin.transform.Transform` — the rigid-
  transform primitive (matrix + quaternion), so motion_planner and
  digital_twin agree on one convention/implementation of "what a Transform
  is" rather than each maintaining their own copy of the same quaternion
  math to independently get right and keep in sync.

This does *not* import digital_twin's business logic (frames, calibration,
interpolation, telemetry sources) — only the one shared, dependency-free
math primitive. The two services stay independently deployable (platform
spec §8.2's stated reason for keeping AI/service modules decoupled applies
here too): motion_planner doesn't start, or fail to start, based on
anything digital_twin-specific.

Importing this module (for its side effect on sys.path) must happen before
`from tools.robot_params import ...` or `from twin.transform import
Transform` anywhere in this package.
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
DIGITAL_TWIN_SYNC_ENGINE = os.path.join(REPO_ROOT, "digital_twin", "sync_engine")

for _path in (REPO_ROOT, DIGITAL_TWIN_SYNC_ENGINE):
    if _path not in sys.path:
        sys.path.insert(0, _path)
