import pytest

from planner.kinematics_bridge import KinematicsBridge

bridge = KinematicsBridge()
requires_native_bridge = pytest.mark.skipif(
    not bridge.is_available(), reason="native_bridge/librobot_bridge.so not built"
)


@requires_native_bridge
def test_ik_fk_round_trip():
    q_known = [0.3, -0.4, 0.5, 0.1, -0.2, 0.15]
    target = bridge.compute_link_frames(q_known)[-1]
    solved = bridge.solve_ik(target, [0.0] * 6)
    assert solved is not None
    recovered = bridge.compute_link_frames(list(solved))[-1]
    assert recovered.p == pytest.approx(target.p, abs=1e-3)


@requires_native_bridge
def test_ik_unreachable_target_returns_none():
    from planner.transform import Transform

    far_target = Transform.from_translation(100.0, 100.0, 100.0)
    solved = bridge.solve_ik(far_target, [0.0] * 6)
    assert solved is None


@requires_native_bridge
def test_sample_joint_move_endpoints():
    start = [0.0] * 6
    target = [0.5, 0.3, -0.2, 0.1, 0.4, -0.6]
    duration, q_end, qdot_end = bridge.sample_joint_move(start, target, True, 1e9)
    assert duration > 0
    assert list(q_end) == pytest.approx(target, abs=1e-6)

    _, q_start, _ = bridge.sample_joint_move(start, target, True, 0.0)
    assert list(q_start) == pytest.approx(start, abs=1e-9)


@requires_native_bridge
def test_sample_joint_move_synchronizes_all_joints():
    """All 6 joints should arrive together (same duration) even though
    they travel very different distances -- the synchronized-move
    guarantee motion/synchronized_move.hpp implements."""
    start = [0.0] * 6
    target = [0.05, 1.5, -0.02, 0.9, 0.01, -1.2]  # wildly different per-joint distances
    duration1, _, _ = bridge.sample_joint_move(start, target, True, 0.0)
    duration2, _, _ = bridge.sample_joint_move(start, target, True, duration1)
    assert duration1 == pytest.approx(duration2)
    _, q_at_end, _ = bridge.sample_joint_move(start, target, True, duration1)
    assert list(q_at_end) == pytest.approx(target, abs=1e-6)


def test_wrong_length_inputs_raise():
    with pytest.raises(ValueError):
        bridge.compute_link_frames([0.0] * 5)


def test_unavailable_bridge_raises_clear_error(tmp_path):
    from planner.kinematics_bridge import KinematicsBridgeUnavailable

    missing = KinematicsBridge(library_path=str(tmp_path / "nope.so"))
    assert not missing.is_available()
    with pytest.raises(KinematicsBridgeUnavailable):
        missing.compute_link_frames([0.0] * 6)
