import os

os.environ.setdefault("MOTION_PLANNER_VIEWER_API_KEY", "test-viewer-key")
os.environ.setdefault("MOTION_PLANNER_OPERATOR_API_KEY", "test-operator-key")
os.environ.setdefault("MOTION_PLANNER_TOKEN_SECRET", "test-token-secret")
