import time

import pytest

from planner.deployment_token import (
    TokenInvalid,
    issue_token,
    program_content_hash,
    verify_token,
)
from planner.program import Program


def _program():
    p = Program(name="test")
    p.add_joint_waypoint("a", tuple([0.0] * 6))
    p.add_joint_waypoint("b", (0.1, 0.2, 0.3, 0.0, 0.0, 0.0))
    return p


def test_issue_and_verify_round_trip():
    program = _program()
    token = issue_token(program, secret=b"secret", ttl_s=60)
    verify_token(token, program, secret=b"secret")  # should not raise


def test_token_encode_decode_survives_floats_with_decimal_points():
    """Regression test: the token separator must not collide with the '.'
    every %.6f-formatted timestamp contains (see deployment_token.py's
    encode()/decode() comment -- this was a real bug caught here)."""
    program = _program()
    token = issue_token(program, secret=b"secret", ttl_s=60)
    assert token.count("|") == 3


def test_wrong_secret_rejected():
    program = _program()
    token = issue_token(program, secret=b"secret-a", ttl_s=60)
    with pytest.raises(TokenInvalid):
        verify_token(token, program, secret=b"secret-b")


def test_modified_program_rejected():
    program = _program()
    token = issue_token(program, secret=b"secret", ttl_s=60)
    program.waypoints[0].target = program.waypoints[0].target.__class__((1.0, 0.0, 0.0, 0.0, 0.0, 0.0))
    with pytest.raises(TokenInvalid):
        verify_token(token, program, secret=b"secret")


def test_expired_token_rejected():
    program = _program()
    token = issue_token(program, secret=b"secret", ttl_s=0.01)
    time.sleep(0.05)
    with pytest.raises(TokenInvalid):
        verify_token(token, program, secret=b"secret")


def test_malformed_token_rejected():
    program = _program()
    with pytest.raises(TokenInvalid):
        verify_token("not-a-real-token", program, secret=b"secret")


def test_reordering_waypoints_changes_hash():
    program = _program()
    h1 = program_content_hash(program)
    program.waypoints.reverse()
    h2 = program_content_hash(program)
    assert h1 != h2


def test_renaming_program_does_not_change_hash():
    program = _program()
    h1 = program_content_hash(program)
    program.name = "renamed"
    h2 = program_content_hash(program)
    assert h1 == h2
