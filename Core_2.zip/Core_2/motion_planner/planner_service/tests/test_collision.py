import numpy as np
import pytest

from planner.collision import (
    EnvironmentObject,
    capsule_clearance,
    check_pose_collisions,
    load_environment,
    point_to_obb_distance,
)
from planner.kinematics_bridge import KinematicsBridge
from planner.transform import Transform

bridge = KinematicsBridge()
requires_native_bridge = pytest.mark.skipif(
    not bridge.is_available(), reason="native_bridge/librobot_bridge.so not built"
)


def _box(position=(0.0, 0.0, 0.0), quaternion=(1.0, 0.0, 0.0, 0.0), half_extents=(0.5, 0.5, 0.5)):
    return EnvironmentObject(id="box", label="box", position=position, quaternion=quaternion, half_extents=half_extents)


def test_point_inside_box_has_zero_distance():
    box = _box()
    assert point_to_obb_distance(np.array([0.1, 0.1, 0.1]), box) == pytest.approx(0.0)


def test_point_outside_box_along_axis():
    box = _box(half_extents=(0.5, 0.5, 0.5))
    # 2.0 along X, box face at 0.5 -> distance 1.5
    assert point_to_obb_distance(np.array([2.0, 0.0, 0.0]), box) == pytest.approx(1.5)


def test_point_distance_is_rotation_aware():
    # Box rotated 90deg about Z: its "long" X-half-extent now points along
    # world Y. A point that would be outside the unrotated box along X
    # should be inside (or closer) once the box is rotated to align with it.
    box = _box(quaternion=(np.sqrt(0.5), 0, 0, np.sqrt(0.5)), half_extents=(0.1, 2.0, 0.1))
    # In world space this box now spans roughly x in [-2,2], y in [-0.1,0.1]
    d = point_to_obb_distance(np.array([1.5, 0.0, 0.0]), box)
    assert d == pytest.approx(0.0, abs=1e-6)


def test_capsule_clearance_matches_point_minus_radius_for_a_point_capsule():
    box = _box(position=(3.0, 0.0, 0.0))
    a = b = np.array([0.0, 0.0, 0.0])
    clearance = capsule_clearance(a, b, radius=0.2, box=box, samples=2)
    expected = point_to_obb_distance(a, box) - 0.2
    assert clearance == pytest.approx(expected)


def test_capsule_clear_of_distant_box():
    box = _box(position=(10.0, 10.0, 10.0), half_extents=(0.1, 0.1, 0.1))
    a, b = np.array([0.0, 0.0, 0.0]), np.array([1.0, 0.0, 0.0])
    clearance = capsule_clearance(a, b, radius=0.05, box=box)
    assert clearance > 0


def test_capsule_overlapping_box_is_detected():
    box = _box(position=(0.5, 0.0, 0.0), half_extents=(0.3, 0.3, 0.3))
    a, b = np.array([0.0, 0.0, 0.0]), np.array([1.0, 0.0, 0.0])  # segment passes straight through the box
    clearance = capsule_clearance(a, b, radius=0.05, box=box)
    assert clearance < 0


@requires_native_bridge
def test_check_pose_collisions_clear_scene_returns_empty():
    link_poses = bridge.compute_link_frames([0.0] * 6)
    far_box = _box(position=(100.0, 100.0, 100.0), half_extents=(0.1, 0.1, 0.1))
    events = check_pose_collisions(link_poses, [far_box])
    assert events == []


@requires_native_bridge
def test_check_pose_collisions_detects_forced_overlap():
    link_poses = bridge.compute_link_frames([0.0] * 6)
    # A huge box centered right on link1's origin will definitely overlap
    # multiple link segments.
    overlapping_box = _box(position=tuple(link_poses[1].p), half_extents=(1.0, 1.0, 1.0))
    events = check_pose_collisions(link_poses, [overlapping_box])
    assert len(events) > 0
    assert all(e.clearance_m < 0 for e in events)


def test_load_environment_applies_cell_to_base_offset():
    default = load_environment()
    offset = Transform.from_translation(10.0, 0.0, 0.0)
    shifted = load_environment(cell_to_base=offset)
    assert len(default) == len(shifted)
    for d, s in zip(default, shifted):
        assert s.position[0] == pytest.approx(d.position[0] + 10.0)
        assert s.position[1] == pytest.approx(d.position[1])
