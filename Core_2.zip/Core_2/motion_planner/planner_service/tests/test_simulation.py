import pytest

from planner.collision import EnvironmentObject
from planner.kinematics_bridge import KinematicsBridge
from planner.program import Program
from planner.simulation import simulate_program

bridge = KinematicsBridge()
requires_native_bridge = pytest.mark.skipif(
    not bridge.is_available(), reason="native_bridge/librobot_bridge.so not built"
)


@requires_native_bridge
def test_clear_program_passes_and_gets_a_token():
    program = Program(name="clear")
    program.add_joint_waypoint("a", tuple([0.0] * 6))
    program.add_joint_waypoint("b", (0.2, -0.1, 0.1, 0.0, 0.1, 0.0))

    result = simulate_program(program, bridge, environment=[], token_secret=b"secret")

    assert result.passed is True
    assert result.deployment_token is not None
    assert result.total_cycle_time_s > 0
    assert not result.collisions
    assert not result.joint_limit_violations
    assert all(f.ok for f in result.feasibility)


@requires_native_bridge
def test_program_with_blocking_obstacle_fails_and_gets_no_token():
    program = Program(name="blocked")
    program.add_joint_waypoint("a", tuple([0.0] * 6))
    program.add_joint_waypoint("b", (0.5, -0.3, 0.2, 0.0, 0.2, 0.0))

    # Put a huge box right where the arm has to be at t=0 (home pose,
    # link1 origin) -- guaranteed to be hit somewhere along the move.
    link1_pos = tuple(bridge.compute_link_frames([0.0] * 6)[0].p)
    blocking_box = EnvironmentObject(
        id="blocker", label="blocker", position=link1_pos, quaternion=(1.0, 0.0, 0.0, 0.0), half_extents=(0.5, 0.5, 0.5)
    )

    result = simulate_program(program, bridge, environment=[blocking_box], token_secret=b"secret")

    assert result.passed is False
    assert result.deployment_token is None
    assert len(result.collisions) > 0


@requires_native_bridge
def test_unreachable_cartesian_waypoint_marked_infeasible():
    program = Program(name="unreachable")
    program.add_joint_waypoint("a", tuple([0.0] * 6))
    program.add_cartesian_waypoint("far", (100.0, 100.0, 100.0), (1.0, 0.0, 0.0, 0.0))

    result = simulate_program(program, bridge, environment=[], token_secret=b"secret")

    assert result.passed is False
    assert result.deployment_token is None
    assert result.feasibility[1].ok is False
    assert result.feasibility[1].reason is not None


@requires_native_bridge
def test_joint_limit_violation_detected():
    program = Program(name="over-limit")
    program.add_joint_waypoint("a", tuple([0.0] * 6))
    # J2 (shoulder) soft limits are -95..95 deg (~-1.658..1.658 rad, see
    # tools/robot_params.py) -- 3.0 rad (~172deg) is well outside that.
    program.add_joint_waypoint("b", (0.0, 3.0, 0.0, 0.0, 0.0, 0.0))

    result = simulate_program(program, bridge, environment=[], token_secret=b"secret")

    assert result.passed is False
    assert len(result.joint_limit_violations) > 0
    assert any(v.joint_name == "shoulder" for v in result.joint_limit_violations)


@requires_native_bridge
def test_empty_program_fails_cleanly():
    program = Program(name="empty")
    result = simulate_program(program, bridge, environment=[], token_secret=b"secret")
    assert result.passed is False
    assert result.deployment_token is None


@requires_native_bridge
def test_move_durations_align_with_waypoint_count():
    program = Program(name="three-move")
    program.add_joint_waypoint("a", tuple([0.0] * 6))
    program.add_joint_waypoint("b", (0.1, 0.0, 0.0, 0.0, 0.0, 0.0))
    program.add_joint_waypoint("c", (0.1, 0.1, 0.0, 0.0, 0.0, 0.0))

    result = simulate_program(program, bridge, environment=[], token_secret=b"secret")
    assert len(result.move_durations_s) == 3
    assert result.total_cycle_time_s == pytest.approx(sum(result.move_durations_s))
