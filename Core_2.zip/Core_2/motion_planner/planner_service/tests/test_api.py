import pytest
from fastapi.testclient import TestClient

from api import app
from planner.kinematics_bridge import KinematicsBridge

VIEWER = {"X-API-Key": "test-viewer-key"}
OPERATOR = {"X-API-Key": "test-operator-key"}

bridge = KinematicsBridge()
requires_native_bridge = pytest.mark.skipif(
    not bridge.is_available(), reason="native_bridge/librobot_bridge.so not built"
)

client = TestClient(app)


def _create_program(waypoints):
    resp = client.post("/api/programs", headers=OPERATOR, json={"name": "test", "waypoints": waypoints})
    assert resp.status_code == 200, resp.text
    return resp.json()["id"]


def test_healthz():
    assert client.get("/healthz").json() == {"status": "ok"}


def test_create_program_requires_operator_key():
    resp = client.post("/api/programs", headers=VIEWER, json={"name": "x", "waypoints": [{"label": "a", "joint_q_rad": [0, 0, 0, 0, 0, 0]}]})
    assert resp.status_code == 401


def test_create_program_rejects_ambiguous_waypoint():
    resp = client.post(
        "/api/programs",
        headers=OPERATOR,
        json={
            "name": "bad",
            "waypoints": [
                {
                    "label": "a",
                    "joint_q_rad": [0, 0, 0, 0, 0, 0],
                    "cartesian_position": [0, 0, 0],
                    "cartesian_quaternion": [1, 0, 0, 0],
                }
            ],
        },
    )
    assert resp.status_code == 422


def test_create_and_fetch_program():
    program_id = _create_program([{"label": "home", "joint_q_rad": [0, 0, 0, 0, 0, 0]}])
    resp = client.get(f"/api/programs/{program_id}", headers=VIEWER)
    assert resp.status_code == 200
    assert resp.json()["waypoint_labels"] == ["home"]


def test_get_unknown_program_404s():
    resp = client.get("/api/programs/does-not-exist", headers=VIEWER)
    assert resp.status_code == 404


@requires_native_bridge
def test_simulate_clear_program_returns_token():
    program_id = _create_program(
        [
            {"label": "a", "joint_q_rad": [0, 0, 0, 0, 0, 0]},
            {"label": "b", "joint_q_rad": [0.2, -0.1, 0.1, 0, 0.1, 0]},
        ]
    )
    resp = client.post(f"/api/programs/{program_id}/simulate", headers=OPERATOR, json={})
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["passed"] is True
    assert body["deployment_token"] is not None


@requires_native_bridge
def test_deploy_without_simulating_first_is_rejected():
    program_id = _create_program([{"label": "a", "joint_q_rad": [0, 0, 0, 0, 0, 0]}])
    resp = client.post(
        f"/api/programs/{program_id}/deploy",
        headers=OPERATOR,
        json={"token": "garbage", "dashboard_url": "http://localhost:9999", "dashboard_api_key": "x"},
    )
    assert resp.status_code == 422


@requires_native_bridge
def test_deploy_rejects_token_for_a_different_program():
    id_a = _create_program([{"label": "a", "joint_q_rad": [0, 0, 0, 0, 0, 0]}])
    id_b = _create_program([{"label": "b", "joint_q_rad": [0.3, 0, 0, 0, 0, 0]}])

    sim = client.post(f"/api/programs/{id_a}/simulate", headers=OPERATOR, json={})
    token = sim.json()["deployment_token"]
    assert token is not None

    resp = client.post(
        f"/api/programs/{id_b}/deploy",
        headers=OPERATOR,
        json={"token": token, "dashboard_url": "http://localhost:9999", "dashboard_api_key": "x"},
    )
    assert resp.status_code == 422
