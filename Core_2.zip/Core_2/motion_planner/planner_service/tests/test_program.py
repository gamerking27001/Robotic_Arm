import pytest

from planner.program import CartesianTarget, JointTarget, Program


def test_add_joint_waypoint():
    p = Program(name="test")
    wp = p.add_joint_waypoint("home", tuple([0.0] * 6))
    assert len(p.waypoints) == 1
    assert isinstance(wp.target, JointTarget)
    assert wp.resolved_q_rad is None


def test_add_cartesian_waypoint():
    p = Program(name="test")
    wp = p.add_cartesian_waypoint("pick", (0.5, 0.0, 0.3), (1.0, 0.0, 0.0, 0.0))
    assert isinstance(wp.target, CartesianTarget)
    assert wp.target.position == (0.5, 0.0, 0.3)


def test_joint_target_wrong_length_raises():
    with pytest.raises(ValueError):
        JointTarget((0.0, 0.0, 0.0))


def test_program_ids_are_unique():
    a, b = Program(), Program()
    assert a.id != b.id
