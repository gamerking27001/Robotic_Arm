# motion_planner/planner_service

The Motion Planner service (FastAPI). See [`../README.md`](../README.md)
for architecture, scope, and end-to-end run instructions.

## Layout

- `api.py` — FastAPI app: auth, program CRUD, `/simulate`, `/deploy`.
- `planner/program.py` — Waypoint/Program data model.
- `planner/kinematics_bridge.py` — ctypes bridge to the native FK/IK/trajectory exports.
- `planner/collision.py` — capsule-vs-box collision checking.
- `planner/simulation.py` — orchestrates the full §7.2 workflow.
- `planner/deployment_token.py` — HMAC-signed simulation-pass token.
- `planner/deploy_client.py` — sequences a validated program to `dashboard/backend`.
- `planner/transform.py`, `planner/_paths.py` — reuse `digital_twin/sync_engine`'s
  `Transform` primitive and the repo's `tools/robot_params.py` single source
  of truth, rather than copying either (see `_paths.py`'s docstring for why).
- `tests/` — pytest suite (41 tests; run with `python3 -m pytest tests/ -q`).

## Local dev

```bash
pip install -r requirements.txt --break-system-packages
python3 -m pytest tests/ -q

export MOTION_PLANNER_ALLOW_INSECURE=1   # dev only -- see api.py's module docstring
uvicorn api:app --reload --port 8200
```

Most tests auto-skip if `dashboard/backend/native_bridge/librobot_bridge.so`
hasn't been built yet (`cd ../../dashboard/backend && ./build.sh`).
