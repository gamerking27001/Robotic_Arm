# Motion Planner (platform spec section 7)

Implements the "Motion Planner" workflow from *Industrial Robotics
Operating Platform for MSMEs*, §7: author a waypoint program, check every
waypoint is kinematically reachable, simulate the whole thing for
collisions and joint-limit violations, and only then allow deployment to a
physical robot — enforced with a signed token (§17.3), not by convention.

```
motion_planner/
  planner_service/   FastAPI service -- program CRUD, /simulate, /deploy
    planner/
      program.py            Waypoint/Program data model (§7.1)
      kinematics_bridge.py  ctypes bridge: FK, IK solve, trajectory sampling
      collision.py          capsule-vs-box collision checking (§7.5)
      simulation.py         orchestrates the §7.2 workflow end to end
      deployment_token.py   HMAC-signed simulation-pass token (§17.3)
      deploy_client.py      sequences a validated program to the dashboard
    tests/            41 tests
```

## What this is (and isn't)

Built to §7's spec:
- §7.1/§7.2: waypoint programs (joint-space or Cartesian targets), the
  Create→Waypoints→Feasibility→Collision→Trajectory→Simulate→Deploy flow.
- §7.3: IK/FK feasibility checking, via a new `robot_bridge_solve_ik`
  native export wrapping the existing, already-tested `IKSolver`.
- §7.4: trajectory optimization — the existing S-curve/synchronized-move
  time-parameterization (`motion/synchronized_move.hpp`, *extracted* from
  `MotionController::beginMove()` so it's reusable offline, not
  reimplemented — see that header's comments).
- §7.5: collision detection (robot-vs-environment) during full-cycle
  simulation, and a program only becomes deployable after passing with zero
  collisions and zero joint-limit violations.
- §17.3: the deploy endpoint only accepts a token cryptographically bound
  to the exact program content that was simulated — editing a waypoint
  after simulating invalidates the token.

Explicitly **not** built here:
- **Robot-to-robot / self-collision** — §7.5 lists "robot-to-robot,
  robot-to-environment, robot-to-fixture"; this repo has one arm, so there's
  no second robot to check against, and self-collision (arm vs. itself)
  isn't implemented either.
- **Exact continuous capsule-vs-OBB collision geometry** — `collision.py`
  samples points along each link segment rather than computing the exact
  continuous minimum distance; accurate to the sampling resolution, not
  exact in the continuous-geometry sense. See that module's docstring.
- **Circular interpolation** — §7.1 lists joint/linear/circular; only
  joint-space and linear(-via-IK) waypoint targets exist here.
- **A queued multi-move dispatch on the robot side** — the existing
  dashboard backend (`dashboard/backend/main.py`) only accepts one move at
  a time; `deploy_client.py` sequences waypoints by polling for each
  move's completion before sending the next, which is a materially
  different (and less robust under connection loss) mechanism than a real
  Local Gateway Service's queued command dispatch would be. See
  `deploy_client.py`'s docstring.
- **A waypoint-editing UI** — programs are created via the REST API
  (JSON), not a drag-and-drop 3D canvas; §7.1's "Drag-and-Drop
  Programming" paradigm isn't built.

## How the pieces connect

```
motion_planner/planner_service  --(ctypes: FK, IK, trajectory sample)-->  native_bridge (robot_bridge_solve_ik,
                                                                            robot_bridge_sample_joint_move -- new)
                                                                                |
                                                                     arm::kinematics::IKSolver,
                                                                     arm::motion::buildSynchronizedProfiles
                                                                     (extracted from MotionController, unchanged math)

motion_planner/planner_service  --(reads)-->  digital_twin/sync_engine/configs/environment_scene.json
                                               (single authored copy of the environment -- see collision.py)

motion_planner/planner_service  --(HTTP: POST /api/moves, GET /api/telemetry)-->  dashboard/backend
                                 (the actual "deploy" step -- see deploy_client.py)
```

Two new native bridge exports were added for this piece:
`robot_bridge_solve_ik` and `robot_bridge_sample_joint_move` — both
stateless, both calling into existing, already-tested C++ (`IKSolver`,
`buildSynchronizedProfiles`), not new algorithms. See
`tests/core/test_ik_and_trajectory.cpp` for the C++-level verification, and
`motion_planner/planner_service/tests/test_kinematics_bridge.py` for the
ctypes-marshalling cross-check.

## Running it end to end

```bash
# 1. Build the native bridge (shared with dashboard/backend and digital_twin)
cd robotic_arm_core/dashboard/backend && ./build.sh && cd -

# 2. Dashboard backend (the thing programs get deployed to)
cd robotic_arm_core/dashboard/backend
export DASHBOARD_ALLOW_INSECURE=1   # dev only
uvicorn main:app --port 8000

# 3. Motion Planner (separate terminal)
cd robotic_arm_core/motion_planner/planner_service
pip install -r requirements.txt --break-system-packages
export MOTION_PLANNER_ALLOW_INSECURE=1   # dev only
uvicorn api:app --port 8200
python3 -m pytest tests/ -q   # 41 tests

# 4. Create, simulate, and deploy a program
curl -X POST localhost:8200/api/programs -H 'Content-Type: application/json' -d '{
  "name": "demo",
  "waypoints": [
    {"label": "home", "joint_q_rad": [0,0,0,0,0,0]},
    {"label": "reach", "joint_q_rad": [0.3,-0.15,0.1,0.0,0.1,0.0]}
  ]
}'
# -> {"id": "<program_id>", ...}

curl -X POST localhost:8200/api/programs/<program_id>/simulate -H 'Content-Type: application/json' -d '{}'
# -> {"passed": true, "deployment_token": "<token>", ...}

curl -X POST localhost:8200/api/programs/<program_id>/deploy -H 'Content-Type: application/json' -d '{
  "token": "<token>", "dashboard_url": "http://localhost:8000", "dashboard_api_key": "unused"
}'
```

## What's actually verified

- C++: `tests/core/test_ik_and_trajectory.cpp` passes — FK→IK→FK round
  trip across multiple configurations (including near-singular ones),
  unreachable-target rejection, synchronized-move endpoint/duration
  correctness, and the zero-displacement-joint degenerate case.
- `motion_controller.cpp`'s refactor to call the extracted
  `buildSynchronizedProfiles()` is confirmed **byte-identical** to
  `arm_demo`'s pre-refactor output.
- Python: **41/41** tests pass — IK/trajectory ctypes bridge (cross-checked
  against known FK values), collision geometry (point-to-OBB, capsule
  clearance, rotation-aware, forced-overlap detection), the deployment
  token (round-trip, tamper detection — including a real bug this test
  suite caught and fixed: the original `.`-separated token format collided
  with the `.` in `%.6f`-formatted timestamps), the full simulation
  workflow (clear/blocked/infeasible/over-limit programs), and the FastAPI
  service end to end.
- **Live, real end-to-end run** (not just unit tests): started the actual
  dashboard backend and Motion Planner as separate processes, created a
  program over HTTP, simulated it, deployed it, and confirmed via the
  dashboard's own telemetry that the simulated arm moved to exactly the
  commanded angles (17.19°, -8.59°, 5.73°, 0.0°, 5.73°, 0.0° — matching
  0.3/-0.15/0.1/0.0/0.1/0.0 rad exactly).
- The sample `environment_scene.json` was corrected using this
  collision checker after it caught a real overlap between the robot's own
  home pose and the originally-authored floor/conveyor placement — see that
  file's `note` field.
