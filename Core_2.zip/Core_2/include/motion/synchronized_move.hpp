// motion/synchronized_move.hpp
// The synchronized multi-axis time-scaling algorithm, extracted out of
// MotionController::beginMove() so it can be reused somewhere that isn't
// wired to a live hal::JointInterface array — specifically, the offline
// Motion Planner / trajectory-optimization service (platform spec §7.4:
// "the trajectory optimizer applies time-parameterization ... to minimize
// cycle time within the robot's joint velocity/acceleration/torque
// limits"), which needs to sample a planned move's trajectory without any
// hardware attached at all.
//
// This is a refactor, not new behavior: MotionController::beginMove() now
// calls buildSynchronizedProfiles() instead of containing this logic
// inline — same two-pass algorithm, same numbers, verified by arm_demo's
// unchanged output (see tests/core/test_quaternion.cpp's sibling
// regression check in digital_twin/README.md's verification log, and
// motion_controller.cpp's own comments for why the algorithm looks the way
// it does).
#pragma once

#include <array>
#include <memory>

#include "core/robot_config.hpp"
#include "kinematics/dh_kinematics.hpp"
#include "motion/trajectory_profile.hpp"

namespace arm::motion {

using JointAngles = kinematics::JointAngles;

struct SynchronizedMove {
    std::array<std::unique_ptr<TrajectoryProfile>, config::kNumJoints> profiles;
    double duration_s = 0.0;
};

// Builds one TrajectoryProfile per joint such that all six arrive together
// (longest-joint-time governs the move; every other joint's velocity/accel/
// jerk limits are scaled down by the time-scaling ratio so its profile
// shape is preserved but stretched to match). Per-joint base limits are
// derived from config::kJointSpecs exactly as motion_controller.cpp always
// has (see that file's comments for why a_max/j_max are derived rather than
// sourced from the spec doc, which doesn't state them).
SynchronizedMove buildSynchronizedProfiles(const JointAngles& start, const JointAngles& target, bool use_s_curve);

}  // namespace arm::motion
