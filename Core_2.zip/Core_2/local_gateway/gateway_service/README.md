# local_gateway/gateway_service

The Local Gateway Service (FastAPI + real OPC UA/Modbus/MQTT). See
[`../README.md`](../README.md) for architecture, scope, and end-to-end run
instructions.

## Layout

- `gateway/adapters.py` -- `RobotAdapter` interface, OPC UA and Modbus implementations.
- `gateway/health_score.py` -- section 4.2's composite health score.
- `gateway/local_buffer.py` -- SQLite edge buffer (section 1.6).
- `gateway/mqtt_publisher.py` -- batched MQTT publish (section 1.5).
- `gateway/service.py` -- orchestrates polling, buffering, scoring, WS push, MQTT sync.
- `gateway/_paths.py` -- imports `../../controller_sim/modbus_codec.py` (shared register-map constants; see that file's docstring).
- `api.py` -- FastAPI app.
- `tests/` -- 48 tests; most require the native bridge built (`cd ../../dashboard/backend && ./build.sh`) and auto-skip otherwise.

## Local dev

```bash
pip install -r requirements.txt --break-system-packages
python3 -m pytest tests/ -q

export LOCAL_GATEWAY_ALLOW_INSECURE=1   # dev only -- see api.py's module docstring
export LOCAL_GATEWAY_PROTOCOL=opcua
export LOCAL_GATEWAY_OPCUA_ENDPOINT=opc.tcp://localhost:4840/robot/
uvicorn api:app --reload --port 8400
```

Needs a controller_sim server running first (`../controller_sim/opcua_server.py`
or `modbus_server.py`) -- the gateway is a client to that, not a
self-contained simulator.
