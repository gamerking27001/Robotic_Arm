"""gateway/_paths.py

Adds local_gateway/controller_sim to sys.path so ModbusRobotAdapter can
import `modbus_codec` -- the fixed-point encode/decode + register-map
constants shared between controller_sim/modbus_server.py (the server side)
and this adapter (the client side). One shared codec module, not two
copies that could silently drift apart on the register layout -- same
"single source of truth" reasoning as every other `_paths.py` in this repo
(digital_twin's, motion_planner's).

Does not import anything from controller_sim beyond modbus_codec (no
SimulatedRobotController, no server classes) -- the gateway talks to a
controller over the network, it doesn't embed one.
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
CONTROLLER_SIM_DIR = os.path.join(REPO_ROOT, "local_gateway", "controller_sim")

if CONTROLLER_SIM_DIR not in sys.path:
    sys.path.insert(0, CONTROLLER_SIM_DIR)
