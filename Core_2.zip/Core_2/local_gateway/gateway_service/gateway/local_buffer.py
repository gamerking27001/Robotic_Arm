"""gateway/local_buffer.py

Section 1.6: "A local time-series store (see Section 2.8) buffers
telemetry at the edge for offline resilience; the cloud platform uses a
managed time-series database for fleet-wide historical analytics."

Section 2.8's own database-technology table picks SQLite specifically for
"local desktop app configuration/state storage" -- reused here for the
same reason it's a reasonable choice there: zero-configuration, embedded,
and the write pattern (append-only samples, occasional batched reads) is
exactly what an edge buffer needs, not a client/server database.

The point of this module is that `write_sample()` never depends on
whether the cloud is reachable -- it's a local file write. Cloud sync
(service.py's sync loop) reads whatever is pending and marks rows synced
only after a confirmed successful forward; if the network is down, or the
Cloud API is down, samples simply accumulate here instead of being lost,
and get forwarded once connectivity returns. That's "offline resilience"
demonstrated, not just asserted -- see
tests/test_local_buffer.py::test_buffer_survives_and_forwards_after_simulated_outage.
"""
from __future__ import annotations

import sqlite3
import time
from dataclasses import dataclass
from typing import Iterable, Sequence


@dataclass(frozen=True)
class BufferedSample:
    row_id: int
    robot_id: str
    recorded_at: float  # time.time() (wall clock -- this is what gets forwarded to the cloud, which needs real timestamps, not time.monotonic())
    metric_name: str
    value: float


class LocalTelemetryBuffer:
    def __init__(self, db_path: str) -> None:
        self.db_path = db_path
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS telemetry_buffer (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                robot_id TEXT NOT NULL,
                recorded_at REAL NOT NULL,
                metric_name TEXT NOT NULL,
                value REAL NOT NULL,
                synced INTEGER NOT NULL DEFAULT 0
            )
            """
        )
        self._conn.execute("CREATE INDEX IF NOT EXISTS ix_buffer_synced ON telemetry_buffer(synced)")
        self._conn.commit()

    def write_batch(self, robot_id: str, samples: Sequence[tuple[str, float]], recorded_at: float | None = None) -> int:
        """samples: sequence of (metric_name, value). Returns the number of
        rows written."""
        ts = recorded_at if recorded_at is not None else time.time()
        rows = [(robot_id, ts, metric_name, value) for metric_name, value in samples]
        with self._conn:
            self._conn.executemany(
                "INSERT INTO telemetry_buffer (robot_id, recorded_at, metric_name, value) VALUES (?, ?, ?, ?)", rows
            )
        return len(rows)

    def pending_samples(self, limit: int = 500) -> list[BufferedSample]:
        cur = self._conn.execute(
            "SELECT id, robot_id, recorded_at, metric_name, value FROM telemetry_buffer WHERE synced = 0 ORDER BY id LIMIT ?",
            (limit,),
        )
        return [BufferedSample(row_id=r[0], robot_id=r[1], recorded_at=r[2], metric_name=r[3], value=r[4]) for r in cur.fetchall()]

    def mark_synced(self, row_ids: Iterable[int]) -> None:
        ids = list(row_ids)
        if not ids:
            return
        placeholders = ",".join("?" for _ in ids)
        with self._conn:
            self._conn.execute(f"UPDATE telemetry_buffer SET synced = 1 WHERE id IN ({placeholders})", ids)

    def pending_count(self) -> int:
        cur = self._conn.execute("SELECT COUNT(*) FROM telemetry_buffer WHERE synced = 0")
        return cur.fetchone()[0]

    def total_count(self) -> int:
        cur = self._conn.execute("SELECT COUNT(*) FROM telemetry_buffer")
        return cur.fetchone()[0]

    def prune_synced(self, older_than_s: float) -> int:
        """Deletes already-synced rows older than `older_than_s` seconds --
        keeps the buffer bounded over a long-running deployment instead of
        growing forever (section 13.2's cost-profile discussion assumes
        "bounded retention windows"). Never deletes unsynced rows,
        regardless of age -- offline resilience means the buffer keeps
        growing while disconnected, not that it silently drops old data
        because the outage lasted a while."""
        cutoff = time.time() - older_than_s
        with self._conn:
            cur = self._conn.execute("DELETE FROM telemetry_buffer WHERE synced = 1 AND recorded_at < ?", (cutoff,))
        return cur.rowcount

    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> "LocalTelemetryBuffer":
        return self

    def __exit__(self, *exc) -> None:
        self.close()
