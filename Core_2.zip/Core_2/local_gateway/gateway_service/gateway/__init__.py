"""Local Gateway Service -- platform spec sections 1-4. See ../README.md."""
from . import _paths  # noqa: F401 -- sys.path side effect, must run before modbus_codec is imported anywhere in this package
