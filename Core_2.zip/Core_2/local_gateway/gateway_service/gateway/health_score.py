"""gateway/health_score.py

Section 4.2: "A single 0-100 health score is computed per robot from a
weighted combination of temperature margin, torque/current deviation from
expected profile, encoder error rate, and connectivity stability -- giving
a non-expert operator a single number to watch, with drill-down into the
underlying signal for a maintenance technician."

Classified per section 8.1's own AI/non-AI taxonomy: this is "Classical
robotics algorithms" / "Rule-based automation" (deterministic, no learned
parameters, no training data) -- explicitly *not* one of section 8's AI
services (Predictive Maintenance, section 8.3, is the learned-model
version of "is this robot healthy", and is out of scope here; see
gateway/README.md's scope note). This module is section 4.2's simpler,
literal reading: a rule-based composite, not a model.

Two of section 4.2's four named signals are approximated here, honestly:
- "torque/current deviation from expected profile" needs a *learned or
  characterized* expected profile (bench data, or section 8.3's model) --
  neither exists in this codebase, so current deviation is approximated
  against a single static nominal-current constant per joint (see
  NOMINAL_CURRENT_A below) rather than a real per-motion-phase profile.
- "encoder error rate" needs actual encoder fault-rate telemetry, which
  isn't part of JointTelemetryC (see robot_bridge.h) -- approximated here
  using the joint's `fault` flag as a coarse proxy (0% implied error rate
  when clear, 100% when set).

Both approximations are documented in-line below, at the exact score
component they affect, not just in this module docstring.
"""
from __future__ import annotations

from dataclasses import dataclass

from .adapters import NormalizedTelemetry

# Approximated "expected profile" (see module docstring) -- a static
# nominal current draw, not a learned/characterized one. This simulated arm
# reports current_a == 0 in a fault-free hold (see
# hal/simulated_joint_driver.cpp -- current isn't modeled beyond a
# placeholder), so in practice this constant rarely triggers a deviation
# penalty against the simulator; it's here so the scoring logic is real and
# testable (see tests/test_health_score.py), not because this simulator
# currently produces current readings worth deviating from.
NOMINAL_CURRENT_A = 2.0
CURRENT_DEVIATION_FULL_PENALTY_A = 10.0  # deviation at/above this maps to a 0 current-component score

TEMPERATURE_MARGIN_FULL_PENALTY_C = 15.0  # margin at/below this (i.e. within 15C of ambient max) maps to a 0 temperature-component score

DEFAULT_WEIGHTS = {
    "temperature_margin": 0.30,
    "current_deviation": 0.25,
    "encoder_error_proxy": 0.20,
    "connectivity": 0.25,
}


@dataclass(frozen=True)
class HealthScoreBreakdown:
    """Section 8.17's "Explainable AI" principle applied to a non-AI
    component too: every component score is reported alongside the
    overall number, not just the overall number, precisely so "why did the
    score drop" has an answer without needing this to be a learned model
    with attribution machinery."""

    overall: float  # 0-100
    temperature_margin_score: float
    current_deviation_score: float
    encoder_error_proxy_score: float
    connectivity_score: float
    worst_joint_index: int  # which joint contributed the lowest temperature/current component


def _clamp01_to_100(x: float) -> float:
    return max(0.0, min(100.0, x))


def compute_health_score(
    telemetry: NormalizedTelemetry,
    ambient_temp_max_c: float,
    connectivity_ok_ratio: float,
    weights: dict[str, float] | None = None,
) -> HealthScoreBreakdown:
    """connectivity_ok_ratio: fraction (0-1) of the gateway's recent poll
    attempts against this robot that succeeded -- see service.py's
    ConnectivityTracker. Not part of NormalizedTelemetry itself (it's a
    property of the gateway's connection to the robot, not something the
    robot reports about itself)."""
    w = weights or DEFAULT_WEIGHTS

    worst_temp_score = 100.0
    worst_current_score = 100.0
    worst_encoder_score = 100.0
    worst_joint_index = 0
    worst_combined = 100.0

    for j in telemetry.joints:
        margin_c = ambient_temp_max_c - j.temperature_c
        temp_score = _clamp01_to_100(100.0 * margin_c / TEMPERATURE_MARGIN_FULL_PENALTY_C) if margin_c < TEMPERATURE_MARGIN_FULL_PENALTY_C else 100.0

        current_deviation = abs(j.current_a - NOMINAL_CURRENT_A)
        current_score = _clamp01_to_100(100.0 * (1.0 - current_deviation / CURRENT_DEVIATION_FULL_PENALTY_A))

        encoder_score = 0.0 if j.fault else 100.0

        combined = min(temp_score, current_score, encoder_score)
        if combined < worst_combined:
            worst_combined = combined
            worst_joint_index = j.joint_index
            worst_temp_score = temp_score
            worst_current_score = current_score
            worst_encoder_score = encoder_score

    connectivity_score = _clamp01_to_100(connectivity_ok_ratio * 100.0)

    overall = (
        w["temperature_margin"] * worst_temp_score
        + w["current_deviation"] * worst_current_score
        + w["encoder_error_proxy"] * worst_encoder_score
        + w["connectivity"] * connectivity_score
    )

    # An E-stop or any_fault at the safety-FSM level overrides the
    # per-joint composite entirely -- a robot that's e-stopped is not "85%
    # healthy", it's stopped, and the score should say so unambiguously
    # rather than average it away.
    if telemetry.estop_pressed or telemetry.any_fault:
        overall = min(overall, 20.0)

    return HealthScoreBreakdown(
        overall=_clamp01_to_100(overall),
        temperature_margin_score=worst_temp_score,
        current_deviation_score=worst_current_score,
        encoder_error_proxy_score=worst_encoder_score,
        connectivity_score=connectivity_score,
        worst_joint_index=worst_joint_index,
    )
