"""gateway/service.py

Section 4.3's monitoring data-flow diagram, implemented end to end:

    RobotSensors/Controller -> GatewayTelemetryReader -> NormalizeToCommonSchema
        -> LocalTimeSeriesBuffer -> LivePushToUI (WebSocket)
                                  -> BatchedCloudSync (MQTT) -> CloudTimescaleDB
                                  -> HealthScore/AnomalyModel -> AlertEngine -> Dashboard+MobileAlert

This module is "GatewayTelemetryReader" through "HealthScore" in that
diagram: it polls a `RobotAdapter` (adapters.py) at a fixed rate, writes
every sample to the local buffer (local_buffer.py, unconditionally --
that's the "offline resilience" part), computes a health score
(health_score.py) from each reading, and publishes the result two ways --
immediately to any live WebSocket subscriber (api.py's /ws/telemetry), and
periodically as a batch over MQTT (mqtt_publisher.py) once enough samples
have accumulated. "AlertEngine"/"Dashboard+MobileAlert" are downstream of
this (cloud_platform's alerts.py, section 4's dashboard) -- not
re-implemented here.
"""
from __future__ import annotations

import asyncio
import logging
import time
from collections import deque
from dataclasses import dataclass
from typing import Deque, Optional

from .adapters import AdapterConnectionError, NormalizedTelemetry, RobotAdapter
from .health_score import HealthScoreBreakdown, compute_health_score
from .local_buffer import LocalTelemetryBuffer

logger = logging.getLogger("local_gateway.service")

DEFAULT_POLL_HZ = 20.0
DEFAULT_MQTT_BATCH_INTERVAL_S = 5.0
DEFAULT_CONNECTIVITY_WINDOW = 20


class ConnectivityTracker:
    """Rolling window of recent poll-attempt outcomes -- feeds
    health_score.py's connectivity component (section 4.2 lists
    "connectivity stability" as one of the four inputs to the composite
    score)."""

    def __init__(self, window: int = DEFAULT_CONNECTIVITY_WINDOW) -> None:
        self._results: Deque[bool] = deque(maxlen=window)

    def record(self, ok: bool) -> None:
        self._results.append(ok)

    def ok_ratio(self) -> float:
        if not self._results:
            return 0.0  # no data yet -- treated as "unknown/unconfirmed", not optimistically 100%
        return sum(1 for r in self._results if r) / len(self._results)


@dataclass(frozen=True)
class TelemetrySnapshot:
    robot_id: str
    read_at: float
    telemetry: NormalizedTelemetry
    health: HealthScoreBreakdown
    connectivity_ok_ratio: float


def _flatten_for_buffer(telemetry: NormalizedTelemetry) -> list[tuple[str, float]]:
    """One (metric_name, value) pair per signal -- matches
    cloud_platform's Telemetry table shape (metric_name/value rows, not
    one wide row) exactly, per that module's own docstring reasoning."""
    samples: list[tuple[str, float]] = []
    for j in telemetry.joints:
        prefix = f"j{j.joint_index + 1}"
        samples.append((f"{prefix}_position_deg", j.position_deg))
        samples.append((f"{prefix}_velocity_deg_s", j.velocity_deg_s))
        samples.append((f"{prefix}_current_a", j.current_a))
        samples.append((f"{prefix}_temperature_c", j.temperature_c))
        samples.append((f"{prefix}_fault", 1.0 if j.fault else 0.0))
    samples.append(("safety_any_fault", 1.0 if telemetry.any_fault else 0.0))
    samples.append(("safety_estop_pressed", 1.0 if telemetry.estop_pressed else 0.0))
    return samples


class GatewayService:
    def __init__(
        self,
        robot_id: str,
        adapter: RobotAdapter,
        buffer: LocalTelemetryBuffer,
        mqtt_publisher=None,  # gateway.mqtt_publisher.MqttTelemetryPublisher, optional (typed loosely to avoid a hard paho-mqtt import here)
        poll_hz: float = DEFAULT_POLL_HZ,
        mqtt_batch_interval_s: float = DEFAULT_MQTT_BATCH_INTERVAL_S,
        ambient_temp_max_c: float = 45.0,
    ) -> None:
        self.robot_id = robot_id
        self.adapter = adapter
        self.buffer = buffer
        self.mqtt_publisher = mqtt_publisher
        self.poll_hz = poll_hz
        self.mqtt_batch_interval_s = mqtt_batch_interval_s
        self.ambient_temp_max_c = ambient_temp_max_c

        self.connectivity = ConnectivityTracker()
        self._latest: Optional[TelemetrySnapshot] = None
        self._subscribers: set[asyncio.Queue] = set()
        self._tasks: list[asyncio.Task] = []
        self._connected = False

    async def start(self) -> None:
        await self.adapter.connect()
        self._connected = True
        self._tasks = [
            asyncio.create_task(self._poll_loop(), name="gateway-poll"),
            asyncio.create_task(self._mqtt_sync_loop(), name="gateway-mqtt-sync"),
        ]

    async def stop(self) -> None:
        for t in self._tasks:
            t.cancel()
        for t in self._tasks:
            try:
                await t
            except asyncio.CancelledError:
                pass
        self._tasks = []
        if self._connected:
            await self.adapter.disconnect()
            self._connected = False
        if self.mqtt_publisher is not None:
            self.mqtt_publisher.close()

    async def _poll_loop(self) -> None:
        period = 1.0 / self.poll_hz
        while True:
            tick_start = time.monotonic()
            try:
                telemetry = await self.adapter.read_telemetry()
                self.connectivity.record(True)
                self.buffer.write_batch(self.robot_id, _flatten_for_buffer(telemetry))
                health = compute_health_score(telemetry, self.ambient_temp_max_c, self.connectivity.ok_ratio())
                snapshot = TelemetrySnapshot(
                    robot_id=self.robot_id, read_at=time.time(), telemetry=telemetry, health=health,
                    connectivity_ok_ratio=self.connectivity.ok_ratio(),
                )
                self._latest = snapshot
                self._publish_ws(snapshot)
            except AdapterConnectionError as exc:
                self.connectivity.record(False)
                logger.warning("Telemetry read failed (robot=%s): %s", self.robot_id, exc)
            elapsed = time.monotonic() - tick_start
            await asyncio.sleep(max(0.0, period - elapsed))

    async def _mqtt_sync_loop(self) -> None:
        while True:
            await asyncio.sleep(self.mqtt_batch_interval_s)
            if self.mqtt_publisher is None:
                continue
            pending = self.buffer.pending_samples(limit=1000)
            if not pending:
                continue
            # Publish is synchronous (paho-mqtt's own background thread
            # handles the actual network I/O) -- run it off the event loop
            # so a slow/blocked broker connection can't stall telemetry
            # polling.
            ok = await asyncio.get_event_loop().run_in_executor(
                None, self.mqtt_publisher.publish_batch, self.robot_id, pending
            )
            if ok:
                self.buffer.mark_synced([s.row_id for s in pending])
                logger.debug("Synced %d buffered samples to MQTT for robot=%s", len(pending), self.robot_id)
            else:
                logger.warning("MQTT publish failed for robot=%s -- %d samples remain buffered", self.robot_id, len(pending))

    def _publish_ws(self, snapshot: TelemetrySnapshot) -> None:
        dead = []
        for q in self._subscribers:
            try:
                q.put_nowait(snapshot)
            except asyncio.QueueFull:
                try:
                    q.get_nowait()
                    q.put_nowait(snapshot)
                except (asyncio.QueueEmpty, asyncio.QueueFull):
                    dead.append(q)
        for q in dead:
            self._subscribers.discard(q)

    def subscribe(self) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=4)
        self._subscribers.add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        self._subscribers.discard(q)

    def latest_snapshot(self) -> Optional[TelemetrySnapshot]:
        return self._latest

    async def send_move_command(self, target_deg: list[float], use_s_curve: bool) -> bool:
        return await self.adapter.send_move_command(target_deg, use_s_curve)
