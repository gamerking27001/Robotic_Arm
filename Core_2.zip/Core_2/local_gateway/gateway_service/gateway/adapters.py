"""gateway/adapters.py

Section 1.4: "Robot communication is deliberately protocol-standard rather
than brand-proprietary: OPC UA and Modbus TCP for PLC/controller-level data
exchange ... and a vendor-adapter pattern (see Section 2.7) so brand-
specific SDKs are isolated behind a common internal interface."

`RobotAdapter` is that common internal interface. `OpcUaRobotAdapter` and
`ModbusRobotAdapter` are the two concrete adapters, each talking to one of
`local_gateway/controller_sim`'s two servers -- standing in for "two
different vendor controllers" (see that package's README). Anything above
this layer (health scoring, buffering, MQTT/WS publishing -- see
service.py) works against `NormalizedTelemetry` only and never needs to
know which protocol a given robot actually speaks.
"""
from __future__ import annotations

import abc
import time
from dataclasses import dataclass, field
from typing import Optional, Sequence


@dataclass(frozen=True)
class NormalizedJointTelemetry:
    joint_index: int
    position_deg: float
    velocity_deg_s: float
    current_a: float
    temperature_c: float
    fault: bool


@dataclass(frozen=True)
class NormalizedTelemetry:
    """The one shape every adapter produces, regardless of source
    protocol -- section 4.3's "Normalize to Common Schema" step in the
    monitoring data-flow diagram."""

    read_at: float  # time.monotonic() when this reading was taken
    joints: tuple[NormalizedJointTelemetry, ...]
    safety_state: str
    any_fault: bool
    estop_pressed: bool = False


class AdapterConnectionError(RuntimeError):
    pass


class AdapterCommandRejected(RuntimeError):
    pass


class RobotAdapter(abc.ABC):
    @abc.abstractmethod
    async def connect(self) -> None: ...

    @abc.abstractmethod
    async def disconnect(self) -> None: ...

    @abc.abstractmethod
    async def read_telemetry(self) -> NormalizedTelemetry: ...

    @abc.abstractmethod
    async def send_move_command(self, target_deg: Sequence[float], use_s_curve: bool) -> bool:
        """Returns True if the robot/controller accepted the move."""
        ...


class OpcUaRobotAdapter(RobotAdapter):
    def __init__(self, endpoint: str) -> None:
        self.endpoint = endpoint
        self._client = None
        self._idx: Optional[int] = None
        self._robot_node = None
        self._joint_nodes: list[dict] = []
        self._safety_state_node = None
        self._any_fault_node = None
        self._move_method = None

    async def connect(self) -> None:
        from asyncua import Client

        self._client = Client(url=self.endpoint)
        try:
            await self._client.connect()
        except Exception as exc:  # noqa: BLE001 -- any connection failure is uniformly "can't reach this robot"
            raise AdapterConnectionError(f"could not connect to OPC UA endpoint {self.endpoint}: {exc}") from exc

        self._idx = await self._client.get_namespace_index("http://robotic-arm-core/opcua/")
        self._robot_node = await self._client.nodes.objects.get_child([f"{self._idx}:Robot"])
        self._joint_nodes = []
        for i in range(6):
            joint = await self._robot_node.get_child([f"{self._idx}:J{i + 1}"])
            self._joint_nodes.append(
                {
                    "position": await joint.get_child([f"{self._idx}:PositionDeg"]),
                    "velocity": await joint.get_child([f"{self._idx}:VelocityDegS"]),
                    "current": await joint.get_child([f"{self._idx}:CurrentA"]),
                    "temperature": await joint.get_child([f"{self._idx}:TemperatureC"]),
                    "fault": await joint.get_child([f"{self._idx}:Fault"]),
                }
            )
        self._safety_state_node = await self._robot_node.get_child([f"{self._idx}:SafetyState"])
        self._any_fault_node = await self._robot_node.get_child([f"{self._idx}:AnyFault"])
        self._move_method = await self._robot_node.get_child([f"{self._idx}:MoveJoints"])

    async def disconnect(self) -> None:
        if self._client is not None:
            await self._client.disconnect()
            self._client = None

    async def read_telemetry(self) -> NormalizedTelemetry:
        if self._client is None:
            raise AdapterConnectionError("not connected -- call connect() first")
        try:
            joints = []
            for i, nodes in enumerate(self._joint_nodes):
                joints.append(
                    NormalizedJointTelemetry(
                        joint_index=i,
                        position_deg=await nodes["position"].get_value(),
                        velocity_deg_s=await nodes["velocity"].get_value(),
                        current_a=await nodes["current"].get_value(),
                        temperature_c=await nodes["temperature"].get_value(),
                        fault=await nodes["fault"].get_value(),
                    )
                )
            safety_state = await self._safety_state_node.get_value()
            any_fault = await self._any_fault_node.get_value()
        except Exception as exc:  # noqa: BLE001
            raise AdapterConnectionError(f"OPC UA read failed: {exc}") from exc
        return NormalizedTelemetry(read_at=time.monotonic(), joints=tuple(joints), safety_state=safety_state, any_fault=any_fault)

    async def send_move_command(self, target_deg: Sequence[float], use_s_curve: bool) -> bool:
        if self._client is None:
            raise AdapterConnectionError("not connected -- call connect() first")
        if len(target_deg) != 6:
            raise ValueError("target_deg must have 6 elements")
        try:
            result = await self._robot_node.call_method(self._move_method, *[float(v) for v in target_deg], bool(use_s_curve))
        except Exception as exc:  # noqa: BLE001
            raise AdapterConnectionError(f"OPC UA MoveJoints call failed: {exc}") from exc
        return bool(result)


class ModbusRobotAdapter(RobotAdapter):
    def __init__(self, host: str, port: int, poll_timeout_s: float = 2.0) -> None:
        self.host = host
        self.port = port
        self.poll_timeout_s = poll_timeout_s
        self._client = None

    async def connect(self) -> None:
        from pymodbus.client import AsyncModbusTcpClient

        self._client = AsyncModbusTcpClient(self.host, port=self.port)
        connected = await self._client.connect()
        if not connected:
            raise AdapterConnectionError(f"could not connect to Modbus endpoint {self.host}:{self.port}")

    async def disconnect(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None

    async def read_telemetry(self) -> NormalizedTelemetry:
        from modbus_codec import (
            REG_FAULT_BITMASK,
            REG_JOINT_BASE,
            REG_SAFETY_STATE,
            SAFETY_STATE_NAMES,
            decode_centi,
        )

        if self._client is None:
            raise AdapterConnectionError("not connected -- call connect() first")
        try:
            resp = await self._client.read_input_registers(REG_JOINT_BASE, count=26)
        except Exception as exc:  # noqa: BLE001
            raise AdapterConnectionError(f"Modbus read failed: {exc}") from exc
        if resp.isError():
            raise AdapterConnectionError(f"Modbus read returned an error response: {resp}")

        regs = resp.registers
        joints = []
        for i in range(6):
            base = i * 4
            joints.append(
                NormalizedJointTelemetry(
                    joint_index=i,
                    position_deg=decode_centi(regs[base + 0]),
                    velocity_deg_s=decode_centi(regs[base + 1]),
                    current_a=decode_centi(regs[base + 2]),
                    temperature_c=decode_centi(regs[base + 3]),
                    fault=False,  # per-joint fault isn't in the Modbus register map -- see module docstring's scope note
                )
            )
        safety_code = regs[REG_SAFETY_STATE]
        safety_state = SAFETY_STATE_NAMES.get(safety_code, f"unknown({safety_code})")
        fault_bits = regs[REG_FAULT_BITMASK]
        return NormalizedTelemetry(
            read_at=time.monotonic(),
            joints=tuple(joints),
            safety_state=safety_state,
            any_fault=bool(fault_bits & 0b01),
            estop_pressed=bool(fault_bits & 0b10),
        )

    async def send_move_command(self, target_deg: Sequence[float], use_s_curve: bool) -> bool:
        from modbus_codec import REG_CMD_LAST_ACCEPTED, REG_CMD_TARGET_BASE, encode_centi

        if self._client is None:
            raise AdapterConnectionError("not connected -- call connect() first")
        if len(target_deg) != 6:
            raise ValueError("target_deg must have 6 elements")

        regs = [encode_centi(v) for v in target_deg] + [1 if use_s_curve else 0, 1]  # ..., use_s_curve, trigger=1
        try:
            await self._client.write_registers(REG_CMD_TARGET_BASE, regs)
        except Exception as exc:  # noqa: BLE001
            raise AdapterConnectionError(f"Modbus write failed: {exc}") from exc

        # Poll for the server to consume the trigger (see modbus_server.py's
        # _command_poll_loop) and report accepted/rejected, rather than
        # assuming acceptance the instant the write succeeds -- the write
        # only proves the registers were set, not that begin_move() itself
        # returned true.
        import asyncio

        deadline = time.monotonic() + self.poll_timeout_s
        while time.monotonic() < deadline:
            resp = await self._client.read_holding_registers(REG_CMD_LAST_ACCEPTED, count=1)
            if not resp.isError() and resp.registers:
                return bool(resp.registers[0])
            await asyncio.sleep(0.05)
        raise AdapterConnectionError("timed out waiting for Modbus controller to acknowledge the move command")
