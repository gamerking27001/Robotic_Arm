"""gateway/mqtt_publisher.py

Section 1.5: "The local Gateway batches and forwards telemetry to the
cloud over MQTT (lightweight, robust on shop-floor networks with
intermittent connectivity)."

Real MQTT (a real broker -- mosquitto -- was installed and is used by the
test suite, not mocked), topic `robots/{robot_id}/telemetry`, one message
per batch (not one per sample -- "batches" per section 1.5's own wording).
service.py's sync loop decides *when* to batch (drains
local_buffer.py's pending rows periodically); this module only knows how
to publish a given batch.
"""
from __future__ import annotations

import json
import logging
from dataclasses import asdict
from typing import Sequence

import paho.mqtt.client as mqtt

from .local_buffer import BufferedSample

logger = logging.getLogger("local_gateway.mqtt_publisher")


class MqttTelemetryPublisher:
    def __init__(self, host: str, port: int = 1883, topic_prefix: str = "robots", client_id: str = "") -> None:
        self.host = host
        self.port = port
        self.topic_prefix = topic_prefix
        self._client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=client_id)
        self._connected = False

    def connect(self, timeout_s: float = 5.0) -> None:
        self._client.connect(self.host, self.port, keepalive=30)
        self._client.loop_start()
        self._connected = True

    def publish_batch(self, robot_id: str, samples: Sequence[BufferedSample]) -> bool:
        """Returns True if the publish was handed to the MQTT client
        successfully (QoS 1 -- at-least-once, matching "robust on
        shop-floor networks with intermittent connectivity"). Does not
        wait for broker acknowledgment beyond what QoS 1's queuing already
        guarantees -- paho-mqtt's background loop (loop_start()) handles
        retransmission on reconnect."""
        if not samples:
            return True
        topic = f"{self.topic_prefix}/{robot_id}/telemetry"
        payload = json.dumps(
            {
                "robot_id": robot_id,
                "samples": [
                    {"metric_name": s.metric_name, "value": s.value, "recorded_at": s.recorded_at} for s in samples
                ],
            }
        )
        result = self._client.publish(topic, payload, qos=1)
        try:
            result.wait_for_publish(timeout=5.0)
        except (ValueError, RuntimeError) as exc:
            logger.warning("MQTT publish did not confirm within timeout: %s", exc)
            return False
        return result.is_published()

    def close(self) -> None:
        if self._connected:
            self._client.loop_stop()
            self._client.disconnect()
            self._connected = False
