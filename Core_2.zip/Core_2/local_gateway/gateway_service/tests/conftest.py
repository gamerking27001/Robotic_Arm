"""tests/conftest.py -- adds controller_sim to sys.path (see
gateway/_paths.py for the same pattern) so tests can import
opcua_server.py, modbus_server.py, modbus_codec.py, and
robot_bridge_ctypes.py directly."""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_REPO_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
_CONTROLLER_SIM_DIR = os.path.join(_REPO_ROOT, "local_gateway", "controller_sim")
if _CONTROLLER_SIM_DIR not in sys.path:
    sys.path.insert(0, _CONTROLLER_SIM_DIR)

os.environ.setdefault("LOCAL_GATEWAY_VIEWER_API_KEY", "test-viewer-key")
os.environ.setdefault("LOCAL_GATEWAY_OPERATOR_API_KEY", "test-operator-key")
