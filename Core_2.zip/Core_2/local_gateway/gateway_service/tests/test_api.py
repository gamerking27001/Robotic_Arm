"""Integration tests for the FastAPI app -- a real controller_sim OPC UA
server and a real running uvicorn server (not TestClient's synchronous
thread-portal wrapper, which runs the ASGI app on its own event loop --
that mismatched badly with the controller_sim server's tasks needing to
keep running concurrently on the *same* loop as the gateway's OPC UA
client connection; this fixture keeps everything on one asyncio event loop
via pytest-asyncio, matching test_adapters.py/test_service.py's already-
working pattern, and drives real HTTP/WS requests at a real socket)."""
import asyncio
import importlib
import itertools
import os

import httpx
import pytest
import uvicorn
import websockets

from robot_bridge_ctypes import RobotBridgeUnavailable

pytestmark = pytest.mark.asyncio

try:
    from robot_bridge_ctypes import SimulatedRobotController

    SimulatedRobotController().close()
    _BRIDGE_AVAILABLE = True
except RobotBridgeUnavailable:
    _BRIDGE_AVAILABLE = False

requires_native_bridge = pytest.mark.skipif(not _BRIDGE_AVAILABLE, reason="native_bridge/librobot_bridge.so not built")

_opcua_port_counter = itertools.count(4980)
_http_port_counter = itertools.count(8480)


@pytest.fixture()
async def running_app(tmp_path):
    from opcua_server import OpcUaControllerServer

    opcua_port = next(_opcua_port_counter)
    controller = OpcUaControllerServer(endpoint=f"opc.tcp://0.0.0.0:{opcua_port}/robot/")
    await controller.start()
    await asyncio.sleep(0.3)

    os.environ["LOCAL_GATEWAY_ALLOW_INSECURE"] = "0"
    os.environ["LOCAL_GATEWAY_VIEWER_API_KEY"] = "test-viewer-key"
    os.environ["LOCAL_GATEWAY_OPERATOR_API_KEY"] = "test-operator-key"
    os.environ["LOCAL_GATEWAY_PROTOCOL"] = "opcua"
    os.environ["LOCAL_GATEWAY_OPCUA_ENDPOINT"] = f"opc.tcp://127.0.0.1:{opcua_port}/robot/"
    os.environ["LOCAL_GATEWAY_BUFFER_DB_PATH"] = str(tmp_path / "buf.sqlite3")
    os.environ.pop("LOCAL_GATEWAY_MQTT_HOST", None)

    import api as api_module

    importlib.reload(api_module)

    http_port = next(_http_port_counter)
    config = uvicorn.Config(api_module.app, host="127.0.0.1", port=http_port, log_level="warning")
    server = uvicorn.Server(config)
    server_task = asyncio.create_task(server.serve())
    while not server.started:
        await asyncio.sleep(0.05)
    await asyncio.sleep(0.5)  # let a few poll cycles happen before tests read telemetry

    yield f"http://127.0.0.1:{http_port}", f"ws://127.0.0.1:{http_port}"

    server.should_exit = True
    await server_task
    await controller.stop()


VIEWER = {"X-API-Key": "test-viewer-key"}
OPERATOR = {"X-API-Key": "test-operator-key"}


async def test_healthz_unauthenticated(running_app):
    base_url, _ = running_app
    async with httpx.AsyncClient(base_url=base_url) as client:
        resp = await client.get("/healthz")
        assert resp.json() == {"status": "ok"}


@requires_native_bridge
async def test_telemetry_requires_auth(running_app):
    base_url, _ = running_app
    async with httpx.AsyncClient(base_url=base_url) as client:
        resp = await client.get("/api/telemetry")
        assert resp.status_code == 401


@requires_native_bridge
async def test_telemetry_returns_live_data(running_app):
    base_url, _ = running_app
    async with httpx.AsyncClient(base_url=base_url) as client:
        resp = await client.get("/api/telemetry", headers=VIEWER)
        assert resp.status_code == 200
        body = resp.json()
        assert len(body["joints"]) == 6
        assert 0.0 <= body["health"]["overall"] <= 100.0


@requires_native_bridge
async def test_buffer_status_reflects_polling(running_app):
    base_url, _ = running_app
    async with httpx.AsyncClient(base_url=base_url) as client:
        resp = await client.get("/api/buffer/status", headers=VIEWER)
        assert resp.status_code == 200
        assert resp.json()["total"] > 0


@requires_native_bridge
async def test_move_requires_operator_not_just_viewer(running_app):
    base_url, _ = running_app
    async with httpx.AsyncClient(base_url=base_url) as client:
        resp = await client.post("/api/moves", json={"target_deg": [10, 0, 0, 0, 0, 0]}, headers=VIEWER)
        assert resp.status_code == 401


@requires_native_bridge
async def test_move_accepted_and_reflected_in_telemetry(running_app):
    base_url, _ = running_app
    async with httpx.AsyncClient(base_url=base_url, timeout=10.0) as client:
        resp = await client.post("/api/moves", json={"target_deg": [22.0, 0, 0, 0, 0, 0], "use_s_curve": True}, headers=OPERATOR)
        assert resp.status_code == 200
        assert resp.json()["accepted"] is True

        await asyncio.sleep(1.2)
        telemetry = (await client.get("/api/telemetry", headers=VIEWER)).json()
        assert telemetry["joints"][0]["position_deg"] == pytest.approx(22.0, abs=0.5)


@requires_native_bridge
async def test_move_wrong_length_rejected(running_app):
    base_url, _ = running_app
    async with httpx.AsyncClient(base_url=base_url) as client:
        resp = await client.post("/api/moves", json={"target_deg": [1, 2, 3]}, headers=OPERATOR)
        assert resp.status_code == 422


@requires_native_bridge
async def test_ws_telemetry_streams_snapshots(running_app):
    _, ws_url = running_app
    async with websockets.connect(f"{ws_url}/ws/telemetry?api_key=test-viewer-key") as ws:
        msg = await asyncio.wait_for(ws.recv(), timeout=3.0)
        import json

        body = json.loads(msg)
        assert "joints" in body
        assert "health" in body


@requires_native_bridge
async def test_ws_telemetry_rejects_bad_key(running_app):
    _, ws_url = running_app
    with pytest.raises(websockets.exceptions.ConnectionClosed):
        async with websockets.connect(f"{ws_url}/ws/telemetry?api_key=wrong") as ws:
            await asyncio.wait_for(ws.recv(), timeout=3.0)
