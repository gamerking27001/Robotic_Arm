import time

from gateway.local_buffer import LocalTelemetryBuffer


def test_write_and_read_pending(tmp_path):
    buf = LocalTelemetryBuffer(str(tmp_path / "buf.sqlite3"))
    buf.write_batch("robot-1", [("j1_position_deg", 12.5), ("j1_current_a", 1.2)])
    pending = buf.pending_samples()
    assert len(pending) == 2
    assert {p.metric_name for p in pending} == {"j1_position_deg", "j1_current_a"}
    buf.close()


def test_mark_synced_removes_from_pending(tmp_path):
    buf = LocalTelemetryBuffer(str(tmp_path / "buf.sqlite3"))
    buf.write_batch("robot-1", [("m1", 1.0), ("m2", 2.0)])
    pending = buf.pending_samples()
    buf.mark_synced([p.row_id for p in pending])
    assert buf.pending_count() == 0
    assert buf.total_count() == 2
    buf.close()


def test_buffer_survives_and_forwards_after_simulated_outage(tmp_path):
    """Section 1.6's "offline resilience": writes always succeed
    regardless of whether anything is consuming them; nothing is lost
    while the (simulated) network/cloud is unreachable, and everything is
    still there once sync resumes."""
    buf = LocalTelemetryBuffer(str(tmp_path / "buf.sqlite3"))

    # "Outage": write telemetry for a while with no sync happening at all.
    for i in range(5):
        buf.write_batch("robot-1", [("j1_position_deg", float(i))])
    assert buf.pending_count() == 5

    # "Connectivity restored": sync consumes everything, in order.
    pending = buf.pending_samples()
    assert [p.value for p in pending] == [0.0, 1.0, 2.0, 3.0, 4.0]
    buf.mark_synced([p.row_id for p in pending])
    assert buf.pending_count() == 0

    # Further writes after "recovery" still work normally.
    buf.write_batch("robot-1", [("j1_position_deg", 5.0)])
    assert buf.pending_count() == 1
    buf.close()


def test_pending_respects_limit(tmp_path):
    buf = LocalTelemetryBuffer(str(tmp_path / "buf.sqlite3"))
    buf.write_batch("robot-1", [(f"m{i}", float(i)) for i in range(10)])
    assert len(buf.pending_samples(limit=3)) == 3
    buf.close()


def test_prune_synced_only_removes_old_synced_rows(tmp_path):
    buf = LocalTelemetryBuffer(str(tmp_path / "buf.sqlite3"))
    old_time = time.time() - 1000.0
    buf.write_batch("robot-1", [("old_synced", 1.0)], recorded_at=old_time)
    buf.write_batch("robot-1", [("old_unsynced", 2.0)], recorded_at=old_time)
    buf.write_batch("robot-1", [("recent_synced", 3.0)])  # now

    pending = buf.pending_samples()
    to_sync = [p.row_id for p in pending if p.metric_name in ("old_synced", "recent_synced")]
    buf.mark_synced(to_sync)

    deleted = buf.prune_synced(older_than_s=500.0)
    assert deleted == 1  # only "old_synced" is both old AND synced
    assert buf.total_count() == 2  # old_unsynced (never synced) + recent_synced (synced but not old) remain
    buf.close()


def test_multiple_robots_are_independent(tmp_path):
    buf = LocalTelemetryBuffer(str(tmp_path / "buf.sqlite3"))
    buf.write_batch("robot-a", [("m", 1.0)])
    buf.write_batch("robot-b", [("m", 2.0)])
    pending = buf.pending_samples()
    robot_ids = {p.robot_id for p in pending}
    assert robot_ids == {"robot-a", "robot-b"}
    buf.close()
