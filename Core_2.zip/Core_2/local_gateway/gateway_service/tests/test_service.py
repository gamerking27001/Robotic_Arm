"""Integration tests for GatewayService -- real OPC UA controller_sim
server, real adapter, real SQLite buffer (tmp_path), no MQTT (tests the
"MQTT not configured" path explicitly, matching how api.py behaves when
LOCAL_GATEWAY_MQTT_HOST isn't set -- see service.py's mqtt_publisher=None
handling)."""
import asyncio
import itertools

import pytest

from gateway.adapters import OpcUaRobotAdapter
from gateway.local_buffer import LocalTelemetryBuffer
from gateway.service import GatewayService

from opcua_server import OpcUaControllerServer
from robot_bridge_ctypes import RobotBridgeUnavailable

pytestmark = pytest.mark.asyncio

try:
    from robot_bridge_ctypes import SimulatedRobotController

    SimulatedRobotController().close()
    _BRIDGE_AVAILABLE = True
except RobotBridgeUnavailable:
    _BRIDGE_AVAILABLE = False

requires_native_bridge = pytest.mark.skipif(not _BRIDGE_AVAILABLE, reason="native_bridge/librobot_bridge.so not built")

_port_counter = itertools.count(4950)


@pytest.fixture()
async def gateway_fixture(tmp_path):
    port = next(_port_counter)
    controller_server = OpcUaControllerServer(endpoint=f"opc.tcp://0.0.0.0:{port}/robot/")
    await controller_server.start()
    await asyncio.sleep(0.3)

    buffer = LocalTelemetryBuffer(str(tmp_path / "buf.sqlite3"))
    adapter = OpcUaRobotAdapter(f"opc.tcp://127.0.0.1:{port}/robot/")
    service = GatewayService(
        robot_id="test-robot", adapter=adapter, buffer=buffer, mqtt_publisher=None, poll_hz=20.0, ambient_temp_max_c=45.0
    )
    await service.start()
    yield service
    await service.stop()
    buffer.close()
    await controller_server.stop()


@requires_native_bridge
async def test_service_polls_and_produces_a_snapshot(gateway_fixture):
    await asyncio.sleep(0.3)  # a few poll cycles at 20Hz
    snapshot = gateway_fixture.latest_snapshot()
    assert snapshot is not None
    assert snapshot.robot_id == "test-robot"
    assert len(snapshot.telemetry.joints) == 6
    assert 0.0 <= snapshot.health.overall <= 100.0


@requires_native_bridge
async def test_service_writes_to_local_buffer(gateway_fixture):
    await asyncio.sleep(0.3)
    assert gateway_fixture.buffer.total_count() > 0


@requires_native_bridge
async def test_service_move_command_reaches_the_robot(gateway_fixture):
    accepted = await gateway_fixture.send_move_command([18.0, 0.0, 0.0, 0.0, 0.0, 0.0], True)
    assert accepted is True
    await asyncio.sleep(1.0)
    snapshot = gateway_fixture.latest_snapshot()
    assert snapshot.telemetry.joints[0].position_deg == pytest.approx(18.0, abs=0.5)


@requires_native_bridge
async def test_service_ws_subscribers_receive_snapshots(gateway_fixture):
    queue = gateway_fixture.subscribe()
    snapshot = await asyncio.wait_for(queue.get(), timeout=2.0)
    assert snapshot.robot_id == "test-robot"
    gateway_fixture.unsubscribe(queue)


@requires_native_bridge
async def test_connectivity_ok_ratio_reflects_successful_polls(gateway_fixture):
    await asyncio.sleep(0.3)
    assert gateway_fixture.connectivity.ok_ratio() == pytest.approx(1.0)
