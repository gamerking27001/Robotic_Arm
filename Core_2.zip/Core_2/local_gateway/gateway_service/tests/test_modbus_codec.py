import pytest

from modbus_codec import decode_centi, encode_centi


@pytest.mark.parametrize("value", [0.0, 1.0, -1.0, 12.34, -12.34, 179.99, -179.99, 300.0, -300.0])
def test_round_trip(value):
    assert decode_centi(encode_centi(value)) == pytest.approx(value, abs=0.01)


def test_encode_produces_valid_16_bit_unsigned():
    for value in (-327.0, 0.0, 327.0):
        reg = encode_centi(value)
        assert 0 <= reg <= 0xFFFF


def test_out_of_range_clamps_rather_than_wraps():
    huge = encode_centi(10000.0)  # far beyond +/-327.67
    assert decode_centi(huge) == pytest.approx(327.67, abs=0.01)
    tiny = encode_centi(-10000.0)
    assert decode_centi(tiny) == pytest.approx(-327.68, abs=0.01)
