import pytest

from gateway.adapters import NormalizedJointTelemetry, NormalizedTelemetry
from gateway.health_score import (
    NOMINAL_CURRENT_A,
    compute_health_score,
)

AMBIENT_MAX_C = 45.0


def _telemetry(overrides: dict[int, dict] | None = None) -> NormalizedTelemetry:
    overrides = overrides or {}
    joints = []
    for i in range(6):
        base = {
            "joint_index": i,
            "position_deg": 0.0,
            "velocity_deg_s": 0.0,
            "current_a": NOMINAL_CURRENT_A,
            "temperature_c": 25.0,
            "fault": False,
        }
        base.update(overrides.get(i, {}))
        joints.append(NormalizedJointTelemetry(**base))
    return NormalizedTelemetry(read_at=0.0, joints=tuple(joints), safety_state="Idle", any_fault=False, estop_pressed=False)


def test_perfect_conditions_score_near_100():
    telemetry = _telemetry()
    result = compute_health_score(telemetry, AMBIENT_MAX_C, connectivity_ok_ratio=1.0)
    assert result.overall == pytest.approx(100.0, abs=0.5)


def test_high_temperature_lowers_score():
    telemetry = _telemetry({0: {"temperature_c": 40.0}})  # 5C margin to ambient max (45C)
    result = compute_health_score(telemetry, AMBIENT_MAX_C, connectivity_ok_ratio=1.0)
    assert result.temperature_margin_score < 100.0
    assert result.overall < 100.0
    assert result.worst_joint_index == 0


def test_current_deviation_lowers_score():
    telemetry = _telemetry({2: {"current_a": NOMINAL_CURRENT_A + 8.0}})
    result = compute_health_score(telemetry, AMBIENT_MAX_C, connectivity_ok_ratio=1.0)
    assert result.current_deviation_score < 100.0
    assert result.worst_joint_index == 2


def test_joint_fault_zeroes_encoder_component():
    telemetry = _telemetry({4: {"fault": True}})
    result = compute_health_score(telemetry, AMBIENT_MAX_C, connectivity_ok_ratio=1.0)
    assert result.encoder_error_proxy_score == 0.0
    assert result.worst_joint_index == 4


def test_poor_connectivity_lowers_score_even_with_healthy_robot():
    telemetry = _telemetry()
    good = compute_health_score(telemetry, AMBIENT_MAX_C, connectivity_ok_ratio=1.0)
    poor = compute_health_score(telemetry, AMBIENT_MAX_C, connectivity_ok_ratio=0.2)
    assert poor.overall < good.overall
    assert poor.connectivity_score == pytest.approx(20.0)


def test_estop_pressed_caps_score_regardless_of_joint_health():
    telemetry = NormalizedTelemetry(
        read_at=0.0,
        joints=_telemetry().joints,  # all-healthy joints
        safety_state="EStop",
        any_fault=False,
        estop_pressed=True,
    )
    result = compute_health_score(telemetry, AMBIENT_MAX_C, connectivity_ok_ratio=1.0)
    assert result.overall <= 20.0


def test_any_fault_caps_score():
    telemetry = NormalizedTelemetry(read_at=0.0, joints=_telemetry().joints, safety_state="Fault", any_fault=True, estop_pressed=False)
    result = compute_health_score(telemetry, AMBIENT_MAX_C, connectivity_ok_ratio=1.0)
    assert result.overall <= 20.0


def test_score_is_bounded_0_to_100():
    # Deliberately extreme/adversarial inputs shouldn't escape [0, 100].
    telemetry = _telemetry({i: {"temperature_c": 1000.0, "current_a": -500.0, "fault": True} for i in range(6)})
    result = compute_health_score(telemetry, AMBIENT_MAX_C, connectivity_ok_ratio=0.0)
    assert 0.0 <= result.overall <= 100.0
