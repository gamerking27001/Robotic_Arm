"""Integration tests: real OPC UA / Modbus TCP servers (controller_sim),
real adapter clients connecting over real sockets -- not mocked. Each test
uses a unique port to avoid clashing with any other test or a leftover
process from a previous run."""
import pytest

from gateway.adapters import AdapterConnectionError, ModbusRobotAdapter, OpcUaRobotAdapter

from modbus_server import ModbusControllerServer
from opcua_server import OpcUaControllerServer
from robot_bridge_ctypes import RobotBridgeUnavailable

pytestmark = pytest.mark.asyncio

try:
    from robot_bridge_ctypes import SimulatedRobotController

    SimulatedRobotController().close()
    _BRIDGE_AVAILABLE = True
except RobotBridgeUnavailable:
    _BRIDGE_AVAILABLE = False

requires_native_bridge = pytest.mark.skipif(not _BRIDGE_AVAILABLE, reason="native_bridge/librobot_bridge.so not built")


import itertools

_opcua_port_counter = itertools.count(4900)
_modbus_port_counter = itertools.count(5100)


@pytest.fixture()
async def opcua_fixture():
    # Unique port per test -- StartAsyncTcpServer/asyncua's server.stop()
    # cancels its task but doesn't guarantee the listening socket is
    # released before the next test's fixture setup runs; reusing a fixed
    # port intermittently raced "address already in use" for exactly that
    # reason (caught by test_modbus_adapter_move_command_moves_the_robot
    # failing when it happened to run right after another test on the same
    # port -- see the Modbus fixture below for the same fix).
    port = next(_opcua_port_counter)
    server = OpcUaControllerServer(endpoint=f"opc.tcp://0.0.0.0:{port}/robot/")
    await server.start()
    await asyncio_sleep(0.3)
    adapter = OpcUaRobotAdapter(f"opc.tcp://127.0.0.1:{port}/robot/")
    await adapter.connect()
    yield adapter
    await adapter.disconnect()
    await server.stop()


@pytest.fixture()
async def modbus_fixture():
    port = next(_modbus_port_counter)  # see opcua_fixture's comment above -- same reasoning
    server = ModbusControllerServer(port=port)
    await server.start()
    await asyncio_sleep(0.3)
    adapter = ModbusRobotAdapter("127.0.0.1", port)
    await adapter.connect()
    yield adapter
    await adapter.disconnect()
    await server.stop()


async def asyncio_sleep(s):
    import asyncio

    await asyncio.sleep(s)


@requires_native_bridge
async def test_opcua_adapter_reads_home_telemetry(opcua_fixture):
    telemetry = await opcua_fixture.read_telemetry()
    assert telemetry.safety_state == "Idle"
    assert telemetry.any_fault is False
    assert len(telemetry.joints) == 6
    assert telemetry.joints[0].position_deg == pytest.approx(0.0, abs=0.01)


@requires_native_bridge
async def test_opcua_adapter_move_command_moves_the_robot(opcua_fixture):
    accepted = await opcua_fixture.send_move_command([30.0, -15.0, 0.0, 0.0, 0.0, 0.0], True)
    assert accepted is True
    import asyncio

    await asyncio.sleep(1.0)
    telemetry = await opcua_fixture.read_telemetry()
    assert telemetry.joints[0].position_deg == pytest.approx(30.0, abs=0.5)
    assert telemetry.joints[1].position_deg == pytest.approx(-15.0, abs=0.5)


@requires_native_bridge
async def test_opcua_adapter_rejects_wrong_length_target(opcua_fixture):
    with pytest.raises(ValueError):
        await opcua_fixture.send_move_command([1.0, 2.0, 3.0], True)


async def test_opcua_adapter_connect_failure_raises_adapter_error():
    adapter = OpcUaRobotAdapter("opc.tcp://127.0.0.1:1/robot/")  # nothing listening on port 1
    with pytest.raises(AdapterConnectionError):
        await adapter.connect()


@requires_native_bridge
async def test_modbus_adapter_reads_home_telemetry(modbus_fixture):
    telemetry = await modbus_fixture.read_telemetry()
    assert telemetry.safety_state == "Idle"
    assert len(telemetry.joints) == 6
    assert telemetry.joints[0].position_deg == pytest.approx(0.0, abs=0.01)


@requires_native_bridge
async def test_modbus_adapter_move_command_moves_the_robot(modbus_fixture):
    accepted = await modbus_fixture.send_move_command([20.0, 10.0, 0.0, 0.0, 0.0, 0.0], True)
    assert accepted is True
    import asyncio

    await asyncio.sleep(1.0)
    telemetry = await modbus_fixture.read_telemetry()
    assert telemetry.joints[0].position_deg == pytest.approx(20.0, abs=0.5)
    assert telemetry.joints[1].position_deg == pytest.approx(10.0, abs=0.5)


@requires_native_bridge
async def test_modbus_adapter_rejects_wrong_length_target(modbus_fixture):
    with pytest.raises(ValueError):
        await modbus_fixture.send_move_command([1.0, 2.0], True)


async def test_modbus_adapter_connect_failure_raises_adapter_error():
    adapter = ModbusRobotAdapter("127.0.0.1", 1)  # nothing listening on port 1
    with pytest.raises(AdapterConnectionError):
        await adapter.connect()


@requires_native_bridge
async def test_two_adapters_control_independent_robots(opcua_fixture, modbus_fixture):
    """opcua_fixture and modbus_fixture each own a *separate*
    SimulatedRobotController (separate robot_bridge sessions) -- moving one
    must not affect the other's telemetry."""
    await opcua_fixture.send_move_command([45.0, 0.0, 0.0, 0.0, 0.0, 0.0], True)
    import asyncio

    await asyncio.sleep(1.0)

    opcua_telemetry = await opcua_fixture.read_telemetry()
    modbus_telemetry = await modbus_fixture.read_telemetry()
    assert opcua_telemetry.joints[0].position_deg == pytest.approx(45.0, abs=0.5)
    assert modbus_telemetry.joints[0].position_deg == pytest.approx(0.0, abs=0.5)  # unaffected
