"""local_gateway/gateway_service/api.py

FastAPI service for the Local Gateway (platform spec sections 1-4). See
../README.md for architecture, scope, and run instructions.

Run:
    export LOCAL_GATEWAY_VIEWER_API_KEY=...
    export LOCAL_GATEWAY_OPERATOR_API_KEY=...
    export LOCAL_GATEWAY_PROTOCOL=opcua   # or "modbus"
    export LOCAL_GATEWAY_OPCUA_ENDPOINT=opc.tcp://localhost:4840/robot/
    uvicorn api:app --port 8400
"""
from __future__ import annotations

import logging
import os
import secrets
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, Security, WebSocket, WebSocketDisconnect
from fastapi.security import APIKeyHeader
from pydantic import BaseModel

from gateway.adapters import AdapterConnectionError, ModbusRobotAdapter, OpcUaRobotAdapter, RobotAdapter
from gateway.local_buffer import LocalTelemetryBuffer
from gateway.mqtt_publisher import MqttTelemetryPublisher
from gateway.service import GatewayService, TelemetrySnapshot

logging.basicConfig(
    level=os.environ.get("LOCAL_GATEWAY_LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
logger = logging.getLogger("local_gateway.api")

_VIEWER_KEY = os.environ.get("LOCAL_GATEWAY_VIEWER_API_KEY")
_OPERATOR_KEY = os.environ.get("LOCAL_GATEWAY_OPERATOR_API_KEY")
_INSECURE = os.environ.get("LOCAL_GATEWAY_ALLOW_INSECURE") == "1"

if not _INSECURE and (not _VIEWER_KEY or not _OPERATOR_KEY):
    raise RuntimeError(
        "LOCAL_GATEWAY_VIEWER_API_KEY and LOCAL_GATEWAY_OPERATOR_API_KEY must both be set "
        "(the /api/moves endpoint commands real robot motion). For local development only, "
        "set LOCAL_GATEWAY_ALLOW_INSECURE=1 instead."
    )
if _INSECURE:
    logger.warning("LOCAL_GATEWAY_ALLOW_INSECURE=1 — authentication is DISABLED. Never set this in a real deployment.")

_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


def _check_key(provided: Optional[str], required: str) -> bool:
    return provided is not None and secrets.compare_digest(provided, required)


def require_viewer(api_key: Optional[str] = Security(_api_key_header)) -> None:
    if _INSECURE or _check_key(api_key, _OPERATOR_KEY) or _check_key(api_key, _VIEWER_KEY):
        return
    raise HTTPException(status_code=401, detail="Invalid or missing API key")


def require_operator(api_key: Optional[str] = Security(_api_key_header)) -> None:
    if _INSECURE or _check_key(api_key, _OPERATOR_KEY):
        return
    raise HTTPException(status_code=401, detail="Invalid or missing operator API key")


def _build_adapter() -> RobotAdapter:
    protocol = os.environ.get("LOCAL_GATEWAY_PROTOCOL", "opcua").lower()
    if protocol == "opcua":
        endpoint = os.environ.get("LOCAL_GATEWAY_OPCUA_ENDPOINT", "opc.tcp://localhost:4840/robot/")
        logger.info("Using OpcUaRobotAdapter: %s", endpoint)
        return OpcUaRobotAdapter(endpoint)
    if protocol == "modbus":
        host = os.environ.get("LOCAL_GATEWAY_MODBUS_HOST", "localhost")
        port = int(os.environ.get("LOCAL_GATEWAY_MODBUS_PORT", "5020"))
        logger.info("Using ModbusRobotAdapter: %s:%d", host, port)
        return ModbusRobotAdapter(host, port)
    raise RuntimeError(f"Unknown LOCAL_GATEWAY_PROTOCOL={protocol!r} (expected 'opcua' or 'modbus')")


_service: Optional[GatewayService] = None


def get_service() -> GatewayService:
    assert _service is not None, "gateway service not initialized (app not started via lifespan?)"
    return _service


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _service
    robot_id = os.environ.get("LOCAL_GATEWAY_ROBOT_ID", "robot-1")
    buffer_path = os.environ.get("LOCAL_GATEWAY_BUFFER_DB_PATH", "gateway_buffer.sqlite3")
    poll_hz = float(os.environ.get("LOCAL_GATEWAY_POLL_HZ", "20"))
    ambient_temp_max_c = float(os.environ.get("LOCAL_GATEWAY_AMBIENT_TEMP_MAX_C", "45.0"))

    mqtt_host = os.environ.get("LOCAL_GATEWAY_MQTT_HOST")
    mqtt_publisher = None
    if mqtt_host:
        mqtt_port = int(os.environ.get("LOCAL_GATEWAY_MQTT_PORT", "1883"))
        mqtt_publisher = MqttTelemetryPublisher(mqtt_host, mqtt_port, client_id=f"gateway-{robot_id}")
        mqtt_publisher.connect()
        logger.info("MQTT publishing enabled: %s:%d", mqtt_host, mqtt_port)
    else:
        logger.warning("LOCAL_GATEWAY_MQTT_HOST not set -- telemetry will buffer locally but never sync to the cloud")

    buffer = LocalTelemetryBuffer(buffer_path)
    adapter = _build_adapter()
    _service = GatewayService(
        robot_id=robot_id, adapter=adapter, buffer=buffer, mqtt_publisher=mqtt_publisher,
        poll_hz=poll_hz, ambient_temp_max_c=ambient_temp_max_c,
    )
    await _service.start()
    logger.info("Local Gateway Service started: robot_id=%s poll_hz=%.1f", robot_id, poll_hz)
    try:
        yield
    finally:
        await _service.stop()
        buffer.close()


app = FastAPI(title="Local Gateway Service", version="0.1.0", lifespan=lifespan)


class MoveRequest(BaseModel):
    target_deg: list[float]
    use_s_curve: bool = True


def _snapshot_to_dict(snapshot: TelemetrySnapshot) -> dict:
    t = snapshot.telemetry
    return {
        "robot_id": snapshot.robot_id,
        "read_at": snapshot.read_at,
        "safety_state": t.safety_state,
        "any_fault": t.any_fault,
        "estop_pressed": t.estop_pressed,
        "joints": [
            {
                "joint_index": j.joint_index,
                "position_deg": j.position_deg,
                "velocity_deg_s": j.velocity_deg_s,
                "current_a": j.current_a,
                "temperature_c": j.temperature_c,
                "fault": j.fault,
            }
            for j in t.joints
        ],
        "health": {
            "overall": snapshot.health.overall,
            "temperature_margin_score": snapshot.health.temperature_margin_score,
            "current_deviation_score": snapshot.health.current_deviation_score,
            "encoder_error_proxy_score": snapshot.health.encoder_error_proxy_score,
            "connectivity_score": snapshot.health.connectivity_score,
            "worst_joint_index": snapshot.health.worst_joint_index,
        },
        "connectivity_ok_ratio": snapshot.connectivity_ok_ratio,
    }


@app.get("/healthz")
def healthz():
    return {"status": "ok"}


@app.get("/api/telemetry")
def get_telemetry(service: GatewayService = Depends(get_service), _: None = Depends(require_viewer)):
    snapshot = service.latest_snapshot()
    if snapshot is None:
        raise HTTPException(status_code=503, detail="no telemetry read yet")
    return _snapshot_to_dict(snapshot)


@app.get("/api/buffer/status")
def get_buffer_status(service: GatewayService = Depends(get_service), _: None = Depends(require_viewer)):
    return {"pending": service.buffer.pending_count(), "total": service.buffer.total_count()}


@app.post("/api/moves")
async def post_move(req: MoveRequest, service: GatewayService = Depends(get_service), _: None = Depends(require_operator)):
    if len(req.target_deg) != 6:
        raise HTTPException(status_code=422, detail="target_deg must have exactly 6 elements")
    try:
        accepted = await service.send_move_command(req.target_deg, req.use_s_curve)
    except AdapterConnectionError as exc:
        raise HTTPException(status_code=502, detail=f"robot unreachable: {exc}") from exc
    if not accepted:
        raise HTTPException(status_code=409, detail="robot rejected the move (see current safety_state via /api/telemetry)")
    return {"accepted": True}


@app.websocket("/ws/telemetry")
async def ws_telemetry(websocket: WebSocket, service: GatewayService = Depends(get_service)):
    await websocket.accept()
    if not _INSECURE:
        provided = websocket.query_params.get("api_key")
        if not (_check_key(provided, _OPERATOR_KEY) or _check_key(provided, _VIEWER_KEY)):
            await websocket.close(code=4401)
            return
    queue = service.subscribe()
    try:
        while True:
            snapshot = await queue.get()
            await websocket.send_json(_snapshot_to_dict(snapshot))
    except WebSocketDisconnect:
        pass
    finally:
        service.unsubscribe(queue)
