"""controller_sim/modbus_server.py

Stands in for a real robot controller's Modbus TCP interface -- platform
spec section 2.4's decision table: "Modbus TCP -- Extremely widely
supported, simple ... Fallback protocol for legacy/lower-cost
controllers." Represents a *different* controller brand/generation than
opcua_server.py (section 1.4's vendor-adapter pattern is about the gateway
speaking to heterogeneous controllers, which needs at least two real,
different protocols to actually exercise -- not just one dressed up two
ways).

Runs its own independent SimulatedRobotController (its own robot_bridge
session -- a separate simulated robot from opcua_server.py's). Register
layout is documented in modbus_codec.py, shared with the client side
(local_gateway/gateway_service/gateway/adapters.py's ModbusRobotAdapter).

Run standalone:
    python3 modbus_server.py --port 5020
"""
from __future__ import annotations

import asyncio
import logging

from pymodbus.datastore import ModbusServerContext, ModbusSequentialDataBlock, ModbusSlaveContext
from pymodbus.server import StartAsyncTcpServer

from modbus_codec import (
    HOLDING_REGISTER_COUNT,
    INPUT_REGISTER_COUNT,
    REG_CMD_LAST_ACCEPTED,
    REG_CMD_TARGET_BASE,
    REG_CMD_TRIGGER,
    REG_CMD_USE_S_CURVE,
    REG_FAULT_BITMASK,
    REG_JOINT_BASE,
    REG_JOINT_STRIDE,
    REG_SAFETY_STATE,
    SAFETY_STATE_CODES,
    UNKNOWN_SAFETY_STATE_CODE,
    decode_centi,
    encode_centi,
)
from robot_bridge_ctypes import SimulatedRobotController

logger = logging.getLogger("controller_sim.modbus_server")

TICK_HZ = 200.0
TICK_DT = 1.0 / TICK_HZ
PUBLISH_HZ = 20.0
COMMAND_POLL_HZ = 20.0  # how often the sim loop checks REG_CMD_TRIGGER for a client-requested move


class ModbusControllerServer:
    def __init__(self, host: str = "0.0.0.0", port: int = 5020, library_path: str | None = None) -> None:
        self.host = host
        self.port = port
        self.controller = SimulatedRobotController(library_path)
        self._device = ModbusSlaveContext(
            ir=ModbusSequentialDataBlock(0, [0] * INPUT_REGISTER_COUNT),
            hr=ModbusSequentialDataBlock(0, [0] * HOLDING_REGISTER_COUNT),
        )
        self._context = ModbusServerContext(slaves=self._device, single=True)
        self._running = False
        self._server_task: asyncio.Task | None = None

    async def start(self) -> None:
        self._running = True
        asyncio.create_task(self._tick_loop())
        asyncio.create_task(self._publish_loop())
        asyncio.create_task(self._command_poll_loop())
        self._server_task = asyncio.create_task(
            StartAsyncTcpServer(context=self._context, address=(self.host, self.port))
        )
        await asyncio.sleep(0.1)  # let the TCP listener actually bind before returning
        logger.info("Modbus TCP controller server started at %s:%d", self.host, self.port)

    async def _tick_loop(self) -> None:
        while self._running:
            self.controller.tick(TICK_DT)
            await asyncio.sleep(TICK_DT)

    async def _publish_loop(self) -> None:
        period = 1.0 / PUBLISH_HZ
        while self._running:
            values = [0] * INPUT_REGISTER_COUNT
            for i, t in enumerate(self.controller.all_joint_telemetry()):
                base = REG_JOINT_BASE + i * REG_JOINT_STRIDE
                values[base + 0] = encode_centi(t.position_deg)
                values[base + 1] = encode_centi(t.velocity_deg_s)
                values[base + 2] = encode_centi(t.current_a)
                values[base + 3] = encode_centi(t.winding_temp_c)
            safety = self.controller.safety_status()
            values[REG_SAFETY_STATE] = SAFETY_STATE_CODES.get(safety.state, UNKNOWN_SAFETY_STATE_CODE)
            fault_bits = (1 if safety.any_fault else 0) | ((1 if safety.estop_pressed else 0) << 1)
            values[REG_FAULT_BITMASK] = fault_bits

            self._device.setValues(4, 0, values)  # function code 4 = input registers
            await asyncio.sleep(period)

    async def _command_poll_loop(self) -> None:
        """Modbus has no native "call a method" concept the way OPC UA
        does -- section 2.4 lists it as simple/widely-supported but
        without OPC UA's richer data modeling. A move command is instead a
        tiny write-then-poll protocol: client writes target registers +
        use_s_curve, then writes REG_CMD_TRIGGER=1; this loop notices the
        trigger, consumes it (begin_move + reset trigger to 0 + write the
        accepted/rejected result to REG_CMD_LAST_ACCEPTED), so the client
        can poll for the trigger to clear as its "command consumed"
        signal."""
        period = 1.0 / COMMAND_POLL_HZ
        while self._running:
            holding = self._device.getValues(3, 0, HOLDING_REGISTER_COUNT)  # function code 3 = holding registers
            if holding[REG_CMD_TRIGGER] == 1:
                target_deg = [decode_centi(holding[REG_CMD_TARGET_BASE + i]) for i in range(6)]
                use_s_curve = bool(holding[REG_CMD_USE_S_CURVE])
                accepted = self.controller.begin_move(target_deg, use_s_curve)
                self._device.setValues(3, REG_CMD_TRIGGER, [0])
                self._device.setValues(3, REG_CMD_LAST_ACCEPTED, [1 if accepted else 0])
                logger.info("Modbus move command consumed: target_deg=%s accepted=%s", target_deg, accepted)
            await asyncio.sleep(period)

    async def stop(self) -> None:
        self._running = False
        if self._server_task is not None:
            self._server_task.cancel()
        self.controller.close()


async def _main() -> None:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=5020)
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)

    server = ModbusControllerServer(port=args.port)
    await server.start()
    try:
        while True:
            await asyncio.sleep(3600)
    finally:
        await server.stop()


if __name__ == "__main__":
    asyncio.run(_main())
