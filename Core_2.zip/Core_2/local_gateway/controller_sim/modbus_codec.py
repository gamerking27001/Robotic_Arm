"""controller_sim/modbus_codec.py

Modbus registers are 16-bit; this repo's telemetry (joint angles, deg/s,
amps, degC) is floating point. Shared fixed-point encode/decode helpers so
the server (controller_sim/modbus_server.py) and the client
(local_gateway/gateway_service/gateway/adapters.py's ModbusRobotAdapter)
agree on exactly one convention, rather than each guessing at the other's
scaling factor.

Convention: value * 100, rounded, stored as a signed 16-bit two's-complement
integer in one register (i.e. "centi-units"). Range is therefore
+/-327.67 in whatever unit -- comfortably covers this arm's joint angles
(soft limits are within +/-180deg, see tools/robot_params.py), velocities,
and currents/temperatures at any value that isn't already a fault
condition. A metric that could realistically exceed that range would need
a 32-bit (2-register) encoding instead; not needed for anything read here.
"""
from __future__ import annotations

import struct

SCALE = 100.0


def encode_centi(value: float) -> int:
    """float -> unsigned 16-bit register value (signed two's complement, scale x100)."""
    scaled = round(value * SCALE)
    scaled = max(-32768, min(32767, scaled))  # clamp rather than silently wrap on overflow
    return struct.unpack(">H", struct.pack(">h", scaled))[0]


def decode_centi(register_value: int) -> float:
    """unsigned 16-bit register value -> float (inverse of encode_centi)."""
    signed = struct.unpack(">h", struct.pack(">H", register_value & 0xFFFF))[0]
    return signed / SCALE


# --- Register map (shared layout constants) ---------------------------------

REG_JOINT_STRIDE = 4  # position, velocity, current, temperature -- per joint
REG_JOINT_BASE = 0  # input registers 0..23 (6 joints * 4 fields)
REG_SAFETY_STATE = 24  # input register: SafetyStateCode (see SAFETY_STATE_CODES)
REG_FAULT_BITMASK = 25  # input register: bit0=any_fault, bit1=estop_pressed
INPUT_REGISTER_COUNT = 26

REG_CMD_TARGET_BASE = 0  # holding registers 0..5: target_centideg per joint
REG_CMD_USE_S_CURVE = 6  # holding register: 0/1
REG_CMD_TRIGGER = 7  # holding register: client writes 1 to request a move; server resets to 0 once consumed
REG_CMD_LAST_ACCEPTED = 8  # holding register: server writes 1/0 after consuming a trigger
HOLDING_REGISTER_COUNT = 9

SAFETY_STATE_CODES = {
    "PowerOn": 0, "Homing": 1, "Idle": 2, "Running": 3, "Paused": 4, "Fault": 5, "EStop": 6,
}
SAFETY_STATE_NAMES = {v: k for k, v in SAFETY_STATE_CODES.items()}
UNKNOWN_SAFETY_STATE_CODE = 255
