# local_gateway/controller_sim

Two independent simulated robot controllers, each wrapping its own
`robot_bridge` session (see `robot_bridge_ctypes.py`), each exposing that
robot over a *different* industrial protocol -- standing in for "two
different vendor controllers" the way section 1.4/2.7's vendor-adapter
pattern is meant to handle:

- `opcua_server.py` -- OPC UA server (`opc.tcp://.../robot/`): read-only
  telemetry variables per joint + a `MoveJoints` method.
- `modbus_server.py` -- Modbus TCP server: telemetry as input registers,
  commands via a write-then-poll holding-register protocol (see
  `modbus_codec.py` for the exact register map and fixed-point encoding).

These are not part of the "Local Gateway Service" itself -- they play the
role of the thing the gateway connects *to*. See `../gateway_service/`.

## Run standalone

```bash
pip install -r ../gateway_service/requirements.txt --break-system-packages
python3 opcua_server.py --port 4840     # separate terminal
python3 modbus_server.py --port 5020    # separate terminal
```
