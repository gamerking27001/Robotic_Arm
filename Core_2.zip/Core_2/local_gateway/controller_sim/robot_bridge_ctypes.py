"""controller_sim/robot_bridge_ctypes.py

ctypes wrapper for the *stateful* half of robot_bridge (create/destroy/
tick/telemetry/move/e-stop) -- a third, independent binding to the same
native_bridge/librobot_bridge.so alongside digital_twin's and
motion_planner's (see either of those `_paths.py`-adjacent docstrings for
why each service keeps its own thin binding rather than sharing one: this
is the "service independence" convention this repo has used throughout).

This one is different in kind from the other two: digital_twin and
motion_planner only ever called *stateless* exports (FK, IK, trajectory
sampling). This module owns a `robot_bridge_create()` handle and drives it
with `robot_bridge_tick()` on a fixed-rate loop -- because here it plays
the role of *the robot controller itself* (see controller_sim/README.md):
opcua_server.py and modbus_server.py each wrap one instance of this class
and expose its live state over OPC UA / Modbus TCP, standing in for what a
real vendor controller's own industrial-protocol interface would do.
"""
from __future__ import annotations

import ctypes
import os
from dataclasses import dataclass

NUM_JOINTS = 6


class _JointTelemetryC(ctypes.Structure):
    _fields_ = [
        ("position_rad", ctypes.c_double),
        ("velocity_rad_s", ctypes.c_double),
        ("current_a", ctypes.c_double),
        ("torque_estimate_nm", ctypes.c_double),
        ("winding_temp_c", ctypes.c_double),
        ("sto_active", ctypes.c_int),
        ("fault", ctypes.c_int),
    ]


class _SafetyStatusC(ctypes.Structure):
    _fields_ = [
        ("state", ctypes.c_char * 16),
        ("estop_pressed", ctypes.c_int),
        ("sto_required", ctypes.c_int),
        ("collision_suspected", ctypes.c_int),
        ("overcurrent", ctypes.c_int),
        ("overtemperature", ctypes.c_int),
        ("soft_limit_violation", ctypes.c_int),
        ("hard_limit_violation", ctypes.c_int),
        ("any_fault", ctypes.c_int),
    ]


class _RobotSpecC(ctypes.Structure):
    _fields_ = [
        ("payload_nominal_kg", ctypes.c_double),
        ("payload_peak_kg", ctypes.c_double),
        ("reach_mm", ctypes.c_double),
        ("repeatability_mm", ctypes.c_double),
        ("pose_accuracy_mm", ctypes.c_double),
        ("max_tcp_speed_mps", ctypes.c_double),
        ("rated_power_w_peak", ctypes.c_double),
        ("bus_voltage_vdc", ctypes.c_double),
        ("weight_kg", ctypes.c_double),
        ("controller_weight_kg", ctypes.c_double),
        ("ambient_temp_min_c", ctypes.c_double),
        ("ambient_temp_max_c", ctypes.c_double),
        ("acoustic_noise_dba", ctypes.c_double),
    ]


@dataclass(frozen=True)
class JointTelemetry:
    position_deg: float
    velocity_deg_s: float
    current_a: float
    torque_estimate_nm: float
    winding_temp_c: float
    sto_active: bool
    fault: bool


@dataclass(frozen=True)
class SafetyStatus:
    state: str
    estop_pressed: bool
    any_fault: bool


class RobotBridgeUnavailable(RuntimeError):
    pass


def _default_library_path() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    # local_gateway/controller_sim/ -> ../../dashboard/backend/native_bridge
    repo_root = os.path.abspath(os.path.join(here, "..", ".."))
    return os.path.join(repo_root, "dashboard", "backend", "native_bridge", "librobot_bridge.so")


class SimulatedRobotController:
    """One robot_bridge session -- create() boots the safety FSM through
    PowerOn->Homing->Idle automatically (see robot_bridge.h), same as
    dashboard/backend's own session. Each instance is fully independent
    (its own simulated joints, its own safety FSM state), so
    opcua_server.py and modbus_server.py each running one of these are two
    entirely separate simulated robots, not two views onto one -- exactly
    modeling "two different physical robots, each behind its own vendor
    controller" rather than one robot double-exposed."""

    def __init__(self, library_path: str | None = None) -> None:
        path = library_path or _default_library_path()
        if not os.path.exists(path):
            raise RobotBridgeUnavailable(f"{path} not found. Build it with: (cd dashboard/backend && ./build.sh)")
        self._lib = ctypes.CDLL(path)
        self._configure_signatures()
        self._handle = self._lib.robot_bridge_create()

    def _configure_signatures(self) -> None:
        lib = self._lib
        lib.robot_bridge_create.restype = ctypes.c_void_p
        lib.robot_bridge_destroy.argtypes = [ctypes.c_void_p]
        lib.robot_bridge_tick.argtypes = [ctypes.c_void_p, ctypes.c_double]
        lib.robot_bridge_get_joint_telemetry.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(_JointTelemetryC)]
        lib.robot_bridge_get_joint_telemetry.restype = ctypes.c_int
        lib.robot_bridge_get_safety_status.argtypes = [ctypes.c_void_p, ctypes.POINTER(_SafetyStatusC)]
        lib.robot_bridge_is_move_active.argtypes = [ctypes.c_void_p]
        lib.robot_bridge_is_move_active.restype = ctypes.c_int
        lib.robot_bridge_begin_move.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_double), ctypes.c_int]
        lib.robot_bridge_begin_move.restype = ctypes.c_int
        lib.robot_bridge_trigger_estop.argtypes = [ctypes.c_void_p]
        lib.robot_bridge_reset_estop.argtypes = [ctypes.c_void_p]
        lib.robot_bridge_get_robot_spec.argtypes = [ctypes.POINTER(_RobotSpecC)]

    def tick(self, dt_s: float) -> None:
        self._lib.robot_bridge_tick(self._handle, dt_s)

    def joint_telemetry(self, joint_index: int) -> JointTelemetry:
        raw = _JointTelemetryC()
        ok = self._lib.robot_bridge_get_joint_telemetry(self._handle, joint_index, ctypes.byref(raw))
        if not ok:
            raise ValueError(f"invalid joint_index: {joint_index}")
        return JointTelemetry(
            position_deg=raw.position_rad * 180.0 / 3.141592653589793,
            velocity_deg_s=raw.velocity_rad_s * 180.0 / 3.141592653589793,
            current_a=raw.current_a,
            torque_estimate_nm=raw.torque_estimate_nm,
            winding_temp_c=raw.winding_temp_c,
            sto_active=bool(raw.sto_active),
            fault=bool(raw.fault),
        )

    def all_joint_telemetry(self) -> list[JointTelemetry]:
        return [self.joint_telemetry(i) for i in range(NUM_JOINTS)]

    def safety_status(self) -> SafetyStatus:
        raw = _SafetyStatusC()
        self._lib.robot_bridge_get_safety_status(self._handle, ctypes.byref(raw))
        return SafetyStatus(state=raw.state.decode("ascii"), estop_pressed=bool(raw.estop_pressed), any_fault=bool(raw.any_fault))

    def is_move_active(self) -> bool:
        return bool(self._lib.robot_bridge_is_move_active(self._handle))

    def begin_move(self, target_deg: list[float], use_s_curve: bool) -> bool:
        if len(target_deg) != NUM_JOINTS:
            raise ValueError(f"expected {NUM_JOINTS} target angles, got {len(target_deg)}")
        arr = (ctypes.c_double * NUM_JOINTS)(*target_deg)
        return bool(self._lib.robot_bridge_begin_move(self._handle, arr, 1 if use_s_curve else 0))

    def ambient_temp_max_c(self) -> float:
        raw = _RobotSpecC()
        self._lib.robot_bridge_get_robot_spec(ctypes.byref(raw))
        return raw.ambient_temp_max_c

    def close(self) -> None:
        if self._handle:
            self._lib.robot_bridge_destroy(self._handle)
            self._handle = None

    def __enter__(self) -> "SimulatedRobotController":
        return self

    def __exit__(self, *exc) -> None:
        self.close()
