"""controller_sim/opcua_server.py

Stands in for a real robot controller's OPC UA interface -- platform spec
section 1.4: "OPC UA and Modbus TCP for PLC/controller-level data
exchange", section 2.4's decision table: "OPC UA -- Purpose-built
industrial standard ... Primary protocol for PLC/robot-controller data
exchange where supported."

Runs one SimulatedRobotController (its own robot_bridge session -- an
independent simulated robot) and exposes it as an OPC UA server: read-only
telemetry variables under an Objects/Robot node, plus a MoveJoints method.
The Local Gateway Service (local_gateway/gateway_service) connects to this
as an OPC UA *client* -- see gateway/adapters.py's OpcUaRobotAdapter, the
vendor-adapter pattern section 1.4/2.7 describe.

Run standalone:
    python3 opcua_server.py --port 4840
"""
from __future__ import annotations

import asyncio
import logging

from asyncua import Server, ua
from asyncua.common.methods import uamethod

from robot_bridge_ctypes import SimulatedRobotController

logger = logging.getLogger("controller_sim.opcua_server")

TICK_HZ = 200.0
TICK_DT = 1.0 / TICK_HZ
PUBLISH_HZ = 20.0  # OPC UA node update rate -- coarser than the internal simulation tick, representative of a real controller's cyclic-data-exchange rate.


class OpcUaControllerServer:
    def __init__(self, endpoint: str = "opc.tcp://0.0.0.0:4840/robot/", library_path: str | None = None) -> None:
        self.endpoint = endpoint
        self.controller = SimulatedRobotController(library_path)
        self._server: Server | None = None
        self._joint_nodes: list[dict] = []
        self._safety_state_node = None
        self._any_fault_node = None
        self._running = False

    async def start(self) -> None:
        self._server = Server()
        await self._server.init()
        self._server.set_endpoint(self.endpoint)
        uri = "http://robotic-arm-core/opcua/"
        idx = await self._server.register_namespace(uri)

        objects = self._server.get_objects_node()
        robot_obj = await objects.add_object(idx, "Robot")

        for i in range(6):
            joint_obj = await robot_obj.add_object(idx, f"J{i + 1}")
            position = await joint_obj.add_variable(idx, "PositionDeg", 0.0)
            velocity = await joint_obj.add_variable(idx, "VelocityDegS", 0.0)
            current = await joint_obj.add_variable(idx, "CurrentA", 0.0)
            temperature = await joint_obj.add_variable(idx, "TemperatureC", 0.0)
            fault = await joint_obj.add_variable(idx, "Fault", False)
            self._joint_nodes.append(
                {"position": position, "velocity": velocity, "current": current, "temperature": temperature, "fault": fault}
            )

        self._safety_state_node = await robot_obj.add_variable(idx, "SafetyState", "PowerOn")
        self._any_fault_node = await robot_obj.add_variable(idx, "AnyFault", False)

        @uamethod
        def move_joints(parent, j1: float, j2: float, j3: float, j4: float, j5: float, j6: float, use_s_curve: bool) -> bool:
            return self.controller.begin_move([j1, j2, j3, j4, j5, j6], bool(use_s_curve))

        await robot_obj.add_method(
            idx,
            "MoveJoints",
            move_joints,
            [ua.VariantType.Double] * 6 + [ua.VariantType.Boolean],  # 6 target angles (deg) + use_s_curve
            [ua.VariantType.Boolean],
        )

        await self._server.start()
        logger.info("OPC UA controller server started at %s", self.endpoint)
        self._running = True
        asyncio.create_task(self._tick_loop())
        asyncio.create_task(self._publish_loop())

    async def _tick_loop(self) -> None:
        while self._running:
            self.controller.tick(TICK_DT)
            await asyncio.sleep(TICK_DT)

    async def _publish_loop(self) -> None:
        period = 1.0 / PUBLISH_HZ
        while self._running:
            for i, nodes in enumerate(self._joint_nodes):
                t = self.controller.joint_telemetry(i)
                await nodes["position"].write_value(t.position_deg)
                await nodes["velocity"].write_value(t.velocity_deg_s)
                await nodes["current"].write_value(t.current_a)
                await nodes["temperature"].write_value(t.winding_temp_c)
                await nodes["fault"].write_value(t.fault)
            safety = self.controller.safety_status()
            await self._safety_state_node.write_value(safety.state)
            await self._any_fault_node.write_value(safety.any_fault)
            await asyncio.sleep(period)

    async def stop(self) -> None:
        self._running = False
        if self._server is not None:
            await self._server.stop()
        self.controller.close()


async def _main() -> None:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=4840)
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)

    server = OpcUaControllerServer(endpoint=f"opc.tcp://0.0.0.0:{args.port}/robot/")
    await server.start()
    try:
        while True:
            await asyncio.sleep(3600)
    finally:
        await server.stop()


if __name__ == "__main__":
    asyncio.run(_main())
