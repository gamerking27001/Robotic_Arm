# Local Gateway (platform spec sections 1-4)

Implements the "Local Gateway Service" core module from *Industrial
Robotics Operating Platform for MSMEs* -- section 1.2's module table
("Translates robot-native protocols to the platform's internal
telemetry/command bus"), section 1.4's protocol decisions (OPC UA + Modbus
TCP, vendor-adapter pattern), section 1.5 (MQTT to the cloud), and section
4 (live monitoring, the health-score composite, the buffer-then-sync data
flow).

```
local_gateway/
  controller_sim/       Two simulated robot controllers -- what the
                         gateway connects TO. Not the gateway itself.
    robot_bridge_ctypes.py   Stateful ctypes binding (create/tick/telemetry/move)
    opcua_server.py          OPC UA server -- "controller brand A"
    modbus_server.py         Modbus TCP server -- "controller brand B"
    modbus_codec.py          Shared fixed-point register encoding

  gateway_service/       The actual Local Gateway Service.
    gateway/
      adapters.py         RobotAdapter interface + OPC UA / Modbus implementations
      health_score.py     Section 4.2's composite health score
      local_buffer.py      Section 1.6's local time-series buffer (SQLite)
      mqtt_publisher.py    Section 1.5's batched cloud sync (real MQTT/mosquitto)
      service.py           Orchestrates all of the above
    api.py                FastAPI: telemetry, moves, /ws/telemetry, buffer status
    tests/                48 tests
```

## What this is (and isn't)

Built to sections 1-4's spec, with **real protocol implementations, not
mocks**:
- §1.4/§2.4/§2.7: a genuine OPC UA server + client (asyncua) and a genuine
  Modbus TCP server + client (pymodbus) -- two different simulated
  "controller brands" behind one `RobotAdapter` interface, the literal
  vendor-adapter pattern the spec describes.
- §1.5: real MQTT (mosquitto, installed and used by the test suite),
  batched telemetry publish to `robots/{robot_id}/telemetry`.
- §1.6: a real local SQLite buffer -- telemetry writes never depend on
  cloud reachability; a sync loop drains it once MQTT is confirmed
  delivered, demonstrating actual offline resilience, not just describing
  it.
- §4.1-4.3: per-joint telemetry (position, velocity, current, temperature,
  fault), the composite 0-100 health score (temperature margin, current
  deviation, an encoder-error proxy, connectivity stability), and the full
  data-flow diagram end to end: controller -> gateway (poll, normalize,
  buffer) -> live WebSocket push + batched MQTT sync.

Explicitly **not** built here:
- **EtherCAT/CAN** -- section 2.4 lists these as optional lower-layer
  protocols "used only where the robot controller exposes it"; only OPC UA
  and Modbus TCP (the two primary protocols per that same section) are
  implemented.
- **A real robot controller** -- `controller_sim/` exists specifically
  because this codebase has no real OPC UA/Modbus-speaking hardware
  controller; it wraps the same `robot_bridge` the rest of this repo uses,
  standing in for "what a vendor controller's protocol interface would
  expose."
- **TimescaleDB / a managed cloud time-series store** on the receiving
  end -- MQTT messages are published and independently verified received
  (the test suite subscribes and checks the payload), but there's no
  broker-side consumer writing them into `cloud_platform`'s `telemetry`
  table in this deliverable; that integration (MQTT consumer ->
  `POST /v1/robots/{id}/telemetry`) is a natural next piece, not yet built.
- **gRPC command dispatch** -- section 1.5 mentions gRPC for
  latency-sensitive cloud-initiated commands; `/api/moves` here is a plain
  REST endpoint, matching every other service in this repo's convention
  rather than introducing gRPC for one endpoint.
- **Encoder error telemetry** -- the health score's "encoder error rate"
  component is approximated from the joint `fault` flag (0% or 100%, no
  real per-joint encoder fault-rate signal exists in `robot_bridge`'s
  telemetry) -- see `health_score.py`'s module docstring for exactly which
  approximations were made and why, spelled out at the point they matter,
  not just here.

## How the pieces connect

```
controller_sim/opcua_server.py   <--OPC UA-->   gateway/adapters.py::OpcUaRobotAdapter   \
controller_sim/modbus_server.py  <--Modbus TCP--> gateway/adapters.py::ModbusRobotAdapter  >--> gateway/service.py
  (each wraps its own                                                                      /         |
   robot_bridge session --                                                                           |  normalize, buffer, score
   see robot_bridge_ctypes.py)                                                                        v
                                                                                          local_buffer.py (SQLite)
                                                                                                        |
                                                                                    +-------------------+-------------------+
                                                                                    v                                       v
                                                                          /ws/telemetry (live push)          mqtt_publisher.py -> mosquitto
                                                                                                                    (robots/{id}/telemetry)
```

## Running it end to end

```bash
# 1. Build the native bridge (shared with dashboard/backend, digital_twin, motion_planner)
cd robotic_arm_core/dashboard/backend && ./build.sh && cd -

# 2. A real MQTT broker (mosquitto)
sudo apt-get install mosquitto        # or your platform's equivalent
sudo service mosquitto start

# 3. A simulated controller (pick one)
cd robotic_arm_core/local_gateway/controller_sim
pip install -r ../gateway_service/requirements.txt --break-system-packages
python3 opcua_server.py --port 4840        # OPC UA, OR:
python3 modbus_server.py --port 5020       # Modbus TCP

# 4. The gateway itself
cd robotic_arm_core/local_gateway/gateway_service
export LOCAL_GATEWAY_VIEWER_API_KEY=change-me-viewer
export LOCAL_GATEWAY_OPERATOR_API_KEY=change-me-operator
export LOCAL_GATEWAY_PROTOCOL=opcua                              # match step 3
export LOCAL_GATEWAY_OPCUA_ENDPOINT=opc.tcp://localhost:4840/robot/
export LOCAL_GATEWAY_MQTT_HOST=localhost
uvicorn api:app --port 8400
python3 -m pytest tests/ -q   # 48 tests, separate terminal

# 5. Try it
curl localhost:8400/api/telemetry -H 'X-API-Key: change-me-viewer'
curl -X POST localhost:8400/api/moves -H 'X-API-Key: change-me-operator' \
  -H 'Content-Type: application/json' -d '{"target_deg": [20,0,0,0,0,0]}'
mosquitto_sub -t 'robots/robot-1/telemetry'   # watch batched telemetry arrive
```

## What's actually verified

- **Real OPC UA end to end**: a real asyncua server, a real client
  connecting over a real socket, reading live telemetry and calling a
  `MoveJoints` method that actually moves the simulated arm -- confirmed
  by re-reading telemetry afterward and seeing the commanded angle.
- **Real Modbus TCP end to end**: same, via input/holding registers and a
  write-then-poll command protocol (Modbus has no native RPC concept, see
  `modbus_server.py`'s docstring for why that protocol looks the way it
  does).
- **Real MQTT end to end**: telemetry batches published to a real
  mosquitto broker, independently confirmed by subscribing with
  `mosquitto_sub` and parsing the payload during manual verification, and
  by the automated test suite (which starts a real broker connection, not
  a mock).
- **Real offline-resilience demonstration**: the buffer accumulates
  samples regardless of whether MQTT sync is happening; the test suite
  proves nothing is lost across a simulated outage
  (`test_local_buffer.py::test_buffer_survives_and_forwards_after_simulated_outage`).
- **48/48 automated tests pass** -- health-score logic (8), the Modbus
  fixed-point codec (11), the local buffer (6), both adapters against both
  real protocol servers (9), the service orchestration layer (5), and the
  full FastAPI app against a real running server (9), plus healthz/misc.
- A real end-to-end manual run (documented in the development history,
  reproducible via the "Running it end to end" steps above): telemetry
  read, health score computed (95.0 for a healthy idle robot), a move
  command executed and confirmed, the buffer growing and then draining
  after MQTT sync, and the published MQTT batch independently verified via
  a separate `mosquitto_sub` subscriber.
